# 体積光（3D）GPU 保真沙箱 — VolumetricLight3D Sandbox（v3.06 配套）

这是一个**纯 Python 复刻的 AviUtl ExEdit2 脚本宿主 + GPU 着色器模拟器**：内置 LuaJIT 2.1
运行时（lupa）、`.obj2` 脚本解析器、AviUtl2 宿主 API 模拟（`obj.load` / `obj.getvalue` /
`obj.pixelshader` / `obj.drawpoly` / `cache:*` 缓冲区等）、VL3DBridge 桥接模拟宿主，以及把
HLSL 像素着色器编译为 SPIR-V 并跑在真实 GPU（Vulkan, wgpu）上的软光栅化层。

它让我们能在**没有 AviUtl2、不装任何插件**的机器上自动渲染和回归测试
`体積光（3D）.obj2`（也适用于其它 `.obj2` 脚本的调试）。本沙箱在 v2.90 ～ v3.06
的全部版本验证中实测使用。

> ⚠️ 本沙箱**不是** AviUtl2 本体，也不包含 ＫＥＮくん 官方的任何文件；最终效果请以实机为准。

## 📁 目录结构

```
VolumetricLight3D-Sandbox/
├── run_v306_checks.py        # ★ 便携自检入口（开箱即用，纯相对路径）
├── aviutl2_sandbox.py        # 核心引擎：Lua 宿主 API 模拟 + wgpu 着色器执行
├── sandbox_v2_fidelity.py    # 保真测试框架：PersistentAviUtl2Session / FidelityLayer / Bridge 模拟
├── generate_assets.py        # 测试素材生成（彩色玻璃窗 / 石膏像 / 鸟笼 OBJ / 角色 GLB）
├── spv_cache/                # 预编译 SPIR-V 着色器缓存（78 个文件，无需安装 glslang）
├── Script/体積光（3D）.obj2 # 自检默认被测脚本（v3.06）
├── lib_linux/                # 可选的 Linux 原生桥（.so，Windows 自动跳过）
├── archive/                  # v2.90～v3.06 全部历史验证脚本（原样存档，含绝对路径）
├── requirements.txt
├── install_windows.bat       # Windows 一键装依赖
└── make_offline_bundle.bat   # 可选：下载离线 wheel 包
```

## 🔧 环境要求

- **Python 3.11 – 3.13（64 位）** — Windows / macOS / Linux 均可
- GPU 支持 **Vulkan**（近十年的独显 / 核显基本都支持；无 Vulkan 时会初始化失败）
- 磁盘 ~10MB + 输出图空间

## 🚀 快速开始

```bat
:: Windows：双击 install_windows.bat 装依赖，然后：
python run_v306_checks.py
```

```bash
# macOS / Linux：
python3 -m pip install -r requirements.txt
python3 run_v306_checks.py
```

预期输出（节选）：

```
[1] Verse1 sub-scene, m1 manual L4 (frame_s=619, frame=146, scene_id=1)
    HUD : @info 体積光（3D）v3.06 GPU=true 光源=レイヤー2(512x512) 遮蔽=L4(m1) ...
[2] ... shadow bbox fill = 0.7xx  (bust-shaped ~0.6-0.8; solid rect > 0.9)
[3] ... fallback fired: True | L4* marker: True | vs healthy maxdiff: 0
[4] ... init-complete under os/io=nil: True
RESULT: ALL CHECKS PASSED ^_^
```

渲染结果与素材会输出到 `outputs/`。测试其它版本：`python run_v306_checks.py --script 路径.obj2`。
分辨率：`--width 1280 --height 720`。

## 🧪 自检项含义

| # | 测试 | 验证内容 |
|---|---|---|
| 1 | Verse1 m1 手动指定图层 | 非零起始帧（`frame_s=619`）＋子合成（`scene_id=1`）下遮挡命中（v3.05 修复项） |
| 2 | 遮蔽关闭参照 + 阴影统计 | 阴影形状为石膏像剪影而非实心矩形（填充率应 ~0.6-0.8） |
| 3 | fx 加载异常模拟 | 「带效果加载返回不透明矩形」时自动回退原始加载并标记 `L4*`（v3.06 剪影审计修复项） |
| 4 | 受限宿主 | `_G.os=nil` / `_G.io=nil`（官方脚本沙箱策略）下正常初始化 |

## 🔍 工作原理（简述）

1. `parse_obj2_script()` 解析 `.obj2` 的参数定义、Lua 主体与 `--[[pixelshader@...]]` HLSL 块；
2. HLSL 经 **glslangValidator** 编译为 SPIR-V（结果缓存在 `spv_cache/`，按 `名称+源码哈希` 命中）；
3. LuaJIT 2.1 执行脚本主体，宿主 API 由 Python 模拟（含 `obj.load("layer", n, effect)` 的
   fx/raw 双模式与子对象重入）；
4. `obj.pixelshader` / `obj.drawpoly` 由 wgpu 在真实 GPU 上渲染到 `cache:*` / `framebuffer`；
5. 渲染结果可逐像素回读，用于版本间回归对比（`max_rgba_diff`）。

> 📌 `spv_cache/` 已包含当前全部着色器，**无需安装 glslang**。
> 只有当你修改/新增了 HLSL 着色器时才需要 [Vulkan SDK](https://vulkan.lunarg.com/) 里的
> `glslangValidator`（沙盒会自动调用并更新缓存）。

## 🐧 Linux 专属（可选）

`lib_linux/` 内的 `.so` 是 Linux 下编译的 VL3DBridge 原生桥测试库（`libvl3d_bridge_linux.so`）
与宿主锁审计库：放在包内时，Linux 上 `PersistentAviUtl2Session` 会自动加载用于原生路径计时/
网格测试；**Windows / macOS 上自动跳过，不影响任何功能**。源码见主仓库 `src/VL3DBridge/`。

## 🗄️ 历史脚本（archive/）

`archive/fresh_eval/` 与 `archive/legacy_root/` 保存了 v2.90 ～ v3.06 期间的全部验证脚本
（各版本回归、极限压力、基准、汇总图生成等），原样存档。它们引用了开发工作区的绝对路径与
历史版本文件树，**不在本包中保证直接可运行**——详见 `archive/NOTE.md`。

## 📄 许可与致谢

MIT License（与主仓库一致）。核心引擎与测试框架由 **南宫若馨Cylna** 与 **Arena.ai Agent**
为 [VolumetricLight3D](https://github.com/CylnaNangong) 项目开发；测试素材（彩色玻璃窗 /
石膏像 / 鸟笼 / 角色 GLB）由脚本程序化生成，可自由使用。AviUtl ExEdit2 是 ＫＥＮくん氏
的软件，与本沙箱相互独立。
