#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Generates deterministic 2D & 3D test assets for AviUtl2 (.obj2) Sandbox Testing:
  1. stained_glass.png   (512x512 Gothic rose window with colorful glass & dark lead mullions)
  2. plaster_bust_2d.png (512x512 crisp 8x-AA white plaster bust 2D cutout for contour tests)
  3. birdcage.obj        (Wavefront OBJ 3D ornate wire birdcage testing wire-splat shmap + OBJ camocc)
  4. character.glb       (glTF 2.0 binary 3D humanoid figure testing pure-Lua GLB/VRM loader + VRM holdout)
"""

import json
import math
import pathlib
import struct
from typing import List, Tuple

import numpy as np
from PIL import Image, ImageDraw


ASSET_DIR = pathlib.Path(__file__).resolve().parent / "assets"
ASSET_DIR.mkdir(parents=True, exist_ok=True)


def make_stained_glass_png(path: pathlib.Path, size: int = 512) -> np.ndarray:
    S = size * 2  # 2x supersampling
    im = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    dr = ImageDraw.Draw(im)
    cx, cy = S // 2, S // 2
    R_outer = int(S * 0.46)
    R_mid = int(S * 0.28)
    R_inner = int(S * 0.12)

    # Outer dark stone/iron frame (alpha=255 dark frame, outside circular frame alpha=0)
    dr.ellipse([cx - R_outer - 14, cy - R_outer - 14, cx + R_outer + 14, cy + R_outer + 14], fill=(12, 12, 18, 255))

    palette_outer = [
        (255, 65, 110), (55, 175, 255), (255, 195, 45), (160, 75, 255),
        (50, 235, 165), (255, 105, 45), (90, 125, 255), (255, 70, 195),
        (255, 225, 75), (45, 215, 235), (235, 75, 75), (130, 235, 85),
    ]
    for k in range(12):
        a0 = k * 30 + 3.2
        a1 = (k + 1) * 30 - 3.2
        c = palette_outer[k % len(palette_outer)]
        dr.pieslice([cx - R_outer, cy - R_outer, cx + R_outer, cy + R_outer], a0, a1, fill=(*c, 255))

    # Middle iron ring
    dr.ellipse([cx - R_mid - 8, cy - R_mid - 8, cx + R_mid + 8, cy + R_mid + 8], fill=(14, 14, 20, 255))
    palette_mid = [(255, 140, 220), (110, 220, 255), (255, 230, 120), (180, 130, 255), (110, 255, 195), (255, 165, 95)]
    for k in range(12):
        a0 = k * 30 + 4.0
        a1 = (k + 1) * 30 - 4.0
        c = palette_mid[k % len(palette_mid)]
        dr.pieslice([cx - R_mid, cy - R_mid, cx + R_mid, cy + R_mid], a0, a1, fill=(*c, 255))

    # Center golden rose core
    dr.ellipse([cx - R_inner - 8, cy - R_inner - 8, cx + R_inner + 8, cy + R_inner + 8], fill=(14, 14, 20, 255))
    dr.ellipse([cx - R_inner, cy - R_inner, cx + R_inner, cy + R_inner], fill=(255, 244, 195, 255))

    im_ds = im.resize((size, size), Image.Resampling.BOX)
    im_ds.save(path)
    arr = np.asarray(im_ds, dtype=np.float32)
    a = arr[..., 3:4] / 255.0
    arr[..., :3] = np.round(arr[..., :3] * a)
    return arr.astype(np.uint8)


def make_plaster_bust_png(path: pathlib.Path, size: int = 512) -> np.ndarray:
    """Crisp 8x supersampled classical white plaster bust silhouette for 2D contour dark-moat vs leak testing."""
    S = size * 8
    mask = Image.new("L", (S, S), 0)
    dr = ImageDraw.Draw(mask)
    cx = S * 0.5
    # Head oval
    dr.ellipse([cx - S * 0.135, S * 0.14, cx + S * 0.135, S * 0.44], fill=255)
    # Classical hair curls
    for ang in np.linspace(-2.4, 0.7, 9):
        hx = cx + math.cos(ang) * S * 0.13
        hy = S * 0.27 + math.sin(ang) * S * 0.13
        r_c = S * 0.042
        dr.ellipse([hx - r_c, hy - r_c, hx + r_c, hy + r_c], fill=255)
    # Neck
    dr.polygon([
        (cx - S * 0.068, S * 0.41),
        (cx + S * 0.068, S * 0.41),
        (cx + S * 0.082, S * 0.55),
        (cx - S * 0.082, S * 0.55),
    ], fill=255)
    # Shoulders & chest pedestal
    dr.ellipse([cx - S * 0.30, S * 0.50, cx + S * 0.30, S * 0.80], fill=255)
    dr.rectangle([cx - S * 0.22, S * 0.65, cx + S * 0.22, S * 0.86], fill=255)
    dr.rectangle([cx - S * 0.16, S * 0.86, cx + S * 0.16, S * 0.94], fill=255)

    cov = np.asarray(mask.resize((size, size), Image.Resampling.BOX), dtype=np.float32) / 255.0
    yy, xx = np.mgrid[0:size, 0:size].astype(np.float32)
    nx = (xx - size * 0.5) / (size * 0.30)
    ny = (yy - size * 0.48) / (size * 0.40)
    # Subtle classical plaster shading (bright warm-white 215..248)
    shade = np.clip(0.93 - 0.10 * nx - 0.06 * ny, 0.80, 0.98)

    straight = np.zeros((size, size, 4), dtype=np.uint8)
    straight[..., 0] = np.round(shade * 250.0).astype(np.uint8)
    straight[..., 1] = np.round(shade * 248.0).astype(np.uint8)
    straight[..., 2] = np.round(shade * 244.0).astype(np.uint8)
    straight[..., 3] = np.round(cov * 255.0).astype(np.uint8)
    Image.fromarray(straight).save(path)

    prem = straight.astype(np.float32)
    prem[..., :3] = np.round(prem[..., :3] * cov[..., None])
    return prem.astype(np.uint8)


def _add_cylinder(verts: List[Tuple[float, float, float]], tris: List[Tuple[int, int, int]],
                  p0, p1, radius: float, segs: int = 6):
    p0 = np.asarray(p0, dtype=np.float64)
    p1 = np.asarray(p1, dtype=np.float64)
    axis = p1 - p0
    L = float(np.linalg.norm(axis))
    if L < 1e-6:
        return
    u = axis / L
    ref = np.array([0.0, 0.0, 1.0]) if abs(u[2]) < 0.9 else np.array([1.0, 0.0, 0.0])
    e1 = np.cross(u, ref)
    e1 /= np.linalg.norm(e1)
    e2 = np.cross(u, e1)

    base_idx = len(verts)
    for end_p in (p0, p1):
        for k in range(segs):
            ang = 2.0 * math.pi * k / segs
            pt = end_p + radius * (math.cos(ang) * e1 + math.sin(ang) * e2)
            verts.append((float(pt[0]), float(pt[1]), float(pt[2])))
    for k in range(segs):
        kn = (k + 1) % segs
        i0, i1 = base_idx + k, base_idx + kn
        j0, j1 = base_idx + segs + k, base_idx + segs + kn
        tris.append((i0, i1, j1))
        tris.append((i0, j1, j0))


def _add_ring(verts, tris, y_val: float, R: float, tube_r: float, n_seg: int = 24, side_seg: int = 5):
    pts = []
    for k in range(n_seg):
        ang = 2.0 * math.pi * k / n_seg
        pts.append((R * math.cos(ang), y_val, R * math.sin(ang)))
    for k in range(n_seg):
        _add_cylinder(verts, tris, pts[k], pts[(k + 1) % n_seg], tube_r, segs=side_seg)


def _add_uv_sphere(verts, tris, center, rx: float, ry: float, rz: float, n_lat: int = 10, n_lon: int = 16):
    cx, cy, cz = center
    base = len(verts)
    for i in range(n_lat + 1):
        th = math.pi * i / n_lat
        sth, cth = math.sin(th), math.cos(th)
        for j in range(n_lon):
            ph = 2.0 * math.pi * j / n_lon
            verts.append((
                cx + rx * sth * math.cos(ph),
                cy + ry * cth,
                cz + rz * sth * math.sin(ph),
            ))
    for i in range(n_lat):
        for j in range(n_lon):
            jn = (j + 1) % n_lon
            a = base + i * n_lon + j
            b = base + i * n_lon + jn
            c = base + (i + 1) * n_lon + jn
            d = base + (i + 1) * n_lon + j
            tris.append((a, b, c))
            tris.append((a, c, d))


def make_birdcage_obj(path: pathlib.Path) -> Tuple[np.ndarray, np.ndarray]:
    """
    Ornate 3D Birdcage in Wavefront .obj meter units (+Y up).
    AviUtl2 & load_wavefront_obj_mesh(adj=0) convert (nx, ny, nz) -> (100*nx, -100*ny, 100*nz) world pixels!
    """
    verts: List[Tuple[float, float, float]] = []
    tris: List[Tuple[int, int, int]] = []

    R = 0.92        # 92 world pixels radius
    y_bot = -1.05   # +105 world pixels (down)
    y_mid = 0.30    # -30 world pixels (up)
    y_top = 1.25    # -125 world pixels (dome peak)

    # Base solid rim & mid/top rings
    _add_ring(verts, tris, y_bot, R, 0.065, n_seg=24)
    _add_ring(verts, tris, y_bot + 0.14, R, 0.050, n_seg=24)
    _add_ring(verts, tris, (y_bot + y_mid) * 0.5, R, 0.026, n_seg=24)
    _add_ring(verts, tris, y_mid, R, 0.050, n_seg=24)

    # 16 thin vertical wire bars + dome ribs converging to top finial
    n_bars = 16
    for k in range(n_bars):
        ang = 2.0 * math.pi * k / n_bars
        xb, zb = R * math.cos(ang), R * math.sin(ang)
        _add_cylinder(verts, tris, (xb, y_bot, zb), (xb, y_mid, zb), 0.020, segs=5)
        n_arc = 5
        prev = (xb, y_mid, zb)
        for s in range(1, n_arc + 1):
            t = s / n_arc
            th = t * (math.pi * 0.5)
            r_cur = R * math.cos(th)
            y_cur = y_mid + (y_top - y_mid) * math.sin(th)
            cur = (r_cur * math.cos(ang), y_cur, r_cur * math.sin(ang))
            _add_cylinder(verts, tris, prev, cur, 0.019, segs=5)
            prev = cur

    # Top hook finial & inner perch
    _add_uv_sphere(verts, tris, (0.0, y_top + 0.10, 0.0), 0.11, 0.11, 0.11, 6, 10)
    _add_cylinder(verts, tris, (-R * 0.72, -0.25, 0.0), (R * 0.72, -0.25, 0.0), 0.035, segs=6)

    lines = ["# Ornate 3D Birdcage for Volumetric Light 3D Sandbox"]
    for vx, vy, vz in verts:
        lines.append(f"v {vx:.5f} {vy:.5f} {vz:.5f}")
    for i0, i1, i2 in tris:
        lines.append(f"f {i0 + 1} {i1 + 1} {i2 + 1}")
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")

    avi_verts = np.array(verts, dtype=np.float64) * np.array([100.0, -100.0, 100.0])
    return avi_verts, np.array(tris, dtype=np.int32)


def make_character_glb(path: pathlib.Path) -> Tuple[np.ndarray, np.ndarray]:
    """
    Writes a valid glTF 2.0 binary (.glb) humanoid character in standard glTF meters (~1.62m tall, +Y up!),
    because load_vrm_glb_mesh in 体積光（3D）.obj2 converts glTF meters (+Y up) to AviUtl2 world pixels (+Y down)!
    Also returns AviUtl2-space (verts_avi, tris) for matching hardware Z-buffer rendering!
    """
    verts_gltf: List[Tuple[float, float, float]] = []
    tris: List[Tuple[int, int, int]] = []

    # Build character in glTF meters (+Y up, feet at y=0, head top at y=1.62m)
    # Head + twin hair buns
    _add_uv_sphere(verts_gltf, tris, (0.0, 1.46, 0.0), 0.115, 0.13, 0.115, 10, 16)
    _add_uv_sphere(verts_gltf, tris, (-0.13, 1.53, -0.02), 0.055, 0.055, 0.055, 7, 10)
    _add_uv_sphere(verts_gltf, tris, ( 0.13, 1.53, -0.02), 0.055, 0.055, 0.055, 7, 10)
    # Neck & Torso
    _add_cylinder(verts_gltf, tris, (0.0, 1.28, 0.0), (0.0, 1.36, 0.0), 0.042, segs=8)
    _add_uv_sphere(verts_gltf, tris, (0.0, 1.10, 0.0), 0.135, 0.20, 0.095, 10, 16)
    # Flared skirt (cone-like frustum)
    n_sk = 18
    b_idx = len(verts_gltf)
    for k in range(n_sk):
        ang = 2.0 * math.pi * k / n_sk
        verts_gltf.append((0.11 * math.cos(ang), 0.94, 0.09 * math.sin(ang)))
    for k in range(n_sk):
        ang = 2.0 * math.pi * k / n_sk
        verts_gltf.append((0.28 * math.cos(ang), 0.48, 0.24 * math.sin(ang)))
    for k in range(n_sk):
        kn = (k + 1) % n_sk
        i0, i1 = b_idx + k, b_idx + kn
        j0, j1 = b_idx + n_sk + k, b_idx + n_sk + kn
        tris.append((i0, i1, j1))
        tris.append((i0, j1, j0))
    # Raised arms (casting dramatic volumetric shadow shafts!)
    _add_cylinder(verts_gltf, tris, (-0.12, 1.23, 0.0), (-0.34, 1.44, 0.06), 0.038, segs=8)
    _add_cylinder(verts_gltf, tris, ( 0.12, 1.23, 0.0), ( 0.34, 1.38, 0.06), 0.038, segs=8)
    # Legs
    _add_cylinder(verts_gltf, tris, (-0.075, 0.50, 0.0), (-0.085, 0.0, 0.0), 0.046, segs=8)
    _add_cylinder(verts_gltf, tris, ( 0.075, 0.50, 0.0), ( 0.085, 0.0, 0.0), 0.046, segs=8)

    v_np = np.array(verts_gltf, dtype=np.float32)
    i_np = np.array(tris, dtype=np.uint16).reshape(-1)

    v_bytes = v_np.tobytes()
    i_bytes = i_np.tobytes()
    while len(i_bytes) % 4 != 0:
        i_bytes += b"\x00"
    bin_blob = v_bytes + i_bytes
    while len(bin_blob) % 4 != 0:
        bin_blob += b"\x00"

    vmin = v_np.min(axis=0).tolist()
    vmax = v_np.max(axis=0).tolist()

    gltf_dict = {
        "asset": {"version": "2.0", "generator": "AviUtl2Sandbox"},
        "scene": 0,
        "scenes": [{"nodes": [0]}],
        "nodes": [{"mesh": 0, "name": "CharacterRoot"}],
        "meshes": [{
            "name": "CharacterMesh",
            "primitives": [{"attributes": {"POSITION": 0}, "indices": 1, "mode": 4}],
        }],
        "buffers": [{"byteLength": len(bin_blob)}],
        "bufferViews": [
            {"buffer": 0, "byteOffset": 0, "byteLength": len(v_bytes), "target": 34962},
            {"buffer": 0, "byteOffset": len(v_bytes), "byteLength": i_np.nbytes, "target": 34963},
        ],
        "accessors": [
            {
                "bufferView": 0, "byteOffset": 0, "componentType": 5126,
                "count": int(v_np.shape[0]), "type": "VEC3",
                "min": vmin, "max": vmax,
            },
            {
                "bufferView": 1, "byteOffset": 0, "componentType": 5123,
                "count": int(i_np.shape[0]), "type": "SCALAR",
            },
        ],
        "extensionsUsed": ["VRMC_vrm"],
        "extensions": {"VRMC_vrm": {"specVersion": "1.0"}},
    }
    json_bytes = json.dumps(gltf_dict, separators=(",", ":")).encode("utf-8")
    while len(json_bytes) % 4 != 0:
        json_bytes += b" "

    total_len = 12 + 8 + len(json_bytes) + 8 + len(bin_blob)
    header = struct.pack("<III", 0x46546C67, 2, total_len)
    chunk_json = struct.pack("<II", len(json_bytes), 0x4E4F534A) + json_bytes
    chunk_bin = struct.pack("<II", len(bin_blob), 0x004E4942) + bin_blob
    path.write_bytes(header + chunk_json + chunk_bin)

    avi_verts = v_np.astype(np.float64) * np.array([100.0, -100.0, -100.0])
    return avi_verts, np.array(tris, dtype=np.int32)


if __name__ == "__main__":
    sg = make_stained_glass_png(ASSET_DIR / "stained_glass.png", 512)
    pb = make_plaster_bust_png(ASSET_DIR / "plaster_bust_2d.png", 512)
    cv, ct = make_birdcage_obj(ASSET_DIR / "birdcage.obj")
    gv, gt = make_character_glb(ASSET_DIR / "character.glb")
    print(f"Generated stained_glass.png: {sg.shape}")
    print(f"Generated plaster_bust_2d.png: {pb.shape}")
    print(f"Generated birdcage.obj: {cv.shape[0]} verts, {ct.shape[0]} tris")
    print(f"Generated character.glb: {gv.shape[0]} verts, {gt.shape[0]} tris")
