@echo off
rem ============================================================
rem  OPTIONAL: download all dependency wheels into .\wheels
rem  for offline installation (e.g. on another Windows PC)
rem ============================================================
python -m pip download -r "%~dp0requirements.txt" -d "%~dp0wheels"
if errorlevel 1 (
    echo [ERROR] wheel download failed.
    pause
    exit /b 1
)
echo.
echo [OK] Wheels saved to wheels\
echo Offline install on any PC with:
echo    python -m pip install --no-index --find-links="%~dp0wheels" -r "%~dp0requirements.txt"
pause
