@echo off
rem ============================================================
rem  VolumetricLight3D GPU Sandbox - dependency installer
rem  Requires: Python 3.11 - 3.13 (64-bit) on PATH
rem  https://www.python.org/downloads/
rem ============================================================
python --version >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Python not found on PATH. Install Python 3.11-3.13 64-bit first.
    pause
    exit /b 1
)
echo Installing sandbox dependencies (numpy / Pillow / wgpu / lupa) ...
python -m pip install --upgrade pip
python -m pip install -r "%~dp0requirements.txt"
if errorlevel 1 (
    echo [ERROR] pip install failed. Check your network / Python version.
    pause
    exit /b 1
)
echo.
echo [OK] Dependencies installed!
echo Next step - run the self-check:
echo    python "%~dp0run_v306_checks.py"
echo.
pause
