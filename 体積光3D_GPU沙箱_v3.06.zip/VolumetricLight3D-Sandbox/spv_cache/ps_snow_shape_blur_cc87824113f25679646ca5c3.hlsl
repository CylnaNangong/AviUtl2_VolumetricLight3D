Texture2D<float4> Src : register(t0);
cbuffer SnowCB : register(b0) { float4 dims; float4 cfg; };
// dims=source width,height,output width,height
// cfg=axis(0 horizontal+pad,1 vertical),sigma,radius,pad
float4 read_safe(int2 q) {
    if (q.x < 0 || q.y < 0 || q.x >= (int)dims.x || q.y >= (int)dims.y)
        return float4(0,0,0,0);
    return Src.Load(int3(q,0));
}
float4 ps_snow_shape_blur(float4 pos : SV_Position) : SV_Target {
    int2 p = int2(pos.xy);
    int2 base = p;
    if (cfg.x < 0.5) base -= int2((int)cfg.w,(int)cfg.w);
    float4 sum = float4(0,0,0,0);
    float total = 0;
    [loop] for (int j=-24; j<=24; ++j) {
        if (abs(j) > (int)cfg.z) continue;
        float w = exp(-0.5*j*j/max(cfg.y*cfg.y,0.0001));
        int2 delta = cfg.x < 0.5 ? int2(j,0) : int2(0,j);
        sum += read_safe(base+delta)*w;
        total += w;
    }
    return sum/max(total,0.00001);
}
