float4 ps_vl_white(float4 pos : SV_Position) : SV_Target
    {
        return float4(1.0, 1.0, 1.0, 1.0);
    }
