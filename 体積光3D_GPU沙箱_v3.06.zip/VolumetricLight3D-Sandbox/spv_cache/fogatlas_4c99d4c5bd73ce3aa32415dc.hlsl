cbuffer FogCB : register(b0)
    {
        float4 p0;  // x: tile_size, y: tiles_x, z: n_slices, w: pad_px
        float4 p1;  // xyz: origin,  w: start_s
        float4 p2;  // xyz: fwd,     w: dz
        float4 p3;  // xyz: right,   w: hw_k (or R_vol)
        float4 p4;  // xyz: down,    w: hh_k (or RY_vol)
        float4 p5;  // xyz: wind_ofs, w: inv_nscale
        float4 p6;  // xyz: fog_rgb, w: sigma_dz
        float4 p7;  // x: pattern, y: dfade, z: mode_sphere, w: anim_t
        float4 p8;  // xyz: light_dir, w: hg_g
        float4 p9;  // xyz: light_rgb_scaled, w: h_fall_k
        float4 p10; // x: height_y, y: inner_u, z: jitter_k, w: cam_dist_y
        float4 p11; // xyz: cam_pos, w: unused
    };

    float hash31(float3 ip)
    {
        float3 q = ip - floor(ip / 289.0) * 289.0;
        float d = dot(q, float3(127.1, 311.7, 74.7));
        return frac(sin(d) * 43758.5453);
    }

    float vnoise3(float3 x)
    {
        float3 i = floor(x);
        float3 f = x - i;
        float3 u = f * f * (3.0 - 2.0 * f);

        float c000 = hash31(i + float3(0.0, 0.0, 0.0));
        float c100 = hash31(i + float3(1.0, 0.0, 0.0));
        float c010 = hash31(i + float3(0.0, 1.0, 0.0));
        float c110 = hash31(i + float3(1.0, 1.0, 0.0));
        float c001 = hash31(i + float3(0.0, 0.0, 1.0));
        float c101 = hash31(i + float3(1.0, 0.0, 1.0));
        float c011 = hash31(i + float3(0.0, 1.0, 1.0));
        float c111 = hash31(i + float3(1.0, 1.0, 1.0));

        float x00 = lerp(c000, c100, u.x);
        float x10 = lerp(c010, c110, u.x);
        float x01 = lerp(c001, c101, u.x);
        float x11 = lerp(c011, c111, u.x);
        float y0  = lerp(x00, x10, u.y);
        float y1  = lerp(x01, x11, u.y);
        return lerp(y0, y1, u.z);
    }

    float fbm4(float3 q, float anim)
    {
        float v  = 0.500 * vnoise3(q + float3(anim * 0.11, -anim * 0.07, anim * 0.05));
        v += 0.260 * vnoise3(q * 2.03 + float3(-anim * 0.17 + 11.3, anim * 0.13 - 7.1, 5.7));
        v += 0.150 * vnoise3(q * 4.07 + float3(anim * 0.23 - 3.9, 13.7, -anim * 0.19 - 9.2));
        v += 0.090 * vnoise3(q * 8.13 + float3(7.7, -anim * 0.29 + 3.1, 17.3));
        return v;
    }

    float4 fogatlas(float4 pos : SV_Position) : SV_Target
    {
        float tile_sz = p0.x;
        float tiles_x = p0.y;
        float n_sl    = p0.z;
        float pad_px  = p0.w;

        float tx = floor(pos.x / tile_sz);
        float ty = floor(pos.y / tile_sz);
        float si = ty * tiles_x + tx;
        if (si >= n_sl)
        {
            return float4(0.0, 0.0, 0.0, 0.0);
        }

        float span = max(tile_sz - 2.0 * pad_px, 1.0);
        float lu = saturate((pos.x - tx * tile_sz - pad_px) / span) * 2.0 - 1.0;
        float lv = saturate((pos.y - ty * tile_sz - pad_px) / span) * 2.0 - 1.0;

        float dz = p2.w;
        float ign = frac(sin(pos.x * 0.0605 + pos.y * 0.0076 + si * 0.2312) * 43758.5453);
        float z_jit = (ign - 0.5) * dz * p10.z;

        float3 wpos;
        float env = 1.0;

        if (p7.z < 0.5)
        {
            float z = p1.w + (si + 0.5) * dz + z_jit;
            wpos = p1.xyz + p2.xyz * z + p3.xyz * (lu * p3.w * z) + p4.xyz * (lv * p4.w * z);

            float denom_e = max(1.0 - p10.y, 0.05);
            float eu = saturate((1.0 - abs(lu)) / denom_e);
            float ev = saturate((1.0 - abs(lv)) / denom_e);
            float edge = (eu * eu * (3.0 - 2.0 * eu)) * (ev * ev * (3.0 - 2.0 * ev));

            float e0 = si / max(n_sl - 1.0, 1.0);
            float ef = saturate(min(e0 / 0.08, (1.0 - e0) / 0.08));
            float df = (1.0 - p7.y) + p7.y * e0;
            env = df * (0.25 + 0.75 * ef) * edge;
        }
        else
        {
            float r_vol  = p3.w;
            float ry_vol = p4.w;
            float s = p1.w + (si + 0.5) * dz + z_jit;
            float rad_s = max(200.0, sqrt(max(0.0, r_vol * r_vol - s * s)));
            float lx = lu * rad_s;
            float ly = lv * rad_s * (ry_vol / max(r_vol, 1.0));
            wpos = p1.xyz + p2.xyz * s + p3.xyz * lx + p4.xyz * ly;

            float3 rel = wpos - p1.xyz;
            float3 dn = float3(rel.x / max(r_vol, 1.0), rel.y / max(ry_vol, 1.0), rel.z / max(r_vol, 1.0));
            float tf = saturate((1.0 - length(dn)) / 0.58);
            env = tf * tf * (3.0 - 2.0 * tf);
        }

        float n = fbm4((wpos + p5.xyz) * p5.w, p7.w);
        float c_raw = clamp((n - 0.34) / 0.42, 0.0, 1.6);
        float dens_f = (0.06 + 2.35 * c_raw * sqrt(c_raw)) * p7.x + 0.72 * (1.0 - p7.x);

        if (p9.w > 0.0)
        {
            float h_above = max(0.0, p10.x - wpos.y);
            dens_f *= exp(-h_above * p9.w);
        }

        float3 vvec = wpos - p11.xyz;
        float  vlen = max(length(vvec), 1e-4);
        float3 vdir = vvec / vlen;

        // 斜め視線に対するスライス通過厚みの正割補正 sec(theta) = 1 / |dot(vdir, sl_n)|
        float3 sl_n = normalize(p2.xyz);
        float sec_k = 1.0 / max(abs(dot(vdir, sl_n)), 0.25);
        float od = max(p6.w * sec_k * env * dens_f, 0.0);
        float alpha = 1.0 - exp(-od);

        // p8.xyz は「光が進む向き」なので、前向散乱角 cos(theta) は -dot(vdir, p8.xyz)
        float cosA = -dot(vdir, p8.xyz);
        float g = clamp(p8.w, -0.92, 0.92);
        float g2 = g * g;
        float d_hg = max(1.0 + g2 - 2.0 * g * cosA, 1e-4);
        float phase = (1.0 - g2) / (d_hg * sqrt(d_hg));
        // 高 g 時の極端な白飛び・色環断層を滑らかに抑制
        phase = phase / (1.0 + 0.08 * max(phase - 1.0, 0.0));

        float3 scol = saturate(p6.xyz + p9.xyz * phase);
        return float4(scol * alpha, alpha);
    }
