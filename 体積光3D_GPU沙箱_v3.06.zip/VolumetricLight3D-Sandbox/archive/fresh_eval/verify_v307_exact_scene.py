#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Exact replication of the user's Verse1 scene with REAL assets:
  L2 camera (0,0,-1024)->(0,0,0); L3 light = church mosaic JPG; L4 statue = real
  石膏像.png at (511.11, 705.12, -910.00) zoom 100; L10 VL occ m1 manual L4.
Renders 2048x1080, prints HUD, saves outputs, analyzes band pattern."""
import pathlib
import sys

import numpy as np
from PIL import Image

sys.path.insert(0, "/home/user/sandbox")
sys.path.insert(0, "/home/user/sandbox/fresh_eval")

from sandbox_v2_fidelity import FidelityLayer, PersistentAviUtl2Session, VL3DBridgeMockHost

ROOT = pathlib.Path("/home/user")
VL = ROOT / "GitHub_VolumetricLight3D/Script/体積光（3D）.obj2"
OUT = ROOT / "sandbox/fresh_eval/outputs/user_repro"
OUT.mkdir(parents=True, exist_ok=True)
W, H = 2048, 1080

statue_img = np.asarray(Image.open(ROOT / "uploads/石膏像.png").convert("RGBA")).copy()
mosaic_rgb = np.asarray(Image.open(ROOT / "uploads/2104.i518.013.S.m005.c12.church windows mosaic.jpg").convert("RGB"))
mosaic = np.dstack([mosaic_rgb, np.full(mosaic_rgb.shape[:2], 255, dtype=np.uint8)]).copy()

CAM = {"x": 0.0, "y": 0.0, "z": -1024.0, "tx": 0.0, "ty": 0.0, "tz": 0.0,
       "ux": 0.0, "uy": -1.0, "uz": 0.0, "rz": 0.0, "d": 1024.0}


def build_layers(light_pos, light_zoom, statue_xyz=(511.11, 705.12, -910.0)):
    light = FidelityLayer(index=3, name="光源马赛克", x=light_pos[0], y=light_pos[1], z=light_pos[2],
                          zoom=light_zoom, alpha=1.0, image=mosaic, kind_override="OTHER")
    statue = FidelityLayer(index=4, name="石膏像", x=statue_xyz[0], y=statue_xyz[1], z=statue_xyz[2],
                           zoom=100.0, alpha=1.0, image=statue_img, kind_override="OTHER")
    return {3: light, 4: statue}


def run(tag, params, layers, with_ref=True):
    br = VL3DBridgeMockHost(mode="v290_sdk_lock", scene_id=1)
    sess = PersistentAviUtl2Session(str(VL), width=W, height=H, strict_getvalue=True, bridge=br)
    res = sess.render_frame(params=params, camera=CAM, layers=layers, self_layer=10,
                            frame=146, totalframe=619, frame_s=619, scene_id=1)
    assert res["error"] is None, res["error"]
    Image.fromarray(res["rgba8"]).save(OUT / f"{tag}.png")
    for l in res["logs"]:
        if "遮蔽" in l or "遮挡" in l:
            print("HUD:", l[:200])
    if with_ref:
        br0 = VL3DBridgeMockHost(mode="v290_sdk_lock", scene_id=1)
        sess0 = PersistentAviUtl2Session(str(VL), width=W, height=H, strict_getvalue=True, bridge=br0)
        ref = sess0.render_frame(params=dict(params, occ_mode=0), camera=CAM, layers=layers,
                                 self_layer=10, frame=146, totalframe=619, frame_s=619, scene_id=1)
        d = np.clip(ref["rgba8"][..., :3].astype(np.int16) - res["rgba8"][..., :3].astype(np.int16), 0, 255).sum(axis=2)
        ys, xs = np.nonzero(d > 30)
        if len(xs):
            print(f"  occ shadow: bbox=({xs.min()},{ys.min()})-({xs.max()},{ys.max()}) px={len(xs)} "
                  f"({100.0*len(xs)/(W*H):.2f}% of screen)")
        else:
            print("  occ shadow: NONE visible on screen")
    return res


def band_profile(img_arr, y0, y1):
    lum = img_arr[y0:y1].mean(axis=2).mean(axis=0)
    # normalize to fractions
    return lum


def main():
    base = {"src_layer": 3, "intensity": 150.0, "direction": 55.0, "pitch": 44.0,
            "occ_mode": 1, "occ_3d_mode": 0, "occ_target": 2, "occ_list": "4",
            "occ_strength": 100.0, "occ_soft": 8.0, "log_mode": True, "show_info": False}

    # attempt 1: light centered at z=1000, zoom 108 (displays ~6750x4860)
    print("=== attempt 1: light (0,-100,1000) zoom108 ===")
    res1 = run("exact_a1", dict(base), build_layers((0.0, -100.0, 1000.0), 108.0))

    # attempt 2: light (0,0,1000)
    print("=== attempt 2: light (0,0,1000) zoom108 ===")
    res2 = run("exact_a2", dict(base), build_layers((0.0, 0.0, 1000.0), 108.0))

    # analyze band pattern of attempt renders vs user close-up
    up = np.asarray(Image.open(ROOT / "uploads/image-1.png").convert("RGB")).astype(np.float32)
    up_lum_mid = up[180:300].mean(axis=2).mean(axis=0)
    def bands(lum, thr_scale=0.45):
        mx = lum.max()
        dark = lum < mx * thr_scale
        runs, inrun = [], False
        for i, v in enumerate(dark):
            if v and not inrun:
                s = i; inrun = True
            elif not v and inrun:
                if i - s > 8:
                    runs.append((round(s/len(lum), 3), round(i/len(lum), 3)))
                inrun = False
        if inrun and len(lum)-s > 8:
            runs.append((round(s/len(lum), 3), 1.0))
        return runs
    print("\nuser close-up dark bands (mid rows, frac):", bands(up_lum_mid))
    for tag in ["exact_a1", "exact_a2"]:
        arr = np.asarray(Image.open(OUT / f"{tag}.png").convert("RGB")).astype(np.float32)
        lum_mid = arr[500:700].mean(axis=2).mean(axis=0)
        print(f"{tag} dark bands (mid rows, frac):", bands(lum_mid))
        lum_hi = arr[100:300].mean(axis=2).mean(axis=0)
        print(f"{tag} dark bands (top rows, frac):", bands(lum_hi))


if __name__ == "__main__":
    main()
