#!/usr/bin/env python3
"""
End-to-End Vulkan GPU Verification for 体積光（3D） v3.00 Mainline Release:
1. LuaJIT bytecode & register budget (< 199 slots across main chunk & all inner functions, 0 GSET leaks).
2. Bit-exact backward compatibility when ab_enable == false vs v2.94-bridge (max_rgba_diff == 0).
3. AutoBlendLight integration:
   - Layer range selection (ab_target=1, ab_list="4-5") vs excluded Layer 3 & closer non-target Text Layer 6.
   - Left/Right Dual + 3D Volumetric Beam color pickup (warm gold left vs cool cyan right).
   - All 3 lighting styles: Gradient Backlight (0), Gradient Normal Light (1), Outline Rim (2).
   - Base brightness + 3D perspective-matched Environment Multiply + 3D foreground beam veiling preservation.
   - Brightness Link (ab_luma_link) tracking scene + volumetric light intensity.
   - Deferred カメラ制御 empty-framebuffer fallback (auto-projects 3D background layers when framebuffer alpha == 0).
4. TemporaryImageCacheSize (< 16M dots) & post-frame 1x1 cache cleanup verification.
"""
import json
import os
import re
import subprocess
import sys
import tempfile
from pathlib import Path
import numpy as np
from PIL import Image, ImageDraw

sys.path.insert(0, str(Path(__file__).resolve().parent))
from sandbox_v2_fidelity import FidelityLayer, PersistentAviUtl2Session, VL3DBridgeMockHost

ROOT = Path("/home/user")
VL_V294 = ROOT / "scripts/pkg1/体积光（3D）/versions/体積光（3D）_v2.94_bridge.obj2"
VL_V300 = ROOT / "scripts/pkg1/体积光（3D）/stable/Script/体積光（3D）.obj2"
OUT_DIR = Path(__file__).resolve().parent / "outputs"
OUT_DIR.mkdir(parents=True, exist_ok=True)


def make_character_sprite(w: int = 220, h: int = 320, coat_rgb=(210, 212, 220)) -> np.ndarray:
    """Create a crisp anime-style character bust silhouette (head + hair + shoulders) with premultiplied RGBA."""
    im = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    dr = ImageDraw.Draw(im)
    cx = w // 2
    dr.pieslice([cx - 88, 150, cx + 88, 390], 180, 360, fill=(*coat_rgb, 255))
    dr.ellipse([cx - 60, 28, cx + 60, 160], fill=(172, 178, 190, 255))
    dr.polygon([(cx - 54, 88), (cx - 82, 166), (cx - 34, 150)], fill=(172, 178, 190, 255))
    dr.polygon([(cx + 54, 88), (cx + 82, 166), (cx + 34, 150)], fill=(172, 178, 190, 255))
    dr.ellipse([cx - 42, 52, cx + 42, 144], fill=(236, 224, 216, 255))
    arr = np.asarray(im, dtype=np.float32)
    a = arr[..., 3:4] / 255.0
    arr[..., :3] = np.round(arr[..., :3] * a)
    return np.clip(arr, 0, 255).astype(np.uint8)


def make_split_stained_glass(w: int = 640, h: int = 360) -> np.ndarray:
    """Left half: warm golden amber light; Right half: cool sapphire-cyan light."""
    img = np.zeros((h, w, 4), dtype=np.uint8)
    xs = np.linspace(0.0, 1.0, w, dtype=np.float32)[None, :]
    warm = np.array([255.0, 164.0, 36.0], dtype=np.float32)
    cool = np.array([42.0, 196.0, 255.0], dtype=np.float32)
    t = np.clip((xs - 0.35) / 0.30, 0.0, 1.0)
    rgb = warm[None, None, :] * (1.0 - t[..., None]) + cool[None, None, :] * t[..., None]
    img[..., :3] = np.clip(np.round(rgb), 0, 255).astype(np.uint8)
    img[..., 3] = 255
    return img


def make_subtitle_rgba(w: int = 260, h: int = 52) -> np.ndarray:
    im = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    dr = ImageDraw.Draw(im)
    dr.rounded_rectangle([8, 10, w - 8, h - 10], radius=8, fill=(12, 12, 16, 255))
    return np.asarray(im, dtype=np.uint8)


def composite_layer_to_screen(dst_rgba: np.ndarray, cam: dict, lx: float, ly: float, lz: float, rgba: np.ndarray, fx=0.0, fy=0.0, zoom=1.0):
    """Project premultiplied 2D layer onto dst_rgba and return boolean opaque mask."""
    H, W = dst_rgba.shape[:2]
    oh, ow = rgba.shape[:2]
    cx_w = lx - (ow * fx) * zoom
    cy_w = ly - (oh * fy) * zoom
    cam_pos = np.array([cam["x"], cam["y"], cam["z"]], dtype=np.float64)
    tgt = np.array([cam["tx"], cam["ty"], cam["tz"]], dtype=np.float64)
    f = tgt - cam_pos; f /= np.linalg.norm(f)
    up = np.array([cam.get("ux", 0.0), cam.get("uy", -1.0), cam.get("uz", 0.0)], dtype=np.float64)
    r = np.cross(f, up); r /= np.linalg.norm(r)
    d = np.cross(f, r);  d /= np.linalg.norm(d)
    focal = float(cam.get("d", 1024.0))

    zc = (cx_w - cam_pos[0]) * f[0] + (cy_w - cam_pos[1]) * f[1] + (lz - cam_pos[2]) * f[2]
    ys, xs = np.mgrid[0:H, 0:W]
    sp_x = (xs + 0.5 - 0.5 * W) * (zc / focal)
    sp_y = (ys + 0.5 - 0.5 * H) * (zc / focal)
    wx = cam_pos[0] + f[0] * zc + r[0] * sp_x + d[0] * sp_y
    wy = cam_pos[1] + f[1] * zc + r[1] * sp_x + d[1] * sp_y
    u = ((wx - cx_w) / (ow * zoom) + 0.5) * ow
    v = ((wy - cy_w) / (oh * zoom) + 0.5) * oh
    inside = (u >= 0) & (u < ow) & (v >= 0) & (v < oh)
    iu = np.clip(u[inside].astype(int), 0, ow - 1)
    iv = np.clip(v[inside].astype(int), 0, oh - 1)
    src = rgba[iv, iu].astype(np.float32)
    sa = src[:, 3:4] / 255.0
    dst = dst_rgba[inside].astype(np.float32)
    out = np.clip(np.round(src + dst * (1.0 - sa)), 0, 255).astype(np.uint8)
    dst_rgba[inside] = out
    mask = np.zeros((H, W), dtype=bool)
    mask[inside] = rgba[iv, iu, 3] > 200
    return mask


def audit_v300_bytecode() -> dict:
    src = VL_V300.read_text(encoding="utf-8")
    ui_vars = re.findall(r"^--(?:track|select|check|color|string|value|figure|file)@([A-Za-z0-9_]+):", src, flags=re.M)
    with tempfile.NamedTemporaryFile("w", suffix=".lua", encoding="utf-8", delete=False) as tf:
        tf.write("local " + ", ".join(ui_vars) + "\n" + src)
        tmp_path = tf.name
    bc = subprocess.check_output(["luajit", "-bl", tmp_path], text=True)
    os.unlink(tmp_path)
    blocks = bc.split("-- BYTECODE -- ")[1:]
    max_fn, main_r, gsets = 0, 0, 0
    for bi, blk in enumerate(blocks):
        regs = []
        for line in blk.splitlines()[1:]:
            m = re.match(r"^\d+\s+([A-Z0-9]+)\s+(.*)$", line)
            if not m:
                continue
            op, rest = m.group(1), m.group(2)
            if op == "GSET":
                gsets += 1
            nums = [int(x) for x in re.findall(r"\b(\d+)\b", rest.split(";")[0])]
            if nums and op not in ("JMP", "LOOP", "FORL", "IFORL", "JFORL", "UCLO"):
                regs.append(nums[0])
        mr = max(regs) if regs else 0
        if bi == len(blocks) - 1:
            main_r = mr
        else:
            max_fn = max(max_fn, mr)
    assert main_r < 190 and max_fn < 190 and gsets == 0
    return {"ui_vars": len(ui_vars), "main_chunk_max_reg": main_r, "inner_fn_max_reg": max_fn, "gset_leaks": gsets}


def main():
    print("[1/5] Auditing v3.00 LuaJIT bytecode & local register budget...")
    bc_res = audit_v300_bytecode()
    print("  Bytecode:", json.dumps(bc_res))

    W, H = 960, 540
    cam = {
        "x": 0.0, "y": 0.0, "z": -1350.0,
        "tx": 0.0, "ty": 0.0, "tz": 0.0,
        "ux": 0.0, "uy": -1.0, "uz": 0.0,
        "rz": 0.0, "d": 540.0,
    }

    glass = make_split_stained_glass(640, 360)
    prop_pillar = np.full((300, 70, 4), [224, 226, 232, 255], dtype=np.uint8)
    char_a = make_character_sprite(220, 320, coat_rgb=(210, 212, 220))
    char_b = make_character_sprite(220, 320, coat_rgb=(210, 212, 220))
    sub_bar = make_subtitle_rgba(260, 52)

    layers = {
        2: FidelityLayer(index=2, name="画像ファイル", x=0.0, y=-20.0, z=650.0, zoom=240.0, image=glass),
        3: FidelityLayer(index=3, name="画像ファイル", x=-560.0, y=20.0, z=-180.0, zoom=100.0, image=prop_pillar),
        4: FidelityLayer(index=4, name="画像ファイル", x=-210.0, y=55.0, z=-250.0, zoom=100.0, image=char_a),
        5: FidelityLayer(index=5, name="画像ファイル", x=210.0, y=55.0, z=-280.0, zoom=100.0, image=char_b),
        6: FidelityLayer(
            index=6, name="テキスト", x=-195.0, y=65.0, z=-520.0, zoom=100.0, image=sub_bar,
            effects={"テキスト": {"文字揃え": "左寄せ[上]", "文字装飾": "標準文字", "サイズ": 52.0}},
        ),
    }

    # Build true pre-volumetric scene framebuffer (warm/cool room + Layers 3, 4, 5, 6 composited in exact order)
    bg_fb = np.zeros((H, W, 4), dtype=np.uint8)
    xs_scr = np.linspace(0.0, 1.0, W, dtype=np.float32)[None, :]
    bg_amb = np.array([96.0, 56.0, 18.0])[None, None, :] * (1.0 - xs_scr[..., None]) + np.array([18.0, 68.0, 108.0])[None, None, :] * xs_scr[..., None]
    bg_fb[..., :3] = np.clip(np.round(bg_amb), 0, 255).astype(np.uint8)
    bg_fb[..., 3] = 255
    mask_l3 = composite_layer_to_screen(bg_fb, cam, -560.0, 20.0, -180.0, prop_pillar)
    mask_l4 = composite_layer_to_screen(bg_fb, cam, -210.0, 55.0, -250.0, char_a)
    mask_l5 = composite_layer_to_screen(bg_fb, cam, 210.0, 55.0, -280.0, char_b)
    mask_l6 = composite_layer_to_screen(bg_fb, cam, -195.0, 65.0, -520.0, sub_bar, fx=-0.5, fy=-0.5)

    base_params = {
        "src_layer": 2, "threshold": 12.0, "intensity": 135.0, "length": 2400.0,
        "ray_mode": 0, "direction": 90.0, "pitch": 90.0, "spread": 32.0,
        "occ_mode": 2, "occ_target": 0, "occ_strength": 100.0, "occ_soft": 6.0,
        "show_info": 0, "log_mode": 1,
    }

    print("[2/5] Verifying bit-exact equivalence when ab_enable == false vs v2.94-bridge...")
    s294 = PersistentAviUtl2Session(str(VL_V294), width=W, height=H, bridge=VL3DBridgeMockHost(mode="v120_native", scene_id=0), restrict_stdlib=True)
    s300 = PersistentAviUtl2Session(str(VL_V300), width=W, height=H, bridge=VL3DBridgeMockHost(mode="v120_native", scene_id=0), restrict_stdlib=True)

    r_294 = s294.render_frame(params=base_params, camera=cam, layers=layers, self_layer=8, frame=20, background_rgba=bg_fb)
    r_off = s300.render_frame(params=dict(base_params, ab_enable=0), camera=cam, layers=layers, self_layer=8, frame=20, background_rgba=bg_fb)
    assert r_294["error"] is None and r_off["error"] is None
    off_max_diff = int(np.max(np.abs(r_294["rgba8"].astype(np.int32) - r_off["rgba8"].astype(np.int32))))
    assert off_max_diff == 0, f"ab_enable=false differed from v2.94-bridge! max_diff={off_max_diff}"
    print(f"  ab_enable=false vs v2.94-bridge max_rgba_diff = {off_max_diff} (100% bit-identical!)")

    print("[3/5] Verifying AutoBlendLight layer-range selection (4-5), 2-color + 3D beam wrap, rim styles & holdout...")
    ab_common = dict(
        base_params,
        ab_enable=1, ab_target=1, ab_list="4-5",
        ab_bright=72.0, ab_color_mode=2, ab_strength=145.0,
        ab_diffusion=48.0, ab_bias=-35.0, ab_color_mix=65.0,
        ab_saturation=140.0, ab_luma_link=1, ab_env_blend=42.0, ab_env_blur=160.0,
    )
    r_nolit = s300.render_frame(params=dict(ab_common, ab_strength=0.0, ab_style=0), camera=cam, layers=layers, self_layer=8, frame=21, background_rgba=bg_fb)
    r_grad  = s300.render_frame(params=dict(ab_common, ab_style=0), camera=cam, layers=layers, self_layer=8, frame=22, background_rgba=bg_fb)
    r_norm  = s300.render_frame(params=dict(ab_common, ab_style=1), camera=cam, layers=layers, self_layer=8, frame=23, background_rgba=bg_fb)
    r_rim   = s300.render_frame(params=dict(ab_common, ab_style=2, ab_diffusion=28.0, ab_bias=-15.0), camera=cam, layers=layers, self_layer=8, frame=24, background_rgba=bg_fb)
    for tag, rr in (("nolit", r_nolit), ("grad", r_grad), ("norm", r_norm), ("rim", r_rim)):
        assert rr["error"] is None, f"{tag} error: {rr['error']}"
        assert not any("@error" in lg for lg in rr["logs"]), f"{tag} runtime log error: {rr['logs']}"

    img_off   = r_off["rgba8"]
    img_nolit = r_nolit["rgba8"]
    img_grad  = r_grad["rgba8"]
    img_rim   = r_rim["rgba8"]

    # 3a) Excluded Layer 3 (prop_pillar, NOT in "4-5") must remain completely untouched!
    eroded_l3 = mask_l3.copy()
    for dx in (-2, 0, 2):
        for dy in (-2, 0, 2):
            eroded_l3 &= np.roll(np.roll(mask_l3, dy, axis=0), dx, axis=1)
    l3_mae = float(np.mean(np.abs(img_grad[eroded_l3].astype(np.float32) - img_off[eroded_l3].astype(np.float32))))
    assert l3_mae == 0.0, f"Excluded Layer 3 was modified! l3_mae={l3_mae}"

    # 3b) Closer Non-Target Subtitle Layer 6 overlapping Character A must be protected by alpha holdout!
    overlap_l6_on_l4 = mask_l6 & mask_l4
    eroded_ov = overlap_l6_on_l4.copy()
    for dx in (-2, 0, 2):
        for dy in (-2, 0, 2):
            eroded_ov &= np.roll(np.roll(overlap_l6_on_l4, dy, axis=0), dx, axis=1)
    assert eroded_ov.sum() > 100
    l6_holdout_mae = float(np.mean(np.abs(img_grad[..., :3][eroded_ov].astype(np.float32) - img_off[..., :3][eroded_ov].astype(np.float32))))
    assert l6_holdout_mae < 1.0, f"Closer non-target Layer 6 got painted over! mae={l6_holdout_mae}"

    # 3c) Selected Characters (Layer 4 warm left vs Layer 5 cool right) must pick up warm vs cool lighting!
    vis_l4 = mask_l4 & (~mask_l6)
    vis_l5 = mask_l5
    c4_off_rgb  = img_off[..., :3][vis_l4].mean(axis=0)
    c4_grad_rgb = img_grad[..., :3][vis_l4].mean(axis=0)
    c5_grad_rgb = img_grad[..., :3][vis_l5].mean(axis=0)
    warm_rb_delta = float(c4_grad_rgb[0] - c4_grad_rgb[2])
    cool_br_delta = float(c5_grad_rgb[2] - c5_grad_rgb[0])
    lr_color_sep  = warm_rb_delta + cool_br_delta
    assert warm_rb_delta > 12.0 and cool_br_delta > 5.0 and lr_color_sep > 20.0, (
        f"Left/Right warm-cool tint separation insufficient! c4={c4_grad_rgb}, c5={c5_grad_rgb}"
    )
    assert float(c4_grad_rgb.mean()) < float(c4_off_rgb.mean()) - 15.0, "Character brightness did not settle into dark scene!"

    # 3d) Silhouette edge wrap lift vs core lift (measured relative to ab_strength=0 baseline so albedo differences cancel!)
    core_l5 = mask_l5.copy()
    for _ in range(5):
        nxt = core_l5.copy()
        for dx in (-2, 0, 2):
            for dy in (-2, 0, 2):
                nxt &= np.roll(np.roll(core_l5, dy, axis=0), dx, axis=1)
        core_l5 = nxt
    edge_l5 = mask_l5 & (~core_l5)
    grad_edge_lift = float(img_grad[..., :3][edge_l5].mean() - img_nolit[..., :3][edge_l5].mean())
    grad_core_lift = float(img_grad[..., :3][core_l5].mean() - img_nolit[..., :3][core_l5].mean())
    rim_edge_lift  = float(img_rim[..., :3][edge_l5].mean()  - img_nolit[..., :3][edge_l5].mean())
    rim_core_lift  = float(img_rim[..., :3][core_l5].mean()  - img_nolit[..., :3][core_l5].mean())
    assert grad_edge_lift > 15.0 and grad_edge_lift > grad_core_lift + 8.0, f"Gradient backlight wrap too weak: edge_lift={grad_edge_lift}, core_lift={grad_core_lift}"
    assert rim_edge_lift  > 10.0 and rim_edge_lift  > rim_core_lift  + 8.0, f"Outline rim contour too weak: edge_lift={rim_edge_lift}, core_lift={rim_core_lift}"

    print("[4/5] Verifying Deferred カメラ制御 Empty-Framebuffer Fallback (alpha == 0)...")
    empty_fb = np.zeros((H, W, 4), dtype=np.uint8)
    r_empty = s300.render_frame(params=dict(ab_common, ab_style=0), camera=cam, layers=layers, self_layer=8, frame=25, background_rgba=empty_fb)
    assert r_empty["error"] is None and not any("@error" in lg for lg in r_empty["logs"])
    c4_emp = r_empty["rgba8"][..., :3][vis_l4].mean(axis=0)
    c5_emp = r_empty["rgba8"][..., :3][vis_l5].mean(axis=0)
    emp_warm = float(c4_emp[0] - c4_emp[2])
    emp_cool = float(c5_emp[2] - c5_emp[0])
    assert emp_warm > 12.0 and emp_cool > 5.0 and (emp_warm + emp_cool) > 20.0, (
        f"Empty-framebuffer カメラ制御 fallback failed to project 3D background Layer 2! c4={c4_emp}, c5={c5_emp}"
    )

    print("[5/5] Verifying Brightness Link (ab_luma_link) & VRAM 16M cache hygiene...")
    dark_bg = bg_fb.copy()
    dark_bg[~(mask_l3 | mask_l4 | mask_l5 | mask_l6)] = [4, 4, 6, 255]
    r_dark = s300.render_frame(
        params=dict(ab_common, intensity=5.0, ab_bright=100.0, ab_env_blend=0.0, ab_style=0, ab_bias=40.0),
        camera=cam, layers=layers, self_layer=8, frame=26, background_rgba=dark_bg,
    )
    r_bright = s300.render_frame(
        params=dict(ab_common, intensity=190.0, ab_bright=100.0, ab_env_blend=0.0, ab_style=0, ab_bias=40.0),
        camera=cam, layers=layers, self_layer=8, frame=27, background_rgba=bg_fb,
    )
    luma_rim_dark   = float(r_dark["rgba8"][..., :3][edge_l5].mean())
    luma_rim_bright = float(r_bright["rgba8"][..., :3][edge_l5].mean())
    assert luma_rim_bright > luma_rim_dark + 5.0, f"Brightness link did not respond: dark={luma_rim_dark}, bright={luma_rim_bright}"

    #Also test occ_mode=3 (3D foreground beam veiling over blended characters!)
    r_occ3 = s300.render_frame(params=dict(ab_common, occ_mode=3, ab_style=0), camera=cam, layers=layers, self_layer=8, frame=28, background_rgba=bg_fb)
    assert r_occ3["error"] is None

    peak_dots = int(s300.sb.peak_cache_dots)
    live_post_dots = sum(b.w * b.h for k, b in s300.sb.buffers.items() if k.startswith("cache:vl3d/"))
    assert peak_dots < 16_000_000, f"Exceeded 16M cache limit: {peak_dots}"
    assert live_post_dots <= 32, f"Cache buffers not released to 1x1 after frame: live_post_dots={live_post_dots}"
    assert "+AB(L4,L5)" in r_grad["logs"][0], f"Expected +AB(L4,L5) in log: {r_grad['logs']}"

    # Save 2x2 visual showcase: [Top-L: ab_enable=OFF | Top-R: Style 0 Gradient Backlight | Bot-L: Style 2 Outline Rim | Bot-R: Style 0 + occ_mode=3 3D Scatter]
    comp = np.concatenate([
        np.concatenate([img_off, img_grad], axis=1),
        np.concatenate([img_rim, r_occ3["rgba8"]], axis=1),
    ], axis=0)
    comp_path = OUT_DIR / "v300_autoblend_comparison.png"
    Image.fromarray(comp).save(comp_path)

    results = {
        "bytecode": bc_res,
        "ab_disabled_vs_v294_max_diff": off_max_diff,
        "excluded_layer3_mae": l3_mae,
        "closer_nontarget_layer6_holdout_mae": round(l6_holdout_mae, 4),
        "char4_warm_rb_delta": round(warm_rb_delta, 2),
        "char5_cool_br_delta": round(cool_br_delta, 2),
        "grad_edge_vs_core_lift": [round(grad_edge_lift, 2), round(grad_core_lift, 2)],
        "rim_edge_vs_core_lift": [round(rim_edge_lift, 2), round(rim_core_lift, 2)],
        "empty_fb_cam_fallback_warm_cool_deltas": [round(float(c4_emp[0] - c4_emp[2]), 2), round(float(c5_emp[2] - c5_emp[0]), 2)],
        "brightness_link_dark_vs_bright_edge_luma": [round(luma_rim_dark, 2), round(luma_rim_bright, 2)],
        "peak_cache_dots": peak_dots,
        "post_frame_live_cache_dots": live_post_dots,
        "log_line": r_grad["logs"][0],
    }
    out_json = OUT_DIR / "verify_v300_mainline_and_autoblend_results.json"
    out_json.write_text(json.dumps(results, indent=2, ensure_ascii=False), encoding="utf-8")
    print("  Results:", json.dumps(results, indent=2, ensure_ascii=False))
    print(f"\nALL v3.00 MAINLINE + AUTOBLENDLIGHT SUITES PASSED! Saved: {comp_path}")


if __name__ == "__main__":
    main()
