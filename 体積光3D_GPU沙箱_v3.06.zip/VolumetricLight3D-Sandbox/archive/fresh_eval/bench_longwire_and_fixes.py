#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import json, math, pathlib, sys
import numpy as np
from PIL import Image

sys.path.insert(0, "/home/user/sandbox")
sys.path.insert(0, "/home/user/sandbox/fresh_eval")
from generate_assets import make_stained_glass_png
from sandbox_v2_fidelity import FidelityLayer, PersistentAviUtl2Session, VL3DBridgeMockHost

ROOT = pathlib.Path("/home/user")
OUT_DIR = ROOT / "sandbox/fresh_eval/outputs"
IMG_DIR = OUT_DIR / "renders"

def make_longwire_bairdcage_38012(out_path: pathlib.Path):
    """
    Realistic CAD/Blender-style Wavefront OBJ birdcage with 38,012 triangles:
      - 900 full-span diagonal lattice wires (1,800 triangles whose 2D AABBs span
        ~320x480 px each at 2048x1080, zoom=20%)
      - 36,212 fine dome/ring/filigree triangles
    """
    verts, faces = [], []
    def add_rib(p0, p1, hw=4.8):
        dx, dy, dz = p1[0]-p0[0], p1[1]-p0[1], p1[2]-p0[2]
        nx, ny, nz = -dy, dx, 0.25*dx
        ln = math.sqrt(nx*nx + ny*ny + nz*nz) + 1e-8
        ox, oy, oz = (nx/ln)*hw, (ny/ln)*hw, (nz/ln)*hw
        b = len(verts) + 1
        verts.extend([
            (p0[0]-ox, p0[1]-oy, p0[2]-oz),
            (p0[0]+ox, p0[1]+oy, p0[2]+oz),
            (p1[0]+ox, p1[1]+oy, p1[2]+oz),
            (p1[0]-ox, p1[1]-oy, p1[2]-oz),
        ])
        faces.append((b, b+1, b+2))
        faces.append((b, b+2, b+3))

    R = 1100.0
    # 900 full-height un-subdivided diagonal cross-wires (1,800 triangles!)
    for i in range(450):
        a0 = 2.0 * math.pi * (i / 450.0)
        a1 = a0 + 0.85  # ~49-degree diagonal sweep across X and Y!
        add_rib((R*math.cos(a0), -1150.0, R*math.sin(a0)), (R*math.cos(a1), 1150.0, R*math.sin(a1)), hw=5.0)
        add_rib((R*math.cos(a1), -1150.0, R*math.sin(a1)), (R*math.cos(a0), 1150.0, R*math.sin(a0)), hw=5.0)

    # Remaining 36,212 triangles = 18,106 quads of rings + vertical & dome filigree
    need_q = (38012 - len(faces)) // 2
    for q in range(need_q):
        ring = q // 120
        seg = q % 120
        t = min(1.0, ring / 151.0)
        y = -1150.0 + 2300.0 * t
        rr = R * (1.0 if t > 0.2 else (0.25 + 0.75 * (t / 0.2)))
        a0 = 2.0 * math.pi * (seg / 120.0)
        a1 = 2.0 * math.pi * ((seg + 1) / 120.0)
        add_rib((rr*math.cos(a0), y, rr*math.sin(a0)), (rr*math.cos(a1), y + 12.0, rr*math.sin(a1)), hw=4.2)

    assert len(faces) == 38012
    with out_path.open("w", encoding="utf-8") as f:
        for vx, vy, vz in verts:
            f.write(f"v {vx:.2f} {vy:.2f} {vz:.2f}\n")
        for f0, f1, f2 in faces:
            f.write(f"f {f0} {f1} {f2}\n")
    return str(out_path)

obj_path = make_longwire_bairdcage_38012(OUT_DIR / "bairdcage_38012_longwire.obj")
glass_rgba = make_stained_glass_png(OUT_DIR / "stained_glass.png")

# Place stained-glass window at (0, -40, 480) and point light at (0, -60, 900) shining THROUGH cage at (0, 20, -180) toward camera (0, 0, -1024)!
win_lay = FidelityLayer(index=2, name="Window", x=0.0, y=-20.0, z=420.0, zoom=130.0, alpha=1.0, image=glass_rgba, kind_override="OTHER")
cam = {"x": 0.0, "y": 0.0, "z": -1024.0, "tx": 0.0, "ty": 0.0, "tz": 0.0, "ux": 0.0, "uy": -1.0, "uz": 0.0, "rz": 0.0, "d": 1024.0}

scripts = [
    ("v2.86", ROOT / "releases/体積光（3D）_v2.86_稳定版/Script/体積光（3D）.obj2", False),
    ("v2.90", pathlib.Path("/tmp/vl_v290.obj2"), True),
    ("v2.91", ROOT / "scripts/pkg1/体积光（3D）/development/branch_v2.90_aux2_bridge/Script/体積光（3D）.obj2", True),
    ("v2.92_ref", OUT_DIR / "vl_v292_ref.obj2", True),
]

out = {}
for tag, sp, strict in scripts:
    br = VL3DBridgeMockHost(mode="v292_param_edit") if strict else None
    sess = PersistentAviUtl2Session(str(sp), width=2048, height=1080, strict_getvalue=strict, bridge=br)
    cage = FidelityLayer(
        index=3, name="bairdcage", x=0.0, y=20.0, z=-220.0, zoom=20.0, alpha=1.0,
        effects={"モデルファイル": {"ファイル": obj_path, "座標系を調整": 0}},
        kind_override="OBJ", model_path=obj_path,
    )
    p_vis = {
        "src_layer": 2, "ray_mode": 1, "screen_dir": False,
        "light_x": 0.0, "light_y": -40.0, "light_z": 950.0,
        "length": 1850.0, "intensity": 165.0, "decay": 35.0,
        "occ_mode": 1, "occ_3d_mode": 0, "occ_target": 0, "occ_strength": 100.0,
        "show_info": False, "log_mode": False, "res_mode": 1, "auto_slice": False, "slices": 32.0,
    }
    p_fast_gpu = {**p_vis, "slices": 8.0}
    r0 = sess.render_frame(params=p_vis, camera=cam, layers={2: win_lay, 3: cage}, self_layer=5, frame=0)
    Image.fromarray(r0["rgba8"]).save(IMG_DIR / f"longwire_2048_{tag.replace('.', '_')}.png")

    play_t = []
    for fi in (1, 2):
        rp = sess.render_frame(params=p_fast_gpu, camera=cam, layers={2: win_lay, 3: cage}, self_layer=5, frame=fi)
        play_t.append(rp["lua_cpu_ms"])

    drag_t = []
    for zv in (20.5, 21.0, 21.5):
        cage.zoom = zv
        rd = sess.render_frame(params=p_fast_gpu, camera=cam, layers={2: win_lay, 3: cage}, self_layer=5, frame=2)
        drag_t.append(rd["lua_cpu_ms"])

    out[tag] = {
        "cold_cpu_ms": round(r0["lua_cpu_ms"], 2),
        "play_cpu_ms": round(float(np.mean(play_t)), 2),
        "drag_scale_cpu_ms": round(float(np.mean(drag_t)), 2),
        "drag_fps_cap": round(1000.0 / max(float(np.mean(drag_t)), 1e-3), 2),
        "luma": round(float(r0["rgba8"][..., :3].mean()), 2),
    }
    print(f"[{tag}] cold_cpu={out[tag]['cold_cpu_ms']}ms | play_cpu={out[tag]['play_cpu_ms']}ms | drag_scale_cpu={out[tag]['drag_scale_cpu_ms']}ms ({out[tag]['drag_fps_cap']} fps)")

(OUT_DIR / "longwire_metrics.json").write_text(json.dumps(out, indent=2), encoding="utf-8")
