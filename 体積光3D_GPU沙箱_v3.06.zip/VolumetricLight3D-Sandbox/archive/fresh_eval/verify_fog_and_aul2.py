#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import json, pathlib, re, sys
import numpy as np
from PIL import Image

sys.path.insert(0, "/home/user/sandbox")
sys.path.insert(0, "/home/user/sandbox/fresh_eval")
from sandbox_v2_fidelity import PersistentAviUtl2Session

ROOT = pathlib.Path("/home/user")
OUT_DIR = ROOT / "sandbox/fresh_eval/outputs"
IMG_DIR = OUT_DIR / "renders"

# Check .aul2 stripping `=0` from `--select@var:label=0,...`
aul2_pairs = [
    ("vl_v286", ROOT / "releases/体積光（3D）_v2.86_稳定版/Script/体積光（3D）.obj2", ROOT / "releases/体積光（3D）_v2.86_稳定版/Language"),
    ("vl_v291", ROOT / "scripts/pkg1/体积光（3D）/development/branch_v2.90_aux2_bridge/Script/体積光（3D）.obj2", ROOT / "scripts/pkg1/体积光（3D）/development/branch_v2.90_aux2_bridge/Language"),
    ("fog_v202", ROOT / "releases/体積霧（3D）_v2.02_稳定版/Script/体積霧（3D）.obj2", ROOT / "releases/体積霧（3D）_v2.02_稳定版/Language"),
    ("snow_v119", ROOT / "releases/雪（3D）_v1.19_稳定版/Script/雪（3D）.obj2", ROOT / "releases/雪（3D）_v1.19_稳定版/Language"),
]
aul2_clean = {}
for tag, obj_p, lang_dir in aul2_pairs:
    src = obj_p.read_text(encoding="utf-8", errors="replace")
    ui_labels = []
    for line in src.splitlines():
        m = re.match(r'^--(track|check|select|color|value|file|group)@?[^:]*:([^,=\r\n]+)', line)
        if m:
            lbl = m.group(2).strip()
            if lbl and lbl not in ("true", "false"):
                ui_labels.append(lbl)
    per_lang = {}
    for lf in sorted(lang_dir.glob("*.aul2")) if lang_dir.exists() else []:
        ltxt = lf.read_text(encoding="utf-8", errors="replace")
        missing = [lbl for lbl in ui_labels if f"{lbl}=" not in ltxt]
        per_lang[lf.name] = {"total": len(ui_labels), "missing": missing}
    aul2_clean[tag] = per_lang
print("AUL2 clean:", json.dumps(aul2_clean, ensure_ascii=False, indent=2))

# Fog v2.02 Sphere Mode (p7.z > 0.5) near-camera slice sec_k = 4.0 test!
fog_p = ROOT / "releases/体積霧（3D）_v2.02_稳定版/Script/体積霧（3D）.obj2"
fog_fix_p = OUT_DIR / "fog_v202_seck_fixed.obj2"
cam_wide = {"x": 0.0, "y": 0.0, "z": -650.0, "tx": 0.0, "ty": 0.0, "tz": 0.0, "ux": 0.0, "uy": -1.0, "uz": 0.0, "rz": 0.0, "d": 380.0}
fp_sph = {"density": 55.0, "slices": 48.0, "view_mode": 2, "spread": 130.0, "area_z": 40.0, "area_d": 2400.0, "scatter": 0.0, "noise_scale": 500.0, "pattern": 0.0}
s_f202 = PersistentAviUtl2Session(str(fog_p), width=960, height=540)
s_ffix = PersistentAviUtl2Session(str(fog_fix_p), width=960, height=540)
rf_202 = s_f202.render_frame(params=fp_sph, camera=cam_wide, layers={}, self_layer=2, frame=0)["rgba8"]
rf_fix = s_ffix.render_frame(params=fp_sph, camera=cam_wide, layers={}, self_layer=2, frame=0)["rgba8"]
Image.fromarray(rf_202).save(IMG_DIR / "fog_v202_sphere_seck_bug.png")
Image.fromarray(rf_fix).save(IMG_DIR / "fog_v202_sphere_seck_fixed.png")

c202 = float(rf_202[240:300, 440:520, :3].mean()) / 255.0
e202 = float(rf_202[20:100, 20:120, :3].mean()) / 255.0
cfix = float(rf_fix[240:300, 440:520, :3].mean()) / 255.0
efix = float(rf_fix[20:100, 20:120, :3].mean()) / 255.0
print(f"Fog Sphere Mode (p7.z): v2.02 center={c202:.4f}, edge={e202:.4f}, edge/center={e202/max(c202,1e-5):.3f} | sec_k=1 center={cfix:.4f}, edge={efix:.4f}, edge/center={efix/max(cfix,1e-5):.3f}")
