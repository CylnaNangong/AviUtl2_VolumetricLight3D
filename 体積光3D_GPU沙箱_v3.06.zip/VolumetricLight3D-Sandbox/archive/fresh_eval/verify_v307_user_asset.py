#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Ready-to-run exact-replication harness for the user's Verse1 scene.

Usage (adjust params to match the user's close-up screenshot):
  python3 verify_v307_user_asset.py --statue /home/user/uploads/石膏像.png \
      --statue-zoom 110 --light-zoom 435 --out-tag user_repro

Renders the Verse1-m1-manual case with the user's actual statue PNG, reads the
occ2d atlas, and dumps render + atlas + shadow-diff diagnostics.
"""
import argparse
import pathlib
import sys

import numpy as np
from PIL import Image

sys.path.insert(0, "/home/user/sandbox")
sys.path.insert(0, "/home/user/sandbox/fresh_eval")

from generate_assets import make_stained_glass_png
from sandbox_v2_fidelity import FidelityLayer, PersistentAviUtl2Session, VL3DBridgeMockHost

ROOT = pathlib.Path("/home/user")
VL = ROOT / "GitHub_VolumetricLight3D/Script/体積光（3D）.obj2"
OUT = ROOT / "sandbox/fresh_eval/outputs/user_repro"
W, H = 640, 360

CAM = {"x": 0.0, "y": -40.0, "z": -1024.0, "tx": 0.0, "ty": 20.0, "tz": 0.0,
       "ux": 0.0, "uy": -1.0, "uz": 0.0, "rz": 0.0, "d": 1024.0}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--statue", required=True, help="path to the user's 石膏像.png")
    ap.add_argument("--light", default="", help="optional path to the user's light layer image")
    ap.add_argument("--statue-zoom", type=float, default=110.0)
    ap.add_argument("--statue-x", type=float, default=0.0)
    ap.add_argument("--statue-y", type=float, default=-30.0)
    ap.add_argument("--statue-z", type=float, default=140.0)
    ap.add_argument("--statue-ry", type=float, default=0.0)
    ap.add_argument("--light-zoom", type=float, default=435.0)
    ap.add_argument("--light-z", type=float, default=333.0)
    ap.add_argument("--occ-mode", type=int, default=1)
    ap.add_argument("--occ-soft", type=float, default=8.0)
    ap.add_argument("--occ-strength", type=float, default=100.0)
    ap.add_argument("--out-tag", default="user_repro")
    args = ap.parse_args()

    OUT.mkdir(parents=True, exist_ok=True)
    st_img = np.asarray(Image.open(args.statue).convert("RGBA")).copy()
    print(f"statue: {st_img.shape[1]}x{st_img.shape[0]} alpha_cov={float((st_img[...,3]>12).mean()):.3f}")
    if args.light:
        lt_img = np.asarray(Image.open(args.light).convert("RGBA")).copy()
    else:
        lt_img = make_stained_glass_png(OUT / "stained_glass.png")

    light = FidelityLayer(index=2, name="光源", x=0.0, y=-100.0, z=args.light_z,
                          zoom=args.light_zoom, alpha=1.0, image=lt_img, kind_override="OTHER")
    statue = FidelityLayer(index=4, name="石膏像", x=args.statue_x, y=args.statue_y,
                           z=args.statue_z, ry=args.statue_ry, zoom=args.statue_zoom,
                           alpha=1.0, image=st_img, kind_override="OTHER")

    params = {"src_layer": 2, "intensity": 150.0, "direction": 55.0, "pitch": 44.0,
              "occ_mode": args.occ_mode, "occ_3d_mode": 0, "occ_target": 2, "occ_list": "4",
              "occ_strength": args.occ_strength, "occ_soft": args.occ_soft,
              "log_mode": True, "show_info": False}

    br = VL3DBridgeMockHost(mode="v290_sdk_lock", scene_id=1)
    sess = PersistentAviUtl2Session(str(VL), width=W, height=H, strict_getvalue=True, bridge=br)
    res = sess.render_frame(params=params, camera=CAM, layers={2: light, 4: statue},
                            self_layer=10, frame=146, totalframe=619, frame_s=619, scene_id=1)
    assert res["error"] is None, res["error"]
    Image.fromarray(res["rgba8"]).save(OUT / f"{args.out_tag}.png")
    for l in res["logs"]:
        if "遮蔽" in l or "遮挡" in l:
            print("HUD:", l[:170])

    # reference without occlusion
    br0 = VL3DBridgeMockHost(mode="v290_sdk_lock", scene_id=1)
    sess0 = PersistentAviUtl2Session(str(VL), width=W, height=H, strict_getvalue=True, bridge=br0)
    res_b = sess0.render_frame(params=dict(params, occ_mode=0), camera=CAM, layers={2: light, 4: statue},
                               self_layer=10, frame=146, totalframe=619, frame_s=619, scene_id=1)
    diff = np.clip(res_b["rgba8"][..., :3].astype(np.int16) - res["rgba8"][..., :3].astype(np.int16), 0, 255).sum(axis=2)
    Image.fromarray(np.clip(diff / 3, 0, 255).astype(np.uint8)).save(OUT / f"{args.out_tag}_shadowdiff.png")
    ys, xs = np.nonzero(diff > 30)
    if len(xs):
        bw, bh = xs.max()-xs.min()+1, ys.max()-ys.min()+1
        print(f"shadow bbox: ({xs.min()},{ys.min()})-({xs.max()},{ys.max()}) fill={len(xs)/(bw*bh):.3f}")
    print("outputs:", OUT)


if __name__ == "__main__":
    main()
