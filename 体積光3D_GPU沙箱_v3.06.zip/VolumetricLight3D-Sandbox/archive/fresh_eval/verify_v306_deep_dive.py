#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Deep dive: read the saved occ2d atlas from the persist table, check its shape
(bust silhouette vs solid rectangle), test same-frame determinism and consecutive
frames (flicker), and structurally analyze the shadow diff for rectangular edges."""
import ctypes
import sys
import pathlib
import numpy as np
from PIL import Image

sys.path.insert(0, "/home/user/sandbox")
sys.path.insert(0, "/home/user/sandbox/fresh_eval")

from generate_assets import make_plaster_bust_png, make_stained_glass_png
from sandbox_v2_fidelity import FidelityLayer, PersistentAviUtl2Session, VL3DBridgeMockHost

ROOT = pathlib.Path("/home/user")
VL = ROOT / "GitHub_VolumetricLight3D/Script/体積光（3D）.obj2"
OUT = ROOT / "sandbox/fresh_eval/outputs/v306_repro"
OUT.mkdir(parents=True, exist_ok=True)
W, H = 640, 360

glass = make_stained_glass_png(OUT / "stained_glass.png")
bust = make_plaster_bust_png(OUT / "plaster_bust.png")

light = FidelityLayer(index=2, name="光源", x=0.0, y=-100.0, z=333.0, zoom=435.0,
                      alpha=1.0, image=glass, kind_override="OTHER")
statue = FidelityLayer(index=4, name="石膏像", x=0.0, y=-30.0, z=140.0, zoom=110.0,
                       alpha=1.0, image=bust, kind_override="OTHER")
CAM = {"x": 0.0, "y": -40.0, "z": -1024.0, "tx": 0.0, "ty": 20.0, "tz": 0.0,
       "ux": 0.0, "uy": -1.0, "uz": 0.0, "rz": 0.0, "d": 1024.0}
PARAMS = {"src_layer": 2, "intensity": 150.0, "direction": 55.0, "pitch": 44.0,
          "occ_mode": 1, "occ_3d_mode": 0, "occ_target": 2, "occ_list": "4",
          "occ_strength": 100.0, "occ_soft": 8.0, "log_mode": False, "show_info": False}


def read_occ2d_atlas(sess):
    lua_code = """
    (function()
        local ok, ffi = pcall(require, 'ffi')
        if not ok then return 0, 0 end
        local s = _G._VL3D_PERSIST_V280 and _G._VL3D_PERSIST_V280.occ2d
        if s == nil or s.rgba == nil or (s.w or 0) < 8 then return 0, 0 end
        return tonumber(ffi.cast('uintptr_t', s.rgba)), s.w, s.h
    end)()
    """
    r = sess.lua.eval(lua_code)
    if r is None or not r[0]:
        return None
    addr, w, h = int(r[0]), int(r[1]), int(r[2])
    data = ctypes.string_at(addr, w * h * 4)
    arr = np.frombuffer(data, dtype=np.uint8).reshape(h, w, 4).copy()
    return arr


def analyze_atlas(arr, tag):
    a = arr[..., 3].astype(np.float32)
    cov = float((a > 8).mean())
    # bust reference coverage in its own 512 image
    bust_a = bust[..., 3].astype(np.float32)
    ref_cov = float((bust_a > 8).mean())
    print(f"[{tag}] atlas {arr.shape[1]}x{arr.shape[0]} alpha coverage={cov:.4f} "
          f"(bust ref coverage={ref_cov:.4f}) -> "
          f"{'SOLID RECTANGLE (BUG!)' if cov > 0.93 else 'silhouette-shaped (OK)'}")
    Image.fromarray(arr).save(OUT / f"{tag}_occ2d_atlas.png")
    # column profile of alpha at middle row to show shape
    mid = a[arr.shape[0] // 2]
    runs = []
    inrun = False
    for i, v in enumerate(mid):
        if v > 8 and not inrun:
            start = i; inrun = True
        elif v <= 8 and inrun:
            runs.append((start, i)); inrun = False
    if inrun:
        runs.append((start, len(mid)))
    print(f"[{tag}] atlas mid-row alpha runs: {runs[:8]}")
    return cov


def rect_edge_score(diff):
    """Detect long straight hard edges in the shadow mask -> rectangle signature."""
    mask = diff > 30
    col_frac = mask.mean(axis=0)
    row_frac = mask.mean(axis=1)
    def longest_run_ge(fr, th=0.85):
        best = cur = 0
        for v in fr:
            cur = cur + 1 if v >= th else 0
            best = max(best, cur)
        return best
    v_edge = longest_run_ge(col_frac)
    h_edge = longest_run_ge(row_frac)
    return v_edge, h_edge, col_frac, row_frac


def main():
    br = VL3DBridgeMockHost(mode="v290_sdk_lock", scene_id=1)
    sess = PersistentAviUtl2Session(str(VL), width=W, height=H, strict_getvalue=True, bridge=br)
    layers = {2: light, 4: statue}

    # --- render same frame twice + consecutive frames ---
    frames = {}
    for i, fr in enumerate([146, 146, 147, 148]):
        res = sess.render_frame(params=dict(PARAMS), camera=CAM, layers=layers,
                                self_layer=10, frame=fr, totalframe=619, frame_s=619, scene_id=1)
        assert res["error"] is None, res["error"]
        frames[i] = res["rgba8"][..., :3].astype(np.int16)
        print(f"frame pass {i} (fr={fr}) rendered, ps_calls={res['pixelshader_calls']}")

    d_same = np.abs(frames[0] - frames[1]).max()
    d_next = np.abs(frames[1] - frames[2]).max()
    d_next2 = np.abs(frames[2] - frames[3]).max()
    print(f"determinism: same-frame rerender maxdiff={d_same} (0 => no flicker on rerender)")
    print(f"consecutive: 146->147 maxdiff={d_next}, 147->148 maxdiff={d_next2}")

    # --- read occ2d atlas ---
    arr = read_occ2d_atlas(sess)
    if arr is not None:
        analyze_atlas(arr, "A_repeat")
    else:
        print("occ2d atlas not saved (reentered?)")

    # --- reference (no occ) in separate session ---
    br0 = VL3DBridgeMockHost(mode="v290_sdk_lock", scene_id=1)
    sess0 = PersistentAviUtl2Session(str(VL), width=W, height=H, strict_getvalue=True, bridge=br0)
    res_b = sess0.render_frame(params=dict(PARAMS, occ_mode=0), camera=CAM, layers=layers,
                               self_layer=10, frame=146, totalframe=619, frame_s=619, scene_id=1)
    ref = res_b["rgba8"][..., :3].astype(np.int16)

    diff = np.clip(ref - frames[1], 0, 255).sum(axis=2)
    Image.fromarray(np.clip(diff / 3, 0, 255).astype(np.uint8)).save(OUT / "deep_shadow_diff.png")
    ys, xs = np.nonzero(diff > 30)
    if len(xs):
        v_edge, h_edge, col_frac, row_frac = rect_edge_score(diff)
        print(f"shadow bbox=({xs.min()},{ys.min()})-({xs.max()},{ys.max()}) "
              f"longest full-height col run={v_edge}, full-width row run={h_edge}")
        print(f"col_frac profile (every 40px): {[round(float(col_frac[i]),2) for i in range(0, W, 40)]}")
        print(f"row_frac profile (every 30px): {[round(float(row_frac[i]),2) for i in range(0, H, 30)]}")
        print("-> straight-edge signature:", "STRONG RECTANGLE" if v_edge > H * 0.9 or h_edge > W * 0.9 else "no clean rectangle")

    # --- hard vs soft edge check: gradient along the shadow boundary ---
    g = np.gradient(diff.astype(np.float32))
    gmag = np.hypot(g[0], g[1])
    bmask = diff > 30
    if bmask.any():
        edge = (gmag > 60) & bmask
        print(f"boundary sharpness: edge pixels={int(edge.sum())}, "
              f"sharp-edge fraction of boundary={float(edge.sum()) / max(int((gmag > 60).sum()), 1):.3f}")


if __name__ == "__main__":
    main()
