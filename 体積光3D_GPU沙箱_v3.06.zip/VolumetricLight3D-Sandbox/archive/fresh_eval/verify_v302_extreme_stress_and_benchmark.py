#!/usr/bin/env python3
"""
Pre-Release Extreme Stress Test & Objective Bridge vs Pure-LuaJIT Benchmark for 体積光（3D） v3.02:
Runs each heavy GPU suite in a clean subprocess so software-Vulkan (llvmpipe) frees 100% RAM between
ultra-large 8K UHD (7680x4320) & 50MP+ asset tests inside a 1.9GB RAM container.
"""
import gc
import json
import math
import os
import re
import subprocess
import sys
import tempfile
import time
from pathlib import Path
import numpy as np
from PIL import Image, ImageDraw

sys.path.insert(0, str(Path(__file__).resolve().parent))
from sandbox_v2_fidelity import FidelityLayer, PersistentAviUtl2Session, VL3DBridgeMockHost
from verify_v301_highres_blue_bug_fix import install_strict_aviutl2_cache_hooks

ROOT = Path("/home/user")
VL_V302 = ROOT / "scripts/pkg1/体积光（3D）/stable/Script/体積光（3D）.obj2"
LANG_DIR = ROOT / "scripts/pkg1/体积光（3D）/stable/Language"
OUT_DIR = Path(__file__).resolve().parent / "outputs"
OUT_DIR.mkdir(parents=True, exist_ok=True)


def generate_ornate_cage_obj(path: Path, rings: int = 24, segs: int = 88) -> int:
    verts = []
    tris = []
    n_bars = segs // 2
    for b in range(n_bars):
        ang = 2.0 * math.pi * b / n_bars
        cx, cz = math.cos(ang) * 260.0, math.sin(ang) * 260.0
        base = len(verts) + 1
        for r in range(rings + 1):
            y = -260.0 + 520.0 * (r / rings)
            for k in range(4):
                ka = 2.0 * math.pi * k / 4.0
                verts.append((cx + math.cos(ka) * 5.5, y, cz + math.sin(ka) * 5.5))
        for r in range(rings):
            i0, i1 = base + r * 4, base + (r + 1) * 4
            for k in range(4):
                kn = (k + 1) % 4
                tris.append((i0 + k, i0 + kn, i1 + kn))
                tris.append((i0 + k, i1 + kn, i1 + k))
    for r in range(rings):
        y = -250.0 + 500.0 * (r / max(rings - 1, 1))
        base = len(verts) + 1
        for s in range(segs):
            ang = 2.0 * math.pi * s / segs
            for k in range(4):
                ka = 2.0 * math.pi * k / 4.0
                rr = 260.0 + math.cos(ka) * 5.0
                yy = y + math.sin(ka) * 5.0
                verts.append((math.cos(ang) * rr, yy, math.sin(ang) * rr))
        for s in range(segs):
            sn = (s + 1) % segs
            i0, i1 = base + s * 4, base + sn * 4
            for k in range(4):
                kn = (k + 1) % 4
                tris.append((i0 + k, i0 + kn, i1 + kn))
                tris.append((i0 + k, i1 + kn, i1 + k))
    lines = ["# High-poly gothic cage"]
    for vx, vy, vz in verts:
        lines.append(f"v {vx * 0.01:.5f} {vy * 0.01:.5f} {vz * 0.01:.5f}")
    for a, b, c in tris:
        lines.append(f"f {a} {b} {c}")
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return len(tris)


def make_fast_stained_glass(w: int, h: int) -> np.ndarray:
    """Zero-copy tiled allocation of huge RGBA8 textures (no intermediate np.repeat bloat!)."""
    tw = min(w, 512)
    th = min(h, max(4, min(h, 512)))
    im = Image.new("RGBA", (tw, th), (16, 14, 38, 255))
    dr = ImageDraw.Draw(im)
    for k, col in enumerate([(255, 168, 64, 255), (242, 96, 212, 255), (72, 214, 255, 255)]):
        x0 = int(tw * (0.08 + k * 0.30))
        x1 = int(tw * (0.32 + k * 0.30))
        dr.rectangle([x0, int(th * 0.12), x1, max(int(th * 0.12) + 1, int(th * 0.88))], fill=col)
    tile = np.asarray(im, dtype=np.uint8)
    out = np.empty((h, w, 4), dtype=np.uint8)
    for y in range(0, h, th):
        yh = min(th, h - y)
        for x in range(0, w, tw):
            xw = min(tw, w - x)
            out[y:y+yh, x:x+xw] = tile[:yh, :xw]
    return out


def make_fast_sprite(w: int, h: int, color=(150, 90, 210)) -> np.ndarray:
    tw = min(w, 256)
    th = min(h, max(8, min(h, 256)))
    im = Image.new("RGBA", (tw, th), (0, 0, 0, 0))
    dr = ImageDraw.Draw(im)
    dr.ellipse([int(tw * 0.2), int(th * 0.08), int(tw * 0.8), int(th * 0.92)], fill=(*color, 255))
    small = np.asarray(im, dtype=np.float32)
    a = small[..., 3:4] / 255.0
    small[..., :3] = np.round(small[..., :3] * a)
    tile = np.clip(small, 0, 255).astype(np.uint8)
    out = np.empty((h, w, 4), dtype=np.uint8)
    for y in range(0, h, th):
        yh = min(th, h - y)
        for x in range(0, w, tw):
            xw = min(tw, w - x)
            out[y:y+yh, x:x+xw] = tile[:yh, :xw]
    return out


def worker_suite1() -> dict:
    src = VL_V302.read_text(encoding="utf-8")
    assert src.startswith("--information:体積光（3D）v3.02")
    ui_vars = re.findall(r"^--(?:track|select|check|color|string|value|figure|file)@([A-Za-z0-9_]+):", src, flags=re.M)
    shaders = re.findall(r"--\[\[pixelshader@([A-Za-z0-9_]+):", src)
    with tempfile.NamedTemporaryFile("w", suffix=".lua", encoding="utf-8", delete=False) as tf:
        tf.write("local " + ", ".join(ui_vars) + "\n" + src)
        tmp = tf.name
    bc = subprocess.check_output(["luajit", "-bl", tmp], text=True)
    os.unlink(tmp)
    blocks = bc.split("-- BYTECODE -- ")[1:]
    max_fn, main_r, gsets = 0, 0, 0
    for bi, blk in enumerate(blocks):
        regs = []
        for line in blk.splitlines()[1:]:
            m = re.match(r"^\d+\s+([A-Z0-9]+)\s+(.*)$", line)
            if not m:
                continue
            op, rest = m.group(1), m.group(2)
            if op == "GSET":
                gsets += 1
            nums = [int(x) for x in re.findall(r"\b(\d+)\b", rest.split(";")[0])]
            if nums and op not in ("JMP", "LOOP", "FORL", "IFORL", "JFORL", "UCLO"):
                regs.append(nums[0])
        mr = max(regs) if regs else 0
        if bi == len(blocks) - 1:
            main_r = mr
        else:
            max_fn = max(max_fn, mr)
    assert main_r < 190 and max_fn < 190 and gsets == 0
    assert len(shaders) == 14
    aul_counts = {}
    for aul in sorted(LANG_DIR.glob("*.体積光（3D）.aul2")):
        keys = [ln.split("=", 1)[0] for ln in aul.read_text(encoding="utf-8").splitlines() if "=" in ln and not ln.startswith(";")]
        aul_counts[aul.name] = len(keys)
    return {
        "ui_vars": len(ui_vars),
        "shader_count": len(shaders),
        "main_chunk_max_reg": main_r,
        "inner_fn_max_reg": max_fn,
        "gset_leaks": gsets,
        "aul2_entries": aul_counts,
    }


def worker_suite2_and_5() -> dict:
    vfiles = {r"C:\ProgramData\aviutl2\aviutl2.ini": b"[System]\r\nLanguage=\xe7\xae\x80\xe4\xbd\x93\xe4\xb8\xad\xe6\x96\x87\r\n"}
    br = VL3DBridgeMockHost(mode="v120_native", scene_id=0)
    sess = PersistentAviUtl2Session(str(VL_V302), width=640, height=360, bridge=br, restrict_stdlib=True, virtual_files=vfiles)
    diag = install_strict_aviutl2_cache_hooks(sess, max_rt_dim=4096, max_cache_dots=16_000_000)
    glass = make_fast_stained_glass(640, 360)
    sprite = make_fast_sprite(320, 480)
    cam = {"x": 0.0, "y": 0.0, "z": -1024.0, "tx": 0.0, "ty": 0.0, "tz": 0.0, "ux": 0.0, "uy": -1.0, "uz": 0.0, "rz": 0.0, "d": 540.0}
    layers = {2: FidelityLayer(index=2, name="画像ファイル", x=0.0, y=0.0, z=400.0, image=glass)}
    p = {"src_layer": 2, "length": 1200.0, "intensity": 100.0, "log_mode": 1}

    # Scene 0 first open
    r_s0_f0 = sess.render_frame(params=p, camera=cam, layers=layers, self_layer=4, frame=0)
    logs_s0 = r_s0_f0["logs"]
    assert logs_s0[0] == "@info\t体积光（3D）v3.02：初始化中……", f"Got: {logs_s0}"
    assert "体积光（3D）v3.02：初始化完成（耗时" in logs_s0[-1], f"Got: {logs_s0}"

    # Playback frames 1..3 -> zero init spam
    for f in (1, 2, 3):
        rf = sess.render_frame(params=p, camera=cam, layers=layers, self_layer=4, frame=f)
        assert not any("初始化" in x for x in rf["logs"])

    # Sub-composition Scene 1 first open -> emits once!
    br.scene_id = 1
    r_s1_f0 = sess.render_frame(params=p, camera=cam, layers=layers, self_layer=4, frame=0)
    assert r_s1_f0["logs"][0] == "@info\t体积光（3D）v3.02：初始化中……"
    assert "体积光（3D）v3.02：初始化完成（耗时" in r_s1_f0["logs"][-1]
    r_s1_f1 = sess.render_frame(params=p, camera=cam, layers=layers, self_layer=4, frame=1)
    assert not any("初始化" in x for x in r_s1_f1["logs"])

    # Back to Scene 0 -> zero repeat spam!
    br.scene_id = 0
    r_back = sess.render_frame(params=p, camera=cam, layers=layers, self_layer=4, frame=4)
    assert not any("初始化" in x for x in r_back["logs"])

    # Suite 5: Nested cross-layer re-entrancy + 20-frame scrub
    nested_layers = {
        2: FidelityLayer(index=2, name="画像ファイル", x=0.0, y=0.0, z=600.0, image=glass),
        4: FidelityLayer(index=4, name="画像ファイル", x=0.0, y=0.0, z=100.0, zoom=40.0, image=sprite),
        5: FidelityLayer(
            index=5, name="体積光（3D）", x=0.0, y=0.0, z=400.0, image=glass,
            sub_obj2_path=str(VL_V302), sub_params={"src_layer": 2, "length": 800.0, "intensity": 100.0, "occ_mode": 2},
        ),
    }
    rn = sess.render_frame(
        params={"src_layer": 5, "length": 1000.0, "intensity": 110.0, "occ_mode": 3, "ab_enable": 1, "ab_target": 1, "ab_list": "4"},
        camera=cam, layers=nested_layers, self_layer=7, frame=0,
    )
    assert rn["error"] is None and len(diag["rtv_errors"]) == 0

    lua_kb, post_dots = [], []
    for f in range(1, 21):
        rs = sess.render_frame(
            params={
                "src_layer": 2, "ray_mode": f % 3, "length": 900.0 + f * 30.0,
                "fog": float((f * 13) % 60), "occ_mode": (f % 4),
                "ab_enable": f % 2, "ab_style": f % 3, "ab_color_mode": f % 3,
            },
            camera=cam, layers={2: nested_layers[2], 4: nested_layers[4]}, self_layer=7, frame=f,
        )
        assert rs["error"] is None
        post_dots.append(sum(b.w * b.h for k, b in sess.sb.buffers.items() if k.startswith("cache:")))
        if f in (5, 20):
            sess.lua.execute("collectgarbage('collect')")
            lua_kb.append(round(float(sess.lua.eval("collectgarbage('count')")), 1))
    assert max(post_dots) <= 20
    return {
        "init_logs": {
            "scene0_first_open": logs_s0,
            "scene1_subcomp_first_open": r_s1_f0["logs"],
            "repeat_spam": 0,
        },
        "reentrancy_and_scrub": {
            "nested_reentrant_ok": True,
            "scrub_20_frames_errors": 0,
            "post_frame_cache_dots_min_max": [min(post_dots), max(post_dots)],
            "lua_heap_kb_frame5_vs_frame20": lua_kb,
        },
    }


def worker_suite3a() -> dict:
    """8192x6144 (50.33 MP!) light source + 4800x6000 (28.80 MP!) character sprite + AutoBlendLight ON."""
    br = VL3DBridgeMockHost(mode="v120_native", scene_id=0)
    sess = PersistentAviUtl2Session(str(VL_V302), width=1280, height=720, bridge=br, restrict_stdlib=True)
    diag = install_strict_aviutl2_cache_hooks(sess, max_rt_dim=4096, max_cache_dots=16_000_000)
    cam = {"x": 0.0, "y": 0.0, "z": -1024.0, "tx": 0.0, "ty": 0.0, "tz": 0.0, "ux": 0.0, "uy": -1.0, "uz": 0.0, "rz": 0.0, "d": 720.0}
    glass_50mp = make_fast_stained_glass(8192, 6144)
    sprite_29mp = make_fast_sprite(4800, 6000, (170, 110, 220))
    layers = {
        2: FidelityLayer(index=2, name="画像ファイル", x=0.0, y=0.0, z=1800.0, zoom=28.0, image=glass_50mp),
        4: FidelityLayer(index=4, name="画像ファイル", x=0.0, y=20.0, z=0.0, zoom=9.5, image=sprite_29mp),
    }
    r = sess.render_frame(
        params={
            "src_layer": 2, "length": 2200.0, "intensity": 120.0, "occ_mode": 3,
            "ab_enable": 1, "ab_target": 1, "ab_list": "4", "ab_strength": 130.0, "ab_env_blend": 35.0,
        },
        camera=cam, layers=layers, self_layer=6, frame=0,
    )
    assert r["error"] is None and len(diag["rtv_errors"]) == 0
    assert diag["max_single_cache_dim"] <= 2048 and diag["peak_live_cache_dots"] < 6_000_000
    return {
        "src_dim": "8192x6144 (50.33 MP)",
        "sprite_dim": "4800x6000 (28.80 MP)",
        "mean_luma": round(float(r["rgba8"][..., :3].mean()), 2),
        "max_cache_dim": diag["max_single_cache_dim"],
        "peak_live_cache_M": round(diag["peak_live_cache_dots"] / 1e6, 2),
        "rtv_errors": len(diag["rtv_errors"]),
    }


def worker_suite3bc() -> dict:
    """16384x16 D3D11-max-width strip + 5200x180 wide banner + 8 simultaneous foreground occluders."""
    br = VL3DBridgeMockHost(mode="v120_native", scene_id=0)
    sess = PersistentAviUtl2Session(str(VL_V302), width=1280, height=720, bridge=br, restrict_stdlib=True)
    diag = install_strict_aviutl2_cache_hooks(sess, max_rt_dim=4096, max_cache_dots=16_000_000)
    cam = {"x": 0.0, "y": 0.0, "z": -1024.0, "tx": 0.0, "ty": 0.0, "tz": 0.0, "ux": 0.0, "uy": -1.0, "uz": 0.0, "rz": 0.0, "d": 720.0}

    strip_16k = make_fast_stained_glass(16384, 16)
    banner_5k = make_fast_sprite(5200, 180, (90, 160, 220))
    r3b = sess.render_frame(
        params={"src_layer": 2, "length": 1400.0, "intensity": 130.0, "occ_mode": 3, "ab_enable": 1, "ab_target": 1, "ab_list": "4"},
        camera=cam,
        layers={
            2: FidelityLayer(index=2, name="画像ファイル", x=0.0, y=-100.0, z=900.0, zoom=12.0, image=strip_16k),
            4: FidelityLayer(index=4, name="画像ファイル", x=0.0, y=0.0, z=0.0, zoom=25.0, image=banner_5k),
        },
        self_layer=6, frame=0,
    )
    assert r3b["error"] is None and len(diag["rtv_errors"]) == 0

    glass_std = make_fast_stained_glass(2400, 1600)
    sp_mid = make_fast_sprite(1600, 2200, (190, 180, 200))
    layers_3c = {2: FidelityLayer(index=2, name="画像ファイル", x=0.0, y=0.0, z=1200.0, zoom=80.0, image=glass_std)}
    for idx in range(3, 10):
        layers_3c[idx] = FidelityLayer(
            index=idx, name="画像ファイル",
            x=-420.0 + (idx - 3) * 140.0, y=0.0, z=200.0 - (idx - 3) * 20.0, zoom=18.0, image=sp_mid
        )
    layers_3c[10] = FidelityLayer(
        index=10, name="テキスト", x=-200.0, y=100.0, z=-150.0, zoom=100.0,
        image=make_fast_sprite(320, 96, (255, 255, 255)),
        effects={"テキスト": {"文字揃え": "左寄せ[上]", "サイズ": "48"}},
    )
    r3c = sess.render_frame(
        params={"src_layer": 2, "length": 1600.0, "intensity": 120.0, "occ_mode": 3, "ab_enable": 1, "ab_target": 1, "ab_list": "4-6"},
        camera=cam, layers=layers_3c, self_layer=12, frame=1,
    )
    assert r3c["error"] is None and len(diag["rtv_errors"]) == 0
    assert diag["max_single_cache_dim"] <= 2048 and diag["peak_live_cache_dots"] < 6_500_000
    return {
        "strip_16384x16_and_banner_5200x180_luma": round(float(r3b["rgba8"][..., :3].mean()), 2),
        "eight_foreground_layers_3x3_atlas_luma": round(float(r3c["rgba8"][..., :3].mean()), 2),
        "max_cache_dim": diag["max_single_cache_dim"],
        "peak_live_cache_M": round(diag["peak_live_cache_dots"] / 1e6, 2),
        "rtv_errors": len(diag["rtv_errors"]),
    }


def worker_canvas(spec: str) -> dict:
    """spec: 'W,H,res_mode' e.g. '7680,4320,1'"""
    W, H, res_m = [int(x) for x in spec.split(",")]
    with tempfile.TemporaryDirectory() as td:
        cage = Path(td) / "cage.obj"
        generate_ornate_cage_obj(cage, rings=8, segs=32)
        glass = make_fast_stained_glass(2400, 1500)
        sprite = make_fast_sprite(1800, 2400, (160, 120, 210))
        br = VL3DBridgeMockHost(mode="v120_native", scene_id=0)
        sess = PersistentAviUtl2Session(str(VL_V302), width=W, height=H, bridge=br, restrict_stdlib=True)
        diag = install_strict_aviutl2_cache_hooks(sess, max_rt_dim=4096, max_cache_dots=16_000_000)
        cam = {"x": 0.0, "y": 0.0, "z": -1024.0, "tx": 0.0, "ty": 0.0, "tz": 0.0, "ux": 0.0, "uy": -1.0, "uz": 0.0, "rz": 0.0, "d": float(H)}
        layers = {
            2: FidelityLayer(index=2, name="画像ファイル", x=0.0, y=0.0, z=900.0, zoom=60.0, image=glass),
            3: FidelityLayer(index=3, name="3Dモデル", x=-120.0, y=0.0, z=260.0, zoom=100.0, kind_override="OBJ", model_path=str(cage)),
            4: FidelityLayer(index=4, name="画像ファイル", x=140.0, y=20.0, z=60.0, zoom=24.0, image=sprite),
        }
        r = sess.render_frame(
            params={
                "src_layer": 2, "res_mode": res_m, "length": 1500.0, "intensity": 120.0,
                "occ_mode": 3, "ab_enable": 1, "ab_target": 1, "ab_list": "4",
            },
            camera=cam, layers=layers, self_layer=6, frame=0,
        )
        assert r["error"] is None, f"Canvas {W}x{H} error: {r['error']}"
        assert len(diag["rtv_errors"]) == 0, f"Canvas {W}x{H} RTV errors: {diag['rtv_errors']}"
        assert diag["max_single_cache_dim"] <= 2048
        assert diag["peak_live_cache_dots"] < 9_000_000
        luma = float(r["rgba8"][..., :3].mean())
        assert luma > 2.0
        return {
            "resolution": f"{W}x{H}",
            "canvas_mp": round((W * H) / 1e6, 2),
            "res_mode": res_m,
            "lua_cpu_ms": round(r["lua_cpu_ms"], 2),
            "peak_live_cache_M": round(diag["peak_live_cache_dots"] / 1e6, 2),
            "max_cache_dim": diag["max_single_cache_dim"],
            "rtv_errors": len(diag["rtv_errors"]),
            "mean_luma": round(luma, 2),
            "log": r["logs"][1] if len(r["logs"]) > 1 else "",
        }


def worker_bench_one(spec: str) -> dict:
    """spec: '<rings>,<segs>,<use_bridge:0|1>'"""
    rings, segs, use_b_int = [int(x) for x in spec.split(",")]
    use_bridge = bool(use_b_int)
    with tempfile.TemporaryDirectory() as td:
        tmp_dir = Path(td)
        obj_file = tmp_dir / "bench.obj"
        nt = generate_ornate_cage_obj(obj_file, rings=rings, segs=segs)

        aup2_lines = ["[project]", "width=1280", "height=720", "[scene.0]", "scene=0"]
        oid = 0
        for extra in range(110):
            aup2_lines += [
                f"[{oid}]", f"layer={10 + (extra % 20)}", f"frame={extra*10},{extra*10+90}",
                f"[{oid}.0]", "effect.name=テキスト", "サイズ=36", "文字揃え=左寄せ[上]", "テキスト=BenchmarkSubtitleLine",
            ]
            oid += 1
        aup2_lines += [
            f"[{oid}]", "layer=1", "frame=0,9999", f"[{oid}.0]", "effect.name=画像ファイル", "ファイル=glass.png",
            f"[{oid+1}]", "layer=2", "frame=0,9999", f"[{oid+1}.0]", "effect.name=3Dモデル", f"ファイル={obj_file}", "座標系を調整=0",
            f"[{oid+2}]", "layer=3", "frame=0,9999", f"[{oid+2}.0]", "effect.name=テキスト", "サイズ=48", "文字揃え=左寄せ[上]",
        ]
        aup2_bytes = ("\r\n".join(aup2_lines) + "\r\n").encode("utf-8")
        proj_dir = str(tmp_dir)
        proj_file = str(tmp_dir / "bench_project.aup2")
        (tmp_dir / "bench_project.aup2").write_bytes(aup2_bytes)

        br = VL3DBridgeMockHost(mode="v120_native", scene_id=0) if use_bridge else None
        vfiles = {
            proj_file: aup2_bytes,
            r"C:\ProgramData\aviutl2\aviutl2.ini": f"[System]\r\nfile={proj_file}\r\n".encode("utf-8"),
        }
        sess = PersistentAviUtl2Session(str(VL_V302), width=640, height=360, bridge=br, restrict_stdlib=True, virtual_files=vfiles)

        glass = make_fast_stained_glass(960, 540)
        txt_img = make_fast_sprite(320, 88, (240, 240, 240))
        cam = {"x": 0.0, "y": 0.0, "z": -1024.0, "tx": 0.0, "ty": 0.0, "tz": 0.0, "ux": 0.0, "uy": -1.0, "uz": 0.0, "rz": 0.0, "d": 640.0}
        layers = {
            2: FidelityLayer(index=2, name="画像ファイル", x=0.0, y=0.0, z=700.0, zoom=100.0, image=glass),
            3: FidelityLayer(index=3, name="3Dモデル", x=0.0, y=0.0, z=220.0, zoom=100.0, kind_override="OBJ", model_path=str(obj_file)),
            4: FidelityLayer(
                index=4, name="テキスト", x=-160.0, y=90.0, z=-80.0, zoom=100.0, image=txt_img,
                effects={"テキスト": {"文字揃え": "左寄せ[上]", "サイズ": "48"}},
            ),
        }
        p = {"src_layer": 2, "res_mode": 1, "slices": 32, "auto_slice": 0, "length": 1300.0, "intensity": 115.0, "occ_mode": 3, "log_mode": 1}

        # 1) Cold Frame 0
        r_cold = sess.render_frame(params=p, camera=cam, layers=layers, self_layer=6, frame=0)
        assert r_cold["error"] is None

        # 2) Warm Static Cached Frames
        static_ms = []
        for f in range(1, 6):
            rs = sess.render_frame(params=p, camera=cam, layers=layers, self_layer=6, frame=f)
            static_ms.append(rs["lua_cpu_ms"])

        # 3) Animated 3D Model Full-Quality Frames (1280² shadow + 1280x720 camocc every frame!)
        anim_ms = []
        for step in range(1, 6):
            layers[3].ry = step * 11.5
            ra = sess.render_frame(params=p, camera=cam, layers=layers, self_layer=6, frame=10 + step)
            anim_ms.append(ra["lua_cpu_ms"])

        # 4) Live Interactive Drag on Frame 20
        sess.render_frame(params=p, camera=cam, layers=layers, self_layer=6, frame=20)
        drag_ms = []
        drag_tris_list = []
        for dstep in range(1, 9):
            layers[3].x = -80.0 + dstep * 20.0
            layers[3].ry = 30.0 + dstep * 7.0
            rd = sess.render_frame(params=p, camera=cam, layers=layers, self_layer=6, frame=20)
            drag_ms.append(rd["lua_cpu_ms"])
            tr_d = int(sess.lua.eval("(_VL3D_PERSIST_V280.occ_stats and _VL3D_PERSIST_V280.occ_stats.last_tris) or 0"))
            if tr_d > 0:
                drag_tris_list.append(tr_d)
        if use_bridge:
            assert br.rast_shadow_calls >= 12 and br.rast_camdepth_calls >= 12, (
                f"Expected native C++ rasterizer calls! Got sh={br.rast_shadow_calls}, cm={br.rast_camdepth_calls}"
            )
        drag_tris_last = int(np.median(drag_tris_list)) if drag_tris_list else 0
        stat_med = float(np.median(static_ms))
        anim_med = float(np.median(anim_ms))
        drag_med = float(np.median(drag_ms))

        return {
            "triangles": nt,
            "cold_init_cpu_ms": round(r_cold["lua_cpu_ms"], 2),
            "static_cached_cpu_ms_median": round(stat_med, 2),
            "animated_full_1280_cpu_ms_median": round(anim_med, 2),
            "pure_3d_rast_delta_ms": round(max(0.05, anim_med - stat_med), 2),
            "live_drag_cpu_ms_median": round(drag_med, 2),
            "live_drag_tris_rendered": drag_tris_last,
            "live_drag_completeness_pct": round(100.0 * drag_tris_last / max(nt, 1), 1),
        }


def run_worker_cmd(mode: str, arg: str = "") -> dict:
    cmd = [sys.executable, __file__, "--worker", mode] + ([arg] if arg else [])
    out = subprocess.check_output(cmd, text=True)
    for ln in reversed(out.strip().splitlines()):
        if ln.startswith("JSON_OUT:"):
            return json.loads(ln[len("JSON_OUT:"):])
    raise RuntimeError(f"Worker {mode} {arg} missing JSON_OUT: {out}")


def main():
    if len(sys.argv) >= 3 and sys.argv[1] == "--worker":
        wmode = sys.argv[2]
        warg = sys.argv[3] if len(sys.argv) >= 4 else ""
        if wmode == "s1":
            res = worker_suite1()
        elif wmode == "s2_5":
            res = worker_suite2_and_5()
        elif wmode == "s3a":
            res = worker_suite3a()
        elif wmode == "s3bc":
            res = worker_suite3bc()
        elif wmode == "canvas":
            res = worker_canvas(warg)
        elif wmode == "bench":
            res = worker_bench_one(warg)
        else:
            raise ValueError(wmode)
        print("JSON_OUT:" + json.dumps(res, ensure_ascii=False))
        return

    t_all = time.perf_counter()
    print("[1/6] Suite 1: Static LuaJIT Bytecode + HLSL + .aul2 Audit...")
    r1 = run_worker_cmd("s1")
    print(" ", json.dumps(r1, ensure_ascii=False), flush=True)

    print("[2/6] Suite 2 & 5: First-Open / Sub-Composition Init Logs + Re-Entrancy + 20-Frame Scrub...", flush=True)
    r2_5 = run_worker_cmd("s2_5")
    print(" ", json.dumps(r2_5, ensure_ascii=False), flush=True)

    print("[3/6] Suite 3A: Ultra-Large Assets (8192x6144 = 50.33MP Source + 4800x6000 = 28.80MP Sprite + AutoBlendLight)...", flush=True)
    r3a = run_worker_cmd("s3a")
    print(" ", json.dumps(r3a, ensure_ascii=False), flush=True)

    print("[3/6] Suite 3B/C: 16384x16 D3D11-Max-Width Strip + 5200x180 Banner + 8-Layer 3x3 Occlusion Pack...", flush=True)
    r3bc = run_worker_cmd("s3bc")
    print(" ", json.dumps(r3bc, ensure_ascii=False), flush=True)

    print("[4/6] Suite 4: Ultra-Large Canvases (FHD High3584, 4K UHD High3584, 4K Portrait, 8K UHD 7680x4320)...", flush=True)
    r4 = {}
    for lbl, spec in [
        ("FHD_1920x1080_High3584", "1920,1080,0"),
        ("4K_UHD_3840x2160_High3584", "3840,2160,0"),
        ("4K_Portrait_2160x3840_Std2560", "2160,3840,1"),
        ("8K_UHD_7680x4320_Std2560", "7680,4320,1"),
    ]:
        r4[lbl] = run_worker_cmd("canvas", spec)
        print(f"  {lbl}:", json.dumps(r4[lbl], ensure_ascii=False), flush=True)

    print("[6/6] Suite 6: Head-to-Head VL3DBridge v1.21 (C++17 -O3) vs Pure LuaJIT Fallback Benchmark...", flush=True)
    b_med_br = run_worker_cmd("bench", "12,44,1")
    b_med_lj = run_worker_cmd("bench", "12,44,0")
    b_hvy_br = run_worker_cmd("bench", "24,88,1")
    b_hvy_lj = run_worker_cmd("bench", "24,88,0")
    b_ext_br = run_worker_cmd("bench", "36,132,1")
    b_ext_lj = run_worker_cmd("bench", "36,132,0")

    r6 = {
        "medium_6k": {
            "VL3DBridge_CPP_O3": b_med_br,
            "Pure_LuaJIT_FFI": b_med_lj,
            "total_frame_cpu_speedup_x": round(b_med_lj["animated_full_1280_cpu_ms_median"] / max(b_med_br["animated_full_1280_cpu_ms_median"], 0.1), 2),
            "rast_stage_speedup_x": round(b_med_lj["pure_3d_rast_delta_ms"] / max(b_med_br["pure_3d_rast_delta_ms"], 0.05), 2),
        },
        "heavy_25k": {
            "VL3DBridge_CPP_O3": b_hvy_br,
            "Pure_LuaJIT_FFI": b_hvy_lj,
            "total_frame_cpu_speedup_x": round(b_hvy_lj["animated_full_1280_cpu_ms_median"] / max(b_hvy_br["animated_full_1280_cpu_ms_median"], 0.1), 2),
            "rast_stage_speedup_x": round(b_hvy_lj["pure_3d_rast_delta_ms"] / max(b_hvy_br["pure_3d_rast_delta_ms"], 0.05), 2),
        },
        "extreme_57k": {
            "VL3DBridge_CPP_O3": b_ext_br,
            "Pure_LuaJIT_FFI": b_ext_lj,
            "total_frame_cpu_speedup_x": round(b_ext_lj["animated_full_1280_cpu_ms_median"] / max(b_ext_br["animated_full_1280_cpu_ms_median"], 0.1), 2),
            "rast_stage_speedup_x": round(b_ext_lj["pure_3d_rast_delta_ms"] / max(b_ext_br["pure_3d_rast_delta_ms"], 0.05), 2),
        },
    }
    print(" ", json.dumps(r6, indent=2, ensure_ascii=False), flush=True)

    report = {
        "suite1_static": r1,
        "suite2_and_5": r2_5,
        "suite3a_ultra_50mp": r3a,
        "suite3bc_extreme_strip_and_8layers": r3bc,
        "suite4_ultra_canvases": r4,
        "suite6_benchmark": r6,
        "total_wall_sec": round(time.perf_counter() - t_all, 2),
    }
    out_json = OUT_DIR / "verify_v302_extreme_stress_and_benchmark.json"
    out_json.write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
    print(f"\nALL 6 EXTREME STRESS & BENCHMARK SUITES PASSED in {report['total_wall_sec']}s! Saved: {out_json}")


if __name__ == "__main__":
    main()
