#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Upgraded High-Fidelity AviUtl2 Sandbox (v2) for Independent Verification
========================================================================
Directly reuses the Vulkan 1.4 (`wgpu` + `glslangValidator`) GPU pipeline in
`aviutl2_sandbox.py` while fixing all 8 fidelity blind spots discovered during
our independent audit:
  1. Isolated fresh SPIR-V compilation (`/home/user/sandbox/fresh_eval/spv_fresh`).
  2. Persistent `LuaRuntime` VM across multi-frame playback & drag/scale ticks.
  3. Strict `obj.getvalue` (`--file` and `--color` items return `nil`; disabled layers return `nil`;
     both 1-arg `"layer3.fx.item"` and 3-arg `("layer3", fx, item)` forms supported).
  4. Accurate `obj.getinfo` (`"script_path"`, `"saving"`, `"version"`, `"image_max"`; `"clock"` -> `nil`).
  5. Live `obj.module("VL3DBridge")` bridge (`v290_sdk_lock` vs `v292_param_edit`).
  6. Re-entrant `obj.load("layer", idx, true)` on the same `LuaRuntime` VM.
  7. Unmasked `--check` numeric `0/1` testing (`raw_numeric_checks=True`) without Python `bool(0)` masking.
  8. Explicit capture of swallowed Lua `pcall` / `[體積光3D-ERR]` errors and drawpoly quad metrics.
"""

import ctypes
import hashlib
import math
import os
import pathlib
import re
import shutil
import sys
import time
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
from PIL import Image, ImageDraw, ImageFont
import wgpu
from lupa.luajit21 import LuaRuntime

sys.path.insert(0, "/home/user/sandbox")
import aviutl2_sandbox as base_sb
from aviutl2_sandbox import (
    AviUtl2Sandbox,
    CompiledHLSL,
    SceneLayer,
    parse_camera_basis,
    parse_obj2_script,
    rot_xyz_np,
)

FRESH_DIR = pathlib.Path("/home/user/sandbox/fresh_eval")
FRESH_SPV_DIR = FRESH_DIR / "spv_fresh"

NON_NUMERIC_ITEMS = {
    "ファイル", "モデルファイル", "VRMファイル", "VRMAファイル",
    "色", "光の色", "霧の色", "雪の色",
}


def reset_fresh_spv_cache() -> pathlib.Path:
    if FRESH_SPV_DIR.exists():
        shutil.rmtree(FRESH_SPV_DIR)
    FRESH_SPV_DIR.mkdir(parents=True, exist_ok=True)
    base_sb.SPV_CACHE_DIR = FRESH_SPV_DIR
    return FRESH_SPV_DIR


@dataclass
class FidelityLayer(SceneLayer):
    enabled: bool = True
    kind_override: Optional[str] = None
    model_path: str = ""
    coord_adj: int = 0
    water_color: int = -1
    sub_obj2_path: Optional[str] = None
    sub_params: Dict[str, Any] = field(default_factory=dict)

    def __init__(
        self,
        index: int = 1,
        name: str = "",
        x: float = 0.0,
        y: float = 0.0,
        z: float = 0.0,
        rx: float = 0.0,
        ry: float = 0.0,
        rz: float = 0.0,
        zoom: float = 100.0,
        alpha: float = 1.0,
        image: Optional[np.ndarray] = None,
        effects: Optional[Dict[str, Dict[str, Any]]] = None,
        enabled: bool = True,
        kind_override: Optional[str] = None,
        model_path: str = "",
        coord_adj: int = 0,
        water_color: int = -1,
        sub_obj2_path: Optional[str] = None,
        sub_params: Optional[Dict[str, Any]] = None,
        raw_image: Optional[np.ndarray] = None,
        start_frame: int = 0,
        end_frame: int = 100000000,
    ):
        super().__init__(
            layer_id=index,
            x=x, y=y, z=z, rx=rx, ry=ry, rz=rz, zoom=zoom, alpha=alpha,
            rgba_image=image, effects=effects or {},
        )
        self.index = index
        self.name = name
        self.enabled = enabled
        self.kind_override = kind_override
        self.model_path = model_path
        self.coord_adj = coord_adj
        self.water_color = water_color
        self.sub_obj2_path = sub_obj2_path
        self.sub_params = sub_params or {}
        self.raw_rgba_image = raw_image
        self.start_frame = int(start_frame)
        self.end_frame = int(end_frame)


class VL3DBridgeMockHost:
    """Models VL3DBridge.aux2 interacting with AviUtl2 EDIT_HANDLE / SCRIPT_MODULE_PARAM::edit."""

    def __init__(self, mode: str = "v290_sdk_lock", scene_id: int = 0):
        self.mode = mode
        self.scene_id = scene_id
        self.drag_edit_locked = False
        self.resolve_calls = 0
        self.deadlock_hits = 0
        self.deadlock_layers: List[int] = []

    def resolve_layer(self, layers: Dict[int, FidelityLayer], layer1: int, frame0: int) -> Tuple[Any, ...]:
        self.resolve_calls += 1
        if self.mode == "v290_sdk_lock" and self.drag_edit_locked:
            self.deadlock_hits += 1
            self.deadlock_layers.append(int(layer1))
            raise RuntimeError(
                f"HOST_SRWLOCK_DEADLOCK: VL3DBridge::ResolveLayer(layer={layer1}, frame={frame0}) "
                f"blocked on EDIT_HANDLE::call_read_section_param while GUI holds exclusive drag-edit lock!"
            )

        lay = layers.get(int(layer1))
        tier = "SDK" if self.mode == "v290_sdk_lock" else "SDK_PARAM_EDIT"
        if lay is None:
            return ("EMPTY", "", "", 0, self.scene_id, -1, tier)
        if not lay.enabled:
            return ("HIDDEN", "", "", 0, self.scene_id, -1, tier)
        if int(frame0) < int(lay.start_frame) or int(frame0) > int(lay.end_frame):
            return ("EMPTY", "", "", 0, self.scene_id, -1, tier)

        kind = lay.kind_override
        fx_name = ""
        path = lay.model_path or ""
        adj = int(lay.coord_adj)
        wcol = int(lay.water_color)

        if kind is None:
            if "モデルファイル" in lay.effects:
                kind = "OBJ"
                fx_name = "モデルファイル"
                fx = lay.effects["モデルファイル"]
                path = path or str(fx.get("ファイル") or fx.get("モデルファイル") or "")
                adj = int(fx.get("座標系を調整", adj))
            elif "VRMToolkitModel" in lay.effects:
                kind = "VRM"
                fx_name = "VRMToolkitModel"
                fx = lay.effects["VRMToolkitModel"]
                path = path or str(fx.get("VRMファイル") or "")
            elif "水面" in lay.effects:
                kind = "WATER"
                fx_name = "水面"
                wcol = int(lay.effects["水面"].get("色", 0x66C8FF))
            elif "テキスト" in lay.effects or lay.name == "テキスト":
                kind = "OTHER"
                fx_name = "テキスト"
            elif lay.rgba_image is not None or lay.sub_obj2_path is not None:
                kind = "OTHER"
                fx_name = lay.name or "画像ファイル"
            else:
                kind = "EMPTY"

        is_text = (fx_name == "テキスト")
        afx, afy, pl, pr, pt, pb = 0.0, 0.0, 0.0, 0.0, 0.0, 0.0
        if is_text:
            tfx = lay.effects.get("テキスト", {})
            align_s = str(tfx.get("文字揃え", "左寄せ[上]")).strip()
            deco_s = str(tfx.get("文字装飾", "標準文字")).strip()
            fsize = float(tfx.get("サイズ", 32.0))
            align_map = {
                "左寄せ[上]": (-0.5, -0.5), "中央揃え[上]": (0.0, -0.5), "右寄せ[上]": (0.5, -0.5),
                "左寄せ[中]": (-0.5,  0.0), "中央揃え[中]": (0.0,  0.0), "右寄せ[中]": (0.5,  0.0),
                "左寄せ[下]": (-0.5,  0.5), "中央揃え[下]": (0.0,  0.5), "右寄せ[下]": (0.5,  0.5),
                "縦書 上寄[右]": (0.5, -0.5), "縦書 中央[右]": (0.5, 0.0), "縦書 下寄[右]": (0.5, 0.5),
                "縦書 上寄[中]": (0.0, -0.5), "縦書 中央[中]": (0.0, 0.0), "縦書 下寄[中]": (0.0, 0.5),
                "縦書 上寄[左]": (-0.5, -0.5), "縦書 中央[左]": (-0.5, 0.0), "縦書 下寄[左]": (-0.5, 0.5),
                "左对齐[上]": (-0.5, -0.5), "居中对齐[中]": (0.0, 0.0), "右对齐[下]": (0.5, 0.5),
            }
            afx, afy = align_map.get(align_s, (-0.5, -0.5))
            if deco_s in ("影付き文字", "带阴影文字", "1"):
                s = max(1.0, float(int(fsize * 0.06)))
                pr, pb = s, s
            elif deco_s in ("影付き文字(薄)", "2"):
                s = max(1.0, float(int(fsize * 0.03)))
                pr, pb = s, s
            elif deco_s in ("縁取り文字", "3"):
                p = max(1.0, float(int(fsize * 0.15)))
                pl = pr = pt = pb = p

        return (kind, fx_name, path, adj, self.scene_id, wcol, tier, is_text, afx, afy, pl, pr, pt, pb)


class PersistentAviUtl2Session:
    """Persistent LuaJIT 2.1 VM + Vulkan GPU session matching real AviUtl2 ExEdit2."""

    def __init__(
        self,
        obj2_path: str,
        width: int = 1280,
        height: int = 720,
        strict_getvalue: bool = True,
        bridge: Optional[VL3DBridgeMockHost] = None,
        raw_numeric_checks: bool = False,
        restrict_stdlib: bool = True,
        virtual_files: Optional[Dict[str, bytes]] = None,
    ):
        self.obj2_path = str(pathlib.Path(obj2_path).resolve())
        self.script_dir = str(pathlib.Path(self.obj2_path).parent) + "/"
        self.defaults, self.shaders_src, self.lua_code = parse_obj2_script(self.obj2_path)
        self.sb = AviUtl2Sandbox(screen_w=width, screen_h=height)
        self.strict_getvalue = strict_getvalue
        self.bridge = bridge
        self.raw_numeric_checks = raw_numeric_checks
        self.restrict_stdlib = restrict_stdlib
        self.virtual_files = virtual_files or {}
        self.saving = False
        self._native_so = None
        so_path = pathlib.Path("/home/user/sandbox/libvl3d_bridge_linux.so")
        if so_path.exists():
            self._native_so = ctypes.CDLL(str(so_path))
            self._native_so.vl3d_test_wall_time_sec.argtypes = []
            self._native_so.vl3d_test_wall_time_sec.restype = ctypes.c_double
            self._native_so.vl3d_test_has_mesh.argtypes = [ctypes.c_char_p, ctypes.c_char_p]
            self._native_so.vl3d_test_has_mesh.restype = ctypes.c_int32
            self._native_so.vl3d_test_upload_mesh_b64.argtypes = [
                ctypes.c_char_p, ctypes.c_char_p, ctypes.c_int, ctypes.c_int, ctypes.c_char_p, ctypes.c_char_p
            ]
            self._native_so.vl3d_test_upload_mesh_b64.restype = ctypes.c_int32
            self._native_so.vl3d_test_rasterize_shadow.argtypes = [
                ctypes.c_void_p, ctypes.c_int, ctypes.POINTER(ctypes.c_double),
                ctypes.POINTER(ctypes.c_double), ctypes.c_int,
                ctypes.POINTER(ctypes.c_int), ctypes.POINTER(ctypes.c_int),
            ]
            self._native_so.vl3d_test_rasterize_shadow.restype = ctypes.c_int
            self._native_so.vl3d_test_rasterize_camdepth.argtypes = [
                ctypes.c_void_p, ctypes.c_int, ctypes.c_int, ctypes.POINTER(ctypes.c_double),
                ctypes.POINTER(ctypes.c_double), ctypes.c_int,
                ctypes.POINTER(ctypes.c_int), ctypes.POINTER(ctypes.c_int),
            ]
            self._native_so.vl3d_test_rasterize_camdepth.restype = ctypes.c_int

        # Compile all embedded HLSL shaders via glslangValidator -> SPIR-V -> wgpu
        self.compiled_shaders: Dict[str, Tuple[str, CompiledHLSL]] = {}
        for sname, scode in self.shaders_src.items():
            h = hashlib.sha256((sname + "::" + scode).encode("utf-8")).hexdigest()[:24]
            self.compiled_shaders[sname] = (h, self.sb.gpu.compile_hlsl(sname, scode))

        # Single persistent LuaJIT 2.1 VM across frames!
        self.lua = LuaRuntime(unpack_returned_tuples=True)
        self.logs: List[str] = []
        self.layer_load_calls: List[int] = []
        self.last_ps_consts: Dict[str, List[float]] = {}
        self.getpixeldata_calls: int = 0
        self._reentrant_depth: int = 0
        self._cur_layers: Dict[int, FidelityLayer] = {}

        self._setup_vm()

    def _setup_vm(self):
        lua = self.lua
        g = lua.globals()
        lua.execute("""
        local ffi = require("ffi")
        _G.global = _G.global or {}
        _SANDBOX_PIXBUF = {}
        function _sandbox_alloc_pix(name, nbytes)
            local b = _SANDBOX_PIXBUF[name]
            if b == nil or b.n < nbytes then
                b = { cdata = ffi.new("uint8_t[?]", nbytes), n = nbytes }
                _SANDBOX_PIXBUF[name] = b
            end
            return b.cdata, tonumber(ffi.cast("uintptr_t", b.cdata))
        end
        function _sandbox_ptr_addr(p)
            return tonumber(ffi.cast("uintptr_t", p))
        end
        """)
        self._alloc_pix_lua = g._sandbox_alloc_pix
        self._ptr_addr_lua = g._sandbox_ptr_addr
        self._wrap_lua_fn = lua.eval("function(pyfn) return function(...) return pyfn(...) end end")
        self._multi_ret_resolve = lua.eval("""
        function(pyfn)
            return function(a, b)
                local t = pyfn(a, b)
                if t == nil then return nil end
                return t[1], t[2], t[3], t[4], t[5], t[6], t[7], t[8], t[9], t[10], t[11], t[12], t[13], t[14]
            end
        end
        """)

        def capture_print(*args):
            self.logs.append("\t".join(str(a) for a in args))

        g["print"] = self._wrap_lua_fn(capture_print)
        g["debug_print"] = self._wrap_lua_fn(capture_print)

        if self.restrict_stdlib:
            def py_vfile_hex(path_str):
                norm = str(path_str).replace("/", "\\")
                for k, v in self.virtual_files.items():
                    if k.replace("/", "\\").lower() == norm.lower():
                        return v.hex()
                return None
            g._sbx_vfile_hex = py_vfile_hex
            # Emulate Windows kernel32 UTF-16LE file & QPC APIs for Linux host, then wipe _G.os, _G.io, _G.debug
            # exactly matching AviUtl ExEdit2 v2.1.15's restricted LuaJIT sandbox!
            lua.execute("""
            do
                local ffi = require("ffi")
                local real_io_open = io.open
                local vfile_hex = _G._sbx_vfile_hex
                _G._sbx_vfile_hex = nil
                local function vfile_get(p)
                    if not vfile_hex then return nil end
                    local hx = vfile_hex(p)
                    if type(hx) ~= "string" then return nil end
                    return (hx:gsub("..", function(cc) return string.char(tonumber(cc, 16)) end))
                end
                pcall(ffi.cdef, "typedef struct { long tv_sec; long tv_nsec; } _sbx_ts_t; int clock_gettime(int, _sbx_ts_t*);")
                local _handles = {}
                local _next_h = 100
                local _ts = ffi.new("_sbx_ts_t[1]")
                local function _u16_to_utf8(wptr)
                    if wptr == nil then return "" end
                    local p = ffi.cast("const uint16_t*", wptr)
                    local out = {}
                    local i = 0
                    while i < 4096 do
                        local u = p[i]
                        if u == 0 then break end
                        if u >= 0xD800 and u <= 0xDBFF then
                            local u2 = p[i + 1]
                            if u2 >= 0xDC00 and u2 <= 0xDFFF then
                                u = 0x10000 + (u - 0xD800) * 1024 + (u2 - 0xDC00)
                                i = i + 1
                            end
                        end
                        i = i + 1
                        if u < 0x80 then out[#out + 1] = string.char(u)
                        elseif u < 0x800 then out[#out + 1] = string.char(0xC0 + math.floor(u / 64), 0x80 + (u % 64))
                        elseif u < 0x10000 then out[#out + 1] = string.char(0xE0 + math.floor(u / 4096), 0x80 + (math.floor(u / 64) % 64), 0x80 + (u % 64))
                        else out[#out + 1] = string.char(0xF0 + math.floor(u / 262144), 0x80 + (math.floor(u / 4096) % 64), 0x80 + (math.floor(u / 64) % 64), 0x80 + (u % 64)) end
                    end
                    return table.concat(out)
                end
                _G.VL3D_TEST_W32_API = {
                    ffi = ffi,
                    CreateFileW = function(wpath, access, share, sec, disp, flags, tmpl)
                        local raw = _u16_to_utf8(wpath)
                        local vdata = vfile_get and vfile_get(raw) or nil
                        if vdata ~= nil then
                            _next_h = _next_h + 1
                            _handles[_next_h] = { data = vdata, pos = 0 }
                            return _next_h
                        end
                        local path = raw:gsub("\\\\", "/")
                        local fh = real_io_open(path, "rb")
                        if fh == nil then return -1 end
                        local data = fh:read("*a") or ""
                        fh:close()
                        _next_h = _next_h + 1
                        _handles[_next_h] = { data = data, pos = 0 }
                        return _next_h
                    end,
                    GetFileSizeEx = function(h, out_sz)
                        local e = _handles[tonumber(h)]
                        if e == nil then return 0 end
                        ffi.cast("int64_t*", out_sz)[0] = #e.data
                        return 1
                    end,
                    ReadFile = function(h, dst, n_req, out_rd, ovl)
                        local e = _handles[tonumber(h)]
                        if e == nil then return 0 end
                        local rem = #e.data - e.pos
                        local n = math.min(tonumber(n_req) or 0, math.max(0, rem))
                        if n > 0 then
                            ffi.copy(dst, e.data:sub(e.pos + 1, e.pos + n), n)
                            e.pos = e.pos + n
                        end
                        if out_rd ~= nil then ffi.cast("uint32_t*", out_rd)[0] = n end
                        return 1
                    end,
                    CloseHandle = function(h)
                        _handles[tonumber(h)] = nil
                        return 1
                    end,
                    QueryPerformanceFrequency = function(out_hz)
                        ffi.cast("int64_t*", out_hz)[0] = 1000000000LL
                        return 1
                    end,
                    QueryPerformanceCounter = function(out_c)
                        ffi.C.clock_gettime(1, _ts)
                        ffi.cast("int64_t*", out_c)[0] = ffi.cast("int64_t", _ts[0].tv_sec) * 1000000000LL + ffi.cast("int64_t", _ts[0].tv_nsec)
                        return 1
                    end,
                }
                _G.os = nil
                _G.io = nil
                _G.debug = nil
                if package and package.loaded then
                    package.loaded.os = nil
                    package.loaded.io = nil
                    package.loaded.debug = nil
                end
            end
            """)

    def render_frame(
        self,
        params: Optional[Dict[str, Any]] = None,
        camera: Optional[Dict[str, float]] = None,
        layers: Optional[Dict[int, FidelityLayer]] = None,
        self_layer: int = 2,
        frame: int = 0,
        totalframe: int = 300,
        fps: float = 30.0,
        obj_pos: Tuple[float, float, float] = (0.0, 0.0, 0.0),
        obj_rot: Tuple[float, float, float] = (0.0, 0.0, 0.0),
        background_rgba: Optional[np.ndarray] = None,
        frame_s: int = 0,
        scene_id: Optional[int] = None,
    ) -> Dict[str, Any]:
        sb = self.sb
        lua = self.lua
        g = lua.globals()

        self._cur_layers = dict(layers or {})
        sb.layers = {k: v for k, v in self._cur_layers.items() if v.enabled}
        sb.camera_mode = 1 if camera is not None else 0
        sb.camera_param = dict(camera) if camera is not None else None

        self.logs.clear()
        self.layer_load_calls.clear()
        self.getpixeldata_calls = 0

        # Prepare background framebuffer
        sb.ensure_buffer("framebuffer", sb.screen_w, sb.screen_h, clear=True)
        if background_rgba is not None:
            sb.upload_numpy("framebuffer", background_rgba)
        else:
            bg = np.zeros((sb.screen_h, sb.screen_w, 4), dtype=np.uint8)
            bg[..., 0], bg[..., 1], bg[..., 2], bg[..., 3] = 10, 13, 18, 255
            sb.upload_numpy("framebuffer", bg)
        sb.ensure_buffer("object", 1, 1, clear=True)
        sb.ensure_buffer("tempbuffer", sb.screen_w, sb.screen_h, clear=True)

        merged_params = dict(self.defaults)
        if params:
            for k, v in params.items():
                if (
                    not self.raw_numeric_checks
                    and k in self.defaults
                    and isinstance(self.defaults[k], bool)
                    and isinstance(v, (int, float))
                ):
                    merged_params[k] = bool(v)
                else:
                    merged_params[k] = v

        state = {
            "drawtarget": "framebuffer",
            "blend": 0,
            "billboard": 0,
            "antialias": 1,
            "culling": 0,
            "sampler": "clamp",
            "font_name": "Noto Sans CJK JP",
            "font_size": 22,
            "font_type": 0,
            "font_col1": 0xFFFFFF,
            "font_col2": 0x000000,
            "pixelshader_calls": 0,
            "drawpoly_calls": 0,
            "drawpoly_verts": 0,
            "drawpoly_quads": 0,
            "gpu_ms": 0.0,
        }

        props = {
            "x": float(obj_pos[0]), "y": float(obj_pos[1]), "z": float(obj_pos[2]),
            "ox": 0.0, "oy": 0.0, "oz": 0.0,
            "rx": float(obj_rot[0]), "ry": float(obj_rot[1]), "rz": float(obj_rot[2]),
            "cx": 0.0, "cy": 0.0, "cz": 0.0,
            "zoom": 1.0, "alpha": 1.0, "aspect": 0.0,
            "time": float(frame) / max(float(fps), 1e-6),
            "totaltime": float(totalframe) / max(float(fps), 1e-6),
            "frame": int(frame), "totalframe": int(totalframe), "framerate": float(fps),
            "frame_s": int(frame_s), "frame_e": int(frame_s) + max(0, int(totalframe) - 1),
            "originframe": int(frame_s) + int(frame),
            "scene_id": int(scene_id) if scene_id is not None else int(self.bridge.scene_id if self.bridge else 0),
            "layer": int(self_layer), "index": 0, "num": 1,
            "w": 0, "h": 0, "screen_w": sb.screen_w, "screen_h": sb.screen_h,
        }
        obj_tbl = lua.table()
        for k, v in props.items():
            obj_tbl[k] = v

        pix_ptrs: Dict[str, Tuple[Any, int, int, int]] = {}

        def sync_obj_wh(w: int, h: int):
            obj_tbl["w"] = int(w)
            obj_tbl["h"] = int(h)

        def lua_table_to_floats(ltbl) -> List[float]:
            if ltbl is None:
                return []
            out, idx = [], 1
            while True:
                v = ltbl[idx]
                if v is None:
                    break
                out.append(float(v))
                idx += 1
            return out

        def lua_table_to_strings(ltbl) -> List[str]:
            if ltbl is None:
                return []
            out, idx = [], 1
            while True:
                v = ltbl[idx]
                if v is None:
                    break
                out.append(str(v))
                idx += 1
            return out

        def _lookup_fx_prop(ln: int, fx_name: str, item_name: str):
            lay = self._cur_layers.get(ln)
            if lay is None or (self.strict_getvalue and not lay.enabled):
                return None
            if self.strict_getvalue and item_name in NON_NUMERIC_ITEMS:
                return None
            fx = lay.effects.get(fx_name)
            if fx is None or item_name not in fx:
                return None
            val = fx[item_name]
            if self.strict_getvalue and isinstance(val, str) and item_name not in ("文字揃え", "文字装飾"):
                return None
            return val

        def api_getvalue(*args):
            if len(args) == 1:
                key = str(args[0])
                if key == "scenechange":
                    return 0.0
                if key == "zoom":
                    return float(obj_tbl["zoom"]) * 100.0
                if key in ("frame_s", "frame_e"):
                    return int(obj_tbl[key])
                if key in ("x", "y", "z", "rx", "ry", "rz", "cx", "cy", "cz", "alpha", "aspect", "time"):
                    return float(obj_tbl[key])
                m_ex = re.match(r"^layer(\d+)$", key)
                if m_ex:
                    ln = int(m_ex.group(1))
                    lay = self._cur_layers.get(ln)
                    if lay is None or (self.strict_getvalue and not lay.enabled):
                        return None
                    return True
                m_dot3 = re.match(r"^layer(\d+)\.([^.]+)\.(.+)$", key)
                if m_dot3:
                    return _lookup_fx_prop(int(m_dot3.group(1)), m_dot3.group(2), m_dot3.group(3))
                m = re.match(r"^layer(\d+)\.([a-zA-Z0-9_]+)$", key)
                if m:
                    ln = int(m.group(1))
                    attr = m.group(2)
                    lay = self._cur_layers.get(ln)
                    if lay is None or (self.strict_getvalue and not lay.enabled):
                        return None
                    if attr == "time":
                        return float(obj_tbl["time"])
                    return getattr(lay, attr, None)
                return None
            elif len(args) >= 3:
                ln_arg, fx_name, item_name = args[0], str(args[1]), str(args[2])
                ln = int(ln_arg.replace("layer", "")) if isinstance(ln_arg, str) and ln_arg.startswith("layer") else int(ln_arg)
                return _lookup_fx_prop(ln, fx_name, item_name)
            return None

        def api_getinfo(name, *args):
            nm = str(name)
            if nm == "script_path":
                return self.script_dir
            if nm == "saving":
                return bool(self.saving)
            if nm == "version":
                return 2011500
            if nm == "image_max":
                return 16384, 16384
            # Real AviUtl2 has NO "clock" key -> returns nil!
            return None

        def api_getoption(name, *args):
            nm = str(name)
            if nm == "camera_mode":
                return sb.camera_mode
            if nm == "camera_param":
                if sb.camera_param is None:
                    return None
                t = lua.table()
                for k, v in sb.camera_param.items():
                    t[k] = float(v)
                return t
            if nm == "multi_object":
                return False
            return None

        def api_setoption(name, val=None, *args):
            nm = str(name)
            if nm in ("drawtarget", "sampler"):
                state[nm] = str(val)
            elif nm == "blend":
                state["blend"] = val
            elif nm in ("billboard", "antialias", "culling"):
                state[nm] = int(val) if isinstance(val, (int, float)) else 0
            return True

        def api_clearbuffer(target, w=None, h=None, color=None):
            tg = time.perf_counter()
            tname = str(target)
            if w is not None and h is not None:
                buf = sb.ensure_buffer(tname, int(w), int(h), clear=True)
            else:
                cur = sb.buffers.get(tname)
                buf = sb.ensure_buffer(tname, cur.w if cur else sb.screen_w, cur.h if cur else sb.screen_h, clear=True)
            if tname == "object":
                sync_obj_wh(buf.w, buf.h)
            state["gpu_ms"] += (time.perf_counter() - tg) * 1000.0
            return True

        def api_copybuffer(dst_name, src_name):
            tg = time.perf_counter()
            dn, sn = str(dst_name), str(src_name)
            sbuf = sb.buffers.get(sn)
            if sbuf is None:
                return False
            if (dn == "framebuffer") != (sn == "framebuffer"):
                arr = sb.read_numpy(sn)
                dbuf = sb.upload_numpy(dn, arr)
            else:
                dbuf = sb.ensure_buffer(dn, sbuf.w, sbuf.h, clear=False)
                enc = sb.gpu.device.create_command_encoder()
                enc.copy_texture_to_texture(
                    {"texture": sbuf.texture, "mip_level": 0, "origin": (0, 0, 0)},
                    {"texture": dbuf.texture, "mip_level": 0, "origin": (0, 0, 0)},
                    (sbuf.w, sbuf.h, 1),
                )
                sb.gpu.device.queue.submit([enc.finish()])
            if dn == "object":
                sync_obj_wh(dbuf.w, dbuf.h)
            state["gpu_ms"] += (time.perf_counter() - tg) * 1000.0
            return True

        def api_getpixel(*args):
            tg = time.perf_counter()
            ob = sb.buffers.get("object")
            if ob is None:
                return 0, 0
            if len(args) == 0:
                return ob.w, ob.h
            arr = sb.read_numpy("object")
            state["gpu_ms"] += (time.perf_counter() - tg) * 1000.0
            x = max(0, min(ob.w - 1, int(args[0])))
            y = max(0, min(ob.h - 1, int(args[1])))
            r, g_c, b, a = arr[y, x]
            return (int(r) << 16) | (int(g_c) << 8) | int(b), float(a) / 255.0

        def api_getpixeldata(target="object", *args):
            tg = time.perf_counter()
            self.getpixeldata_calls += 1
            tname = str(target)
            buf = sb.buffers.get(tname)
            if buf is None or buf.w <= 0 or buf.h <= 0:
                return None, 0, 0
            arr = sb.read_numpy(tname)
            nbytes = buf.w * buf.h * 4
            cdata, addr = self._alloc_pix_lua(tname, nbytes)
            ctypes.memmove(int(addr), arr.ctypes.data, nbytes)
            pix_ptrs[tname] = (cdata, int(addr), buf.w, buf.h)
            state["gpu_ms"] += (time.perf_counter() - tg) * 1000.0
            return cdata, buf.w, buf.h

        def api_putpixeldata(target, data_ptr, w=None, h=None, *args):
            tg = time.perf_counter()
            tname = str(target)
            buf = sb.buffers.get(tname)
            bw = int(w) if w is not None else (buf.w if buf else 0)
            bh = int(h) if h is not None else (buf.h if buf else 0)
            if bw <= 0 or bh <= 0:
                return False
            addr = int(self._ptr_addr_lua(data_ptr))
            arr = np.empty((bh, bw, 4), dtype=np.uint8)
            ctypes.memmove(arr.ctypes.data, addr, bw * bh * 4)
            sb.upload_numpy(tname, arr)
            if tname == "object":
                sync_obj_wh(bw, bh)
            state["gpu_ms"] += (time.perf_counter() - tg) * 1000.0
            return True

        def api_setfont(name="Noto Sans CJK JP", size=24, ftype=0, col1=0xFFFFFF, col2=0x000000):
            state["font_name"] = str(name)
            state["font_size"] = max(8, int(size))
            state["font_type"] = int(ftype or 0)
            state["font_col1"] = int(col1 if col1 is not None else 0xFFFFFF)
            state["font_col2"] = int(col2 if col2 is not None else 0x000000)

        def api_load(kind, *args):
            tg_ld = time.perf_counter()
            k = str(kind)
            if k == "figure":
                fig_name = str(args[0]) if len(args) >= 1 else "円"
                col = int(args[1]) if len(args) >= 2 and args[1] is not None else 0xFFFFFF
                sz = int(args[2]) if len(args) >= 3 and args[2] is not None else 100
                arr = sb.render_figure_rgba(fig_name, col, sz)
                sb.upload_numpy("object", arr)
                sync_obj_wh(sz, sz)
                state["gpu_ms"] += (time.perf_counter() - tg_ld) * 1000.0
                return True
            elif k == "layer":
                ln = int(args[0])
                run_fx = bool(args[1]) if len(args) >= 2 else False
                self.layer_load_calls.append(ln)
                lay = self._cur_layers.get(ln)
                if lay is None or not lay.enabled:
                    sync_obj_wh(0, 0)
                    return False
                if run_fx and lay.sub_obj2_path and self._reentrant_depth < 1:
                    self._reentrant_depth += 1
                    try:
                        sub_def, sub_sh, sub_lua = parse_obj2_script(lay.sub_obj2_path)
                        for sname, scode in sub_sh.items():
                            if sname not in self.compiled_shaders:
                                h = hashlib.sha256((sname + "::" + scode).encode("utf-8")).hexdigest()[:24]
                                self.compiled_shaders[sname] = (h, sb.gpu.compile_hlsl(sname, scode))
                        saved_layer = obj_tbl["layer"]
                        obj_tbl["layer"] = ln
                        for pk, pv in {**sub_def, **lay.sub_params}.items():
                            g[pk] = pv
                        lua.execute(sub_lua)
                        obj_tbl["layer"] = saved_layer
                        for pk, pv in merged_params.items():
                            g[pk] = pv
                    finally:
                        self._reentrant_depth -= 1
                img_to_load = (lay.raw_rgba_image if (not run_fx and lay.raw_rgba_image is not None) else lay.rgba_image)
                if img_to_load is None:
                    sync_obj_wh(0, 0)
                    return False
                tg_up = time.perf_counter()
                sb.upload_numpy("object", img_to_load)
                sync_obj_wh(img_to_load.shape[1], img_to_load.shape[0])
                state["gpu_ms"] += (time.perf_counter() - tg_up) * 1000.0
                return True
            elif k == "tempbuffer":
                if "tempbuffer" not in sb.buffers:
                    return False
                return api_copybuffer("object", "tempbuffer")
            elif k == "text":
                txt = str(args[0]) if args else ""
                fsz = state["font_size"]
                im = Image.new("RGBA", (max(32, len(txt) * fsz), fsz + 12), (0, 0, 0, 0))
                arr = np.asarray(im, dtype=np.uint8)
                sb.upload_numpy("object", arr)
                sync_obj_wh(arr.shape[1], arr.shape[0])
                return True
            return False

        def api_pixelshader(ps_name, dst_name, res_tbl=None, const_tbl=None, blend_mode="copy", sampler_mode="clamp"):
            sname = str(ps_name)
            if sname not in self.compiled_shaders:
                return False
            spv_key, comp = self.compiled_shaders[sname]
            dst = sb.buffers.get(str(dst_name))
            if dst is None:
                return False
            res_names = lua_table_to_strings(res_tbl)
            consts = lua_table_to_floats(const_tbl)
            self.last_ps_consts[sname] = list(consts)
            bmode = str(blend_mode) if blend_mode is not None else "copy"
            smode = str(sampler_mode) if sampler_mode is not None else "clamp"
            bgl, pipe = sb.gpu.get_ps_pipeline(comp, spv_key, bmode, smode == "dot")

            bg_entries = []
            if comp.has_cbuffer:
                n_f = max(256, ((len(consts) + 3) // 4) * 4)
                carr = np.zeros(n_f, dtype=np.float32)
                if consts:
                    carr[: len(consts)] = consts
                cbuf = sb.gpu.device.create_buffer_with_data(data=carr, usage=wgpu.BufferUsage.UNIFORM)
                bg_entries.append({"binding": 0, "resource": {"buffer": cbuf}})
            for slot in comp.tex_slots:
                tview = sb.buffers[res_names[slot]].view if (slot < len(res_names) and res_names[slot] in sb.buffers) else sb.gpu.dummy_view
                bg_entries.append({"binding": 10 + slot, "resource": tview})
            if comp.has_sampler:
                bg_entries.append({"binding": 20, "resource": sb.gpu.samplers.get(smode, sb.gpu.samplers["clamp"])})

            tg0 = time.perf_counter()
            bg = sb.gpu.device.create_bind_group(layout=bgl, entries=bg_entries)
            enc = sb.gpu.device.create_command_encoder()
            rp = enc.begin_render_pass(color_attachments=[{"view": dst.view, "load_op": "load", "store_op": "store"}])
            rp.set_pipeline(pipe)
            rp.set_bind_group(0, bg)
            rp.draw(3)
            rp.end()
            sb.gpu.device.queue.submit([enc.finish()])
            state["gpu_ms"] += (time.perf_counter() - tg0) * 1000.0
            state["pixelshader_calls"] += 1
            return True

        def _resolve_blend():
            b = state["blend"]
            if b == "none":
                return "none_oit", True
            if b in (1, "add", "alpha_add"):
                return "add", False
            if b in (3, "screen"):
                return "screen", False
            return "normal", False

        def api_drawpoly(*args):
            if not args:
                return
            ob = sb.buffers.get("object")
            if ob is None:
                return
            tw, th = max(1.0, float(ob.w)), max(1.0, float(ob.h))
            tris_pos, tris_uv, tris_col = [], [], []
            untextured_vcol = False
            poly_alpha = float(obj_tbl["alpha"])

            if not isinstance(args[0], (int, float)):
                vtbl = args[0]
                n_prim = int(args[1]) if len(args) >= 2 and args[1] is not None else 4
                if n_prim not in (3, 4):
                    n_prim = 4
                if len(args) >= 3 and args[2] is not None:
                    poly_alpha *= float(args[2])
                raw_verts, idx = [], 1
                while True:
                    v = vtbl[idx]
                    if v is None:
                        break
                    raw_verts.append(v)
                    idx += 1
                n_groups = len(raw_verts) // n_prim
                if n_groups <= 0:
                    return
                state["drawpoly_quads"] += n_groups
                v0 = raw_verts[0]
                vlen = 0
                while v0[vlen + 1] is not None:
                    vlen += 1
                if vlen >= 7:
                    untextured_vcol = True
                default_uvs4 = [(0.0, 0.0), (1.0, 0.0), (1.0, 1.0), (0.0, 1.0)]
                default_uvs3 = [(0.0, 0.0), (1.0, 0.0), (0.0, 1.0)]
                tri_indices = [(0, 1, 2), (0, 2, 3)] if n_prim == 4 else [(0, 1, 2)]
                for gi in range(n_groups):
                    gp, gu, gc = [], [], []
                    base_i = gi * n_prim
                    for k in range(n_prim):
                        vk = raw_verts[base_i + k]
                        gp.append((float(vk[1]), float(vk[2]), float(vk[3])))
                        if vlen >= 7:
                            gu.append((0.5, 0.5))
                            gc.append((float(vk[4]), float(vk[5]), float(vk[6]), float(vk[7])))
                        elif vlen >= 5:
                            gu.append((float(vk[4]), float(vk[5])))
                            gc.append((1.0, 1.0, 1.0, 1.0))
                        else:
                            gu.append(default_uvs4[k] if n_prim == 4 else default_uvs3[k])
                            gc.append((1.0, 1.0, 1.0, 1.0))
                    for i0, i1, i2 in tri_indices:
                        tris_pos.append((gp[i0], gp[i1], gp[i2]))
                        tris_uv.append((gu[i0], gu[i1], gu[i2]))
                        tris_col.append((gc[i0], gc[i1], gc[i2]))
            else:
                state["drawpoly_quads"] += 1
                nums = [float(x) for x in args]
                qp = [(nums[0], nums[1], nums[2]), (nums[3], nums[4], nums[5]),
                      (nums[6], nums[7], nums[8]), (nums[9], nums[10], nums[11])]
                if len(nums) >= 20:
                    qu = [(nums[12] / tw, nums[13] / th), (nums[14] / tw, nums[15] / th),
                          (nums[16] / tw, nums[17] / th), (nums[18] / tw, nums[19] / th)]
                    if len(nums) >= 21:
                        poly_alpha *= nums[20]
                else:
                    qu = [(0.0, 0.0), (1.0, 0.0), (1.0, 1.0), (0.0, 1.0)]
                qc = [(1.0, 1.0, 1.0, 1.0)] * 4
                for i0, i1, i2 in ((0, 1, 2), (0, 2, 3)):
                    tris_pos.append((qp[i0], qp[i1], qp[i2]))
                    tris_uv.append((qu[i0], qu[i1], qu[i2]))
                    tris_col.append((qc[i0], qc[i1], qc[i2]))

            tri_pos_np = np.array(tris_pos, dtype=np.float64)
            tri_uv_np = np.array(tris_uv, dtype=np.float32)
            tri_col_np = np.array(tris_col, dtype=np.float32)
            target_name = state["drawtarget"]
            dst_buf = sb.ensure_buffer(target_name, sb.screen_w, sb.screen_h, clear=True) if target_name not in sb.buffers else sb.buffers[target_name]
            blend_key, shader118_none = _resolve_blend()
            ox = float(obj_tbl["x"]) + float(obj_tbl["ox"] or 0.0)
            oy = float(obj_tbl["y"]) + float(obj_tbl["oy"] or 0.0)
            oz = float(obj_tbl["z"]) + float(obj_tbl["oz"] or 0.0)

            tg_dp = time.perf_counter()
            if target_name != "framebuffer" or sb.camera_mode == 0:
                zm = float(obj_tbl["zoom"])
                px = tri_pos_np[..., 0] * zm + ox
                py = tri_pos_np[..., 1] * zm + oy
                clip4 = np.zeros((tri_pos_np.shape[0], 3, 4), dtype=np.float32)
                clip4[..., 0] = px / (0.5 * dst_buf.w)
                clip4[..., 1] = -py / (0.5 * dst_buf.h)
                clip4[..., 3] = 1.0
                vbuf_data = np.concatenate(
                    [clip4.reshape(-1, 4), tri_uv_np.reshape(-1, 2), tri_col_np.reshape(-1, 4)], axis=-1
                ).astype(np.float32)
                sb._submit_poly_draw(
                    target_name=target_name, src_name="object", vbuf_data=vbuf_data,
                    blend_key=blend_key, shader118_none=shader118_none, poly_alpha=poly_alpha,
                    use_depth=False, depth_write=False, sampler_mode=state["sampler"],
                    untextured_vcol=untextured_vcol,
                )
            else:
                rx, ry, rz = float(obj_tbl["rx"]), float(obj_tbl["ry"]), float(obj_tbl["rz"])
                cx, cy, cz = float(obj_tbl["cx"]), float(obj_tbl["cy"]), float(obj_tbl["cz"])
                zm = float(obj_tbl["zoom"])
                loc = (tri_pos_np - np.array([cx, cy, cz])) * zm
                if state["billboard"] == 3:
                    _, cam_r, cam_d, cam_f, _ = parse_camera_basis(sb.camera_param, sb.screen_w, sb.screen_h)
                    wld = (
                        loc[..., 0:1] * cam_r[None, None, :]
                        + loc[..., 1:2] * cam_d[None, None, :]
                        + loc[..., 2:3] * cam_f[None, None, :]
                        + np.array([ox, oy, oz])[None, None, :]
                    )
                else:
                    wld = rot_xyz_np(loc, rx, ry, rz) + np.array([ox, oy, oz])[None, None, :]
                vbuf_data = sb.project_world_triangles(wld, tri_uv_np, tri_col_np)
                if vbuf_data is not None:
                    sb._submit_poly_draw(
                        target_name=target_name, src_name="object", vbuf_data=vbuf_data,
                        blend_key=blend_key, shader118_none=shader118_none, poly_alpha=poly_alpha,
                        use_depth=True, depth_write=False, sampler_mode=state["sampler"],
                        untextured_vcol=untextured_vcol,
                    )
            state["gpu_ms"] += (time.perf_counter() - tg_dp) * 1000.0
            state["drawpoly_calls"] += 1

        def api_draw(dx=0.0, dy=0.0, dz=0.0, zoom=1.0, alpha=1.0, rx=0.0, ry=0.0, rz=0.0):
            ob = sb.buffers.get("object")
            if ob is None or int(obj_tbl["w"]) <= 0:
                return
            hw, hh = 0.5 * ob.w * float(zoom), 0.5 * ob.h * float(zoom)
            x0, y0, x1, y1, z0 = float(dx) - hw, float(dy) - hh, float(dx) + hw, float(dy) + hh, float(dz)
            saved_cam = sb.camera_mode
            sb.camera_mode = 0
            try:
                api_drawpoly(
                    x0, y0, z0, x1, y0, z0, x1, y1, z0, x0, y1, z0,
                    0.0, 0.0, ob.w, 0.0, ob.w, ob.h, 0.0, ob.h, float(alpha),
                )
            finally:
                sb.camera_mode = saved_cam

        def api_module(mod_name, *args):
            if str(mod_name) != "VL3DBridge" or self.bridge is None or self.bridge.mode == "none":
                return None
            br = self.bridge
            mtbl = lua.table()
            mtbl["get_status"] = self._wrap_lua_fn(
                lambda: (True, True, False, False, 2011000, 0, 0, br.scene_id, "SDK_ONLY", "")
            )

            def _py_resolve(lay1, frm0=None):
                f_use = int(frm0) if frm0 is not None and int(frm0) >= 0 else int(frame)
                tup = br.resolve_layer(self._cur_layers, int(lay1), f_use)
                lt = lua.table()
                for i_t, v_t in enumerate(tup, start=1):
                    lt[i_t] = v_t
                return lt

            mtbl["resolve_layer"] = self._multi_ret_resolve(_py_resolve)
            mtbl["get_water_color"] = self._wrap_lua_fn(
                lambda lay1, frm0=-1: br.resolve_layer(self._cur_layers, int(lay1), int(frame))[5]
            )
            mtbl["get_edit_camera"] = self._wrap_lua_fn(
                lambda: (True, *br.edit_camera) if getattr(br, "edit_camera", None) is not None else False
            )
            mtbl["get_camera_lights"] = self._wrap_lua_fn(lambda *a: (False, 1.0, 0))
            mtbl["get_scene_camera"] = self._wrap_lua_fn(lambda *a: False)

            if self._native_so is not None and br.mode in ("v120_native", "v292_param_edit"):
                so = self._native_so
                br.has_mesh_hits = getattr(br, "has_mesh_hits", 0)
                br.upload_mesh_calls = getattr(br, "upload_mesh_calls", 0)
                br.rast_shadow_calls = getattr(br, "rast_shadow_calls", 0)
                br.rast_camdepth_calls = getattr(br, "rast_camdepth_calls", 0)

                mtbl["wall_time_sec"] = self._wrap_lua_fn(lambda: float(so.vl3d_test_wall_time_sec()))
                mtbl["get_gpu_status"] = self._wrap_lua_fn(
                    lambda: (False, False, False, 1, 0, "CPP_CPU", "")
                )

                def _py_has_mesh(key, rev):
                    mid = int(so.vl3d_test_has_mesh(str(key).encode("utf-8"), str(rev).encode("utf-8")))
                    if mid > 0:
                        br.has_mesh_hits += 1
                    return mid

                def _py_upload_mesh(key, rev, nv, nt, vb64, tb64):
                    br.upload_mesh_calls += 1
                    return int(so.vl3d_test_upload_mesh_b64(
                        str(key).encode("utf-8"), str(rev).encode("utf-8"),
                        int(nv), int(nt), str(vb64).encode("ascii"), str(tb64).encode("ascii")
                    ))

                def _py_rast_shadow(dst_ptr, sh_res, p_tbl, i_tbl):
                    br.rast_shadow_calls += 1
                    addr = int(self._ptr_addr_lua(dst_ptr))
                    p_list = lua_table_to_floats(p_tbl)
                    i_list = lua_table_to_floats(i_tbl)
                    if len(p_list) < 22 or len(i_list) < 14 or (len(i_list) % 14) != 0:
                        return False, 0, False, "CPP_CPU"
                    n_inst = len(i_list) // 14
                    p_arr = (ctypes.c_double * 22)(*p_list[:22])
                    i_arr = (ctypes.c_double * len(i_list))(*i_list)
                    out_t = ctypes.c_int(0)
                    out_a = ctypes.c_int(0)
                    ok = so.vl3d_test_rasterize_shadow(
                        ctypes.c_void_p(addr), int(sh_res), p_arr, i_arr, n_inst,
                        ctypes.byref(out_t), ctypes.byref(out_a)
                    )
                    backend_label = getattr(br, "gpu_backend_label", "D3D11_CS")
                    return bool(ok == 1), int(out_t.value), bool(out_a.value == 1), backend_label

                def _py_rast_camdepth(dst_ptr, cm_w, cm_h, p_tbl, i_tbl):
                    br.rast_camdepth_calls += 1
                    addr = int(self._ptr_addr_lua(dst_ptr))
                    p_list = lua_table_to_floats(p_tbl)
                    i_list = lua_table_to_floats(i_tbl)
                    if len(p_list) < 16 or len(i_list) < 14 or (len(i_list) % 14) != 0:
                        return False, 0, False, "CPP_CPU"
                    n_inst = len(i_list) // 14
                    p_arr = (ctypes.c_double * 16)(*p_list[:16])
                    i_arr = (ctypes.c_double * len(i_list))(*i_list)
                    out_t = ctypes.c_int(0)
                    out_a = ctypes.c_int(0)
                    ok = so.vl3d_test_rasterize_camdepth(
                        ctypes.c_void_p(addr), int(cm_w), int(cm_h), p_arr, i_arr, n_inst,
                        ctypes.byref(out_t), ctypes.byref(out_a)
                    )
                    backend_label = getattr(br, "gpu_backend_label", "D3D11_CS")
                    return bool(ok == 1), int(out_t.value), bool(out_a.value == 1), backend_label

                mtbl["has_mesh"] = self._wrap_lua_fn(_py_has_mesh)
                mtbl["upload_mesh"] = self._wrap_lua_fn(_py_upload_mesh)
                mtbl["rasterize_shadow"] = self._wrap_lua_fn(_py_rast_shadow)
                mtbl["rasterize_camdepth"] = self._wrap_lua_fn(_py_rast_camdepth)

            return mtbl

        def api_rand(st_min, st_max, seed=0, frm=0):
            lo, hi = int(st_min), int(st_max)
            if hi <= lo:
                return lo
            h = ((int(seed) * 1103515245 + int(frm) * 12345 + int(obj_tbl["index"]) * 2654435761) & 0x7FFFFFFF)
            return lo + (h % (hi - lo + 1))

        wfn = self._wrap_lua_fn
        obj_tbl["getvalue"] = wfn(api_getvalue)
        obj_tbl["getinfo"] = wfn(api_getinfo)
        obj_tbl["getoption"] = wfn(api_getoption)
        obj_tbl["setoption"] = wfn(api_setoption)
        obj_tbl["clearbuffer"] = wfn(api_clearbuffer)
        obj_tbl["copybuffer"] = wfn(api_copybuffer)
        obj_tbl["getpixel"] = wfn(api_getpixel)
        obj_tbl["getpixeldata"] = wfn(api_getpixeldata)
        obj_tbl["putpixeldata"] = wfn(api_putpixeldata)
        obj_tbl["setfont"] = wfn(api_setfont)
        obj_tbl["load"] = wfn(api_load)
        obj_tbl["pixelshader"] = wfn(api_pixelshader)
        obj_tbl["drawpoly"] = wfn(api_drawpoly)
        obj_tbl["draw"] = wfn(api_draw)
        obj_tbl["module"] = wfn(api_module)
        obj_tbl["rand"] = wfn(api_rand)
        obj_tbl["interpolation"] = wfn(lambda t, x0, y0, z0, x1, y1, z1: (
            x0 + (x1 - x0) * t, y0 + (y1 - y0) * t, z0 + (z1 - z0) * t
        ))

        g["obj"] = obj_tbl
        for k, v in merged_params.items():
            g[k] = v

        lua_error = None
        t0 = time.perf_counter()
        try:
            lua.execute(self.lua_code)
        except Exception as exc:
            lua_error = f"{type(exc).__name__}: {exc}"
        elapsed_ms = (time.perf_counter() - t0) * 1000.0

        err_logs = [ln for ln in self.logs if "ERR]" in ln or "DEADLOCK" in ln]
        if lua_error is None and err_logs:
            lua_error = err_logs[0]

        fb_u8 = sb.read_numpy("framebuffer")
        fb_f = (fb_u8.astype(np.float32) / 255.0) if (fb_u8.shape[0] * fb_u8.shape[1] <= 10_000_000) else None
        lua_cpu_ms = max(0.0, elapsed_ms - state["gpu_ms"])
        return {
            "rgba8": fb_u8,
            "float": fb_f,
            "elapsed_ms": elapsed_ms,
            "lua_cpu_ms": lua_cpu_ms,
            "gpu_ms": state["gpu_ms"],
            "error": lua_error,
            "logs": list(self.logs),
            "total_quads": state["drawpoly_quads"],
            "pixelshader_calls": state["pixelshader_calls"],
            "layer_load_calls": list(self.layer_load_calls),
            "getpixeldata_calls": self.getpixeldata_calls,
        }
