#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import json, pathlib
import numpy as np
from PIL import Image, ImageDraw

ROOT = pathlib.Path("/home/user")
OUT_DIR = ROOT / "sandbox/fresh_eval/outputs"
IMG_DIR = OUT_DIR / "renders"

lw = json.loads((OUT_DIR / "longwire_metrics.json").read_text(encoding="utf-8"))
fm = json.loads((OUT_DIR / "fresh_metrics.json").read_text(encoding="utf-8"))

W, H = 1920, 1180
canvas = Image.new("RGB", (W, H), (15, 18, 25))
draw = ImageDraw.Draw(canvas)

draw.rectangle([0, 0, W, 62], fill=(24, 30, 44))
draw.text((28, 14), "AviUtl2 3D Scripts Independent Audit (2026-10-24) - Native C++ SDK Lock Sim + Persistent LuaJIT VM + Vulkan wgpu", fill=(238, 244, 255))
draw.text((28, 36), "End-to-End Verification: Volumetric Light v2.86 / v2.90 / v2.91 / v2.92_ref  |  Volumetric Fog v2.01 / v2.02  |  Snow v1.19", fill=(160, 185, 220))

def paste_thumb(img_name, x, y, tw, th, label, border=(70, 90, 125)):
    p = IMG_DIR / img_name
    draw.rectangle([x - 2, y - 2, x + tw + 2, y + th + 24], fill=(24, 28, 38), outline=border, width=2)
    if p.exists():
        im = Image.open(p).convert("RGB").resize((tw, th), Image.Resampling.LANCZOS)
        canvas.paste(im, (x, y))
    draw.text((x + 6, y + th + 5), label, fill=(225, 232, 245))

# Row 1: Volumetric Light 3D (Birdcage 38,012 tris + VRM strict getvalue("--file")==nil)
draw.text((28, 76), "1. Volumetric Light (3D): 38,012-Tri Birdcage Shadow Shafts (MAE=0.0000) & Strict VRM --file==nil Bug vs v2.92_ref Fix", fill=(120, 210, 255))
paste_thumb("cage38k_2048_v2_90.png",     28,  100, 445, 235, "v2.90: 38,012-tri OBJ (FREEZES on Windows drag; 1237ms CPU)", border=(225, 85, 85))
paste_thumb("cage38k_2048_v2_92_ref.png", 495, 100, 445, 235, "v2.92_ref: MAE=0.0000 identical! Play 19.2ms / Drag 54.4ms", border=(75, 215, 130))
paste_thumb("vrm_occ_v2_91.png",          962, 100, 445, 235, "v2.90/v2.91 BUG: VRM L3 misclassified as 2D (0 GLB loaded)", border=(225, 145, 70))
paste_thumb("vrm_occ_v2_92_ref.png",      1429, 100, 445, 235, "v2.92_ref FIX: ls=='VRM' -> 3D VRM mesh loaded + shadow shaft", border=(75, 215, 130))

# Row 2: Volumetric Fog 3D + Snow 3D
draw.text((28, 376), "2. Volumetric Fog (Sphere Mode sec_k=4x Distortion vs Fixed) & Snow v1.19 (cam==nil 61.5% Cull Bug vs Fixed)", fill=(120, 210, 255))
paste_thumb("fog_v202_sphere_seck_bug.png",   28,  400, 445, 235, "Fog v2.02 Sphere Mode: sec_k=4x Edge Overdensity (ratio 0.929)", border=(225, 145, 70))
paste_thumb("fog_v202_sphere_seck_fixed.png", 495, 400, 445, 235, "Fog v2.02 sec_k=1.0 Ref: Natural Sphere Chord Falloff (0.701)", border=(75, 215, 130))
paste_thumb("snow_v119_nocam_camz0_bug.png",  962, 400, 445, 235, "Snow v1.19 BUG: cam==nil sets cam_z=0 -> Culls 61.5% Snow!", border=(225, 85, 85))
paste_thumb("snow_v119_nocam_camz1024_fix.png", 1429, 400, 445, 235, "Snow v1.19 Ref (cam_z=-1024): Full 1,199 Snowflakes Restored", border=(75, 215, 130))

# Row 3 Left: Pure LuaJIT CPU Performance Chart on 38,012-tri Un-subdivided Birdcage (2048x1080)
bx, by, bw, bh = 28, 682, 912, 468
draw.rectangle([bx, by, bx + bw, by + bh], fill=(22, 26, 36), outline=(65, 80, 110), width=2)
draw.text((bx + 18, by + 14), "3. Pure LuaJIT CPU Frame Time on 38,012-Tri Birdcage @ 2048x1080 (GPU Transfer Excluded)", fill=(255, 220, 130))
draw.text((bx + 18, by + 36), "Why v2.90 & v2.91 Both Freeze on Real Machine: (A) SRWLock Deadlock in VL3DBridge + (B) O(W*H) Full-AABB & Uncached camocc", fill=(175, 190, 215))

bars = [
    ("v2.86 Play (Static)",      lw["v2.86"]["play_cpu_ms"],       (140, 155, 185), "Uncached camocc every frame"),
    ("v2.86 Drag/Zoom",          lw["v2.86"]["drag_scale_cpu_ms"], (215, 135, 75),  "0.81 fps (Full-AABB + wire_splat)"),
    ("v2.90 Play (Static)",      lw["v2.90"]["play_cpu_ms"],       (140, 155, 185), "Uncached camocc every frame"),
    ("v2.90 Drag/Zoom (occ>=1)", lw["v2.90"]["drag_scale_cpu_ms"], (230, 70, 70),   "INFINITE SRWLOCK DEADLOCK + 1237ms CPU"),
    ("v2.91 Play (Static)",      lw["v2.91"]["play_cpu_ms"],       (140, 155, 185), "Uncached camocc every frame"),
    ("v2.91 Drag/Zoom (occ>=1)", lw["v2.91"]["drag_scale_cpu_ms"], (230, 70, 70),   "STILL DEADLOCKS (.aux2 unchanged) + 977ms CPU"),
    ("v2.92_ref Play (Static)",  lw["v2.92_ref"]["play_cpu_ms"],   (65, 210, 125),  "45.9x FASTER (52.1 fps, camocc_cache)"),
    ("v2.92_ref Drag/Zoom",      lw["v2.92_ref"]["drag_scale_cpu_ms"], (65, 210, 125), "22.8x FASTER (18.4 fps, 0 deadlocks!)"),
]
max_ms = 1400.0
for idx, (lbl, val, col, note) in enumerate(bars):
    ry = by + 74 + idx * 47
    draw.text((bx + 18, ry + 6), lbl, fill=(225, 232, 245))
    bar_x0 = bx + 235
    bar_w = int(min(val / max_ms, 1.0) * 330)
    draw.rectangle([bar_x0, ry + 4, bar_x0 + max(bar_w, 4), ry + 28], fill=col)
    draw.text((bar_x0 + bar_w + 10, ry + 6), f"{val:.1f} ms  |  {note}", fill=(210, 220, 238))

# Row 3 Right: Native C++ Lock Matrix & Key Findings Summary
rx, ry0, rw, rh = 962, 682, 912, 468
draw.rectangle([rx, ry0, rx + rw, ry0 + rh], fill=(22, 26, 36), outline=(65, 80, 110), width=2)
draw.text((rx + 18, ry0 + 14), "4. Root-Cause Verification Matrix (Native C++ Host Lock Sim + Hardware MMU Guard Pages)", fill=(255, 220, 130))

lines = [
    ("A. Why ALL Foreground Objects (2D / OBJ / VRM) Freeze Instantly on Drag/Zoom in v2.90 & v2.91:", (255, 145, 145)),
    ("   - Playback (no GUI edit lock): call_read_section_param acquires shared SRWLock in 0.012 ms -> works.", (210, 220, 235)),
    ("   - GUI Drag / Trackbar Zoom: Main thread holds EXCLUSIVE edit lock + waits on wait_rendering_task().", (210, 220, 235)),
    ("   - Render worker enters beam_frame (when occ_mode > 0) -> resolve_live_scene_layer_object ->", (210, 220, 235)),
    ("     VL3DBridge.query_layer -> g_edit_handle->call_read_section_param -> AcquireSRWLockShared().", (210, 220, 235)),
    ("   - Classic AB-BA Lock-Order Inversion (or non-reentrant SRWLock on same thread) -> 100% Instant Freeze!", (255, 185, 110)),
    ("   - Fix Verified: SCRIPT_MODULE_PARAM::edit (SDK beta46+/v2.0.54+) -> 1,500 drag frames in 2.17ms, 0 locks!", (110, 235, 155)),
    ("", (200, 200, 200)),
    ("B. Secondary Defects Uncovered Across Codebase & Legacy Sandbox:", (130, 210, 255)),
    ("   - VL v2.90/v2.91: Missing `elseif ls == 'VRM'` in 2 places -> VRM layers silently broken when --file==nil.", (210, 220, 235)),
    ("   - VL v2.90/v2.91: GLB_MESH_CACHE[path|scale] leaks FFI buffers on every zoom tick; GGET `ln` nil bug (L5103).", (210, 220, 235)),
    ("   - VL v2.86: Hardware PROT_NONE guard-page test proves real SIGSEGV (-11) in pe_find_export_addr.", (210, 220, 235)),
    ("   - Fog v2.02: HG forward-scatter fixed (+47% backlight), but Sphere Mode sec_k=4x distorts wide-angle edges.", (210, 220, 235)),
    ("   - Snow v1.19: cam==nil sets cam_z=0 -> culls 61.47% snow; raw --check=0 truthy in Lua; ignores cam.rz.", (210, 220, 235)),
    ("   - Legacy Sandbox: Stubbed obj.module->None, faked --file strings, fresh VM/frame, vacuous jb.get('error').", (255, 185, 110)),
]
for i, (txt, col) in enumerate(lines):
    draw.text((rx + 18, ry0 + 50 + i * 26), txt, fill=col)

out_board = OUT_DIR / "fresh_independent_audit_summary.png"
canvas.save(out_board)
print("Saved updated board:", out_board)
