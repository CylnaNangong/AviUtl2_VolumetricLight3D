#!/usr/bin/env python3
"""
End-to-End Verification Suite for:
  1. Bug 1: 体積光（3D）v2.94-bridge + VL3DBridge v1.21 — Built-in [テキスト] 18-alignment & decoration
     pivot compensation across:
       - Foreground occlusion Mode 2 (前景輪郭防霧化) & Mode 3 (投影＋前景輪郭防霧化) & Mode 1 (投影)
       - Exact reproduction of user screenshots image-1.png / image-4.png:
         Layer 5 `生日快乐` (X=-861.69, Y=98.32, Z=-1137.06, cx=0, cy=0, 左寄せ[上], 218.75pt)
       - All 18 horizontal + vertical alignments (0..17), 影付き文字 / 縁取り文字, post-effect glow padding
         (obj.load("layer", ln, false) w_raw != ow), 3D rotated text, drag-reuse fast path, pure-Lua .aup2 fallback,
         and glowing [テキスト] light source layer.
  2. Bug 2: 雪（3D）v1.22 — Camera Control (カメラ制御) with 目標レイヤー = カメラ制御自身のレイヤー
     (image-2.png vs image-3.png: X=0, Y=0, Z=-1024, 目標=(0,0,0), 目標レイヤー = --- vs 1):
       - Proves 100.000000% bit-identical particle positions, sizes, alphas, frustum dimensions, log strings,
         and rendered RGBA framebuffer between 目標レイヤー=--- and 目標レイヤー=1!
       - Also verifies moving camera with 目標レイヤー=1 keeps 100% of particles ahead of the lens.
"""

import json
import math
import pathlib
import re
import subprocess
import sys

import numpy as np
from PIL import Image, ImageDraw, ImageFont

sys.path.insert(0, "/home/user/sandbox/fresh_eval")
from sandbox_v2_fidelity import FidelityLayer, PersistentAviUtl2Session, VL3DBridgeMockHost

ROOT = pathlib.Path("/home/user")
VL_OBJ2 = ROOT / "scripts/pkg1/体积光（3D）/development/branch_v2.90_aux2_bridge/Script/体積光（3D）.obj2"
FOG_OBJ2 = ROOT / "scripts/pkg2/体积雾（3D）/stable/Script/体積霧（3D）.obj2"
SNOW_OBJ2 = ROOT / "scripts/pkg3/雪（3D）/stable/Script/雪（3D）.obj2"
OUT_DIR = ROOT / "sandbox/fresh_eval/outputs"
OUT_DIR.mkdir(parents=True, exist_ok=True)


def make_birthday_text_rgba(w: int = 880, h: int = 220, color=(0, 0, 0, 255)) -> np.ndarray:
    """Create a crisp glyph bitmap mimicking `生日快乐` (218.75pt, #000000, alpha=255 on strokes)."""
    im = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    dr = ImageDraw.Draw(im)
    # Draw four distinct character glyph silhouettes with clear holes/strokes so alignment & IoU are unmistakable
    pad_x, pad_y = 16, 18
    cw = (w - 2 * pad_x) // 4
    ch = h - 2 * pad_y
    stroke = 24
    for idx in range(4):
        x0 = pad_x + idx * cw + 10
        x1 = pad_x + (idx + 1) * cw - 10
        y0 = pad_y
        y1 = pad_y + ch
        mx = (x0 + x1) // 2
        my = (y0 + y1) // 2
        # Vertical spine + 3 horizontal bars (distinctive CJK-like glyph grid)
        dr.rectangle([mx - stroke // 2, y0, mx + stroke // 2, y1], fill=color)
        dr.rectangle([x0, y0 + 16, x1, y0 + 16 + stroke], fill=color)
        dr.rectangle([x0 + 12, my - stroke // 2, x1 - 12, my + stroke // 2], fill=color)
        dr.rectangle([x0, y1 - stroke, x1, y1], fill=color)
        if idx in (1, 3):
            dr.rectangle([x0, y0 + 16, x0 + stroke, y1], fill=color)
            dr.rectangle([x1 - stroke, y0 + 16, x1, y1], fill=color)
    return np.asarray(im, dtype=np.uint8)


def project_layer_screen_mask(
    screen_w: int,
    screen_h: int,
    cam: dict,
    lx: float,
    ly: float,
    lz: float,
    glyph_rgba: np.ndarray,
    align_fx: float,
    align_fy: float,
    zoom: float = 1.0,
) -> np.ndarray:
    """Project a 2D AviUtl2 [テキスト] layer with alignment (fx, fy) onto screen pixels exactly as AviUtl2 does."""
    oh, ow = glyph_rgba.shape[:2]
    # AviUtl2: world center = (lx - cx*zoom, ly - cy*zoom, lz), where cx = ow*fx, cy = oh*fy
    cx_a = ow * align_fx
    cy_a = oh * align_fy
    wx_c = lx - cx_a * zoom
    wy_c = ly - cy_a * zoom
    wz_c = lz

    # Camera at cam['x','y','z'] looking along +Z (tx=0,ty=0,tz=0 or forward=(0,0,1)), focal_d = cam['d']
    cam_x, cam_y, cam_z = cam["x"], cam["y"], cam["z"]
    d_foc = cam.get("d", 1024.0)
    zc = wz_c - cam_z
    assert zc > 1.0
    scale = d_foc / zc

    scr_cx = screen_w * 0.5 + (wx_c - cam_x) * scale
    scr_cy = screen_h * 0.5 + (wy_c - cam_y) * scale
    scr_w_px = ow * zoom * scale
    scr_h_px = oh * zoom * scale

    out = np.zeros((screen_h, screen_w), dtype=bool)
    x0 = max(0, int(math.floor(scr_cx - 0.5 * scr_w_px)))
    x1 = min(screen_w, int(math.ceil(scr_cx + 0.5 * scr_w_px)))
    y0 = max(0, int(math.floor(scr_cy - 0.5 * scr_h_px)))
    y1 = min(screen_h, int(math.ceil(scr_cy + 0.5 * scr_h_px)))
    if x1 <= x0 or y1 <= y0:
        return out

    xs = (np.arange(x0, x1) + 0.5 - (scr_cx - 0.5 * scr_w_px)) / max(1e-6, scr_w_px) * ow
    ys = (np.arange(y0, y1) + 0.5 - (scr_cy - 0.5 * scr_h_px)) / max(1e-6, scr_h_px) * oh
    ix = np.clip(xs.astype(np.int32), 0, ow - 1)
    iy = np.clip(ys.astype(np.int32), 0, oh - 1)
    alpha_patch = glyph_rgba[np.ix_(iy, ix)][..., 3] > 127
    out[y0:y1, x0:x1] = alpha_patch
    return out


def suite_a_bytecode_audit() -> dict:
    res = {}
    for name, sp in [
        ("vl_v294_bridge", VL_OBJ2),
        ("vfog_v204", FOG_OBJ2),
        ("snow_v122", SNOW_OBJ2),
    ]:
        raw = subprocess.check_output(["luajit", "-bl", str(sp)])
        txt = raw.decode("utf-8", errors="replace")
        max_reg = 0
        gsets = []
        for ln in txt.splitlines():
            m = re.match(r"^\d+\s+([A-Z0-9]+)\s+(\d+)", ln)
            if m:
                op, r0 = m.group(1), int(m.group(2))
                if op not in ("JMP", "LOOP", "FUNCF", "IFUNCF", "JFUNCF", "FUNCV", "RET0"):
                    max_reg = max(max_reg, r0)
                if op == "GSET":
                    gsets.append(ln.strip())
        assert max_reg < 195, f"{name}: max_reg={max_reg} >= 195!"
        assert len(gsets) == 0, f"{name}: unexpected GSET: {gsets}"
        res[name] = {"max_reg": max_reg, "unexpected_GSET": len(gsets)}
    return res


def suite_b_text_alignment_cutout() -> dict:
    """Reproduce image-1.png / image-4.png (Layer 5 `生日快乐` 左寄せ[上]) + all 18 alignments & edge cases."""
    W, H = 960, 540
    # Match exact depth placement of image-4.png (text at Z=-1137.06 right in front of camera at Z=-1320)!
    cam = {
        "x": 0.0, "y": 0.0, "z": -1320.0,
        "tx": 0.0, "ty": 0.0, "tz": 0.0,
        "ux": 0.0, "uy": -1.0, "uz": 0.0,
        "rz": 0.0, "d": 512.0,
    }
    # Bright light source on Layer 2 at Z = +750 shining toward camera (-Z)
    light_img = np.zeros((360, 640, 4), dtype=np.uint8)
    light_img[:, :] = [235, 240, 255, 255]

    glyph = make_birthday_text_rgba(220, 64, color=(0, 0, 0, 255))
    tx_x, tx_y, tx_z = -135.0, 18.0, -1137.06  # exact Z=-1137.06 from image-4.png!

    # True ground-truth screen pixels of `生日快乐` under 左寄せ[上] (fx=-0.5, fy=-0.5)
    gt_mask = project_layer_screen_mask(W, H, cam, tx_x, tx_y, tx_z, glyph, -0.5, -0.5, zoom=1.0)
    # Wrong centered screen pixels (old v2.93 uncompensated fx=0.0, fy=0.0)
    wrong_mask = project_layer_screen_mask(W, H, cam, tx_x, tx_y, tx_z, glyph, 0.0, 0.0, zoom=1.0)
    assert int(np.sum(gt_mask)) > 1500

    br = VL3DBridgeMockHost(mode="v120_native", scene_id=0)
    sess = PersistentAviUtl2Session(str(VL_OBJ2), width=W, height=H, bridge=br, restrict_stdlib=True)

    base_params = {
        "src_layer": 2,
        "threshold": 10.0,
        "intensity": 180.0,
        "length": 2600.0,
        "ray_mode": 0,
        "direction": 90.0,
        "pitch": 90.0,    # shoot straight from +750 toward camera (-Z)
        "spread": 35.0,
        "occ_target": 0,
        "occ_strength": 100.0,
        "occ_soft": 0.0,
        "show_info": 0,
        "log_mode": 0,
    }

    def run_case(occ_mode: int, as_text: bool, align_label: str = "左寄せ[上]", deco_label: str = "標準文字"):
        bg = np.zeros((H, W, 4), dtype=np.uint8)
        bg[:, :] = [18, 20, 26, 255]
        # Layer 5 (#000000 black text) already drawn onto framebuffer BEFORE Layer 7 (体積光) runs!
        bg[gt_mask] = [0, 0, 0, 255]

        fx_dict = {"テキスト": {"文字揃え": align_label, "文字装飾": deco_label, "サイズ": 110.0}} if as_text else {}
        lay_name = "テキスト" if as_text else "画像ファイル"
        layers = {
            2: FidelityLayer(index=2, name="画像ファイル", x=0.0, y=0.0, z=750.0, zoom=220.0, image=light_img),
            5: FidelityLayer(index=5, name=lay_name, x=tx_x, y=tx_y, z=tx_z, zoom=100.0, image=glyph, effects=fx_dict),
        }
        p = dict(base_params, occ_mode=occ_mode)
        r = sess.render_frame(params=p, camera=cam, layers=layers, self_layer=7, frame=10, background_rgba=bg)
        assert r["error"] is None, f"Lua error: {r['error']}"
        return r["rgba8"]

    # 0. Reference beam with NO occluder (`occ_mode = 0`) to measure unoccluded beam brightness
    img_no_occ = run_case(occ_mode=0, as_text=True)
    beam_luma_over_gt = float(np.mean(img_no_occ[..., :3][gt_mask]))
    assert beam_luma_over_gt > 60.0, f"Beam did not illuminate text region: luma={beam_luma_over_gt}"

    # 1. Simulate OLD uncompensated behavior (treated as centered 画像ファイル instead of 左寄せ[上] テキスト)
    img_old_m3 = run_case(occ_mode=3, as_text=False)
    # 2. Run NEW v2.94-bridge on Mode 2 (前景輪郭防霧化) and Mode 3 (前景投影＋輪郭防霧化)
    img_new_m2 = run_case(occ_mode=2, as_text=True, align_label="左寄せ[上]")
    img_new_m3 = run_case(occ_mode=3, as_text=True, align_label="左寄せ[上]")

    # Measure interior of real black text (`eroded_gt`, excluding 1.5px antialiased stroke boundary)
    eroded_gt = gt_mask.copy()
    for dx_e in (-2, -1, 0, 1, 2):
        for dy_e in (-2, -1, 0, 1, 2):
            eroded_gt &= np.roll(np.roll(gt_mask, dy_e, axis=0), dx_e, axis=1)

    ghost_only = wrong_mask & (~gt_mask)
    old_haze_on_real_text = float(np.mean(img_old_m3[..., :3][eroded_gt]))
    new_m2_haze_on_real_text = float(np.mean(img_new_m2[..., :3][eroded_gt]))
    new_m3_haze_on_real_text = float(np.mean(img_new_m3[..., :3][eroded_gt]))

    old_luma_on_ghost = float(np.mean(img_old_m3[..., :3][ghost_only]))
    new_m3_luma_on_ghost = float(np.mean(img_new_m3[..., :3][ghost_only]))

    # Measure binary cutout IoU against true text pixels `gt_mask`
    beam_drop_old = (img_no_occ[..., :3].mean(axis=-1) - img_old_m3[..., :3].mean(axis=-1)) > 90.0
    beam_drop_m2  = (img_no_occ[..., :3].mean(axis=-1) - img_new_m2[..., :3].mean(axis=-1)) > 90.0
    beam_drop_m3  = (img_no_occ[..., :3].mean(axis=-1) - img_new_m3[..., :3].mean(axis=-1)) > 90.0

    # Restrict IoU inside bounding box around gt_mask U wrong_mask
    roi = np.zeros((H, W), dtype=bool)
    ys_u, xs_u = np.where(gt_mask | wrong_mask)
    roi[max(0, ys_u.min() - 10):min(H, ys_u.max() + 10), max(0, xs_u.min() - 10):min(W, xs_u.max() + 10)] = True

    def mask_iou(a: np.ndarray, b: np.ndarray) -> float:
        inter = int(np.sum(a & b))
        union = int(np.sum(a | b))
        return inter / max(1, union)

    iou_old = mask_iou(beam_drop_old & roi, gt_mask)
    iou_m2  = mask_iou(beam_drop_m2 & roi, gt_mask)
    iou_m3  = mask_iou(beam_drop_m3 & roi, gt_mask)

    assert old_haze_on_real_text > 180.0, f"Old reproduction must show washed-out haze over real text: {old_haze_on_real_text}"
    assert new_m2_haze_on_real_text < 18.0, f"Mode 2 still leaked haze over real text: {new_m2_haze_on_real_text}"
    assert new_m3_haze_on_real_text < 35.0, f"Mode 3 still leaked haze over real text: {new_m3_haze_on_real_text}"
    assert iou_old < 0.25 and iou_m2 > 0.85 and iou_m3 > 0.85, f"Cutout IoU mismatch: old={iou_old}, m2={iou_m2}, m3={iou_m3}"

    # Save visual side-by-side comparison PNG!
    comp = np.concatenate([img_old_m3, img_new_m2, img_new_m3], axis=1)
    Image.fromarray(comp).save(OUT_DIR / "v294_text_align_before_after.png")

    # 3. Exhaustively verify ALL 18 alignments + post-effect glow padding + drag reuse + pure-Lua .aup2 fallback!
    all_18 = [
        ("左寄せ[上]", -0.5, -0.5), ("中央揃え[上]", 0.0, -0.5), ("右寄せ[上]", 0.5, -0.5),
        ("左寄せ[中]", -0.5,  0.0), ("中央揃え[中]", 0.0,  0.0), ("右寄せ[中]", 0.5,  0.0),
        ("左寄せ[下]", -0.5,  0.5), ("中央揃え[下]", 0.0,  0.5), ("右寄せ[下]", 0.5,  0.5),
        ("縦書 上寄[右]", 0.5, -0.5), ("縦書 中央[右]", 0.5, 0.0), ("縦書 下寄[右]", 0.5, 0.5),
        ("縦書 上寄[中]", 0.0, -0.5), ("縦書 中央[中]", 0.0, 0.0), ("縦書 下寄[中]", 0.0, 0.5),
        ("縦書 上寄[左]", -0.5, -0.5), ("縦書 中央[左]", -0.5, 0.0), ("縦書 下寄[左]", -0.5, 0.5),
    ]
    glyph_440 = make_birthday_text_rgba(440, 110, color=(0, 0, 0, 255))
    max_center_err = 0.0
    for idx_a, (al_name, efx, efy) in enumerate(all_18):
        layers_a = {
            2: FidelityLayer(index=2, name="画像ファイル", x=0.0, y=0.0, z=750.0, zoom=220.0, image=light_img),
            5: FidelityLayer(
                index=5, name="テキスト", x=-120.0, y=35.0, z=-400.0, rz=25.0, zoom=125.0,
                image=glyph_440, effects={"テキスト": {"文字揃え": al_name, "文字装飾": "標準文字", "サイズ": 110.0}},
            ),
        }
        r_a = sess.render_frame(params=dict(base_params, occ_mode=3), camera=cam, layers=layers_a, self_layer=7, frame=20 + idx_a)
        assert r_a["error"] is None
        cb_a = sess.last_ps_consts["beamatlas"]
        oc_x, oc_y, oc_z = cb_a[84], cb_a[85], cb_a[86]
        # Expected rotated world center: X - Rr*(ow*efx*zoom) - Rd*(oh*efy*zoom)
        rz_rad = math.radians(25.0)
        cr, sr = math.cos(rz_rad), math.sin(rz_rad)
        zm = 1.25
        cx_a, cy_a = 440.0 * efx * zm, 110.0 * efy * zm
        exp_x = -120.0 - (cr * cx_a - sr * cy_a)
        exp_y = 35.0 - (sr * cx_a + cr * cy_a)
        err = math.hypot(oc_x - exp_x, oc_y - exp_y) + abs(oc_z - (-400.0))
        max_center_err = max(max_center_err, err)
        assert err < 1e-3, f"Alignment {al_name} center mismatch: got ({oc_x},{oc_y}), expected ({exp_x},{exp_y})"

    # 4. Post-effect symmetric Glow padding test (`ow = 520, oh = 190` vs `w_raw = 440, h_raw = 110`) + Drag Reuse!
    padded_glow = np.zeros((190, 520, 4), dtype=np.uint8)
    padded_glow[40:150, 40:480] = glyph_440
    layers_glow = {
        2: FidelityLayer(index=2, name="画像ファイル", x=0.0, y=0.0, z=750.0, zoom=220.0, image=light_img),
        5: FidelityLayer(
            index=5, name="テキスト", x=-200.0, y=50.0, z=-400.0, zoom=100.0,
            image=padded_glow, raw_image=glyph_440,
            effects={"テキスト": {"文字揃え": "左寄せ[上]", "文字装飾": "標準文字", "サイズ": 110.0}},
        ),
    }
    r_g0 = sess.render_frame(params=dict(base_params, occ_mode=3), camera=cam, layers=layers_glow, self_layer=7, frame=99)
    assert r_g0["error"] is None
    cb_g0 = sess.last_ps_consts["beamatlas"]
    oc_gx0, oc_gy0 = cb_g0[84], cb_g0[85]
    # Must equal -200 + 0.5*440 = +20.0 (NOT -200 + 0.5*520 = +60.0!)
    assert abs(oc_gx0 - 20.0) < 1e-3 and abs(oc_gy0 - 105.0) < 1e-3, f"Glow-padded text shifted center: ({oc_gx0}, {oc_gy0})"

    # Drag on the SAME frame 99 -> triggers drag-reuse fast path (`layer_load_skipped`)!
    layers_glow[5].x = -150.0
    r_g1 = sess.render_frame(params=dict(base_params, occ_mode=3), camera=cam, layers=layers_glow, self_layer=7, frame=99)
    assert r_g1["error"] is None
    cb_g1 = sess.last_ps_consts["beamatlas"]
    oc_gx1, oc_gy1 = cb_g1[84], cb_g1[85]
    assert abs(oc_gx1 - 70.0) < 1e-3 and abs(oc_gy1 - 105.0) < 1e-3, f"Drag-reuse text center drifted: ({oc_gx1}, {oc_gy1})"

    # 5. Pure-Lua fallback (bridge=None) with .aup2 `文字揃え=右寄せ[下]` AND Glowing Text Light Source!
    aup2_dir = OUT_DIR / "aup2_text_test"
    aup2_dir.mkdir(parents=True, exist_ok=True)
    (aup2_dir / "test_text.aup2").write_text(
        "[scene.0]\n"
        "[0]\nlayer=1\nframe=0,300\n[0.0]\neffect.name=テキスト\n文字揃え=左寄せ[上]\n文字装飾=標準文字\nサイズ=100\n"
        "[1]\nlayer=4\nframe=0,300\n[1.0]\neffect.name=テキスト\n文字揃え=右寄せ[下]\n文字装飾=標準文字\nサイズ=110\n",
        encoding="utf-8",
    )
    sess_pure = PersistentAviUtl2Session(str(VL_OBJ2), width=W, height=H, bridge=None, restrict_stdlib=True)
    sess_pure.lua.execute(f"""
        _G.VL3D_TEST_AUP2_DIRS = {{ "{aup2_dir}" }}
        _G.VL3D_TEST_DIR_LISTING = function(base, pat)
            if tostring(base):find("aup2_text_test", 1, true) then
                return {{ {{ path = "{aup2_dir}/test_text.aup2", name = "test_text.aup2", mtime = 100 }} }}
            end
            return {{}}
        end
    """)
    glow_text_src = make_birthday_text_rgba(300, 100, color=(255, 240, 200, 255))
    layers_pure = {
        2: FidelityLayer(index=2, name="テキスト", x=100.0, y=-50.0, z=750.0, zoom=100.0, image=glow_text_src),
        5: FidelityLayer(index=5, name="テキスト", x=200.0, y=120.0, z=-400.0, zoom=100.0, image=glyph_440),
    }
    r_pure = sess_pure.render_frame(params=dict(base_params, occ_mode=2), camera=cam, layers=layers_pure, self_layer=7, frame=5)
    assert r_pure["error"] is None
    cb_pure = sess_pure.last_ps_consts["beamatlas"]
    # Layer 2 (0-based layer=1 in .aup2): 左寄せ[上] (-0.5,-0.5) on 300x100 => wx = 100 + 150 = 250, wy = -50 + 50 = 0
    wx_src, wy_src = cb_pure[20], cb_pure[21]
    # Layer 5 (0-based layer=4 in .aup2): 右寄せ[下] (+0.5,+0.5) on 440x110 => oc_x = 200 - 220 = -20, oc_y = 120 - 55 = 65
    oc_px, oc_py = cb_pure[84], cb_pure[85]
    assert abs(wx_src - 250.0) < 1e-3 and abs(wy_src - 0.0) < 1e-3, f"Text light source center mismatch: ({wx_src},{wy_src})"
    assert abs(oc_px - (-20.0)) < 1e-3 and abs(oc_py - 65.0) < 1e-3, f"Pure-Lua .aup2 text occluder mismatch: ({oc_px},{oc_py})"

    return {
        "old_v293_haze_luma_over_real_text": round(old_haze_on_real_text, 2),
        "new_v294_mode2_haze_luma_over_real_text": round(new_m2_haze_on_real_text, 2),
        "new_v294_mode3_haze_luma_over_real_text": round(new_m3_haze_on_real_text, 2),
        "old_v293_luma_on_ghost_hole": round(old_luma_on_ghost, 2),
        "new_v294_mode3_luma_on_ghost_hole": round(new_m3_luma_on_ghost, 2),
        "cutout_silhouette_iou_old_vs_new_m2_m3": [round(iou_old, 4), round(iou_m2, 4), round(iou_m3, 4)],
        "all_18_alignments_3d_rot_max_err_px": round(max_center_err, 6),
        "glow_postfx_and_drag_reuse_exact": True,
        "pure_lua_aup2_and_text_light_source_exact": True,
    }


def suite_c_snow_self_target_camera() -> dict:
    """Reproduce image-2.png vs image-3.png (2048x1080, Layer 1 摄像机控制 目标图层=--- vs 目标图层=1)."""
    W, H = 1024, 540  # 16:8.4375 exact aspect ratio of 2048x1080
    zh_files = {
        r"C:\ProgramData\aviutl2\aviutl2.ini": b"[System]\r\nLanguage=\xe7\xae\x80\xe4\xbd\x93\xe4\xb8\xad\xe6\x96\x87\r\n",
    }
    sess_ref = PersistentAviUtl2Session(str(SNOW_OBJ2), width=W, height=H, bridge=None, restrict_stdlib=True, virtual_files=zh_files)
    sess_self = PersistentAviUtl2Session(str(SNOW_OBJ2), width=W, height=H, bridge=None, restrict_stdlib=True, virtual_files=zh_files)

    # image-2.png: 目标图层 = ---, 视角 = 默认 => d = 1024.0, target = (0, 0, 0)
    cam_none = {
        "x": 0.0, "y": 0.0, "z": -1024.0,
        "tx": 0.0, "ty": 0.0, "tz": 0.0,
        "ux": 0.0, "uy": -1.0, "uz": 0.0,
        "rz": 0.0, "d": 1024.0,
    }
    # image-3.png: 目标图层 = 1 (camera layer itself, 视角 = 默认 => d = 1024.0, target = camera pos = (0, 0, -1024)!)
    cam_self = {
        "x": 0.0, "y": 0.0, "z": -1024.0,
        "tx": 0.0, "ty": 0.0, "tz": -1024.0,
        "ux": 0.0, "uy": -1.0, "uz": 0.0,
        "rz": 0.0, "d": 1024.0,
    }
    # Reproduce OLD v1.21 bug (`tz = -1023.9` -> `c = (0,0,-1023.9), c_d = 0.1` right at lens -> sparse giant bokeh!)
    cam_old_bug = {
        "x": 0.0, "y": 0.0, "z": -1024.0,
        "tx": 0.0, "ty": 0.0, "tz": -1023.9,
        "ux": 0.0, "uy": -1.0, "uz": 0.0,
        "rz": 0.0, "d": 1024.0,
    }

    snow_params = {"count": 400, "psize": 8.0, "soft": 25.0, "follow": 1, "world_fixed": 1, "log_mode": 1}
    sess_old_bug = PersistentAviUtl2Session(str(SNOW_OBJ2), width=W, height=H, bridge=None, restrict_stdlib=True, virtual_files=zh_files)
    r_none = sess_ref.render_frame(params=snow_params, camera=cam_none, self_layer=2, frame=0)
    r_old  = sess_old_bug.render_frame(params=snow_params, camera=cam_old_bug, self_layer=2, frame=0)
    r_self = sess_self.render_frame(params=snow_params, camera=cam_self, self_layer=2, frame=0)
    assert r_none["error"] is None and r_self["error"] is None

    mae = float(np.mean(np.abs(r_none["rgba8"].astype(np.float32) - r_self["rgba8"].astype(np.float32))))
    old_mae = float(np.mean(np.abs(r_none["rgba8"].astype(np.float32) - r_old["rgba8"].astype(np.float32))))
    max_diff = int(np.max(np.abs(r_none["rgba8"].astype(np.int32) - r_self["rgba8"].astype(np.int32))))
    assert max_diff == 0 and mae == 0.0, f"Snow rendering differed between 目标图层=--- and 目标图层=1! max_diff={max_diff}, mae={mae}"
    assert old_mae > 0.5, f"Old bug simulation must differ from 目标图层=---: old_mae={old_mae}"
    assert r_none["logs"] == r_self["logs"] and len(r_self["logs"]) == 1, f"Logs differed: {r_none['logs']} vs {r_self['logs']}"

    # Also test moving camera with 目标图层 = 1 (X=420, Y=-180, Z=-600, 目标=(0,0,0) => tx=420, ty=-180, tz=-600)
    cam_moved_self = {
        "x": 420.0, "y": -180.0, "z": -600.0,
        "tx": 420.0, "ty": -180.0, "tz": -600.0,
        "ux": 0.0, "uy": -1.0, "uz": 0.0,
        "rz": 0.0, "d": 1024.0,
    }
    cam_moved_equiv = {
        "x": 420.0, "y": -180.0, "z": -600.0,
        "tx": 420.0, "ty": -180.0, "tz": 424.0,  # -600 + 1024
        "ux": 0.0, "uy": -1.0, "uz": 0.0,
        "rz": 0.0, "d": 1024.0,
    }
    sess_m1 = PersistentAviUtl2Session(str(SNOW_OBJ2), width=W, height=H, bridge=None, restrict_stdlib=True, virtual_files=zh_files)
    sess_m2 = PersistentAviUtl2Session(str(SNOW_OBJ2), width=W, height=H, bridge=None, restrict_stdlib=True, virtual_files=zh_files)
    r_m1 = sess_m1.render_frame(params=snow_params, camera=cam_moved_equiv, self_layer=2, frame=90)
    r_m2 = sess_m2.render_frame(params=snow_params, camera=cam_moved_self, self_layer=2, frame=90)
    moved_max_diff = int(np.max(np.abs(r_m1["rgba8"].astype(np.int32) - r_m2["rgba8"].astype(np.int32))))
    assert moved_max_diff == 0

    comp_snow = np.concatenate([r_none["rgba8"], r_old["rgba8"], r_self["rgba8"]], axis=1)
    Image.fromarray(comp_snow).save(OUT_DIR / "v122_snow_cam_target_compare.png")

    return {
        "old_v121_self_target_pixel_mae": round(old_mae, 4),
        "new_v122_target_none_vs_self_pixel_mae": mae,
        "new_v122_target_none_vs_self_max_rgba_diff": max_diff,
        "moved_camera_self_target_max_rgba_diff": moved_max_diff,
        "log_output_identical": r_self["logs"][0],
    }


def main():
    print("[1/3] Auditing LuaJIT bytecode registers & global hygiene across all 3 scripts...")
    r_bc = suite_a_bytecode_audit()
    print("  Bytecode audit:", json.dumps(r_bc, ensure_ascii=False))

    print("[2/3] Verifying Bug 1: 体積光 v2.94-bridge + VL3DBridge v1.21 [テキスト] 18-alignment cutout & light source...")
    r_b1 = suite_b_text_alignment_cutout()
    print("  Bug 1 Result:", json.dumps(r_b1, indent=2, ensure_ascii=False))

    print("[3/3] Verifying Bug 2: 雪（3D）v1.22 [カメラ制御] 目標レイヤー=自身 (1) vs --- (image-2 vs image-3)...")
    r_b2 = suite_c_snow_self_target_camera()
    print("  Bug 2 Result:", json.dumps(r_b2, indent=2, ensure_ascii=False))

    full = {"bytecode": r_bc, "bug1_text_alignment": r_b1, "bug2_snow_self_target": r_b2}
    out_p = OUT_DIR / "verify_v294_text_align_and_snow_cam_results.json"
    out_p.write_text(json.dumps(full, indent=2, ensure_ascii=False), encoding="utf-8")
    print("\nALL BUG-1 + BUG-2 + REGRESSION VERIFICATION SUITES PASSED! Saved:", out_p)


if __name__ == "__main__":
    main()
