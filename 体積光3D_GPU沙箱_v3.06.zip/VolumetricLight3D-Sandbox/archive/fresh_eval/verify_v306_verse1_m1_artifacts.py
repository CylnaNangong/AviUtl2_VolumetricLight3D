#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
v3.06 diagnosis: reproduce the user's Verse1 artifact
  (manual occ_list="4", occ_mode=1 (3D影のみ/物理遮光), 2D plaster bust occluder
   -> 矩形黑块 / 破碎边缘 / 闪烁)

Cases:
  A) Verse1 repro   : frame_s=619, frame=146, scene_id=1, m1 manual L4
  B) Reference      : same scene, occ_mode=0 (no occlusion)
  C) Main-scene     : frame_s=0,  scene_id=0, m1 manual L4
  D) Recommended m3 : same as A but occ_mode=3
  E) Rotated bust   : same as A but statue ry=18deg

Diagnostics per case:
  - rendered frame PNG
  - occlusion atlas (cache:vl3d/occ_a / occ_b) readback + alpha coverage stats
  - HUD logs (遮蔽=...), layer_load_calls, occ_stats
  - A-vs-B shadow diff -> bbox fill ratio (rectangular vs bust-shaped)
"""
import sys
import pathlib
import numpy as np
from PIL import Image

sys.path.insert(0, "/home/user/sandbox")
sys.path.insert(0, "/home/user/sandbox/fresh_eval")

from generate_assets import make_plaster_bust_png, make_stained_glass_png
from sandbox_v2_fidelity import FidelityLayer, PersistentAviUtl2Session, VL3DBridgeMockHost

ROOT = pathlib.Path("/home/user")
VL = ROOT / "GitHub_VolumetricLight3D/Script/体積光（3D）.obj2"
OUT = ROOT / "sandbox/fresh_eval/outputs/v306_repro"
OUT.mkdir(parents=True, exist_ok=True)

W, H = 640, 360

glass = make_stained_glass_png(OUT / "stained_glass.png")   # 512x512 bright window
bust = make_plaster_bust_png(OUT / "plaster_bust.png")      # 512x512 silhouette w/ alpha

# 1/3-scale equivalents of the user's 6673x4923 @ Z=1000 light:
LIGHT_Z = 333.0
LIGHT_ZOOM = 435.0  # 512 * 4.35 ~= 2227 world units wide

def make_light():
    return FidelityLayer(index=2, name="光源", x=0.0, y=-100.0, z=LIGHT_Z,
                         zoom=LIGHT_ZOOM, alpha=1.0, image=glass, kind_override="OTHER")

def make_statue(ry=0.0, z=140.0):
    return FidelityLayer(index=4, name="石膏像", x=0.0, y=-30.0, z=z,
                         ry=ry, zoom=110.0, alpha=1.0, image=bust, kind_override="OTHER")

CAM = {"x": 0.0, "y": -40.0, "z": -1024.0, "tx": 0.0, "ty": 20.0, "tz": 0.0,
       "ux": 0.0, "uy": -1.0, "uz": 0.0, "rz": 0.0, "d": 1024.0}

BASE_PARAMS = {
    "src_layer": 2,
    "intensity": 150.0,
    "direction": 55.0,
    "pitch": 44.0,
    "occ_3d_mode": 0,
    "occ_target": 2,
    "occ_list": "4",
    "occ_strength": 100.0,
    "occ_soft": 8.0,
    "log_mode": True,
    "show_info": False,
}


def run(tag, occ_mode, frame_s=619, scene_id=1, frame=146, statue=None):
    br = VL3DBridgeMockHost(mode="v290_sdk_lock", scene_id=scene_id)
    sess = PersistentAviUtl2Session(str(VL), width=W, height=H, strict_getvalue=True, bridge=br)
    layers = {2: make_light(), 4: statue or make_statue()}
    params = dict(BASE_PARAMS)
    params["occ_mode"] = occ_mode
    res = sess.render_frame(params=params, camera=CAM, layers=layers, self_layer=10,
                            frame=frame, totalframe=619, frame_s=frame_s, scene_id=scene_id)
    img = res["rgba8"]
    Image.fromarray(img).save(OUT / f"{tag}.png")

    atlas = {}
    for bn in ("cache:vl3d/occ_a", "cache:vl3d/occ_b"):
        try:
            arr = sess.sb.read_numpy(bn)
            if arr is not None and arr.ndim == 3 and arr.shape[0] > 8 and arr.shape[1] > 8:
                a = arr[..., 3].astype(np.float32)
                cov = float((a > 8).mean())
                atlas[bn] = {"shape": arr.shape[:2], "cov>a8": round(cov, 4),
                             "amax": int(a.max()), "solid_rect": cov > 0.93}
                Image.fromarray(arr).save(OUT / f"{tag}_atlas_{bn.split('/')[-1]}.png")
        except Exception as e:
            atlas[bn] = f"err:{e}"

    try:
        stats = sess.lua.eval(
            "(function() local t=_G._VL3D_PERSIST_V280 and _G._VL3D_PERSIST_V280.occ_stats or {} "
            "local r={} for k,v in pairs(t) do r[k]=v end return r end)()")
        stats = dict(stats) if stats else {}
    except Exception:
        stats = {}

    hud = [l for l in res["logs"] if ("遮蔽" in l or "光源" in l or "体積光" in l)]
    print(f"--- {tag} (occ_mode={occ_mode}) ---")
    print("  error      :", res["error"])
    for l in hud[:3]:
        print("  log        :", l[:160])
    print("  layer_loads:", res["layer_load_calls"])
    print("  atlas      :", atlas)
    print("  occ_stats  :", stats)
    return res


def shadow_analysis(tag_a, res_a, res_b, thr=30):
    a = res_a["rgba8"][..., :3].astype(np.int16)
    b = res_b["rgba8"][..., :3].astype(np.int16)
    diff = np.clip(b - a, 0, 255).sum(axis=2)
    ys, xs = np.nonzero(diff > thr)
    print(f"=== shadow diff analysis: {tag_a} vs reference ===")
    if len(xs) == 0:
        print("  NO visible shadow from occluder!")
        return
    x0, x1, y0, y1 = int(xs.min()), int(xs.max()), int(ys.min()), int(ys.max())
    bw, bh = x1 - x0 + 1, y1 - y0 + 1
    fill = len(xs) / float(bw * bh)
    print(f"  bbox=({x0},{y0})-({x1},{y1}) size={bw}x{bh} fill_ratio={fill:.3f} "
          f"-> {'RECTANGULAR (bug!)' if fill > 0.90 else ('bust-shaped/soft (plausible)' if fill < 0.62 else 'mixed')}")
    d = np.zeros((H, W, 3), dtype=np.uint8)
    d[..., 0] = np.clip(diff / 3, 0, 255)
    Image.fromarray(d).save(OUT / f"{tag_a}_shadow_diff.png")


def main():
    res_a = run("A_verse1_m1_manual", 1)
    res_b = run("B_verse1_noocc", 0)
    res_c = run("C_main_m1_manual", 1, frame_s=0, scene_id=0)
    res_d = run("D_verse1_m3_manual", 3)
    res_e = run("E_verse1_m1_rot18", 1, statue=make_statue(ry=18.0))

    shadow_analysis("A_verse1_m1_manual", res_a, res_b)
    shadow_analysis("C_main_m1_manual", res_c, res_b)
    shadow_analysis("D_verse1_m3_manual", res_d, res_b)
    shadow_analysis("E_verse1_m1_rot18", res_e, res_b)
    print("\nOutputs in:", OUT)


if __name__ == "__main__":
    main()
