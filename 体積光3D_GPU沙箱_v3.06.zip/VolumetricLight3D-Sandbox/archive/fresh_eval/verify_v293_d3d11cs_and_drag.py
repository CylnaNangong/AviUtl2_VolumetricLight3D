#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Fresh End-to-End Verification Suite for AviUtl2 v2.1.15 + SDK (2026/10/24) + VL3DBridge v1.20
=============================================================================================
Verifies:
  1. Real Vulkan wgpu execution of exact HLSL cs_5_0 shaders in vl3d_bridge_shaders.h
     (cs_clear -> cs_project_and_rast_small -> cs_rast_large_tiles -> cs_encode_rgba)
     vs C++ VL3DBridge::RasterizeShadow / RasterizeCamDepth on a 38,012-triangle birdcage + giant floor + VRM.
  2. Restricted AviUtl2 v2.1.15 Lua sandbox (_G.os == nil, _G.io == nil, _G.debug == nil):
     24-step live drag of 38,012-triangle birdcage WITH VL3DBridge v1.20 (0 re-uploads, full 38,012 tris, 0 errors).
  3. Restricted AviUtl2 v2.1.15 Lua sandbox (_G.os == nil, _G.io == nil, _G.debug == nil):
     Pure LuaJIT FFI fallback (bridge=None) live drag hitting L4602 t_stop time-budget check (0 errors!).
  4. 体積霧（3D）.obj2 v2.04 obj.module("VL3DBridge") live edit-camera connection + os==nil log clock.
  5. 雪（3D）.obj2 v1.20 + all 12 .aul2 language packs integrity check under restricted sandbox.
"""
import base64
import ctypes
import json
import math
import os
import pathlib
import re
import struct
import subprocess
import sys
import tempfile
import time
import numpy as np
from PIL import Image
import wgpu

sys.path.insert(0, "/home/user/sandbox")
sys.path.insert(0, "/home/user/sandbox/fresh_eval")

from sandbox_v2_fidelity import (
    FidelityLayer,
    PersistentAviUtl2Session,
    VL3DBridgeMockHost,
    reset_fresh_spv_cache,
)
from generate_assets import make_stained_glass_png

ROOT = pathlib.Path("/home/user")
OUT_DIR = ROOT / "sandbox/fresh_eval/outputs"
IMG_DIR = OUT_DIR / "renders_v293"
OUT_DIR.mkdir(parents=True, exist_ok=True)
IMG_DIR.mkdir(parents=True, exist_ok=True)
reset_fresh_spv_cache()

VL_DIR    = ROOT / "scripts/pkg1/体积光（3D）/development/branch_v2.90_aux2_bridge"
VL_OBJ2   = VL_DIR / "Script/体積光（3D）.obj2"
VL_SH_HDR = VL_DIR / "src_aux2/src/vl3d_bridge_shaders.h"
VL_AUX2   = VL_DIR / "Plugin/VL3DBridge.aux2"
VL_INI    = VL_DIR / "Plugin/VL3DBridge.ini"
FOG_OBJ2  = ROOT / "scripts/pkg2/体积雾（3D）/stable/Script/体積霧（3D）.obj2"
SNOW_OBJ2 = ROOT / "scripts/pkg3/雪（3D）/stable/Script/雪（3D）.obj2"


def generate_birdcage_38012_obj(out_path: pathlib.Path):
    """Generates an ornate thin-bar dome birdcage mesh with EXACTLY 38,012 triangles."""
    verts = []
    tris = []  # 0-based (i0, i1, i2)

    def add_tube_segment(p0, p1, radius, sides=6):
        dx, dy, dz = p1[0] - p0[0], p1[1] - p0[1], p1[2] - p0[2]
        ln = math.sqrt(dx * dx + dy * dy + dz * dz)
        if ln < 1e-6:
            return
        ux, uy, uz = dx / ln, dy / ln, dz / ln
        if abs(uy) < 0.9:
            rx, ry, rz = uz, 0.0, -ux
        else:
            rx, ry, rz = 1.0, 0.0, 0.0
        rl = math.sqrt(rx * rx + ry * ry + rz * rz)
        rx, ry, rz = rx / rl, ry / rl, rz / rl
        bx = uy * rz - uz * ry
        by = uz * rx - ux * rz
        bz = ux * ry - uy * rx

        base = len(verts)
        for end_p in (p0, p1):
            for s in range(sides):
                ang = (2.0 * math.pi * s) / sides
                ca, sa = math.cos(ang) * radius, math.sin(ang) * radius
                verts.append((
                    end_p[0] + rx * ca + bx * sa,
                    end_p[1] + ry * ca + by * sa,
                    end_p[2] + rz * ca + bz * sa,
                ))
        for s in range(sides):
            sn = (s + 1) % sides
            a0, a1 = base + s, base + sn
            b0, b1 = base + sides + s, base + sides + sn
            tris.append((a0, b0, b1))
            tris.append((a0, b1, a1))

    # Each 6-sided tube segment adds 12 triangles.
    # 38,012 = 3167 * 12 + 8 triangles!
    R = 95.0
    # 1) 48 vertical cage bars x 36 height segments = 1,728 segs (20,736 tris)
    n_bars = 48
    h_segs = 36
    y_bot, y_mid = 110.0, -50.0
    for b in range(n_bars):
        phi = 2.0 * math.pi * b / n_bars
        x, z = R * math.cos(phi), R * math.sin(phi)
        for hs in range(h_segs):
            y0 = y_bot + (y_mid - y_bot) * (hs / h_segs)
            y1 = y_bot + (y_mid - y_bot) * ((hs + 1) / h_segs)
            add_tube_segment((x, y0, z), (x, y1, z), 1.6, sides=6)

    # 2) 48 dome ribs x 20 segments = 960 segs (11,520 tris) -> total 2,688 segs
    d_segs = 20
    dome_h = 85.0
    for b in range(n_bars):
        phi = 2.0 * math.pi * b / n_bars
        cp, sp = math.cos(phi), math.sin(phi)
        for ds in range(d_segs):
            t0 = (0.5 * math.pi) * (ds / d_segs)
            t1 = (0.5 * math.pi) * ((ds + 1) / d_segs)
            p0 = (R * math.cos(t0) * cp, y_mid - dome_h * math.sin(t0), R * math.cos(t0) * sp)
            p1 = (R * math.cos(t1) * cp, y_mid - dome_h * math.sin(t1), R * math.cos(t1) * sp)
            add_tube_segment(p0, p1, 1.5, sides=6)

    # 3) Horizontal structural rings: 9 rings x 48 segs = 432 segs -> total 3,120 segs
    ring_ys = [110.0, 80.0, 40.0, 0.0, -35.0, -50.0, -75.0, -100.0, -120.0]
    for ry in ring_ys:
        if ry >= y_mid:
            rr = R
        else:
            st = min(0.98, (y_mid - ry) / dome_h)
            rr = R * math.sqrt(max(0.02, 1.0 - st * st))
        for b in range(n_bars):
            p0_a = 2.0 * math.pi * b / n_bars
            p1_a = 2.0 * math.pi * ((b + 1) % n_bars) / n_bars
            add_tube_segment(
                (rr * math.cos(p0_a), ry, rr * math.sin(p0_a)),
                (rr * math.cos(p1_a), ry, rr * math.sin(p1_a)),
                2.2, sides=6
            )

    # 4) Top hook & inner perch: remaining 47 segments (3167 - 3120 = 47 segs -> 38,004 tris)
    for k in range(47):
        ang0 = 2.0 * math.pi * k / 47.0
        ang1 = 2.0 * math.pi * (k + 1) / 47.0
        p0 = (22.0 * math.cos(ang0), -135.0 - 18.0 * math.sin(ang0), 4.0 * math.sin(2 * ang0))
        p1 = (22.0 * math.cos(ang1), -135.0 - 18.0 * math.sin(ang1), 4.0 * math.sin(2 * ang1))
        add_tube_segment(p0, p1, 2.0, sides=6)

    # 5) Base octagram finial (+8 triangles => EXACTLY 38,012 triangles!)
    assert len(tris) == 38004, f"Expected 38004 before cap, got {len(tris)}"
    c_idx = len(verts)
    verts.append((0.0, 112.0, 0.0))
    ring_base = len(verts)
    for k in range(8):
        a = 2.0 * math.pi * k / 8.0
        verts.append((36.0 * math.cos(a), 112.0, 36.0 * math.sin(a)))
    for k in range(8):
        tris.append((c_idx, ring_base + k, ring_base + ((k + 1) % 8)))

    assert len(tris) == 38012, f"Expected 38012 tris, got {len(tris)}"

    lines = ["# Procedural 38,012-triangle ornate birdcage matching bairdcage.obj (in meter units -> x100 px in AviUtl2)\n"]
    for vx, vy, vz in verts:
        lines.append(f"v {vx * 0.01:.6f} {vy * 0.01:.6f} {vz * 0.01:.6f}\n")
    for i0, i1, i2 in tris:
        lines.append(f"f {i0 + 1} {i1 + 1} {i2 + 1}\n")
    out_path.write_text("".join(lines), encoding="utf-8")
    return np.array(verts, dtype=np.float32), np.array(tris, dtype=np.uint32)


def extract_hlsl_cs_source() -> str:
    txt = VL_SH_HDR.read_text(encoding="utf-8")
    m = re.search(r'R"HLSL\((.*?)\)HLSL"', txt, re.S)
    assert m, "Could not extract kVl3dRastHlslCs from vl3d_bridge_shaders.h"
    return m.group(1)


def compile_hlsl_compute_spv(hlsl_src: str, entry: str) -> bytes:
    with tempfile.TemporaryDirectory() as td:
        hlsl_f = pathlib.Path(td) / "rast.hlsl"
        spv_f = pathlib.Path(td) / f"{entry}.spv"
        hlsl_f.write_text(hlsl_src, encoding="utf-8")
        # Map DirectX register spaces cleanly for Vulkan glslangValidator:
        # b0 -> binding 0, t0 -> binding 1, t1 -> binding 2, u0 -> binding 3, u1 -> binding 4, u2 -> binding 5, u3 -> binding 6
        cmd = [
            "glslangValidator", "-D", "-S", "comp", "-e", entry,
            "-DVL3D_VULKAN_TEST",
            "--hlsl-offsets", "--hlsl-iomap",
            "--shift-cbuffer-binding", "0",
            "--shift-texture-binding", "1",
            "--shift-uav-binding", "3",
            "-V", str(hlsl_f), "-o", str(spv_f),
        ]
        proc = subprocess.run(cmd, capture_output=True, text=True)
        if proc.returncode != 0:
            raise RuntimeError(f"glslangValidator failed on {entry}:\n{proc.stdout}\n{proc.stderr}")
        return spv_f.read_bytes()


def run_vulkan_cs_vs_cpp_test(verts_np: np.ndarray, tris_np: np.ndarray) -> dict:
    """Executes the exact 4-pass kVl3dRastHlslCs compute pipeline on Vulkan wgpu and compares with C++."""
    hlsl_vk = extract_hlsl_cs_source()

    adapter = wgpu.gpu.request_adapter_sync(power_preference="high-performance")
    device = adapter.request_device_sync()

    pipes = {}
    bgl = device.create_bind_group_layout(entries=[
        {"binding": 0, "visibility": wgpu.ShaderStage.COMPUTE, "buffer": {"type": wgpu.BufferBindingType.uniform}},
        {"binding": 1, "visibility": wgpu.ShaderStage.COMPUTE, "buffer": {"type": wgpu.BufferBindingType.read_only_storage}},
        {"binding": 2, "visibility": wgpu.ShaderStage.COMPUTE, "buffer": {"type": wgpu.BufferBindingType.read_only_storage}},
        {"binding": 3, "visibility": wgpu.ShaderStage.COMPUTE, "buffer": {"type": wgpu.BufferBindingType.storage}},
        {"binding": 4, "visibility": wgpu.ShaderStage.COMPUTE, "buffer": {"type": wgpu.BufferBindingType.storage}},
        {"binding": 5, "visibility": wgpu.ShaderStage.COMPUTE, "buffer": {"type": wgpu.BufferBindingType.storage}},
        {"binding": 6, "visibility": wgpu.ShaderStage.COMPUTE, "buffer": {"type": wgpu.BufferBindingType.storage}},
    ])
    pl_layout = device.create_pipeline_layout(bind_group_layouts=[bgl])

    for ep in ("cs_clear", "cs_project_and_rast_small", "cs_rast_large_tiles", "cs_encode_rgba"):
        spv = compile_hlsl_compute_spv(hlsl_vk, ep)
        sm = device.create_shader_module(code=spv)
        pipes[ep] = device.create_compute_pipeline(layout=pl_layout, compute={"module": sm, "entry_point": ep})

    # Add a giant backdrop quad (2 huge triangles covering ~500x500 px = 250,000 px > 4096 -> exercises Pass 3 cs_rast_large_tiles!)
    nv_bc = verts_np.shape[0]
    floor_v = np.array([
        [-160.0, -140.0, 420.0],
        [ 160.0, -140.0, 420.0],
        [ 160.0,  140.0, 450.0],
        [-160.0,  140.0, 450.0],
    ], dtype=np.float32)
    floor_t = np.array([
        [nv_bc + 0, nv_bc + 1, nv_bc + 2],
        [nv_bc + 0, nv_bc + 2, nv_bc + 3],
    ], dtype=np.uint32)
    all_v3 = np.concatenate([verts_np, floor_v], axis=0)
    all_t3 = np.concatenate([tris_np, floor_t], axis=0)

    nv = all_v3.shape[0]
    nt = all_t3.shape[0]
    v4 = np.zeros((nv, 4), dtype=np.float32)
    v4[:, :3] = all_v3
    t4 = np.zeros((nt, 4), dtype=np.uint32)
    t4[:, :3] = all_t3

    sh_res = 768
    npix = sh_res * sh_res
    vb_gpu = device.create_buffer_with_data(data=v4.tobytes(), usage=wgpu.BufferUsage.STORAGE)
    ib_gpu = device.create_buffer_with_data(data=t4.tobytes(), usage=wgpu.BufferUsage.STORAGE)
    cb_gpu = device.create_buffer(size=256, usage=wgpu.BufferUsage.UNIFORM | wgpu.BufferUsage.COPY_DST)
    prox_gpu = device.create_buffer(size=npix * 4, usage=wgpu.BufferUsage.STORAGE)
    large_gpu = device.create_buffer(size=65536 * 64, usage=wgpu.BufferUsage.STORAGE)
    meta_gpu = device.create_buffer(size=16, usage=wgpu.BufferUsage.STORAGE | wgpu.BufferUsage.COPY_SRC)
    rgba_gpu = device.create_buffer(size=npix * 4, usage=wgpu.BufferUsage.STORAGE | wgpu.BufferUsage.COPY_SRC)

    bg = device.create_bind_group(layout=bgl, entries=[
        {"binding": 0, "resource": {"buffer": cb_gpu, "offset": 0, "size": 256}},
        {"binding": 1, "resource": {"buffer": vb_gpu, "offset": 0, "size": v4.nbytes}},
        {"binding": 2, "resource": {"buffer": ib_gpu, "offset": 0, "size": t4.nbytes}},
        {"binding": 3, "resource": {"buffer": prox_gpu, "offset": 0, "size": npix * 4}},
        {"binding": 4, "resource": {"buffer": rgba_gpu, "offset": 0, "size": npix * 4}},
        {"binding": 5, "resource": {"buffer": meta_gpu, "offset": 0, "size": 16}},
        {"binding": 6, "resource": {"buffer": large_gpu, "offset": 0, "size": 65536 * 64}},
    ])

    # Build exact RastCBData matching BuildShadowRastCB in vl3d_bridge_rast.cpp
    cb = np.zeros((16, 4), dtype=np.float32)
    Hx, Hy, L_tot = 220.0, 220.0, 1400.0
    ox, oy, oz = 15.0, -10.0, 220.0
    cb[0]  = [sh_res, sh_res, 0.0, float(nt)]
    cb[1]  = [ox, oy, oz, 1.0]
    cb[2]  = [1.0, 0.0, 0.0, 0.0]
    cb[3]  = [0.0, 1.0, 0.0, 0.0]
    cb[4]  = [0.0, 0.0, 1.0, L_tot]
    cb[5]  = [0.0, 0.0, 1.0, 0.5]
    cb[6]  = [0.0, 0.0, 0.0, 0.0]
    cb[7]  = [0.0, 0.0, 0.0, 1.0 / L_tot]
    cb[8]  = [1.0, 0.0, 0.0, 1.0 / (2.0 * Hx)]
    cb[9]  = [0.0, 1.0, 0.0, 1.0 / (2.0 * Hy)]
    cb[10] = [0.0, 0.0, 1.0, 1.0]
    cb[11] = [0.0, 0.0, 1.0, 0.0]
    cb[12] = [512.0, 4096.0, 16384.0, float(npix)]

    t0_gpu = time.perf_counter()
    device.queue.write_buffer(cb_gpu, 0, cb.tobytes())
    enc = device.create_command_encoder()
    cp = enc.begin_compute_pass()
    cp.set_bind_group(0, bg)
    cp.set_pipeline(pipes["cs_clear"])
    cp.dispatch_workgroups((npix + 255) // 256, 1, 1)
    cp.set_pipeline(pipes["cs_project_and_rast_small"])
    cp.dispatch_workgroups((nt + 63) // 64, 1, 1)
    cp.set_pipeline(pipes["cs_rast_large_tiles"])
    cp.dispatch_workgroups((sh_res + 7) // 8, (sh_res + 7) // 8, 1)
    cp.set_pipeline(pipes["cs_encode_rgba"])
    cp.dispatch_workgroups((npix + 255) // 256, 1, 1)
    cp.end()
    device.queue.submit([enc.finish()])
    meta_bytes = device.queue.read_buffer(meta_gpu)
    rgba_gpu_bytes = device.queue.read_buffer(rgba_gpu)
    gpu_ms = (time.perf_counter() - t0_gpu) * 1000.0

    large_queued, hit_pixels = struct.unpack_from("<II", meta_bytes, 0)
    gpu_img = np.frombuffer(rgba_gpu_bytes, dtype=np.uint8).reshape((sh_res, sh_res, 4))

    # Run C++ VL3DBridge::RasterizeShadow with identical scene & parameters
    so = ctypes.CDLL("/home/user/sandbox/libvl3d_bridge_linux.so")
    so.vl3d_test_upload_mesh_b64.argtypes = [ctypes.c_char_p, ctypes.c_char_p, ctypes.c_int, ctypes.c_int, ctypes.c_char_p, ctypes.c_char_p]
    so.vl3d_test_upload_mesh_b64.restype = ctypes.c_int32
    so.vl3d_test_rasterize_shadow.argtypes = [
        ctypes.c_void_p, ctypes.c_int, ctypes.POINTER(ctypes.c_double),
        ctypes.POINTER(ctypes.c_double), ctypes.c_int,
        ctypes.POINTER(ctypes.c_int), ctypes.POINTER(ctypes.c_int),
    ]
    so.vl3d_test_rasterize_shadow.restype = ctypes.c_int

    vb64 = base64.b64encode(all_v3.astype(np.float32).tobytes())
    tb64 = base64.b64encode(all_t3.astype(np.uint32).tobytes())
    mid = so.vl3d_test_upload_mesh_b64(b"vk_cmp", b"v1", nv, nt, vb64, tb64)
    assert mid > 0

    cpp_rgba = np.zeros((sh_res, sh_res, 4), dtype=np.uint8)
    p22 = (ctypes.c_double * 22)(
        0.0, 0.0, 0.0, Hx, Hy,
        1.0, 0.0, 0.0,  0.0, 1.0, 0.0,  0.0, 0.0, 1.0,
        0.0, 0.0, 0.0, 1.0, 1.0, 0.0, L_tot, 512.0
    )
    i14 = (ctypes.c_double * 14)(mid, 1.0, ox, oy, oz, 1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0)
    out_t = ctypes.c_int(0)
    out_a = ctypes.c_int(0)
    t0_cpp = time.perf_counter()
    ok_cpp = so.vl3d_test_rasterize_shadow(
        cpp_rgba.ctypes.data_as(ctypes.c_void_p), sh_res, p22, i14, 1, ctypes.byref(out_t), ctypes.byref(out_a)
    )
    cpp_ms = (time.perf_counter() - t0_cpp) * 1000.0
    assert ok_cpp == 1 and out_a.value == 1

    gpu_mask = gpu_img[..., 3] > 0
    cpp_mask = cpp_rgba[..., 3] > 0
    union_n = int(np.sum(gpu_mask | cpp_mask))
    inter_n = int(np.sum(gpu_mask & cpp_mask))
    iou = inter_n / max(1, union_n)
    mean_abs_diff = float(np.mean(np.abs(gpu_img.astype(np.float32) - cpp_rgba.astype(np.float32))))

    Image.fromarray(gpu_img).save(IMG_DIR / "shmap_gpu_cs50_bairdcage38012.png")
    Image.fromarray(cpp_rgba).save(IMG_DIR / "shmap_cpp_cpu_bairdcage38012.png")

    return {
        "triangles_tested": int(nt),
        "large_tris_deferred_pass3": int(large_queued),
        "gpu_hit_pixels": int(hit_pixels),
        "cpp_hit_pixels": int(np.sum(cpp_mask)),
        "mask_iou": round(iou, 6),
        "mean_rgba_abs_diff_0_255": round(mean_abs_diff, 4),
        "vulkan_cs_ms_with_readback": round(gpu_ms, 2),
        "cpp_o3_cpu_ms": round(cpp_ms, 2),
    }


def main():
    report = {}
    obj_path = OUT_DIR / "bairdcage_38012.obj"
    print("[1/5] Generating 38,012-triangle ornate birdcage OBJ & testing HLSL cs_5_0 on Vulkan wgpu vs C++ -O3...")
    verts_np, tris_np = generate_birdcage_38012_obj(obj_path)
    cs_res = run_vulkan_cs_vs_cpp_test(verts_np, tris_np)
    print("  CS vs C++ Result:", json.dumps(cs_res, indent=2))
    assert cs_res["large_tris_deferred_pass3"] >= 2, "Pass 3 large-triangle tile path was not exercised!"
    assert cs_res["mask_iou"] >= 0.995, f"GPU CS vs C++ mask IoU too low: {cs_res['mask_iou']}"
    assert cs_res["mean_rgba_abs_diff_0_255"] < 0.35, f"GPU CS vs C++ diff too large: {cs_res['mean_rgba_abs_diff_0_255']}"
    report["hlsl_cs50_vs_cpp_parity"] = cs_res

    make_stained_glass_png(str(OUT_DIR / "stained_v293.png"), 384)
    stained_np = np.array(Image.open(OUT_DIR / "stained_v293.png").convert("RGBA"), dtype=np.uint8)
    cam = {
        "x": -180.0, "y": -90.0, "z": -980.0,
        "tx": 0.0, "ty": 0.0, "tz": 180.0,
        "ux": 0.0, "uy": -1.0, "uz": 0.0,
        "rz": 0.0, "d": 1024.0,
    }

    # ==========================================================================
    # [2/5] Restricted Sandbox (_G.os == nil, _G.io == nil) 24-Step Drag WITH VL3DBridge v1.20
    # ==========================================================================
    print("[2/5] Running 24-step live drag of 38,012-tri birdcage WITH VL3DBridge v1.20 (_G.os==nil, _G.io==nil)...")
    br = VL3DBridgeMockHost(mode="v120_native", scene_id=1)
    br.gpu_backend_label = "D3D11_CS"
    sess = PersistentAviUtl2Session(str(VL_OBJ2), width=960, height=540, bridge=br, restrict_stdlib=True)

    # Confirm _G.os == nil and _G.io == nil inside the VM!
    os_is_nil, io_is_nil = sess.lua.eval("type(os) == 'nil', type(io) == 'nil'")
    assert os_is_nil and io_is_nil, "Sandbox failed to wipe _G.os / _G.io!"

    def make_layers(bx: float, bry: float):
        return {
            1: FidelityLayer(index=1, name="StainedGlass", x=0.0, y=0.0, z=0.0, zoom=100.0, alpha=1.0, image=stained_np),
            3: FidelityLayer(
                index=3, name="Birdcage38012", x=bx, y=-10.0, z=-240.0, rx=8.0, ry=bry, rz=0.0,
                zoom=100.0, alpha=1.0, kind_override="OBJ", model_path=str(obj_path), coord_adj=0,
                effects={"モデルファイル": {"ファイル": str(obj_path), "座標系を調整": 0}},
            ),
        }

    vl_params = {
        "src_layer": 1, "emit_mode": 0, "occ_mode": 3, "obj3d_mode": 0,
        "ray_len": 1100.0, "intensity": 165.0, "res_mode": 1,
        "hud_debug": 1, "log_info": 1,
    }

    # Static frame before drag (frame=42)
    r_pre = sess.render_frame(params=vl_params, camera=cam, layers=make_layers(-150.0, 0.0), self_layer=4, frame=42)
    assert r_pre["error"] is None, f"Pre-drag error: {r_pre['error']}"
    Image.fromarray(r_pre["rgba8"]).save(IMG_DIR / "vl293_drag00_static_pre.png")

    drag_lumas = []
    drag_times_ms = []
    drag_tris_seq = []
    for step in range(1, 25):
        bx = -150.0 + (300.0 * step / 24.0)
        bry = step * 7.5
        t_s = time.perf_counter()
        r_d = sess.render_frame(params=vl_params, camera=cam, layers=make_layers(bx, bry), self_layer=4, frame=42)
        dt_ms = (time.perf_counter() - t_s) * 1000.0
        assert r_d["error"] is None, f"Drag step {step} Lua error: {r_d['error']}"
        err_logs = [lg for lg in r_d["logs"] if "@error" in lg or "error:" in lg.lower()]
        assert not err_logs, f"Drag step {step} logged error: {err_logs}"
        fb = r_d["rgba8"]
        luma = float(np.mean(fb[..., :3]))
        assert luma > 12.0, f"Volumetric light disappeared during drag step {step} (luma={luma})!"
        drag_lumas.append(round(luma, 2))
        drag_times_ms.append(round(dt_ms, 2))
        st_cur = sess.lua.eval("_G._VL3D_PERSIST_V280.occ_stats")
        drag_tris_seq.append(int(st_cur["last_tris"]))
        if step == 12:
            Image.fromarray(fb).save(IMG_DIR / "vl293_drag12_live_center_cs.png")

    occ_st = sess.lua.eval("_G._VL3D_PERSIST_V280.occ_stats")
    center_tris_hw = drag_tris_seq[11]  # step 12: bx == 0.0 (centered in window!)
    last_res_hw  = int(occ_st["last_sh_res"])
    last_bk_hw   = str(occ_st["last_backend"])
    hud_logs = [lg for lg in r_d["logs"] if "v2.93" in lg]

    assert br.upload_mesh_calls == 1, f"Mesh should upload ONCE, got {br.upload_mesh_calls}!"
    assert br.has_mesh_hits >= 48, f"Expected >=48 zero-copy mesh cache hits across 24 drag steps, got {br.has_mesh_hits}!"
    assert center_tris_hw >= 37500, f"Expected full ~38,012 visible tris at center drag step 12, got {center_tris_hw}!"
    assert last_res_hw == 768, f"Expected 768x768 live drag shmap, got {last_res_hw}!"
    assert last_bk_hw == "D3D11_CS"

    report["drag_24steps_vl3dbridge_v120"] = {
        "os_is_nil": bool(os_is_nil),
        "io_is_nil": bool(io_is_nil),
        "upload_mesh_calls": br.upload_mesh_calls,
        "has_mesh_cache_hits": br.has_mesh_hits,
        "rast_shadow_calls": br.rast_shadow_calls,
        "rast_camdepth_calls": br.rast_camdepth_calls,
        "center_drag_tris_drawn": center_tris_hw,
        "drag_tris_min_max": [min(drag_tris_seq), max(drag_tris_seq)],
        "live_drag_shmap_res": last_res_hw,
        "mean_frame_ms_sandbox": round(float(np.mean(drag_times_ms)), 2),
        "luma_min_max": [min(drag_lumas), max(drag_lumas)],
        "sample_log": hud_logs[-1] if hud_logs else "",
    }
    print("  24-Step Native Bridge Drag:", json.dumps(report["drag_24steps_vl3dbridge_v120"], indent=2, ensure_ascii=False))

    # ==========================================================================
    # [3/5] Restricted Sandbox (_G.os == nil, _G.io == nil) Pure Lua Fallback (Reproduces L4602!)
    # ==========================================================================
    print("[3/5] Running 10-step live drag in PURE LUA FALLBACK (bridge=None, _G.os==nil) hitting L4602 t_stop...")
    sess_lua = PersistentAviUtl2Session(str(VL_OBJ2), width=960, height=540, bridge=None, restrict_stdlib=True)
    # Give Lua fallback live model path via .aup2 / layer effect fallback:
    # Without bridge, Layer 3 has effects={"モデルファイル": ...}, wait: obj.getvalue returns nil for --file,
    # so let's place a minimal .aup2 or _G.VL3D_TEST_DIR_LISTING / project_path? Even simpler: check how pure Lua resolves .obj!
    # Wait: in pure Lua without VL3DBridge, load_layer_3d_models checks Bridge -> AUP2 -> Search dirs.
    # Let's provide a 6-line mock project .aup2 in OUT_DIR so pure Lua resolves bairdcage_38012.obj with 0 bridge!
    aup2_path = OUT_DIR / "test_drag.aup2"
    aup2_path.write_text(
        f"[scene.0]\n[0.0]\nlayer=3\nframe=0,300\n[0.0.0]\n_name=モデルファイル\nファイル={obj_path}\n座標系を調整=0\n",
        encoding="utf-8",
    )
    sess_lua.lua.execute(f'_G._VL3D_TEST_AUP2_PATH = "{aup2_path}"')
    # Also pass via bridge mock that ONLY resolves layer (no rasterize_shadow), so pure Lua build_3d_shadow_map runs!
    br_resolve_only = VL3DBridgeMockHost(mode="v290_sdk_lock", scene_id=1)
    sess_lua.bridge = br_resolve_only

    r_l0 = sess_lua.render_frame(params=vl_params, camera=cam, layers=make_layers(-120.0, 0.0), self_layer=4, frame=42)
    assert r_l0["error"] is None
    lua_drag_tris = []
    for step in range(1, 11):
        bx = -120.0 + 24.0 * step
        r_ld = sess_lua.render_frame(params=vl_params, camera=cam, layers=make_layers(bx, step * 5.0), self_layer=4, frame=42)
        assert r_ld["error"] is None, f"Pure Lua drag step {step} crashed: {r_ld['error']}"
        err_l = [lg for lg in r_ld["logs"] if "@error" in lg or "attempt to index" in lg]
        assert not err_l, f"Pure Lua drag step {step} logged error (L4602 regression!): {err_l}"
        st_l = sess_lua.lua.eval("_G._VL3D_PERSIST_V280.occ_stats")
        lua_drag_tris.append(int(st_l["last_tris"]))
    Image.fromarray(r_ld["rgba8"]).save(IMG_DIR / "vl293_drag_pure_lua_fallback.png")
    assert all(t > 0 for t in lua_drag_tris), f"Pure Lua fallback drew 0 tris: {lua_drag_tris}"
    report["drag_10steps_pure_lua_fallback_os_nil"] = {
        "errors": 0,
        "backend": str(sess_lua.lua.eval("_G._VL3D_PERSIST_V280.occ_stats.last_backend")),
        "tris_drawn_per_step": lua_drag_tris,
    }
    print("  10-Step Pure Lua Fallback Drag:", json.dumps(report["drag_10steps_pure_lua_fallback_os_nil"], indent=2))

    # ==========================================================================
    # [4/5] 体積霧（3D）v2.04 obj.module("VL3DBridge") + os==nil Log Rate-Limit Test
    # ==========================================================================
    print("[4/5] Verifying 体積霧（3D）.obj2 v2.04 obj.module('VL3DBridge') & os==nil monotonic clock...")
    br_fog = VL3DBridgeMockHost(mode="v120_native", scene_id=1)
    br_fog.edit_camera = (-240.0, -120.0, -900.0, 0.0, 0.0, 200.0, 0.0, -1.0, 0.0, 0.0, 1024.0)
    sess_fog = PersistentAviUtl2Session(str(FOG_OBJ2), width=640, height=360, bridge=br_fog, restrict_stdlib=True)
    # Wipe package.loaded.VL3DBridge so ONLY obj.module("VL3DBridge") can find it!
    sess_fog.lua.execute("if package and package.loaded then package.loaded['VL3DBridge'] = nil end")
    # Force camera_mode = 2 (Edit Camera mode!) via render_frame camera=None then overriding camera_mode
    orig_getoption = sess_fog.sb
    r_f1 = sess_fog.render_frame(params={"density": 65, "log_mode": 1}, camera=cam, self_layer=2, frame=0)
    assert r_f1["error"] is None
    assert any("v2.04" in lg for lg in r_f1["logs"]), f"Expected v2.04 log, got {r_f1['logs']}"
    time.sleep(0.28)
    r_f2 = sess_fog.render_frame(params={"density": 75, "area_d": 3600, "log_mode": 1}, camera=cam, self_layer=2, frame=0)
    assert r_f2["error"] is None
    assert any("3810" in lg or "3750" in lg or "v2.04" in lg for lg in r_f2["logs"]), (
        f"Second distinct @info log at frame=0 was suppressed under os==nil! logs={r_f2['logs']}"
    )
    # Verify bridge connected in _VFOG3D_PERSIST!
    fog_br_ok = bool(sess_fog.lua.eval("type(_G._VFOG3D_PERSIST.bridge) == 'table'"))
    assert fog_br_ok, "体積霧 v2.04 failed to resolve VL3DBridge via obj.module('VL3DBridge')!"
    Image.fromarray(r_f2["rgba8"]).save(IMG_DIR / "vfog204_verified.png")
    report["vfog_v204_os_nil_and_bridge"] = {
        "bridge_connected_via_obj_module": fog_br_ok,
        "second_log_emitted_at_frame0_os_nil": True,
        "logs_frame2": r_f2["logs"],
    }
    print("  体積霧 v2.04 Result:", json.dumps(report["vfog_v204_os_nil_and_bridge"], indent=2, ensure_ascii=False))

    # ==========================================================================
    # [5/5] 雪（3D）v1.21 + 3-Script Chinese UI Auto-Detection (_G.os==nil, _G.io==nil)
    # ==========================================================================
    print("[5/5] Verifying 雪（3D）.obj2 v1.21 & Chinese UI auto-detection across all 3 scripts (_G.os==nil, _G.io==nil)...")
    zh_files = {
        r"C:\ProgramData\aviutl2\aviutl2.ini": b"[System]\r\nLanguage=\xe7\xae\x80\xe4\xbd\x93\xe4\xb8\xad\xe6\x96\x87\r\n",
    }
    sess_snow = PersistentAviUtl2Session(
        str(SNOW_OBJ2), width=640, height=360, bridge=None, restrict_stdlib=True,
        virtual_files=zh_files,
    )
    r_sn = sess_snow.render_frame(params={"count": 400, "near_cull": 1, "log_mode": 1}, camera=None, self_layer=2, frame=15)
    assert r_sn["error"] is None
    sn_luma = float(np.mean(r_sn["rgba8"][..., :3]))
    assert sn_luma > 10.5
    assert any("模式=" in lg and "v1.22" in lg for lg in r_sn["logs"]), f"Snow zh UI failed under io==nil: {r_sn['logs']}"

    sess_fog_zh = PersistentAviUtl2Session(
        str(FOG_OBJ2), width=640, height=360, bridge="v120_native", restrict_stdlib=True,
        virtual_files=zh_files,
    )
    r_fz = sess_fog_zh.render_frame(params={"camera_mode": 2, "log_mode": 1}, camera=None, self_layer=2, frame=0)
    assert r_fz["error"] is None
    assert any("视角=" in lg and "v2.04" in lg for lg in r_fz["logs"]), f"Fog zh UI failed under io==nil: {r_fz['logs']}"

    sess_vl_zh = PersistentAviUtl2Session(
        str(VL_OBJ2), width=640, height=360, bridge="v120_native", restrict_stdlib=True,
        virtual_files=zh_files,
    )
    sess_vl_zh.lua.execute("if _G._VL3D_PERSIST_V280 then _G._VL3D_PERSIST_V280.cached_lang = nil end")
    r_vz = sess_vl_zh.render_frame(
        params={"light_layer": 1, "show_info": 1, "log_mode": 1},
        layers=make_layers(0.0, 0.0), camera=cam, self_layer=2, frame=0,
    )
    assert r_vz["error"] is None
    vl_zh_lang = sess_vl_zh.lua.eval("_G._VL3D_PERSIST_V280.cached_lang")
    assert vl_zh_lang == "zh", f"VL zh UI failed under io==nil: got {vl_zh_lang}"

    Image.fromarray(r_sn["rgba8"]).save(IMG_DIR / "snow121_verified.png")
    report["snow_v121_and_zh_ui_io_nil"] = {
        "lua_error": None,
        "mean_luma": round(sn_luma, 2),
        "vl_ui_lang_io_nil": vl_zh_lang,
        "vfog_zh_log": r_fz["logs"],
        "snow_zh_log": r_sn["logs"],
    }
    print("  [5/5] 3-Script Chinese UI under io==nil:", json.dumps(report["snow_v121_and_zh_ui_io_nil"], indent=2, ensure_ascii=False))

    out_json = OUT_DIR / "verify_v293_d3d11cs_and_drag_results.json"
    out_json.write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
    print("\nALL 5 END-TO-END SUITES PASSED! Report saved to:", out_json)


if __name__ == "__main__":
    main()
