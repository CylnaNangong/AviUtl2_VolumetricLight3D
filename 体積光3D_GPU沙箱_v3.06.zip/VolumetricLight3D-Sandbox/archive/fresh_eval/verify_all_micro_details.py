#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import json, math, pathlib, re, subprocess, sys
import numpy as np
from PIL import Image

sys.path.insert(0, "/home/user/sandbox")
sys.path.insert(0, "/home/user/sandbox/fresh_eval")
from aviutl2_sandbox import parse_obj2_script
from sandbox_v2_fidelity import FidelityLayer, PersistentAviUtl2Session, VL3DBridgeMockHost
from generate_assets import make_stained_glass_png

ROOT = pathlib.Path("/home/user")
OUT_DIR = ROOT / "sandbox/fresh_eval/outputs"
IMG_DIR = OUT_DIR / "renders"

# 1. Bytecode GSET (global variable write) scan across all 3 scripts!
scripts_map = {
    "vl_v286": ROOT / "releases/体積光（3D）_v2.86_稳定版/Script/体積光（3D）.obj2",
    "vl_v290": pathlib.Path("/tmp/vl_v290.obj2"),
    "vl_v291": ROOT / "scripts/pkg1/体积光（3D）/development/branch_v2.90_aux2_bridge/Script/体積光（3D）.obj2",
    "fog_v202": ROOT / "releases/体積霧（3D）_v2.02_稳定版/Script/体積霧（3D）.obj2",
    "snow_v119": ROOT / "releases/雪（3D）_v1.19_稳定版/Script/雪（3D）.obj2",
}
gset_report = {}
for name, sp in scripts_map.items():
    _, _, lua_code = parse_obj2_script(sp)
    tmp_lua = pathlib.Path(f"/tmp/_gset_{name}.lua")
    tmp_lua.write_text(lua_code, encoding="utf-8")
    bc = subprocess.run(["luajit", "-bl", str(tmp_lua)], capture_output=True, encoding="utf-8", errors="replace").stdout
    gsets = sorted(set(re.findall(r'\bGSET\s+\d+\s+\d+\s+;\s+"([^"]+)"', bc)))
    ggets = sorted(set(re.findall(r'\bGGET\s+\d+\s+\d+\s+;\s+"([^"]+)"', bc)))
    non_std_ggets = [g for g in ggets if g not in {"obj", "math", "string", "table", "io", "os", "tonumber", "tostring", "type", "pairs", "ipairs", "next", "pcall", "xpcall", "select", "unpack", "error", "print", "require", "package", "_G", " debug", "debug", "bit"}]
    gset_report[name] = {"GSET_leaks": gsets, "non_std_GGET": non_std_ggets}

print("GSET / GGET scan:", json.dumps(gset_report, ensure_ascii=False, indent=2))

# 2. Check .aul2 localization coverage!
aul2_pairs = [
    ("vl_v286", ROOT / "releases/体積光（3D）_v2.86_稳定版/Script/体積光（3D）.obj2", ROOT / "releases/体積光（3D）_v2.86_稳定版/Language"),
    ("vl_v291", ROOT / "scripts/pkg1/体积光（3D）/development/branch_v2.90_aux2_bridge/Script/体積光（3D）.obj2", ROOT / "scripts/pkg1/体积光（3D）/development/branch_v2.90_aux2_bridge/Language"),
    ("fog_v202", ROOT / "releases/体積霧（3D）_v2.02_稳定版/Script/体積霧（3D）.obj2", ROOT / "releases/体積霧（3D）_v2.02_稳定版/Language"),
    ("snow_v119", ROOT / "releases/雪（3D）_v1.19_稳定版/Script/雪（3D）.obj2", ROOT / "releases/雪（3D）_v1.19_稳定版/Language"),
]
aul2_report = {}
for tag, obj_p, lang_dir in aul2_pairs:
    src = obj_p.read_text(encoding="utf-8", errors="replace")
    ui_labels = []
    for line in src.splitlines():
        m = re.match(r'^--(track|check|select|color|value|file|group)@[^:]+:([^,]+)', line)
        if m:
            ui_labels.append(m.group(2).strip())
    files = sorted(lang_dir.glob("*.aul2")) if lang_dir.exists() else []
    per_lang = {}
    for lf in files:
        ltxt = lf.read_text(encoding="utf-8", errors="replace")
        missing = [lbl for lbl in ui_labels if lbl and f"{lbl}=" not in ltxt]
        per_lang[lf.name] = {"total_labels": len(ui_labels), "missing_count": len(missing), "missing_sample": missing[:8]}
    aul2_report[tag] = per_lang
print("AUL2 report:", json.dumps(aul2_report, ensure_ascii=False, indent=2))

# 3. Render visible dark birdcage shadow shafts on longwire 38,012-tri mesh + measure MAE between v2.90 and v2.92_ref!
def make_vis_longwire_38012(out_path: pathlib.Path):
    verts, faces = [], []
    def add_rib(p0, p1, hw=22.0):
        dx, dy, dz = p1[0]-p0[0], p1[1]-p0[1], p1[2]-p0[2]
        nx, ny, nz = -dy, dx, 0.25*dx
        ln = math.sqrt(nx*nx + ny*ny + nz*nz) + 1e-8
        ox, oy, oz = (nx/ln)*hw, (ny/ln)*hw, (nz/ln)*hw
        b = len(verts) + 1
        verts.extend([
            (p0[0]-ox, p0[1]-oy, p0[2]-oz),
            (p0[0]+ox, p0[1]+oy, p0[2]+oz),
            (p1[0]+ox, p1[1]+oy, p1[2]+oz),
            (p1[0]-ox, p1[1]-oy, p1[2]-oz),
        ])
        faces.append((b, b+1, b+2))
        faces.append((b, b+2, b+3))
    R = 1150.0
    # 720 full-height un-subdivided diagonal & vertical iron bars (1,440 large-AABB tris!)
    for i in range(180):
        a0 = 2.0 * math.pi * (i / 180.0)
        a1 = a0 + 0.72
        add_rib((R*math.cos(a0), -1180.0, R*math.sin(a0)), (R*math.cos(a1), 1180.0, R*math.sin(a1)), hw=16.0)
        add_rib((R*math.cos(a1), -1180.0, R*math.sin(a1)), (R*math.cos(a0), 1180.0, R*math.sin(a0)), hw=16.0)
    need_q = (38012 - len(faces)) // 2
    for q in range(need_q):
        ring = q // 120
        seg = q % 120
        t = min(1.0, ring / 153.0)
        y = -1180.0 + 2360.0 * t
        rr = R * (1.0 if t > 0.22 else (0.22 + 0.78 * (t / 0.22)))
        a0 = 2.0 * math.pi * (seg / 120.0)
        a1 = 2.0 * math.pi * ((seg + 1) / 120.0)
        add_rib((rr*math.cos(a0), y, rr*math.sin(a0)), (rr*math.cos(a1), y + 8.0, rr*math.sin(a1)), hw=12.0)
    assert len(faces) == 38012
    with out_path.open("w", encoding="utf-8") as f:
        for vx, vy, vz in verts:
            f.write(f"v {vx:.2f} {vy:.2f} {vz:.2f}\n")
        for f0, f1, f2 in faces:
            f.write(f"f {f0} {f1} {f2}\n")
    return str(out_path)

vis_obj = make_vis_longwire_38012(OUT_DIR / "bairdcage_38012_vis.obj")
glass_rgba = make_stained_glass_png(OUT_DIR / "stained_glass.png")
win_lay = FidelityLayer(index=2, name="Window", x=0.0, y=-20.0, z=420.0, zoom=125.0, alpha=1.0, image=glass_rgba, kind_override="OTHER")
cam = {"x": 0.0, "y": 0.0, "z": -1024.0, "tx": 0.0, "ty": 0.0, "tz": 0.0, "ux": 0.0, "uy": -1.0, "uz": 0.0, "rz": 0.0, "d": 1024.0}
p_vis = {
    "src_layer": 2, "ray_mode": 1, "screen_dir": False,
    "light_x": 0.0, "light_y": -30.0, "light_z": 960.0,
    "length": 1850.0, "intensity": 72.0, "decay": 42.0,
    "occ_mode": 1, "occ_3d_mode": 0, "occ_target": 0, "occ_strength": 100.0,
    "show_info": False, "log_mode": False, "res_mode": 1, "auto_slice": False, "slices": 32.0,
}

imgs = {}
perf = {}
for tag, sp, strict in [
    ("v2.86", scripts_map["vl_v286"], False),
    ("v2.90", scripts_map["vl_v290"], True),
    ("v2.91", scripts_map["vl_v291"], True),
    ("v2.92_ref", OUT_DIR / "vl_v292_ref.obj2", True),
]:
    br = VL3DBridgeMockHost(mode="v292_param_edit") if strict else None
    sess = PersistentAviUtl2Session(str(sp), width=2048, height=1080, strict_getvalue=strict, bridge=br)
    cage = FidelityLayer(
        index=3, name="bairdcage", x=0.0, y=10.0, z=-180.0, zoom=22.0, alpha=1.0,
        effects={"モデルファイル": {"ファイル": vis_obj, "座標系を調整": 0}},
        kind_override="OBJ", model_path=vis_obj,
    )
    r0 = sess.render_frame(params=p_vis, camera=cam, layers={2: win_lay, 3: cage}, self_layer=5, frame=0)
    imgs[tag] = r0["rgba8"]
    Image.fromarray(r0["rgba8"]).save(IMG_DIR / f"cage38k_2048_{tag.replace('.', '_')}.png")
    p_fast = {**p_vis, "slices": 8.0}
    rp = sess.render_frame(params=p_fast, camera=cam, layers={2: win_lay, 3: cage}, self_layer=5, frame=1)
    cage.zoom = 22.8
    rd = sess.render_frame(params=p_fast, camera=cam, layers={2: win_lay, 3: cage}, self_layer=5, frame=1)
    perf[tag] = {
        "cold_cpu_ms": round(r0["lua_cpu_ms"], 2),
        "play_cpu_ms": round(rp["lua_cpu_ms"], 2),
        "drag_cpu_ms": round(rd["lua_cpu_ms"], 2),
    }

mae_v290_vs_v292 = float(np.abs(imgs["v2.90"].astype(np.float32) - imgs["v2.92_ref"].astype(np.float32)).mean())
print("Perf vis:", json.dumps(perf, indent=2), "MAE(v2.90, v2.92_ref)=", round(mae_v290_vs_v292, 4))

# 4. Fog v2.02 Sphere Mode (p7.z > 0.5) near-camera slice sec_k = 4.0 test!
fog202_src = scripts_map["fog_v202"].read_text(encoding="utf-8")
fog_fix_src = fog202_src.replace(
    "float sec_k = 1.0 / max(abs(dot(vdir, sl_n)), 0.25);",
    "float sec_k = (p7.z > 0.5) ? 1.0 : (1.0 / max(abs(dot(vdir, sl_n)), 0.25));"
)
assert fog_fix_src != fog202_src, "Fog sec_k replacement failed!"
fog_fix_p = OUT_DIR / "fog_v202_seck_fixed.obj2"
fog_fix_p.write_text(fog_fix_src, encoding="utf-8")

# Camera inside the fog sphere (z = -650, target = 0,0,0, wide angle d = 380)
cam_wide = {"x": 0.0, "y": 0.0, "z": -650.0, "tx": 0.0, "ty": 0.0, "tz": 0.0, "ux": 0.0, "uy": -1.0, "uz": 0.0, "rz": 0.0, "d": 380.0}
fp_sph = {"density": 55.0, "slices": 48.0, "view_mode": 2, "spread": 130.0, "near_z": 40.0, "far_z": 2400.0, "light_on": False, "noise_scale": 500.0, "puff": 0.0}
s_f202 = PersistentAviUtl2Session(str(scripts_map["fog_v202"]), width=960, height=540)
s_ffix = PersistentAviUtl2Session(str(fog_fix_p), width=960, height=540)
rf_202 = s_f202.render_frame(params=fp_sph, camera=cam_wide, layers={}, self_layer=2, frame=0)["rgba"]
rf_fix = s_ffix.render_frame(params=fp_sph, camera=cam_wide, layers={}, self_layer=2, frame=0)["rgba"]
Image.fromarray((np.clip(rf_202, 0.0, 1.0) * 255).astype(np.uint8)).save(IMG_DIR / "fog_v202_sphere_seck_bug.png")
Image.fromarray((np.clip(rf_fix, 0.0, 1.0) * 255).astype(np.uint8)).save(IMG_DIR / "fog_v202_sphere_seck_fixed.png")

c202 = float(rf_202[240:300, 440:520, :3].mean())
e202 = float(rf_202[20:100, 20:120, :3].mean())
cfix = float(rf_fix[240:300, 440:520, :3].mean())
efix = float(rf_fix[20:100, 20:120, :3].mean())
print(f"Fog Sphere Mode (p7.z): v2.02 center={c202:.4f}, edge={e202:.4f}, edge/center={e202/max(c202,1e-5):.3f} | sec_k=1 center={cfix:.4f}, edge={efix:.4f}, edge/center={efix/max(cfix,1e-5):.3f}")

micro = {
    "gset_scan": gset_report,
    "aul2_coverage": aul2_report,
    "longwire_vis_perf": perf,
    "longwire_mae_v290_vs_v292": round(mae_v290_vs_v292, 4),
    "fog_sphere_p7z": {
        "v202_center": round(c202, 4), "v202_edge": round(e202, 4), "v202_edge_over_center": round(e202/max(c202, 1e-5), 4),
        "fixed_center": round(cfix, 4), "fixed_edge": round(efix, 4), "fixed_edge_over_center": round(efix/max(cfix, 1e-5), 4),
    },
}
(OUT_DIR / "micro_verification.json").write_text(json.dumps(micro, ensure_ascii=False, indent=2), encoding="utf-8")
