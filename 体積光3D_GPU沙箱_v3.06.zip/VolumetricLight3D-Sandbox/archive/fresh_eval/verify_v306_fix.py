#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v3.06 verification battery:
T1  SIMULATION of the real-host failure (fx load -> opaque rect, raw load -> bust):
    v3.05 must show the RECTANGLE shadow bug; v3.06 must auto-fallback to the bust.
T2  Parity: normal layers -> v3.06 vs v3.05 identical output (Verse1 frame_s=619 AND frame_s=0).
T3  Genuinely opaque image -> v3.06 keeps behavior (parity) + HUD gains ",opq".
T4  Restricted host (_G.os=nil, _G.io=nil) still initializes fine on v3.06.
"""
import sys
import pathlib
import numpy as np
from PIL import Image

sys.path.insert(0, "/home/user/sandbox")
sys.path.insert(0, "/home/user/sandbox/fresh_eval")

from generate_assets import make_plaster_bust_png, make_stained_glass_png
from sandbox_v2_fidelity import FidelityLayer, PersistentAviUtl2Session, VL3DBridgeMockHost

ROOT = pathlib.Path("/home/user")
VL_306 = ROOT / "GitHub_VolumetricLight3D/Script/体積光（3D）.obj2"
VL_305 = ROOT / "releases/体積光（3D）_v3.05_正式版/Script/体積光（3D）.obj2"
OUT = ROOT / "sandbox/fresh_eval/outputs/v306_repro"
OUT.mkdir(parents=True, exist_ok=True)
W, H = 640, 360

glass = make_stained_glass_png(OUT / "stained_glass.png")
bust = make_plaster_bust_png(OUT / "plaster_bust.png")
# fully opaque rectangle (simulates a garbage / non-cutout fx-applied load)
opaque_rect = np.full((512, 512, 4), 200, dtype=np.uint8)
opaque_rect[..., 3] = 255

CAM = {"x": 0.0, "y": -40.0, "z": -1024.0, "tx": 0.0, "ty": 20.0, "tz": 0.0,
       "ux": 0.0, "uy": -1.0, "uz": 0.0, "rz": 0.0, "d": 1024.0}
PARAMS = {"src_layer": 2, "intensity": 150.0, "direction": 55.0, "pitch": 44.0,
          "occ_mode": 1, "occ_3d_mode": 0, "occ_target": 2, "occ_list": "4",
          "occ_strength": 100.0, "occ_soft": 8.0, "log_mode": True, "show_info": False}


def light_layer():
    return FidelityLayer(index=2, name="光源", x=0.0, y=-100.0, z=333.0, zoom=435.0,
                         alpha=1.0, image=glass, kind_override="OTHER")


def render(vl_path, tag, statue, frame_s=619, scene_id=1, frame=146, occ_mode=1, restrict=False):
    br = VL3DBridgeMockHost(mode="v290_sdk_lock", scene_id=scene_id)
    sess = PersistentAviUtl2Session(str(vl_path), width=W, height=H, strict_getvalue=True, bridge=br)
    if restrict:
        sess.lua.execute("_G.os = nil; _G.io = nil")
    res = sess.render_frame(params=dict(PARAMS, occ_mode=occ_mode), camera=CAM,
                            layers={2: light_layer(), 4: statue}, self_layer=10,
                            frame=frame, totalframe=619, frame_s=frame_s, scene_id=scene_id)
    assert res["error"] is None, f"{tag}: {res['error']}"
    Image.fromarray(res["rgba8"]).save(OUT / f"{tag}.png")
    hud = [l for l in res["logs"] if "遮蔽" in l]
    stats = sess.lua.eval(
        "(function() local t=_G._VL3D_PERSIST_V280 and _G._VL3D_PERSIST_V280.occ_stats or {} "
        "local r={} for k,v in pairs(t) do r[k]=v end return r end)()")
    return res, (dict(stats) if stats else {}), (hud[0] if hud else "")


def shadow_fill(res, res_ref, thr=30):
    a = res["rgba8"][..., :3].astype(np.int16)
    b = res_ref["rgba8"][..., :3].astype(np.int16)
    diff = np.clip(b - a, 0, 255).sum(axis=2)
    ys, xs = np.nonzero(diff > thr)
    if len(xs) == 0:
        return None
    bw = xs.max() - xs.min() + 1
    bh = ys.max() - ys.min() + 1
    return len(xs) / float(bw * bh)


def main():
    # reference: no occlusion (v3.06 session, occ_mode=0)
    ref, _, _ = render(VL_306, "ref_noocc", FidelityLayer(
        index=4, name="石膏像", x=0.0, y=-30.0, z=140.0, zoom=110.0, alpha=1.0,
        image=bust, kind_override="OTHER"), occ_mode=0)

    print("=== T1: real-host failure simulation (fx=opaque rect / raw=bust) ===")
    sim_statue = FidelityLayer(index=4, name="石膏像", x=0.0, y=-30.0, z=140.0, zoom=110.0,
                               alpha=1.0, image=opaque_rect, raw_image=bust,
                               kind_override="OTHER")
    r305, s305, h305 = render(VL_305, "T1_v305_sim", sim_statue)
    r306, s306, h306 = render(VL_306, "T1_v306_sim", sim_statue)
    f305, f306 = shadow_fill(r305, ref), shadow_fill(r306, ref)
    print(f"  v3.05 shadow bbox fill = {f305}  -> {'RECTANGLE BUG REPRODUCED' if f305 and f305 > 0.9 else 'not rect'}")
    print(f"  v3.06 shadow bbox fill = {f306}  -> {'bust-shaped (FIXED!)' if f306 and f306 < 0.75 else '??'}")
    print(f"  v3.05 HUD: {h305[h305.find('遮蔽='):] if '遮蔽=' in h305 else h305}")
    print(f"  v3.06 HUD: {h306[h306.find('遮蔽='):] if '遮蔽=' in h306 else h306}")
    print(f"  v3.06 occ_stats: {s306}")
    print(f"  v3.06 fallback fired: {s306.get('opaque_rect_fallback', 0) >= 1}")
    d = np.abs(r305["rgba8"].astype(np.int16) - r306["rgba8"].astype(np.int16)).max()
    print(f"  v3.05 vs v3.06 output maxdiff on sim = {d} (must be > 0: bug fixed)")

    print("=== T2: parity on healthy layers ===")
    ok = True
    for tag, fs, sid in [("Verse1(frame_s=619)", 619, 1), ("Main(frame_s=0)", 0, 0)]:
        st = FidelityLayer(index=4, name="石膏像", x=0.0, y=-30.0, z=140.0, zoom=110.0,
                           alpha=1.0, image=bust, kind_override="OTHER")
        r5, _, _ = render(VL_305, f"T2_v305_{sid}_{fs}", st, frame_s=fs, scene_id=sid)
        r6, s6, h6 = render(VL_306, f"T2_v306_{sid}_{fs}", st, frame_s=fs, scene_id=sid)
        dd = np.abs(r5["rgba8"].astype(np.int16) - r6["rgba8"].astype(np.int16)).max()
        print(f"  {tag}: maxdiff v3.05 vs v3.06 = {dd} (must be 0)")
        ok = ok and dd == 0
        print(f"    v3.06 HUD: {h6[h6.find('遮蔽='):h6.find('遮蔽=') + 24] if '遮蔽=' in h6 else h6}")
        print(f"    v3.06 occ_stats: {s6}")

    print("=== T3: genuinely opaque image (both loads opaque) ===")
    opq_statue = FidelityLayer(index=4, name="不透明画像", x=0.0, y=-30.0, z=140.0, zoom=110.0,
                               alpha=1.0, image=opaque_rect, kind_override="OTHER")
    r5o, _, _ = render(VL_305, "T3_v305_opq", opq_statue)
    r6o, s6o, h6o = render(VL_306, "T3_v306_opq", opq_statue)
    dd = np.abs(r5o["rgba8"].astype(np.int16) - r6o["rgba8"].astype(np.int16)).max()
    print(f"  parity maxdiff = {dd} (must be 0); HUD contains ,opq: {',opq' in h6o}")
    print(f"  HUD: {h6o[h6o.find('遮蔽='):h6o.find('遮蔽=') + 28] if '遮蔽=' in h6o else h6o}")

    print("=== T4: restricted host (os=nil, io=nil) on v3.06 ===")
    st = FidelityLayer(index=4, name="石膏像", x=0.0, y=-30.0, z=140.0, zoom=110.0,
                       alpha=1.0, image=bust, kind_override="OTHER")
    rr, _, hr = render(VL_306, "T4_v306_restrict", st, restrict=True)
    init_ok = any("初期化完了" in l for l in rr["logs"]) or any("初始化完成" in l for l in rr["logs"])
    print(f"  render ok, init-complete log present: {init_ok}")

    print("\nALL CHECKS DONE")


if __name__ == "__main__":
    main()
