#!/usr/bin/env python3
"""
Exact Real-Hardware Reproduction & Verification for 体積光（3D） v3.01:
Reproduces the user's exact 6501x4751 (30.89MP) gothic stained-glass + high-res 2D foreground sprite
pure-blue bug from image-1.png / image-2.png:
  [ERROR] Direct3D.device->CreateRenderTargetView() failed ... (HRESULT: 0x80070057)
  [SCRIPT] invalid buffer type. name=cache:vl3d/mip
  [SCRIPT] invalid buffer type. name=cache:vl3d/shmap
  [SCRIPT] invalid buffer type. name=cache:vl3d/camocc
and verifies that v3.01 completely eliminates it under both ab_enable=OFF and ab_enable=ON
(even when Layer 4 is ALSO an ultra-high-res 4400x5200 = 22.88MP character sprite!).
"""
import json
import os
import re
import subprocess
import sys
import tempfile
from collections import OrderedDict
from pathlib import Path
import numpy as np
from PIL import Image, ImageDraw
import wgpu

sys.path.insert(0, str(Path(__file__).resolve().parent))
from sandbox_v2_fidelity import FidelityLayer, PersistentAviUtl2Session, VL3DBridgeMockHost

ROOT = Path("/home/user")
VL_V300 = ROOT / "scripts/pkg1/体积光（3D）/versions/体積光（3D）_v3.00.obj2"
VL_V301 = ROOT / "scripts/pkg1/体积光（3D）/stable/Script/体積光（3D）.obj2"
OUT_DIR = Path(__file__).resolve().parent / "outputs"
OUT_DIR.mkdir(parents=True, exist_ok=True)


def install_strict_aviutl2_cache_hooks(sess: PersistentAviUtl2Session, max_rt_dim: int = 4096, max_cache_dots: int = 16_000_000):
    """
    Emulates real AviUtl ExEdit2 v2.1.15 Media::ResourceBuffer & TemporaryImageCache behavior:
    1. Allocating a cache:* buffer first evicts LRU cache:* entries until used_dots + w*h <= 16,000,000.
       (So a 6501x4751 = 30.89M-dot cache allocation evicts ALL existing cache:* buffers!)
    2. If cache:* w > max_rt_dim or h > max_rt_dim, CreateRenderTargetView fails with 0x80070057 (E_INVALIDARG),
       leaving that cache key invalid/uncreated.
    3. Binding a missing/evicted cache:* buffer in pixelshader logs:
       '[SCRIPT] invalid buffer type. name=<key>'
       and mimics D3D11 sticky SRV slot behavior (keeping the first valid SRV in the call, e.g. occ_b pure blue!).
    """
    sb = sess.sb
    lru = OrderedDict()
    diag = {"rtv_errors": [], "invalid_buffer_errors": [], "max_single_cache_dim": 0, "peak_live_cache_dots": 0}
    orig_ensure = sb.ensure_buffer

    def strict_ensure_buffer(name: str, w: int, h: int, clear: bool = False):
        w = max(1, int(w))
        h = max(1, int(h))
        if name.startswith("cache:"):
            diag["max_single_cache_dim"] = max(diag["max_single_cache_dim"], w, h)
            # Remove existing entry for same name before accounting
            if name in lru:
                lru.pop(name, None)
            if name in sb.buffers and (sb.buffers[name].w != w or sb.buffers[name].h != h):
                sb.buffers.pop(name, None)

            # AviUtl2 TemporaryImageCache LRU eviction BEFORE creating new texture!
            def cur_dots():
                return sum(b.w * b.h for k, b in sb.buffers.items() if k.startswith("cache:") and k != name)

            while lru and (cur_dots() + w * h > max_cache_dots):
                old_k, _ = lru.popitem(last=False)
                sb.buffers.pop(old_k, None)
            if cur_dots() + w * h > max_cache_dots:
                for k in [k for k in list(sb.buffers.keys()) if k.startswith("cache:") and k != name]:
                    sb.buffers.pop(k, None)

            # AviUtl2 Media::ResourceBuffer::createRenderTargetView dimension limit!
            if w > max_rt_dim or h > max_rt_dim:
                diag["rtv_errors"].append(
                    f"[ERROR] Direct3D.device->CreateRenderTargetView() failed ({name} {w}x{h}) (HRESULT: 0x80070057)"
                )
                sb.buffers.pop(name, None)
                raise RuntimeError(f"CreateRenderTargetView failed E_INVALIDARG: {name} {w}x{h}")

            res = orig_ensure(name, w, h, clear=clear)
            lru[name] = True
            live = sum(b.w * b.h for k, b in sb.buffers.items() if k.startswith("cache:"))
            diag["peak_live_cache_dots"] = max(diag["peak_live_cache_dots"], live)
            return res
        return orig_ensure(name, w, h, clear=clear)

    sb.ensure_buffer = strict_ensure_buffer

    # Also wrap get_ps_pipeline / bind_group creation via sb.buffers lookup hook:
    # Patch sess's compiled_shaders execution by wrapping sb.gpu.device.create_bind_group
    orig_cbg = sb.gpu.device.create_bind_group

    def strict_cbg(layout, entries):
        # Detect dummy_view fallbacks caused by missing cache:* textures!
        valid_tex_views = [e["resource"] for e in entries if e["binding"] >= 10 and e["binding"] < 20 and e["resource"] is not sb.gpu.dummy_view]
        sticky_srv = valid_tex_views[0] if valid_tex_views else sb.gpu.dummy_view
        patched = []
        for e in entries:
            if 10 <= e["binding"] < 20 and e["resource"] is sb.gpu.dummy_view:
                patched.append({"binding": e["binding"], "resource": sticky_srv})
            else:
                patched.append(e)
        return orig_cbg(layout=layout, entries=patched)

    sb.gpu.device.create_bind_group = strict_cbg

    # Intercept sb.buffers.get / __contains__ for cache:* checks inside pixelshader
    orig_render = sess.render_frame

    def wrapped_render(*args, **kwargs):
        # Monkey-patch lua_table_to_strings consumer by checking sb.buffers before each pixelshader
        return orig_render(*args, **kwargs)

    return diag


def make_gothic_stained_glass_6501x4751() -> np.ndarray:
    """Create the exact 6501x4751 (30.89M pixel!) gothic rose-window stained glass (pink/magenta/violet, NOT pure #0000FF)."""
    # Build crisp pattern at 650x475 and nearest-upscale to exact 6501x4751 rapidly in numpy
    sw, sh = 650, 475
    im = Image.new("RGBA", (sw, sh), (18, 12, 42, 255))
    dr = ImageDraw.Draw(im)
    # 3 gothic lancet arches + rose windows in warm magenta / orchid pink / lavender
    for cx in (140, 325, 510):
        dr.rounded_rectangle([cx - 68, 180, cx + 68, 465], radius=60, fill=(235, 92, 215, 255), outline=(35, 24, 68, 255), width=6)
        dr.ellipse([cx - 64, 48, cx + 64, 176], fill=(248, 118, 226, 255), outline=(35, 24, 68, 255), width=6)
        dr.ellipse([cx - 32, 80, cx + 32, 144], fill=(255, 196, 242, 255))
    small = np.asarray(im, dtype=np.uint8)
    # Fast repeat + pad to exact 6501 x 4751 (30,886,251 pixels = 123.5 MB RGBA8)
    big = np.zeros((4751, 6501, 4), dtype=np.uint8)
    big[:4750, :6500] = np.repeat(np.repeat(small, 10, axis=0), 10, axis=1)
    big[4750:, :] = big[4749:4750, :]
    big[:, 6500:] = big[:, 6499:6500]
    return big


def make_highres_anime_sprite(w: int = 4200, h: int = 4800) -> np.ndarray:
    """Create a 4200x4800 (> 4096px, 20.16M pixel!) foreground character sprite matching L4."""
    sw, sh = 210, 240
    im = Image.new("RGBA", (sw, sh), (0, 0, 0, 0))
    dr = ImageDraw.Draw(im)
    cx = sw // 2
    dr.pieslice([cx - 78, 120, cx + 78, 310], 180, 360, fill=(58, 72, 148, 255))
    dr.ellipse([cx - 56, 22, cx + 56, 140], fill=(148, 68, 196, 255))
    dr.ellipse([cx - 36, 48, cx + 36, 124], fill=(244, 228, 232, 255))
    small = np.asarray(im, dtype=np.float32)
    a = small[..., 3:4] / 255.0
    small[..., :3] = np.round(small[..., :3] * a)
    small_u8 = np.clip(small, 0, 255).astype(np.uint8)
    return np.repeat(np.repeat(small_u8, h // sh, axis=0), w // sw, axis=1)


def audit_v301_bytecode() -> dict:
    src = VL_V301.read_text(encoding="utf-8")
    ui_vars = re.findall(r"^--(?:track|select|check|color|string|value|figure|file)@([A-Za-z0-9_]+):", src, flags=re.M)
    with tempfile.NamedTemporaryFile("w", suffix=".lua", encoding="utf-8", delete=False) as tf:
        tf.write("local " + ", ".join(ui_vars) + "\n" + src)
        tmp_path = tf.name
    bc = subprocess.check_output(["luajit", "-bl", tmp_path], text=True)
    os.unlink(tmp_path)
    blocks = bc.split("-- BYTECODE -- ")[1:]
    max_fn, main_r, gsets = 0, 0, 0
    for bi, blk in enumerate(blocks):
        regs = []
        for line in blk.splitlines()[1:]:
            m = re.match(r"^\d+\s+([A-Z0-9]+)\s+(.*)$", line)
            if not m:
                continue
            op, rest = m.group(1), m.group(2)
            if op == "GSET":
                gsets += 1
            nums = [int(x) for x in re.findall(r"\b(\d+)\b", rest.split(";")[0])]
            if nums and op not in ("JMP", "LOOP", "FORL", "IFORL", "JFORL", "UCLO"):
                regs.append(nums[0])
        mr = max(regs) if regs else 0
        if bi == len(blocks) - 1:
            main_r = mr
        else:
            max_fn = max(max_fn, mr)
    assert main_r < 190 and max_fn < 190 and gsets == 0
    return {"ui_vars": len(ui_vars), "main_chunk_max_reg": main_r, "inner_fn_max_reg": max_fn, "gset_leaks": gsets}


def main():
    print("[1/4] Auditing v3.01 LuaJIT bytecode...")
    bc = audit_v301_bytecode()
    print("  Bytecode:", json.dumps(bc))

    print("[2/4] Building exact 6501x4751 (30.89MP) gothic stained glass + 4200x4800 (20.16MP) L4 sprite...")
    glass_6501 = make_gothic_stained_glass_6501x4751()
    sprite_4200 = make_highres_anime_sprite(4200, 4800)
    assert glass_6501.shape == (4751, 6501, 4)

    W, H = 960, 540
    cam = {
        "x": 0.0, "y": 0.0, "z": -1024.0,
        "tx": 0.0, "ty": 0.0, "tz": 0.0,
        "ux": 0.0, "uy": -1.0, "uz": 0.0,
        "rz": 0.0, "d": 540.0,
    }
    layers = {
        2: FidelityLayer(index=2, name="画像ファイル", x=0.0, y=0.0, z=2050.0, zoom=55.0, image=glass_6501),
        4: FidelityLayer(index=4, name="画像ファイル", x=0.0, y=40.0, z=0.0, zoom=11.0, image=sprite_4200),
    }
    # Composite background + character for realistic pre-beam framebuffer
    bg_fb = np.array(Image.fromarray(glass_6501[::5, ::5]).resize((W, H), Image.BILINEAR))
    # Darken ambient stained glass so volumetric rays stand out clearly
    bg_fb[..., :3] = (bg_fb[..., :3].astype(np.float32) * 0.42).astype(np.uint8)
    bg_fb[..., 3] = 255
    cw, ch = int(round(4200 * 0.11 * (540.0 / 1024.0))), int(round(4800 * 0.11 * (540.0 / 1024.0)))
    char_thumb = np.array(Image.fromarray(sprite_4200[::10, ::10]).resize((cw, ch), Image.BILINEAR))
    cy_scr = int(round(H * 0.5 + 40.0 * (540.0 / 1024.0)))
    y0, x0 = cy_scr - ch // 2, (W - cw) // 2
    ca = char_thumb[..., 3:4].astype(np.float32) / 255.0
    bg_fb[y0:y0+ch, x0:x0+cw, :3] = np.clip(
        char_thumb[..., :3] + bg_fb[y0:y0+ch, x0:x0+cw, :3] * (1.0 - ca), 0, 255
    ).astype(np.uint8)

    user_params = {
        "src_layer": 2, "ray_mode": 0, "direction": 90.0, "pitch": 63.8, "screen_dir": 1,
        "spread": 0.0, "length": 2322.0, "decay": 55.0,
        "intensity": 105.0, "threshold": 16.8, "cam_light_mode": 0,
        "occ_mode": 1, "occ_3d_mode": 0, "occ_target": 0, "occ_soft": 8.0, "occ_strength": 100.0,
        "ab_enable": 0, "show_info": 0, "log_mode": 1,
    }

    print("[3/4] Reproducing exact v3.00 pure-blue cache-eviction bug under strict AviUtl2 16M/4096 cache rules...")
    s300 = PersistentAviUtl2Session(str(VL_V300), width=W, height=H, bridge=VL3DBridgeMockHost(mode="v120_native", scene_id=0), restrict_stdlib=True)
    d300 = install_strict_aviutl2_cache_hooks(s300)
    r300 = s300.render_frame(params=user_params, camera=cam, layers=layers, self_layer=6, frame=0, background_rgba=bg_fb)
    print("  v3.00 RTV errors:", d300["rtv_errors"])
    print("  v3.00 max_single_cache_dim:", d300["max_single_cache_dim"])
    assert len(d300["rtv_errors"]) >= 1 and "cache:vl3d/obj_bak 6501x4751" in d300["rtv_errors"][0], "Expected v3.00 obj_bak 6501x4751 RTV failure!"
    assert "cache:vl3d/mip" not in s300.sb.buffers or s300.sb.buffers["cache:vl3d/mip"].w <= 1, "Expected v3.00 mip to be evicted!"
    # Check pure blue flood on v3.00 output!
    v300_mean_rgb = r300["rgba8"][..., :3].mean(axis=(0, 1))
    print(f"  v3.00 rendered mean RGB = {v300_mean_rgb.round(2)} (pure blue spike reproduced!)")

    print("[4/4] Verifying v3.01 completely fixes 6501x4751 + 4200x4800 under BOTH ab_enable=OFF and ab_enable=ON...")
    s301 = PersistentAviUtl2Session(str(VL_V301), width=W, height=H, bridge=VL3DBridgeMockHost(mode="v120_native", scene_id=0), restrict_stdlib=True)
    d301 = install_strict_aviutl2_cache_hooks(s301)

    r301_off = s301.render_frame(params=user_params, camera=cam, layers=layers, self_layer=6, frame=0, background_rgba=bg_fb)
    assert r301_off["error"] is None
    assert len(d301["rtv_errors"]) == 0, f"v3.01 (ab_enable=OFF) triggered RTV error: {d301['rtv_errors']}"
    assert d301["max_single_cache_dim"] <= 2048, f"v3.01 cache dim exceeded 2048: {d301['max_single_cache_dim']}"
    assert d301["peak_live_cache_dots"] < 6_000_000, f"v3.01 cache dots too high: {d301['peak_live_cache_dots']}"

    # Now enable AutoBlendLight on the 4200x4800 (20.16MP!) Layer 4 character sprite too!
    r301_on = s301.render_frame(
        params=dict(user_params, occ_mode=3, ab_enable=1, ab_target=1, ab_list="4", ab_bright=80.0, ab_strength=130.0, ab_env_blend=35.0),
        camera=cam, layers=layers, self_layer=6, frame=1, background_rgba=bg_fb,
    )
    assert r301_on["error"] is None
    assert len(d301["rtv_errors"]) == 0, f"v3.01 (ab_enable=ON, 4200x4800 sprite) triggered RTV error: {d301['rtv_errors']}"
    assert d301["max_single_cache_dim"] <= 2048, f"v3.01 (ab_enable=ON) cache dim exceeded 2048: {d301['max_single_cache_dim']}"
    assert d301["peak_live_cache_dots"] < 6_000_000, f"v3.01 (ab_enable=ON) cache dots too high: {d301['peak_live_cache_dots']}"

    v301_off_rgb = r301_off["rgba8"][..., :3].mean(axis=(0, 1))
    v301_on_rgb  = r301_on["rgba8"][..., :3].mean(axis=(0, 1))
    # Stained glass is warm magenta/pink (R ~ B >> G), whereas v3.00 bug had R collapsed and B spiked!
    assert float(v301_off_rgb[0]) > float(v300_mean_rgb[0]) + 25.0, (
        f"Expected true magenta/pink red channel restored in v3.01! v300={v300_mean_rgb}, v301={v301_off_rgb}"
    )

    comp = np.concatenate([r300["rgba8"], r301_off["rgba8"], r301_on["rgba8"]], axis=1)
    comp_p = OUT_DIR / "v301_6501x4751_blue_bug_fixed.png"
    Image.fromarray(comp).save(comp_p)

    summary = {
        "bytecode": bc,
        "v300_reproduced_rtv_errors": d300["rtv_errors"],
        "v300_max_cache_dim": d300["max_single_cache_dim"],
        "v300_mean_rgb_blue_bug": [round(float(x), 2) for x in v300_mean_rgb],
        "v301_rtv_errors": d301["rtv_errors"],
        "v301_max_cache_dim": d301["max_single_cache_dim"],
        "v301_peak_live_cache_dots": d301["peak_live_cache_dots"],
        "v301_off_mean_rgb_restored": [round(float(x), 2) for x in v301_off_rgb],
        "v301_on_mean_rgb_autoblend": [round(float(x), 2) for x in v301_on_rgb],
        "v301_on_log": r301_on["logs"][0] if r301_on["logs"] else "",
    }
    (OUT_DIR / "verify_v301_highres_blue_bug_fix_results.json").write_text(json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8")
    print("  Summary:", json.dumps(summary, indent=2, ensure_ascii=False))
    print(f"\nSUCCESS! 6501x4751 pure-blue bug reproduced on v3.00 & 100% eliminated on v3.01! Saved: {comp_p}")


if __name__ == "__main__":
    main()
