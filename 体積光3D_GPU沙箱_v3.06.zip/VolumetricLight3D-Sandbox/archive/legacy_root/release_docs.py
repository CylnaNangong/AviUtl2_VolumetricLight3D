#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v3.06 release: aul2 bumps, v3.05 archival, docs (更新历史/CSV/CHANGELOG/README×3 incl.
new Bug-Report section), packaging refs. Sync + zip build happen separately."""
import pathlib
import shutil

ROOT = pathlib.Path("/home/user")
GH = ROOT / "GitHub_VolumetricLight3D"
PKG = ROOT / "scripts/pkg1/体积光（3D）"
REL = ROOT / "releases"
V305_REL = REL / "体積光（3D）_v3.05_正式版"

def rep(path, old, new, count=1):
    b = path.read_bytes()
    ob, nb = old.encode("utf-8"), new.encode("utf-8")
    n = b.count(ob)
    assert n == count, f"{path}: anchor x{n} (want {count}): {old[:60]!r}"
    path.write_bytes(b.replace(ob, nb))

def eol(path):
    return "\r\n" if b"\r\n" in path.read_bytes()[:4096] else "\n"

# ---------- 1) archive v3.05 ----------
VER = PKG / "versions"
for src, dst in [
    (V305_REL / "Script/体積光（3D）.obj2", VER / "体積光（3D）_v3.05.obj2"),
    (V305_REL / "Language/简体中文.体積光（3D）.aul2", VER / "简体中文.体積光（3D）_v3.05.aul2"),
    (V305_REL / "Language/English.体積光（3D）.aul2", VER / "English.体積光（3D）_v3.05.aul2"),
    (V305_REL / "Language/Deutsch.体積光（3D）.aul2", VER / "Deutsch.体積光（3D）_v3.05.aul2"),
    (V305_REL / "Language/community_de.体積光（3D）.aul2", VER / "community_de.体積光（3D）_v3.05.aul2"),
]:
    assert src.is_file(), src
    shutil.copy2(src, dst)
ARC = REL / "au2pkg_GitHub_Release/archive_v3.05"
ARC.mkdir(parents=True, exist_ok=True)
for z in ["VolumetricLight3D-v3.05.au2pkg.zip", "VolumetricLight3D-v3.05-ScriptOnly.au2pkg.zip"]:
    shutil.move(str(REL / "au2pkg_GitHub_Release" / z), str(ARC / z))
print("[1] v3.05 archived (obj2 + 4 aul2 + 2 zips)")

# ---------- 2) aul2 version bumps (GitHub tree) ----------
for aul in sorted((GH / "Language").glob("*.体積光（3D）.aul2")):
    b = aul.read_bytes()
    n = b.count("v3.05".encode())
    assert n == 3, f"{aul.name}: v3.05 x{n}"
    aul.write_bytes(b.replace("v3.05".encode(), "v3.06".encode()))
print("[2] 4 aul2 bumped to v3.06")

# ---------- 3) 更新历史 append (zh, append-only) ----------
HIST = PKG / "更新历史_体積光3D.md"
nl = eol(HIST)
hist_add = """
---

## v3.06（2026-10-24）：特定图层构成下前景遮挡阴影「矩形黑块・边缘破碎・闪烁」的多层防御修复

2026-10-24：根据实机 `Verse1` 次合成（手动指定图层 4「石膏像.png」＋ 前景遮挡模式「仅真实3D遮光投影（m1）」）的测试反馈——遮挡检测已正常命中（`遮蔽=L4(m1)`）但阴影渲染出现「矩形黑块 / 边缘破碎 / 闪烁」异常——完成根因分析与修复。GPU 保真沙盒全链路复核确认 `v3.05` 的遮挡 atlas 构建、平面投影与阴影采样逻辑在理想宿主下完全正确（atlas 为标准剪影、阴影无矩形特征、同帧重渲染与连续帧 `maxdiff=0`），异常仅出现在真机 `obj.load("layer", no, effect)` 的「带效果加载」路径——该行为被官方 Lua 参考文档明确标注为「エフェクト側で描画処理が入る場合は上手く動作しない場合がある」（图层效果侧参与绘制时可能无法正确返回）。升级前已将 `v3.05` 脚本与四套 `v3.05` 语言包完整归档至 `versions/`，14 段 HLSL 着色器保持 100% 字节级不变（完全兼容 `D3DCOMPILE_WARNINGS_ARE_ERRORS`），健康图层下渲染结果与 `v3.05` 逐像素完全一致（`max_rgba_diff = 0`，含 `frame_s=0` 主场景与 `frame_s=619` 子合成两种工况）。

- **新增「剪影审计」`audit_object_alpha()` 与双模式加载自动回退**：对每个 2D 遮挡图层，在打包进遮挡 atlas 前通过 `obj.getpixeldata("object", "rgba")` 指针的稀疏网格采样（最多 64×64 点、`pcall` 全防护、不支持环境自动跳过、常态开销近似为零）估算已加载图像的 α 覆盖率；当「带效果加载（effect=true）」返回近乎全不透明的矩形（覆盖率 ≥ 98.5%，即官方文档警告的不良返回形态）时，自动改用「无效果原始加载（effect=false）」重试，若剪影显著改善（覆盖率差 ≥ 12%）则采用原始图像，从根上消除「矩形黑块」阴影。
- **HUD 自诊断标记**：若最终采用的遮罩仍近乎全不透明（如图像素材本身无透明通道），遮挡栏追加 `,opq` 标记；发生原始加载回退的图层以 `L4*` 星号标记（如 `遮蔽=L4*(m1)`），方便一眼定位问题图层（例如改用带 Alpha 通道的 PNG 或预抠像素材）。
- **拖拽缓存一致性加固（防闪烁）**：`occ2d` 拖拽缓存键加入加载模式（fx/raw）维度，保存瓦片记录 `load_mode` 并在拖拽恢复前预先回填，杜绝加载模式切换后误恢复旧蒙版导致的闪烁。
- **验证矩阵**：真机故障模拟（带效果加载返回不透明矩形 / 原始加载返回标准剪影）下，`v3.05` 阴影 bbox 填充率 `0.984`（矩形黑块成功复现）→ `v3.06` `0.733`（与健康素材完全一致的剪影阴影，修复生效）；健康素材奇偶校验 `maxdiff=0`（`frame_s=619` 子合成与 `frame_s=0` 主场景）；真不透明素材行为与 `v3.05` 完全一致且正确标记 `,opq`；受限宿主（`_G.os=nil`、`_G.io=nil`）初始化与渲染正常。
""".replace("\n", nl)
with open(HIST, "ab") as f:
    f.write(hist_add.lstrip("\n").encode("utf-8"))
print("[3] 更新历史 appended")

# ---------- 4) 版本状态.csv ----------
CSV = PKG / "版本状态.csv"
rep(CSV,
    "stable/Script/体積光（3D）.obj2,3.05,正式版默认主线（非零起始帧/次合成遮挡0hit修复+实机D3DCompile修复+开源正式版）,",
    "stable/Script/体積光（3D）.obj2,3.06,正式版默认主线（遮挡剪影审计修复+非零起始帧/次合成遮挡0hit修复+实机D3DCompile修复+开源正式版）,")
rep(CSV, "development/branch_v2.90_aux2_bridge/Script/体積光（3D）.obj2,3.05,已合入stable主线同步镜像,与 stable/Script/体積光（3D）.obj2 v3.05 保持字节级同步",
    "development/branch_v2.90_aux2_bridge/Script/体積光（3D）.obj2,3.06,已合入stable主线同步镜像,与 stable/Script/体積光（3D）.obj2 v3.06 保持字节级同步")
csv_b = CSV.read_bytes()
row = "versions/体積光（3D）_v3.05.obj2,3.05,历史归档,v3.05 非零起始帧/次合成遮挡0hit修复版留档（含配套四语v3.05 .aul2备份）".encode("utf-8")
csv_eol = b"\r\n" if b"\r\n" in csv_b else b"\n"
if not csv_b.endswith(csv_eol):
    csv_b += csv_eol
csv_b += row + csv_eol
CSV.write_bytes(csv_b)
print("[4] 版本状态.csv updated")

# ---------- 5) CHANGELOG zh/ja ----------
CLZ = GH / "docs/CHANGELOG_zh.md"
nlz = eol(CLZ)
clz_add = """## v3.06（2026-10-24）
- **修复特定图层构成下前景遮挡阴影呈「矩形黑块 / 边缘破碎 / 闪烁」的问题**
  - 新增遮挡蒙版「剪影审计」`audit_object_alpha()`：当带效果加载（`obj.load("layer", no, true)`，官方文档标注效果侧绘制时可能异常）返回近乎全不透明矩形（α 覆盖率 ≥ 98.5%）时，自动回退无效果原始加载并择优采用，消除矩形黑块阴影；审计经 `getpixeldata` 稀疏采样（≤64×64 点）实现，`pcall` 全防护且不支持环境自动跳过。
  - HUD 自诊断：遮挡栏新增 `,opq`（遮罩近乎全不透明）与 `L4*`（已回退原始加载）标记，方便定位缺少 Alpha 通道的遮挡素材。
  - `occ2d` 拖拽缓存键加入加载模式（fx/raw）并在恢复前回填，杜绝误恢复旧蒙版导致的闪烁。
  - 14 段 HLSL 着色器 0 改动（字节级一致）；健康图层渲染结果与 `v3.05` 逐像素一致（`max_rgba_diff=0`，`frame_s=0` 与 `frame_s=619` 双工况验证）。

""".replace("\n", nlz)
rep(CLZ, "## v3.05（2026-10-24）", clz_add + "## v3.05（2026-10-24）")

CLJ = GH / "docs/CHANGELOG_ja.md"
nlj = eol(CLJ)
clj_add = """## v3.06（2026-10-24）
- **特定のレイヤー構成で前景遮蔽影が「矩形黒塊・輪郭崩れ・点滅」になる不具合の修正**
  - 遮蔽マスクの「シルエット監査」`audit_object_alpha()` を追加：効果付き読み込み（`obj.load("layer", no, true)`、公式ドキュメントがエフェクト側描画時の不定挙動を注意喚起）がほぼ全面不透明のベタ矩形（α カバレッジ ≥ 98.5%）を返した場合、効果なし生ロードへ自動フォールバックして良い方を採用し、矩形黒塊影を根治。監査は `getpixeldata` 疎格子サンプリング（≤64x64 点・`pcall` 完全防護・非対応環境では自動スキップ）で定常コストほぼゼロ。
  - HUD 自己診断：遮蔽表示に `,opq`（マスクほぼ全面不透明）と `L4*`（生ロードへフォールバック済み）マークを追加。
  - `occ2d` ドラッグキャッシュキーへ読み込みモード（fx/raw）を反映し復元前に事前スタンプ、点滅を防止。
  - 14 段の HLSL シェーダーは 0 変更（バイト級一致）。健全レイヤーの描画結果は `v3.05` と完全一致（`max_rgba_diff=0`、`frame_s=0` / `frame_s=619` 両検証）。

""".replace("\n", nlj)
rep(CLJ, "## v3.05（2026-10-24）", clj_add + "## v3.05（2026-10-24）")
print("[5] CHANGELOG zh/ja prepended")

print("release_docs.py DONE")
