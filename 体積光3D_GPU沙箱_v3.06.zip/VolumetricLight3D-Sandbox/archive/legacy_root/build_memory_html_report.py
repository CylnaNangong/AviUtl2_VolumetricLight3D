#!/usr/bin/env python3
"""Build self-contained offline HTML report for AviUtl2 3D Scripts Memory-Access Audit."""

import base64
import html
import io
import re
from pathlib import Path
from PIL import Image

ROOT = Path("/home/user")
MD_PATH = ROOT / "AviUtl2_三款3D脚本内存访问专项审计与硬件沙盒实证报告.md"
HTML_PATH = ROOT / "AviUtl2_三款3D脚本内存访问专项审计与硬件沙盒实证报告.html"


def img_to_webp_data_uri(img_path: Path, quality: int = 88) -> str:
    im = Image.open(img_path).convert("RGB")
    buf = io.BytesIO()
    im.save(buf, format="WEBP", quality=quality, method=6)
    b64 = base64.b64encode(buf.getvalue()).decode("ascii")
    return f"data:image/webp;base64,{b64}"


def inline_md(s: str) -> str:
    # Escape HTML first except code spans
    parts = re.split(r"(`[^`]+`)", s)
    out = []
    for p in parts:
        if p.startswith("`") and p.endswith("`") and len(p) >= 2:
            out.append(f"<code>{html.escape(p[1:-1])}</code>")
        else:
            t = html.escape(p)
            t = re.sub(r"\*\*([^*]+)\*\*", r"<strong>\1</strong>", t)
            t = re.sub(r"\*([^*]+)\*", r"<em>\1</em>", t)
            t = t.replace("SIGSEGV (-11)", '<span class="badge-danger">SIGSEGV (-11)</span>')
            t = t.replace("0 崩溃", '<span class="badge-ok">0 崩溃</span>')
            t = t.replace("0 越界", '<span class="badge-ok">0 越界</span>')
            t = t.replace("0 堆污染", '<span class="badge-ok">0 堆污染</span>')
            t = t.replace("0 泄漏", '<span class="badge-ok">0 泄漏</span>')
            out.append(t)
    return "".join(out)


def md_to_html_body(md_text: str) -> str:
    lines = md_text.splitlines()
    out = []
    i = 0
    in_ul = False
    in_ol = False

    def close_lists():
        nonlocal in_ul, in_ol
        if in_ul:
            out.append("</ul>")
            in_ul = False
        if in_ol:
            out.append("</ol>")
            in_ol = False

    while i < len(lines):
        ln = lines[i]
        stripped = ln.strip()

        # Code block
        if stripped.startswith("```"):
            close_lists()
            lang = stripped[3:].strip() or "text"
            code_lines = []
            i += 1
            while i < len(lines) and not lines[i].strip().startswith("```"):
                code_lines.append(lines[i])
                i += 1
            i += 1
            raw_code = "\n".join(code_lines)
            highlighted = []
            for cl in code_lines:
                esc = html.escape(cl)
                if lang == "diff":
                    if cl.startswith("+") and not cl.startswith("+++"):
                        highlighted.append(f'<span class="diff-add">{esc}</span>')
                    elif cl.startswith("-") and not cl.startswith("---"):
                        highlighted.append(f'<span class="diff-del">{esc}</span>')
                    elif cl.startswith("@@"):
                        highlighted.append(f'<span class="diff-hunk">{esc}</span>')
                    else:
                        highlighted.append(esc)
                else:
                    highlighted.append(esc)
            code_html = "\n".join(highlighted)
            out.append(
                f'<div class="code-card"><div class="code-hdr"><span>{html.escape(lang.upper())}</span>'
                f'<button class="copy-btn" onclick="copyCode(this)">复制补丁</button></div>'
                f'<pre><code data-raw="{html.escape(raw_code)}">{code_html}</code></pre></div>'
            )
            continue

        # Image
        m_img = re.match(r"^!\[([^\]]*)\]\(([^)]+)\)$", stripped)
        if m_img:
            close_lists()
            alt, rel = m_img.group(1), m_img.group(2)
            img_file = (ROOT / rel).resolve()
            uri = img_to_webp_data_uri(img_file)
            out.append(
                f'<figure class="report-fig"><img src="{uri}" alt="{html.escape(alt)}" loading="lazy"/>'
                f'<figcaption>{html.escape(alt)}</figcaption></figure>'
            )
            i += 1
            continue

        # Table
        if stripped.startswith("|") and i + 1 < len(lines) and re.match(r"^\|[\s:\-\|]+\|$", lines[i + 1].strip()):
            close_lists()
            hdr_cells = [c.strip() for c in stripped.strip("|").split("|")]
            i += 2
            rows = []
            while i < len(lines) and lines[i].strip().startswith("|"):
                rows.append([c.strip() for c in lines[i].strip().strip("|").split("|")])
                i += 1
            out.append('<div class="table-wrap"><table><thead><tr>')
            for hc in hdr_cells:
                out.append(f"<th>{inline_md(hc)}</th>")
            out.append("</tr></thead><tbody>")
            for r in rows:
                out.append("<tr>" + "".join(f"<td>{inline_md(c)}</td>" for c in r) + "</tr>")
            out.append("</tbody></table></div>")
            continue

        # Blockquote
        if stripped.startswith(">"):
            close_lists()
            q_lines = []
            while i < len(lines) and lines[i].strip().startswith(">"):
                q_lines.append(lines[i].strip()[1:].strip())
                i += 1
            out.append('<blockquote class="meta-quote">' + "<br/>".join(inline_md(q) for q in q_lines if q) + "</blockquote>")
            continue

        # HR
        if stripped == "---":
            close_lists()
            out.append("<hr/>")
            i += 1
            continue

        # Headings
        m_h = re.match(r"^(#{1,4})\s+(.+)$", stripped)
        if m_h:
            close_lists()
            lvl = len(m_h.group(1))
            txt = m_h.group(2)
            hid = re.sub(r"[^\w\u4e00-\u9fff]+", "-", txt).strip("-")
            out.append(f"<h{lvl} id=\"{hid}\">{inline_md(txt)}</h{lvl}>")
            i += 1
            continue

        # Lists
        m_ul = re.match(r"^[-*]\s+(.+)$", stripped)
        if m_ul:
            if in_ol:
                out.append("</ol>")
                in_ol = False
            if not in_ul:
                out.append("<ul>")
                in_ul = True
            out.append(f"<li>{inline_md(m_ul.group(1))}</li>")
            i += 1
            continue

        m_ol = re.match(r"^\d+\.\s+(.+)$", stripped)
        if m_ol:
            if in_ul:
                out.append("</ul>")
                in_ul = False
            if not in_ol:
                out.append("<ol>")
                in_ol = True
            out.append(f"<li>{inline_md(m_ol.group(1))}</li>")
            i += 1
            continue

        if stripped == "":
            close_lists()
            i += 1
            continue

        close_lists()
        out.append(f"<p>{inline_md(stripped)}</p>")
        i += 1

    close_lists()
    return "\n".join(out)


def main():
    md_text = MD_PATH.read_text(encoding="utf-8")
    body_html = md_to_html_body(md_text)

    doc = f"""<!DOCTYPE html>
<html lang="zh-CN" data-theme="dark">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
<title>AviUtl2 三款 3D 脚本内存访问安全专项审计与硬件沙盒实证报告</title>
<style>
:root {{
  --bg: #0c1119;
  --surface: #141c28;
  --surface-2: #1b2638;
  --border: #2a3952;
  --text: #e6eef8;
  --muted: #9cb0c9;
  --accent: #4c8bf5;
  --danger: #ff5b6b;
  --ok: #2dd498;
  --warn: #f6ad3c;
  --code-bg: #0f1622;
}}
[data-theme="light"] {{
  --bg: #f4f7fb;
  --surface: #ffffff;
  --surface-2: #eef3fa;
  --border: #d4dfee;
  --text: #162032;
  --muted: #52647c;
  --accent: #2563eb;
  --danger: #dc2626;
  --ok: #059669;
  --warn: #d97706;
  --code-bg: #121926;
}}
* {{ box-sizing: border-box; }}
body {{
  margin: 0;
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", "PingFang SC", "Noto Sans CJK SC", "Microsoft YaHei", sans-serif;
  background: var(--bg);
  color: var(--text);
  line-height: 1.72;
}}
.topbar {{
  position: sticky; top: 0; z-index: 50;
  display: flex; justify-content: space-between; align-items: center;
  padding: 12px 28px;
  background: var(--surface);
  border-bottom: 1px solid var(--border);
  box-shadow: 0 4px 18px rgba(0,0,0,0.22);
}}
.topbar-title {{ font-weight: 700; font-size: 15px; color: var(--text); }}
.theme-btn {{
  cursor: pointer;
  background: var(--surface-2);
  color: var(--text);
  border: 1px solid var(--border);
  border-radius: 8px;
  padding: 6px 14px;
  font-size: 13px;
  font-weight: 600;
}}
.container {{ max-width: 1180px; margin: 28px auto 72px; padding: 0 24px; }}
.kpi-grid {{
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(215px, 1fr));
  gap: 14px;
  margin: 22px 0 28px;
}}
.kpi-card {{
  background: var(--surface);
  border: 1px solid var(--border);
  border-radius: 12px;
  padding: 16px 18px;
}}
.kpi-label {{ font-size: 12.5px; color: var(--muted); margin-bottom: 4px; }}
.kpi-val {{ font-size: 24px; font-weight: 800; line-height: 1.25; }}
.kpi-sub {{ font-size: 12px; color: var(--muted); margin-top: 6px; }}
.val-danger {{ color: var(--danger); }}
.val-ok {{ color: var(--ok); }}
.val-warn {{ color: var(--warn); }}
h1 {{ font-size: 28px; line-height: 1.35; margin: 12px 0 18px; letter-spacing: -0.01em; }}
h2 {{
  font-size: 21px; margin-top: 40px; padding-bottom: 8px;
  border-bottom: 2px solid var(--border); color: var(--text);
}}
h3 {{ font-size: 17px; margin-top: 26px; color: var(--accent); }}
p, li {{ font-size: 15px; }}
ul, ol {{ padding-left: 22px; }}
li {{ margin: 6px 0; }}
hr {{ border: none; border-top: 1px solid var(--border); margin: 32px 0; }}
code {{
  font-family: "JetBrains Mono", Consolas, Monaco, monospace;
  font-size: 13.2px;
  background: var(--surface-2);
  padding: 2px 6px;
  border-radius: 5px;
  border: 1px solid var(--border);
}}
.meta-quote {{
  margin: 16px 0 24px;
  padding: 14px 18px;
  background: var(--surface);
  border-left: 4px solid var(--accent);
  border-radius: 8px;
  color: var(--muted);
  font-size: 14px;
}}
.table-wrap {{
  overflow-x: auto;
  margin: 18px 0 26px;
  border: 1px solid var(--border);
  border-radius: 10px;
  background: var(--surface);
}}
table {{ width: 100%; border-collapse: collapse; font-size: 13.8px; }}
th, td {{ padding: 10px 13px; border-bottom: 1px solid var(--border); text-align: left; vertical-align: top; }}
th {{ background: var(--surface-2); font-weight: 700; white-space: nowrap; }}
tr:last-child td {{ border-bottom: none; }}
.report-fig {{
  margin: 26px 0;
  background: var(--surface);
  border: 1px solid var(--border);
  border-radius: 12px;
  padding: 14px;
  text-align: center;
}}
.report-fig img {{ max-width: 100%; height: auto; border-radius: 8px; display: block; margin: 0 auto; }}
.report-fig figcaption {{ margin-top: 10px; font-size: 13px; color: var(--muted); }}
.code-card {{
  margin: 16px 0 24px;
  border-radius: 10px;
  overflow: hidden;
  border: 1px solid #2b3850;
  background: var(--code-bg);
}}
.code-hdr {{
  display: flex; justify-content: space-between; align-items: center;
  padding: 7px 14px;
  background: #1a2436;
  color: #a8bbd8;
  font-size: 12px;
  font-weight: 700;
}}
.copy-btn {{
  cursor: pointer;
  background: #283854;
  color: #e6eef8;
  border: 1px solid #3c5278;
  border-radius: 5px;
  padding: 3px 10px;
  font-size: 12px;
}}
pre {{ margin: 0; padding: 14px 16px; overflow-x: auto; color: #dbe6f5; line-height: 1.52; }}
pre code {{ background: none; border: none; padding: 0; color: inherit; font-size: 12.8px; }}
.diff-add {{ color: #4ade80; display: inline-block; width: 100%; background: rgba(45,212,152,0.10); }}
.diff-del {{ color: #fb7185; display: inline-block; width: 100%; background: rgba(255,91,107,0.11); }}
.diff-hunk {{ color: #60a5fa; font-weight: 700; }}
.badge-danger {{
  display: inline-block; padding: 1px 7px; border-radius: 5px;
  background: rgba(255,91,107,0.18); color: #ff7b88; font-weight: 700; font-size: 12.5px;
}}
.badge-ok {{
  display: inline-block; padding: 1px 7px; border-radius: 5px;
  background: rgba(45,212,152,0.18); color: #3ce0a6; font-weight: 700; font-size: 12.5px;
}}
</style>
</head>
<body>
<div class="topbar">
  <div class="topbar-title">AviUtl2 三款 3D 脚本 — 内存访问安全专项审计与硬件保护页 (PROT_NONE) 沙盒实证</div>
  <button class="theme-btn" onclick="toggleTheme()">切换深浅主题</button>
</div>
<div class="container">
  <div class="kpi-grid">
    <div class="kpi-card">
      <div class="kpi-label">体积雾 v2.01 / 雪 v1.18 裸指针暴露</div>
      <div class="kpi-val val-ok">0 处 FFI / 0 越界</div>
      <div class="kpi-sub">100% 纯托管 Lua + HLSL 纹理常量槽</div>
    </div>
    <div class="kpi-card">
      <div class="kpi-label">体积光 v2.81 / v2.85 原生内存原语</div>
      <div class="kpi-val val-warn">105 处 ffi.cast</div>
      <div class="kpi-sub">55 处 ffi.new · 16 处 Win32 内存调用 · 22 处硬编码偏移</div>
    </div>
    <div class="kpi-card">
      <div class="kpi-label">硬件保护页实测复现崩溃 / 堆破坏</div>
      <div class="kpi-val val-danger">11 项高危触发</div>
      <div class="kpi-sub">含宿主 _Mylast 裸写、128TB TOCTOU、+64KB 越界、负步长</div>
    </div>
    <div class="kpi-card">
      <div class="kpi-label">加固补丁后崩溃率 & GLB 缓存提速</div>
      <div class="kpi-val val-ok">0 崩溃 · 1,697x</div>
      <div class="kpi-sub">60帧 GC 抖动从 90.04 MB 降至 0.59 KB</div>
    </div>
  </div>
  {body_html}
</div>
<script>
function toggleTheme() {{
  const root = document.documentElement;
  root.setAttribute("data-theme", root.getAttribute("data-theme") === "dark" ? "light" : "dark");
}}
function copyCode(btn) {{
  const code = btn.closest(".code-card").querySelector("code");
  const raw = code.getAttribute("data-raw") || code.innerText;
  navigator.clipboard.writeText(raw).then(() => {{
    const old = btn.innerText;
    btn.innerText = "已复制 ✓";
    setTimeout(() => btn.innerText = old, 1400);
  }});
}}
</script>
</body>
</html>
"""
    HTML_PATH.write_text(doc, encoding="utf-8")
    print(f"Generated {HTML_PATH} ({HTML_PATH.stat().st_size / 1024:.1f} KB)")


if __name__ == "__main__":
    main()
