#!/usr/bin/env python3
"""Generate publication-grade Chinese figures (fig9 & fig10) for the Memory Access Audit."""

import json
from pathlib import Path
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch
import numpy as np

plt.rcParams["font.sans-serif"] = ["Noto Sans CJK JP", "Noto Sans CJK SC", "DejaVu Sans"]
plt.rcParams["axes.unicode_minus"] = False

SANDBOX = Path("/home/user/sandbox")
METRICS = json.loads((SANDBOX / "results/memory_audit_metrics.json").read_text(encoding="utf-8"))
FIG_DIR = SANDBOX / "results/figures"
FIG_DIR.mkdir(parents=True, exist_ok=True)


def make_fig9():
    fig = plt.figure(figsize=(16.8, 8.6), dpi=160, facecolor="#0f141d")
    gs = fig.add_gridspec(1, 2, width_ratios=[0.96, 1.14], wspace=0.10, left=0.195, right=0.98, top=0.88, bottom=0.06)

    fig.suptitle(
        "图 9：三款脚本底层内存访问暴露面对比与 11 项硬件保护页 (PROT_NONE) 实证测试矩阵",
        fontsize=15, fontweight="bold", color="#f0f4fa", y=0.955,
    )

    # Left panel: Grouped bar of static memory surface + pass/fail matrix table
    ax_top = fig.add_subplot(gs[0, 0])
    ax_top.set_facecolor("#151c28")
    for sp in ax_top.spines.values():
        sp.set_color("#2b364a")

    categories = [
        "T1: pcall 捕获裸指针越界 (SEGV)",
        "T2b: 只读 gbuf 强写 _Mylast (+0xA0)",
        "T2c: aviutl2 +8B ABI 偏移静默写坏堆",
        "T3a: EditCam PE opt_sz 越界读 (+8KB)",
        "T3b: Layer 解析 hdr[4096] 越界 (+64KB)",
        "T4a: Modelfile 扫描 e_lfanew 未检越界",
        "T4c: 128TB 裸指针扫描多线程 TOCTOU",
        "T5a-c: PE 导出表 RVA/無終端/Ordinal 越界",
        "T6a-b: GLB 负 byteStride 向前越界读",
        "T7a: pool 1x1 缓存未验尺寸越界读",
        "T7b: fb_save 抓屏未验尺寸越界写溢出",
    ]
    y = np.arange(len(categories))[::-1]

    # Plot horizontal status bars: Unpatched (left=-1 crash/corrupt) vs Hardened Patch (right=+1 safe)
    ax_top.barh(y + 0.17, [1.0] * len(categories), height=0.32, color="#e05260", alpha=0.90, label="原版 v2.81 / v2.85（触发硬件 SIGSEGV / 堆写坏）")
    ax_top.barh(y - 0.17, [1.0] * len(categories), height=0.32, color="#2fbf8f", alpha=0.90, label="加固补丁版（边界校验 + 分块 RPM + 只读接管）")

    unpatched_tags = [
        "SIGSEGV (-11) 进程秒退",
        "SIGSEGV (-11) 写保护异常",
        "堆指针静默篡改 (0x..80→00)",
        "SIGSEGV (-11) 越过保护页",
        "越界读 +64,151 B 邻近堆",
        "SIGSEGV (-11) 越过保护页",
        "SIGSEGV (-11) 23.8ms 竞态崩",
        "3/3 用例全部 SIGSEGV (-11)",
        "SIGSEGV (-11) 负步长越界",
        "SIGSEGV (-11) 4B 缓冲越界",
        "SIGSEGV (-11) 缓冲区写溢出",
    ]
    patched_tags = [
        "改用内核态 RPM 探测 (0 崩溃)",
        "移除内存强写→安全告警/系数抵消",
        "零宿主内存写入 (0 堆污染)",
        "校验 opt_sz+nsec*40<=4096 (安全拦截)",
        "校验 <= nrd[0] 实读字节 (0 越界)",
        "校验 0x40<=lfanew<=0x800 (安全拦截)",
        "64KB 分块 RPM 遇解映射安全中止",
        "SizeOfImage + 有界 strnlen + ord<n_fn",
        "强制 12<=stride<=4096 且 4B 对齐",
        "强制 pw==gw & ph==gh & 'rgba'",
        "强制核验目标 pw,ph 后再 ffi.copy",
    ]

    for idx in range(len(categories)):
        yi = y[idx]
        ax_top.text(0.03, yi + 0.17, unpatched_tags[idx], va="center", ha="left", fontsize=8.3, color="#ffffff", fontweight="bold")
        ax_top.text(0.03, yi - 0.17, patched_tags[idx], va="center", ha="left", fontsize=8.1, color="#091512", fontweight="bold")

    ax_top.set_yticks(y)
    ax_top.set_yticklabels(categories, fontsize=8.6, color="#dce5f2")
    ax_top.set_xlim(0, 1.06)
    ax_top.set_ylim(-1.45, len(categories) - 0.35)
    ax_top.set_xticks([])
    ax_top.set_title("A. 11 项高危内存缺陷硬件沙盒实证对比（体积雾/雪为纯托管 0 裸指针）", fontsize=11.0, color="#f0f4fa", pad=10, fontweight="bold")
    ax_top.legend(loc="lower right", ncol=1, facecolor="#1c2536", edgecolor="#3a4963", labelcolor="#eef3fb", fontsize=8.3)

    # Right panel: Reverse-engineered aviutl2.exe memory access topology diagram
    ax_r = fig.add_subplot(gs[0, 1])
    ax_r.set_facecolor("#151c28")
    for sp in ax_r.spines.values():
        sp.set_color("#2b364a")
    ax_r.set_xlim(0, 100)
    ax_r.set_ylim(0, 100)
    ax_r.set_xticks([])
    ax_r.set_yticks([])
    ax_r.set_title("B. 《体积光（3D）》对宿主 aviutl2.exe 进程内存的逆向读写拓扑图", fontsize=11.2, color="#f0f4fa", pad=10, fontweight="bold")

    def draw_box(x, y, w, h, title, body, edge="#4c8bf5", fill="#1c273b", title_col="#9ec3ff"):
        box = FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.6,rounding_size=1.6",
                             facecolor=fill, edgecolor=edge, linewidth=1.6)
        ax_r.add_patch(box)
        ax_r.text(x + 1.8, y + h - 3.0, title, fontsize=8.9, fontweight="bold", color=title_col, va="top")
        ax_r.text(x + 1.8, y + h - 6.8, body, fontsize=7.9, color="#d7e1f0", va="top", linespacing=1.35)

    draw_box(
        4, 79, 92, 16.5,
        "① PE64 镜像头与代码段扫描 (exe_base = GetModuleHandleW(NULL))",
        "• .data 候选全局指针 + 硬编码 RVA exe_base + 0x58AAB8 (v2.1.14)\n"
        "• [高危 M-02/M-04] opt_sz(uint16) 未校验 → 越界读 +64KB；导出表无 SizeOfImage/strnlen 边界\n"
        "• .text 26 字节机器码特征扫描 (48 8B 05 ... 4C 8D 87) → 读取编辑摄像机 float[14]",
        edge="#f59e42", fill="#292118", title_col="#ffc278"
    )

    draw_box(
        4, 56, 44, 18.5,
        "② 渲染上下文链路 (ReadProcessMemory)",
        "lctx (+0x88) → rctx\n"
        "• rctx + 0x00 → active Scene*\n"
        "• rctx + 0x0C → ctx_frame\n"
        "• rctx + 0xC0 == 30 (0x1e 硬件阴影趟, v2.85)\n"
        "• rctx + 0xD0 → Deferred GBuffer*",
        edge="#4c8bf5", fill="#192538", title_col="#9cc2ff"
    )

    draw_box(
        52, 56, 44, 18.5,
        "③ [致命高危 M-01] 宿主内存直接覆写!",
        "gbuf + 0x98..0xA8 (std::vector<Light64>)\n"
        "• cam_light_mode==2 执行裸指针强写：\n"
        "  *(uint64_t*)(gbuf+0xA0) = lb_addr\n"
        "• 风险：无写权限检查 + 全局抹除同场模型照明\n"
        "  + 版本偏移即静默写坏 C++ 堆/虚表指针！",
        edge="#ff4d5e", fill="#331820", title_col="#ff9aa4"
    )

    draw_box(
        4, 31, 44, 20.5,
        "④ 实时时间轴场景图 (22 处硬编码偏移)",
        "Scene(+0x08) → Layer(+0x00, 16B 二分查找)\n"
        "→ Object(+0x50..54 帧区间, +0x18 Effect*)\n"
        "→ fx0(+0x40 名称, +0xB8 模型路径 wstring)\n"
        "→ fx0(+0x90..98 EffectItem*, +0x38 RGB, v2.85)",
        edge="#3cc7a6", fill="#162928", title_col="#84f0d5"
    )

    draw_box(
        52, 31, 44, 20.5,
        "⑤ [高危 M-03] 128TB 私有堆裸指针遍历",
        "VirtualQuery 遍历全进程 RW 私有堆 (≤64MB/块)\n"
        "直接用 const uint64_t* qw 逐字扫描：\n"
        "• 多线程解码/插件释放内存 → TOCTOU 崩溃\n"
        "• 任意缓冲区含特征指针即被误判为 3D 实例",
        edge="#f59e42", fill="#292118", title_col="#ffc278"
    )

    draw_box(
        4, 4.5, 92, 22.0,
        "⑥ FFI 文件解析器 / 像素缓冲区 / 全局持久化缓存 (_G._VL3D_PERSIST)",
        "• [高危 M-06] GLB 未检 byteStride<0 致向前越界崩溃；每帧重分 svx/svy/svz (1.5MB/帧)\n"
        "• [高危 M-07/M-08] scan_pool/fb_save 忽略返回宽高致越界读写；RGBA8 截断 71.4% HDR\n"
        "• [中危 M-10/M-12] CreateFileW 异常 100% 漏句柄；多场景同层 VRM_POSE_CACHE 句柄颠簸",
        edge="#a78bfa", fill="#211d33", title_col="#d2c2ff"
    )

    # Arrows connecting topology
    arrow_kw = dict(arrowstyle="->,head_width=0.35,head_length=0.45", color="#8fa8cc", lw=1.5)
    ax_r.annotate("", xy=(26, 74.8), xytext=(26, 78.8), arrowprops=arrow_kw)
    ax_r.annotate("", xy=(51.8, 65.2), xytext=(48.2, 65.2), arrowprops=dict(arrowstyle="->,head_width=0.4,head_length=0.5", color="#ff6b7a", lw=2.0))
    ax_r.annotate("", xy=(26, 51.8), xytext=(26, 55.8), arrowprops=arrow_kw)
    ax_r.annotate("", xy=(74, 51.8), xytext=(74, 55.8), arrowprops=arrow_kw)

    out_path = FIG_DIR / "fig9_memory_architecture_and_hazards.png"
    fig.savefig(out_path, dpi=160)
    plt.close(fig)
    print(f"Saved {out_path}")


def make_fig10():
    fig = plt.figure(figsize=(15.0, 6.8), dpi=160, facecolor="#0f141d")
    gs = fig.add_gridspec(1, 3, width_ratios=[1.05, 1.0, 1.0], wspace=0.25, left=0.06, right=0.97, top=0.84, bottom=0.14)

    fig.suptitle(
        "图 10：三款脚本内存分配吞吐、文件加载峰值放大与多场景句柄颠簸实测基准",
        fontsize=14.8, fontweight="bold", color="#f0f4fa", y=0.95,
    )

    # Panel 1: 60-frame LuaJIT GC allocation churn (MB over 60 frames, log scale)
    ax1 = fig.add_subplot(gs[0, 0])
    ax1.set_facecolor("#151c28")
    for sp in ax1.spines.values():
        sp.set_color("#2b364a")

    labels = [
        "体积雾\nv2.01",
        "雪 3D\nv1.15",
        "雪 3D\nv1.18",
        "体积光 GLB\nv2.81 原版",
        "体积光 GLB\nFFI 加固版",
    ]
    # 60-frame measured / derived Lua GC allocations (MB):
    # Fog v2.01: ~0.04 MB / 60f (pure constant tables)
    # Snow v1.15: 91,872 verts * ~120B table/subtable * 60f ≈ 630 MB / 60f
    # Snow v1.18: 696 verts * ~120B * 60f ≈ 4.8 MB / 60f
    # VL GLB v2.81 (36k verts): measured 90.042 MB / 60f
    # VL GLB FFI patched: measured 0.00058 MB / 60f
    vals_mb = [0.04, 631.0, 4.78, 90.04, 0.0006]
    colors = ["#38bdf8", "#e05260", "#2fbf8f", "#f59e42", "#2fbf8f"]
    x = np.arange(len(labels))
    bars = ax1.bar(x, vals_mb, width=0.56, color=colors, edgecolor="#ffffff22")
    ax1.set_yscale("log")
    ax1.set_ylim(0.0002, 2500)
    ax1.set_xticks(x)
    ax1.set_xticklabels(labels, fontsize=8.8, color="#dce5f2")
    ax1.tick_params(axis="y", colors="#dce5f2", labelsize=8.5)
    ax1.grid(axis="y", linestyle="--", alpha=0.22, color="#8fa8cc")
    ax1.set_ylabel("60 帧累计 LuaJIT GC 分配量 (MB，对数坐标)", fontsize=9.2, color="#dce5f2")
    ax1.set_title("A. 连续 60 帧托管堆分配抖动对比", fontsize=10.8, color="#f0f4fa", fontweight="bold", pad=10)

    ann = ["0.04 MB", "631 MB\n(9.2万顶点)", "4.8 MB\n(-99.2%)", "90.04 MB\n(56.0ms)", "0.59 KB\n(0.033ms)"]
    for b, txt in zip(bars, ann):
        h = b.get_height()
        ax1.text(b.get_x() + b.get_width() / 2, h * 1.45, txt, ha="center", va="bottom", fontsize=8.0, color="#eef3fb", fontweight="bold")

    # Panel 2: Peak RAM amplification during Win32 64MB VRM load + fb_save per-frame copy bandwidth
    ax2 = fig.add_subplot(gs[0, 1])
    ax2.set_facecolor("#151c28")
    for sp in ax2.spines.values():
        sp.set_color("#2b364a")

    stages = ["原始磁盘文件\n(64MB VRM)", "win32_read 峰值\n(buf + ffi.string)", "GLB 解析峰值\n(+JSON/Lua表)", "fb_save 每秒带宽\n(1080p@60fps)"]
    mb_vals = [64.0, 128.0, 176.0, 31.64 * 60.0]
    c2 = ["#4c8bf5", "#f59e42", "#e05260", "#a78bfa"]
    x2 = np.arange(len(stages))
    b2 = ax2.bar(x2, mb_vals, width=0.54, color=c2)
    ax2.set_yscale("log")
    ax2.set_ylim(20, 5000)
    ax2.set_xticks(x2)
    ax2.set_xticklabels(stages, fontsize=8.5, color="#dce5f2")
    ax2.tick_params(axis="y", colors="#dce5f2", labelsize=8.5)
    ax2.grid(axis="y", linestyle="--", alpha=0.22, color="#8fa8cc")
    ax2.set_ylabel("内存占用 / 每秒拷贝吞吐 (MB，对数坐标)", fontsize=9.2, color="#dce5f2")
    ax2.set_title("B. 大文件双倍峰值与 fb_save 带宽开销", fontsize=10.8, color="#f0f4fa", fontweight="bold", pad=10)
    tags2 = ["64.0 MB\n(1.0x 基准)", "128.0 MB\n(2.00x 实测)", "~176 MB\n(~2.75x 峰值)", "1,898 MB/s\n(-71.4% HDR)"]
    for b, txt in zip(b2, tags2):
        h = b.get_height()
        ax2.text(b.get_x() + b.get_width() / 2, h * 1.22, txt, ha="center", va="bottom", fontsize=8.0, color="#eef3fb", fontweight="bold")

    # Panel 3: VRM_POSE_CACHE multi-scene collision & Win32 handle leak
    ax3 = fig.add_subplot(gs[0, 2])
    ax3.set_facecolor("#151c28")
    for sp in ax3.spines.values():
        sp.set_color("#2b364a")

    m_labels = ["多场景同层 30 帧\nopen_model 次数", "10 次异常读取\n泄漏 Win32 句柄数"]
    orig_v = [60, 10]
    fix_v  = [2, 0]
    x3 = np.arange(len(m_labels))
    w3 = 0.30
    r1 = ax3.bar(x3 - w3 / 2, orig_v, width=w3, color="#e05260", label="原版 v2.81")
    r2 = ax3.bar(x3 + w3 / 2, fix_v,  width=w3, color="#2fbf8f", label="加固补丁版")
    ax3.set_ylim(0, 72)
    ax3.set_xticks(x3)
    ax3.set_xticklabels(m_labels, fontsize=9.0, color="#dce5f2")
    ax3.tick_params(axis="y", colors="#dce5f2", labelsize=8.5)
    ax3.grid(axis="y", linestyle="--", alpha=0.22, color="#8fa8cc")
    ax3.set_ylabel("调用次数 / 泄漏内核句柄数", fontsize=9.2, color="#dce5f2")
    ax3.set_title("C. 多场景句柄颠簸与异常句柄泄漏", fontsize=10.8, color="#f0f4fa", fontweight="bold", pad=10)
    ax3.legend(loc="upper right", facecolor="#1c2536", edgecolor="#3a4963", labelcolor="#eef3fb", fontsize=8.5)

    for b in r1:
        h = b.get_height()
        ax3.text(b.get_x() + b.get_width() / 2, h + 1.5, f"{int(h)}", ha="center", va="bottom", fontsize=9.2, color="#ff9aa4", fontweight="bold")
    for b in r2:
        h = b.get_height()
        ax3.text(b.get_x() + b.get_width() / 2, h + 1.5, f"{int(h)}", ha="center", va="bottom", fontsize=9.2, color="#7bf0c4", fontweight="bold")

    out_path = FIG_DIR / "fig10_memory_churn_and_bandwidth.png"
    fig.savefig(out_path, dpi=160)
    plt.close(fig)
    print(f"Saved {out_path}")


if __name__ == "__main__":
    make_fig9()
    make_fig10()
