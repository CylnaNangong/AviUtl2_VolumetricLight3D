#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""README x3 updates: version bumps, new section 8 (bug report), renumber 8->9, 9->10, TOC."""
import pathlib

GH = pathlib.Path("/home/user/GitHub_VolumetricLight3D")

def rep(path, old, new, count=1):
    b = path.read_bytes()
    ob, nb = old.encode("utf-8"), new.encode("utf-8")
    if ob not in b:
        assert nb in b, f"{path}: anchor missing AND replacement missing: {old[:60]!r}"
        return  # already applied (idempotent)
    n = b.count(ob)
    assert n == count, f"{path}: anchor x{n} (want {count}): {old[:70]!r}"
    path.write_bytes(b.replace(ob, nb))

SEC_ZH = """## 8. 问题反馈（Bug 报告途径）

- **首选 [GitHub Issues](./issues)（最推荐！）**。反馈时请尽量附上：
  - 脚本版本号（勾选「画面に状態表示 / 状态显示」后可在画面左上角 HUD 看到，例如 `v3.06`）与 `AviUtl ExEdit2` 本体版本；
  - 复现步骤、时间轴图层构成截图、以及异常效果的截图（**请保留 HUD 信息一起截**，里面的 `遮挡=…`、`光源=…` 等字段是定位问题的关键线索哦！）；
  - 若 HUD 遮挡栏出现 `,opq`（遮罩近乎全不透明，请检查遮挡图层素材是否带 Alpha 透明通道）或 `L4*`（该图层已自动回退为原始图像加载）标记，也请一并说明 ^_^
- **Discord 社区**：也可以加入日文 AviUtl2 情报共享社区 **「AviUtl2の情報が知りたいだろって‼」**（[点击加入](https://discord.gg/8qzmGY5NgQ)），在服务器里找 **南宫若馨Cylna**（作者本人）就可以直接反馈啦～

---

"""

SEC_JA = """## 8. バグ報告・フィードバック

- **一番確実なのは [GitHub Issues](../../issues) です！** 報告の際は以下を添えていただけると大変助かります：
  - スクリプトのバージョン（「画面に状態表示」を ON にすると画面左上の HUD に表示されます。例: `v3.06`）と `AviUtl ExEdit2` 本体のバージョン；
  - 再現手順・タイムラインのレイヤー構成スクリーンショット・異常時の描画スクリーンショット（**HUD を写したまま撮ってください**。`遮蔽=…` `光源=…` などの表示が原因特定の重要な手がかりになります！）；
  - HUD の遮蔽表示に `,opq`（マスクがほぼ全面不透明＝遮蔽レイヤー素材に Alpha 透過チャンネルがあるかご確認を）や `L4*`（そのレイヤーは生画像ロードへ自動フォールバック済み）が出ている場合も併記ください ^_^
- **Discord コミュニティ**：日本語 AviUtl2 情報共有サーバー **「AviUtl2の情報が知りたいだろって‼」**（[参加リンク](https://discord.gg/8qzmGY5NgQ)）でも OK！サーバー内で **南宫若馨Cylna**（作者本人）を見つけて直接報告できます～

---

"""

SEC_EN = """## 8. Reporting Bugs

- **[GitHub Issues](../../issues) is the best channel!** Please include:
  - the script version (turn on 「画面に状態表示 / status overlay」 to show it in the top-left HUD, e.g. `v3.06`) and your AviUtl ExEdit2 version;
  - steps to reproduce, a screenshot of your timeline layer layout, and of the visual glitch (**keep the HUD visible** — fields like `遮蔽=…` / `光源=…` are key clues!);
  - if the HUD occlusion tag shows `,opq` (mask nearly fully opaque — check that the occluder image has an alpha channel) or `L4*` (that layer fell back to raw image load), mention it too ^_^
- **Discord community**: you can also join the Japanese AviUtl2 community server **「AviUtl2の情報が知りたいだろって‼」** ([invite link](https://discord.gg/8qzmGY5NgQ)) and ping **南宫若馨Cylna** (the author) directly!

---

"""

# ================= README.md (zh, root) =================
R = GH / "README.md"
rep(R, "`体積光（3D）.obj2 v3.05`", "`体積光（3D）.obj2 v3.06`")
rep(R, "VolumetricLight3D-v3.05.au2pkg.zip", "VolumetricLight3D-v3.06.au2pkg.zip")
rep(R, "VolumetricLight3D-v3.05-ScriptOnly.au2pkg.zip", "VolumetricLight3D-v3.06-ScriptOnly.au2pkg.zip")
rep(R, "核心自定义对象脚本（v3.05）", "核心自定义对象脚本（v3.06）")
rep(R, "协助完成 `v2.90`～`v3.05` 全链路重构", "协助完成 `v2.90`～`v3.06` 全链路重构")
# renumber sections 8/9 -> 9/10 (body)
rep(R, "## 8. 从源码构建 `VL3DBridge.aux2` 与打包", "## 9. 从源码构建 `VL3DBridge.aux2` 与打包")
rep(R, "## 9. 作者、致谢与开源许可", "## 10. 作者、致谢与开源许可")
# insert new section 8 before the build section
rep(R, "## 9. 从源码构建 `VL3DBridge.aux2` 与打包", SEC_ZH + "## 9. 从源码构建 `VL3DBridge.aux2` 与打包")
# TOC
rep(R, "- [8. 从源码构建 `VL3DBridge.aux2` 与打包](#8-从源码构建-vl3dbridgeaux2-与打包)\n- [9. 作者、致谢与开源许可](#9-作者致谢与开源许可)",
    "- [8. 问题反馈（Bug 报告途径）](#8-问题反馈bug-报告途径)\n- [9. 从源码构建 `VL3DBridge.aux2` 与打包](#9-从源码构建-vl3dbridgeaux2-与打包)\n- [10. 作者、致谢与开源许可](#10-作者致谢与开源许可)")
print("README.md done")

# ================= README_ja.md =================
R = GH / "docs/README_ja.md"
rep(R, "`体積光（3D）.obj2 v3.05`", "`体積光（3D）.obj2 v3.06`")
rep(R, "VolumetricLight3D-v3.05.au2pkg.zip", "VolumetricLight3D-v3.06.au2pkg.zip")
rep(R, "VolumetricLight3D-v3.05-ScriptOnly.au2pkg.zip", "VolumetricLight3D-v3.06-ScriptOnly.au2pkg.zip")
rep(R, "カスタムオブジェクト本体（v3.05）", "カスタムオブジェクト本体（v3.06）")
rep(R, "`v2.90`〜`v3.05` の設計刷新", "`v2.90`〜`v3.06` の設計刷新")
rep(R, "## 8. `VL3DBridge.aux2` のソースビルドとパッケージ生成", "## 9. `VL3DBridge.aux2` のソースビルドとパッケージ生成")
rep(R, "## 9. 作者・謝辞・ライセンス", "## 10. 作者・謝辞・ライセンス")
rep(R, "## 9. `VL3DBridge.aux2` のソースビルドとパッケージ生成", SEC_JA + "## 9. `VL3DBridge.aux2` のソースビルドとパッケージ生成")
rep(R, "- [8. `VL3DBridge.aux2` のソースビルドとパッケージ生成](#8-vl3dbridgeaux2-のソースビルドとパッケージ生成)\n- [9. 作者・謝辞・ライセンス](#9-作者謝辞ライセンス)",
    "- [8. バグ報告・フィードバック](#8-バグ報告フィードバック)\n- [9. `VL3DBridge.aux2` のソースビルドとパッケージ生成](#9-vl3dbridgeaux2-のソースビルドとパッケージ生成)\n- [10. 作者・謝辞・ライセンス](#10-作者謝辞ライセンス)")
print("README_ja.md done")

# ================= README_en.md =================
R = GH / "docs/README_en.md"
rep(R, "`体積光（3D）.obj2 v3.05`", "`体積光（3D）.obj2 v3.06`")
rep(R, "VolumetricLight3D-v3.05.au2pkg.zip", "VolumetricLight3D-v3.06.au2pkg.zip")
rep(R, "VolumetricLight3D-v3.05-ScriptOnly.au2pkg.zip", "VolumetricLight3D-v3.06-ScriptOnly.au2pkg.zip")
rep(R, "Core custom object script (v3.05)", "Core custom object script (v3.06)")
rep(R, "`v2.90`–`v3.05` architecture", "`v2.90`–`v3.06` architecture")
rep(R, "## 8. Building `VL3DBridge.aux2` & `.au2pkg.zip` Packages", "## 9. Building `VL3DBridge.aux2` & `.au2pkg.zip` Packages")
rep(R, "## 9. Authors, Acknowledgements & License", "## 10. Authors, Acknowledgements & License")
rep(R, "## 9. Building `VL3DBridge.aux2` & `.au2pkg.zip` Packages", SEC_EN + "## 9. Building `VL3DBridge.aux2` & `.au2pkg.zip` Packages")
rep(R, "- [8. Building `VL3DBridge.aux2` & `.au2pkg.zip` Packages](#8-building-vl3dbridgeaux2--au2pkgzip-packages)\n- [9. Authors, Acknowledgements & License](#9-authors-acknowledgements--license)",
    "- [8. Reporting Bugs](#8-reporting-bugs)\n- [9. Building `VL3DBridge.aux2` & `.au2pkg.zip` Packages](#9-building-vl3dbridgeaux2--au2pkgzip-packages)\n- [10. Authors, Acknowledgements & License](#10-authors-acknowledgements--license)")
print("README_en.md done")

# ================= packaging =================
rep(GH / "packaging/package.ini", "information=体積光（3D） v3.05 (+ VL3DBridge v1.21)",
    "information=体積光（3D） v3.06 (+ VL3DBridge v1.21)")
rep(GH / "packaging/package.txt", "[ 体積光（3D） / 体积光（3D） / Volumetric Light (3D) — v3.05 ]",
    "[ 体積光（3D） / 体积光（3D） / Volumetric Light (3D) — v3.06 ]")
rep(GH / "packaging/package.txt", "面向 AviUtl ExEdit2 的真·3D 丁达尔体积光自定义对象（v3.05）。",
    "面向 AviUtl ExEdit2 的真·3D 丁达尔体积光自定义对象（v3.06）。")
rep(GH / "packaging/package.txt", "THE REAL 3D volumetric god-ray custom object (v3.05) for AviUtl ExEdit2",
    "THE REAL 3D volumetric god-ray custom object (v3.06) for AviUtl ExEdit2")
rep(GH / "packaging/build_au2pkg.py", 'VERSION = "v3.05"', 'VERSION = "v3.06"')
rep(GH / "packaging/build_au2pkg.py", "VolumetricLight3D-v3.05.au2pkg.zip", "VolumetricLight3D-v3.06.au2pkg.zip")
rep(GH / "packaging/build_au2pkg.py", "VolumetricLight3D-v3.05-ScriptOnly.au2pkg.zip", "VolumetricLight3D-v3.06-ScriptOnly.au2pkg.zip")
print("packaging done")
