#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Build the v2.90 branch of 体積光（3D） without touching the v2.86 mainline.

The branch:
  * prefers the read-only VL3DBridge.aux2 module (graceful Lua fallback)
  * removes the host GBuffer write (M-01) and compensates mode 2 in-shader/gain
  * applies memory patches M-02..M-12 to the Lua fallback
  * refactors beam_frame() (P0-8) so its active local count is far under 60
  * backs up the framebuffer with obj.copybuffer when the host supports it
"""
from __future__ import annotations

import pathlib
import re
import subprocess
import sys
import textwrap

ROOT = pathlib.Path("/home/user")
SRC = ROOT / "scripts/pkg1/体积光（3D）/stable/Script/体積光（3D）.obj2"
OUT_DIR = ROOT / "scripts/pkg1/体积光（3D）/development/branch_v2.90_aux2_bridge/Script"
OUT = OUT_DIR / "体積光（3D）.obj2"

SCAN_FN = r'''local function scan_live_modelfile_instances()
    local api = get_w32_api()
    if api == nil or api.GetModuleHandleW == nil or api.VirtualQuery == nil or api.ReadProcessMemory == nil then
        return _live_modelfile_cache.list
    end
    local ffi = api.ffi
    if ffi.arch ~= "x64" then return _live_modelfile_cache.list end

    local now_t = (type(os) == "table" and type(os.clock) == "function") and os.clock() or 0.0
    if now_t - _live_modelfile_cache.t < 0.75 then
        return _live_modelfile_cache.list
    end
    _live_modelfile_cache.t = now_t

    local found = {}
    pcall(function()
        local mbi = ffi.new("uint8_t[64]")
        local nrd = ffi.new("size_t[1]")
        local hproc = (api.GetCurrentProcess ~= nil) and api.GetCurrentProcess() or ffi.cast("intptr_t", -1)
        local function rpm(addr, dst, nbytes)
            if addr == nil or addr < 0x10000 or nbytes <= 0 then return false end
            nrd[0] = 0
            if api.ReadProcessMemory(hproc, ffi.cast("const void*", addr), dst, nbytes, nrd) == 0 then
                return false
            end
            return tonumber(nrd[0]) or 0
        end
        local function page_info(addr)
            if addr == nil or addr < 0x10000 then return nil end
            if api.VirtualQuery(ffi.cast("const void*", addr), mbi, 48) < 48 then return nil end
            return {
                base = tonumber(ffi.cast("const uint64_t*", mbi)[0]) or 0,
                size = tonumber(ffi.cast("const uint64_t*", mbi + 24)[0]) or 0,
                state = ffi.cast("const uint32_t*", mbi + 32)[0],
                prot = ffi.cast("const uint32_t*", mbi + 36)[0],
                typ = ffi.cast("const uint32_t*", mbi + 40)[0],
            }
        end

        local exe_base = tonumber(api.GetModuleHandleW(nil)) or 0
        local exe_pi = page_info(exe_base)
        if exe_base == 0 or exe_pi == nil or exe_pi.state ~= 0x1000 then return end

        -- [M-02/M-03] PE header is copied by the kernel. A wild e_lfanew cannot walk into PROT_NONE.
        local hdr = ffi.new("uint8_t[4096]")
        local hdr_n = rpm(exe_base, hdr, 4096)
        if not hdr_n or hdr_n < 0x200 or hdr[0] ~= 0x4D or hdr[1] ~= 0x5A then return end
        local lf = ffi.cast("const int32_t*", hdr + 0x3C)[0]
        if lf < 0x40 or lf > 0x800 or (lf + 0x58) > hdr_n then return end
        if hdr[lf] ~= 0x50 or hdr[lf + 1] ~= 0x45 then return end
        local img_sz = math.min(tonumber(ffi.cast("const uint32_t*", hdr + lf + 0x50)[0]) or 0, 0x1000000)
        if img_sz < 0x1000 then return end

        if _live_modelfile_cache.wstr_addr == nil then
            _live_modelfile_cache.wstr_addr = 0
            local pat = ffi.new("uint8_t[16]")
            local pw = ffi.new("uint16_t[8]", { 0x30E2, 0x30C7, 0x30EB, 0x30D5, 0x30A1, 0x30A4, 0x30EB, 0x0000 })
            ffi.copy(pat, pw, 16)
            local chunk = ffi.new("uint8_t[65536]")
            local cur = exe_base + 0x1000
            local end_img = exe_base + img_sz
            while cur < end_img and _live_modelfile_cache.wstr_addr == 0 do
                local pi = page_info(cur)
                if pi == nil or pi.size <= 0 then break end
                local pm = pi.prot % 256
                if pi.state == 0x1000 and pm == 2 and pi.size >= 16 then
                    local s0 = math.max(cur, pi.base)
                    local s1 = math.min(end_img, pi.base + pi.size)
                    local off = s0
                    while off + 16 <= s1 and _live_modelfile_cache.wstr_addr == 0 do
                        local req = math.min(65536, s1 - off)
                        local got = rpm(off, chunk, req)
                        if not got or got < 16 then break end
                        local lim = got - 16
                        local p = 0
                        while p <= lim do
                            local match = true
                            for k = 0, 15 do
                                if chunk[p + k] ~= pat[k] then match = false; break end
                            end
                            if match then
                                _live_modelfile_cache.wstr_addr = off + p
                                break
                            end
                            p = p + 2
                        end
                        if got < req then break end
                        off = off + math.max(1, got - 16)
                    end
                end
                local nxt = pi.base + math.max(pi.size, 0x1000)
                if nxt <= cur then break end
                cur = nxt
            end
        end

        local wstr_target = _live_modelfile_cache.wstr_addr or 0
        if wstr_target == 0 then return end
        local target_u64 = ffi.cast("uint64_t", wstr_target)
        local chunk_qw = ffi.new("uint64_t[8192]")
        local inst_buf = ffi.new("uint8_t[0x110]")
        local addr = 0x10000
        local max_user = 0x7FFFFFFF0000
        while addr < max_user and #found < 16 do
            local pi = page_info(addr)
            if pi == nil or pi.size <= 0 then break end
            if pi.state == 0x1000 and pi.prot == 0x04 and pi.typ == 0x20000 and pi.size >= 0x120 and pi.size <= 0x4000000 then
                local off_b = 0
                while off_b + 0x110 <= pi.size and #found < 16 do
                    local req_b = math.min(65536, pi.size - off_b)
                    local got = rpm(pi.base + off_b, chunk_qw, req_b)
                    if not got or got < 72 then
                        break
                    end
                    local got_qw = math.floor(got / 8) - 1
                    for i = 0, got_qw do
                        if chunk_qw[i] == target_u64 and (off_b + i * 8) >= 0x40 then
                            local inst_addr = pi.base + off_b + i * 8 - 0x40
                            local igot = rpm(inst_addr, inst_buf, 0x110)
                            if igot and igot >= 0x110 then
                                local vt0 = tonumber(ffi.cast("const uint64_t*", inst_buf)[0]) or 0
                                local vt1 = tonumber(ffi.cast("const uint64_t*", inst_buf + 0x68)[0]) or 0
                                if vt0 > exe_base and vt0 < exe_base + 0x1000000 and vt1 > exe_base and vt1 < exe_base + 0x1000000 then
                                    local slen = tonumber(ffi.cast("const uint64_t*", inst_buf + 0xB8)[0]) or 0
                                    local scap = tonumber(ffi.cast("const uint64_t*", inst_buf + 0xC0)[0]) or 0
                                    if slen >= 4 and slen <= 1024 and scap >= 7 and scap <= 4096 and slen <= scap then
                                        local warr = nil
                                        if scap < 8 then
                                            warr = ffi.cast("const uint16_t*", inst_buf + 0xA8)
                                        else
                                            local hp = tonumber(ffi.cast("const uint64_t*", inst_buf + 0xA8)[0]) or 0
                                            local tmpw = ffi.new("uint16_t[?]", slen + 1)
                                            local wgot = rpm(hp, tmpw, slen * 2)
                                            if wgot and wgot >= slen * 2 then
                                                tmpw[slen] = 0
                                                warr = tmpw
                                            end
                                        end
                                        if warr ~= nil then
                                            local fpath = utf16le_ptr_to_utf8(warr, slen)
                                            local adj_b = inst_buf[0x108]
                                            if fpath ~= "" and fpath:lower():find(".obj", 1, true) then
                                                found[#found + 1] = { path = fpath, adj = (adj_b ~= 0) and 1 or 0 }
                                            end
                                        end
                                    end
                                end
                            end
                        end
                    end
                    if got < req_b then break end
                    off_b = off_b + 65536
                end
            end
            local nxt = pi.base + pi.size
            if nxt <= addr then break end
            addr = nxt
        end
    end)

    _live_modelfile_cache.list = found
    return found
end
'''

PE_FN = r'''local function pe_find_export_addr(ffi, mod_base, target_name)
    if mod_base == 0 or type(target_name) ~= "string" or target_name == "" then return 0 end
    local b = ffi.cast("const uint8_t*", mod_base)
    if b[0] ~= 0x4D or b[1] ~= 0x5A then return 0 end
    local e_lfanew = ffi.cast("const int32_t*", b + 0x3C)[0]
    -- e_lfanew <= 0x800 keeps the PE optional-header read inside the first 0x890 bytes.
    if e_lfanew < 0x40 or e_lfanew > 0x800 then return 0 end
    local nt = b + e_lfanew
    if nt[0] ~= 0x50 or nt[1] ~= 0x45 or nt[2] ~= 0 or nt[3] ~= 0 then return 0 end
    local magic = ffi.cast("const uint16_t*", nt + 0x18)[0]
    local img_sz = tonumber(ffi.cast("const uint32_t*", nt + 0x50)[0]) or 0
    if img_sz < 0x1000 or img_sz > 0x20000000 then return 0 end
    local dd_off = (magic == 0x20B) and 0x88 or ((magic == 0x10B) and 0x78 or 0)
    if dd_off == 0 or (e_lfanew + dd_off + 8) > img_sz then return 0 end
    local exp_rva = ffi.cast("const uint32_t*", nt + dd_off)[0]
    local exp_sz  = ffi.cast("const uint32_t*", nt + dd_off + 4)[0]
    if exp_rva == 0 or exp_sz < 0x28 or exp_rva >= img_sz or (exp_rva + exp_sz) > img_sz then return 0 end
    local exp = b + exp_rva
    local n_funcs = ffi.cast("const uint32_t*", exp + 0x14)[0]
    local n_names = ffi.cast("const uint32_t*", exp + 0x18)[0]
    local rva_fn  = ffi.cast("const uint32_t*", exp + 0x1C)[0]
    local rva_nm  = ffi.cast("const uint32_t*", exp + 0x20)[0]
    local rva_ord = ffi.cast("const uint32_t*", exp + 0x24)[0]
    if n_funcs == 0 or n_names == 0 or n_funcs > 65536 or n_names > 65536 then return 0 end
    if rva_fn == 0 or rva_nm == 0 or rva_ord == 0 then return 0 end
    if (rva_fn + n_funcs * 4) > img_sz or (rva_nm + n_names * 4) > img_sz or (rva_ord + n_names * 2) > img_sz then
        return 0
    end

    local function safe_cstr(rva, max_len)
        if rva == 0 or rva >= img_sz then return nil end
        local lim = math.min(max_len, img_sz - rva)
        local p = b + rva
        for k = 0, lim - 1 do
            if p[k] == 0 then return ffi.string(p, k) end
        end
        return nil
    end

    local names = ffi.cast("const uint32_t*", b + rva_nm)
    local ords  = ffi.cast("const uint16_t*", b + rva_ord)
    local funcs = ffi.cast("const uint32_t*", b + rva_fn)
    local lo, hi = 0, tonumber(n_names) - 1
    while lo <= hi do
        local mid = math.floor((lo + hi) * 0.5)
        local nm = safe_cstr(tonumber(names[mid]) or 0, 256)
        if nm == nil then return 0 end
        if nm == target_name then
            local ord = ords[mid]
            if ord >= n_funcs then return 0 end
            local fn_rva = funcs[ord]
            if fn_rva == 0 or fn_rva >= img_sz or (fn_rva >= exp_rva and fn_rva < exp_rva + exp_sz) then
                return 0
            end
            return mod_base + tonumber(fn_rva)
        elseif nm < target_name then
            lo = mid + 1
        else
            hi = mid - 1
        end
    end
    return 0
end
'''

BRIDGE_CLIENT = r'''
-- =====================================================================
-- VL3DBridge（.aux2 / obj.module）优先通道
-- 编辑相机、图层模型路径、摄像机光源全部改为只读官方 SDK + 版本白名单探针。
-- 插件缺失或宿主 ABI 未验证时，自动回退到下方已加固的 Lua 只读路径，绝不写宿主内存。
-- =====================================================================
local function vl3d_bridge()
    if type(_G.VL3D_TEST_BRIDGE) == "table" then
        return _G.VL3D_TEST_BRIDGE
    end
    if _VL_PERSIST.bridge_mod ~= nil then
        return (_VL_PERSIST.bridge_mod ~= false) and _VL_PERSIST.bridge_mod or nil
    end
    local br = nil
    pcall(function()
        if type(obj.module) ~= "function" then return end
        local m = obj.module("VL3DBridge")
        if type(m) == "table" and type(m.resolve_layer) == "function" then
            br = m
        end
    end)
    _VL_PERSIST.bridge_mod = br or false
    return br
end

'''


def replace_once(src: str, old: str, new: str, label: str) -> str:
    n = src.count(old)
    if n != 1:
        raise SystemExit(f"{label}: expected 1 occurrence, found {n}")
    return src.replace(old, new, 1)


def replace_function(src: str, name: str, new_fn: str) -> str:
    marker = f"local function {name}("
    start = src.find(marker)
    if start < 0:
        raise SystemExit(f"function not found: {name}")
    # next top-level local function or section banner after this one
    rest = src[start + len(marker):]
    # match function/end from the function keyword
    kw = src.find("function", start)
    end = matching_end(src, kw)
    # include trailing newline
    end_nl = src.find("\n", end)
    if end_nl < 0:
        end_nl = len(src)
    else:
        end_nl += 1
    return src[:start] + new_fn.rstrip() + "\n" + src[end_nl:]


def tokenize(src: str):
    i, n = 0, len(src)
    toks = []
    while i < n:
        c = src[i]
        if c in " \t\r":
            i += 1
            continue
        if c == "\n":
            toks.append(("nl", i, i + 1, "\n"))
            i += 1
            continue
        if c == "-" and i + 1 < n and src[i + 1] == "-":
            if src.startswith("--[[", i):
                j = src.find("]]", i + 4)
                i = n if j < 0 else j + 2
                continue
            while i < n and src[i] != "\n":
                i += 1
            continue
        if c in "\"'":
            q = c
            j = i + 1
            while j < n and src[j] != "\n":
                if src[j] == "\\":
                    j += 2
                    continue
                if src[j] == q:
                    j += 1
                    break
                j += 1
            toks.append(("str", i, j, src[i:j]))
            i = j
            continue
        if c == "[" and i + 1 < n and src[i + 1] == "[":
            j = src.find("]]", i + 2)
            i = n if j < 0 else j + 2
            toks.append(("str", i, i, ""))
            continue
        if c.isalpha() or c == "_":
            j = i + 1
            while j < n and (src[j].isalnum() or src[j] == "_"):
                j += 1
            toks.append(("id", i, j, src[i:j]))
            i = j
            continue
        if c.isdigit() or (c == "." and i + 1 < n and src[i + 1].isdigit()):
            j = i + 1
            while j < n and (src[j].isdigit() or src[j] == "."):
                j += 1
            toks.append(("num", i, j, src[i:j]))
            i = j
            continue
        toks.append(("sym", i, i + 1, c))
        i += 1
    return toks


def matching_end(src: str, func_kw: int) -> int:
    """Return index just after the `end` that closes the function keyword at func_kw."""
    toks = tokenize(src[func_kw:])
    stack = ["func"]
    i = 1  # skip the function keyword itself
    while i < len(toks):
        kind, a, b, val = toks[i]
        if kind == "id" and val == "function":
            stack.append("func")
        elif kind == "id" and val == "if":
            stack.append("if")
        elif kind == "id" and val == "do":
            stack.append("do")
        elif kind == "id" and val == "repeat":
            stack.append("repeat")
        elif kind == "id" and val == "until":
            if not stack or stack[-1] != "repeat":
                raise SystemExit("until mismatch")
            stack.pop()
        elif kind == "id" and val == "end":
            if not stack:
                raise SystemExit("end mismatch")
            stack.pop()
            if not stack:
                return func_kw + b
        i += 1
    raise SystemExit("unclosed function")


def wrap_handle_closes(src: str) -> str:
    lines = src.split("\n")
    out = []
    i = 0
    while i < len(lines):
        line = lines[i]
        if line.strip() == "if h ~= 0 and h ~= -1 then":
            indent = line[: len(line) - len(line.lstrip())]
            out.append(line)
            # collect until the CloseHandle at this block
            i += 1
            body = []
            while i < len(lines):
                if "api.CloseHandle(h)" in lines[i] and lines[i].startswith(indent + "    "):
                    inner = indent + "    "
                    out.append(inner + "pcall(function()")
                    for bl in body:
                        out.append("    " + bl)
                    out.append(inner + "end)")
                    out.append(inner + "pcall(api.CloseHandle, h)")
                    i += 1
                    break
                body.append(lines[i])
                i += 1
            else:
                raise SystemExit("CloseHandle block not closed")
            continue
        out.append(line)
        i += 1
    text = "\n".join(out)
    if text.count("pcall(api.CloseHandle, h)") < 2:
        raise SystemExit("expected to wrap both CreateFileW sites")
    return text


def collect_top_locals(body_lines):
    names = []
    for ln in body_lines:
        if not re.match(r"    local\s+", ln):
            continue
        lhs = ln.split("=", 1)[0]
        if "function" in lhs:
            continue
        lhs = re.sub(r"^\s*local\s+", "", lhs)
        for raw in lhs.split(","):
            n = raw.strip()
            if n and n != "_":
                names.append(n)
    if len(names) != len(set(names)):
        raise SystemExit("duplicate top-level beam_frame locals")
    return names


def rewrite_decl_line(line: str, names: set[str]) -> str:
    indent = line[: len(line) - len(line.lstrip())]
    rest = line.lstrip()[len("local "):]
    if "=" in rest:
        lhs, rhs = rest.split("=", 1)
        rhs = "=" + rhs
    else:
        lhs = rest
        nslots = len([p for p in lhs.split(",") if p.strip()])
        rhs = " = " + ", ".join(["nil"] * nslots)
        if line.endswith("\r"):
            rhs += "\r"
    parts = []
    for raw in lhs.split(","):
        n = raw.strip()
        if not n:
            continue
        if n == "_":
            parts.append("VL_BF._discard")
        elif n in names:
            parts.append("VL_BF." + n)
        else:
            raise SystemExit(f"unexpected decl name {n!r} in {line!r}")
    return indent + ", ".join(parts) + rhs


def rename_idents(text: str, names: set[str]) -> str:
    toks = tokenize(text)
    repls = []
    prev_val = None
    for kind, a, b, val in toks:
        if kind == "id" and val in names and prev_val not in (".", ":"):
            repls.append((a, b, "VL_BF." + val))
        if kind != "nl":
            prev_val = val
    for a, b, rep in reversed(repls):
        text = text[:a] + rep + text[b:]
    return text


def convert_phase_returns(body: str) -> str:
    toks = tokenize(body)
    stack = []
    repls = []
    for kind, a, b, val in toks:
        if kind == "id" and val == "function":
            stack.append("func")
        elif kind == "id" and val == "if":
            stack.append("if")
        elif kind == "id" and val == "do":
            stack.append("do")
        elif kind == "id" and val == "repeat":
            stack.append("repeat")
        elif kind == "id" and val == "until":
            if stack and stack[-1] == "repeat":
                stack.pop()
        elif kind == "id" and val == "end":
            if stack:
                stack.pop()
        elif kind == "id" and val == "return" and "func" not in stack:
            repls.append((a, b))
    for a, b in reversed(repls):
        body = body[:a] + "do VL_BF._abort = true; return end" + body[b:]
    return body


PHASES = [
    ("vl_bf_prepare", None, "-- 1) 光源レイヤー"),
    ("vl_bf_capture", "-- 1) 光源レイヤー", "-- 2) 光線ジオメトリ"),
    ("vl_bf_geometry", "-- 2) 光線ジオメトリ", "-- 3) \"object\" から直接"),
    ("vl_bf_mip", "-- 3) \"object\" から直接", "-- 4) 複数前景オブジェクト"),
    ("vl_bf_occlusion", "-- 4) 複数前景オブジェクト", "-- 5) GPU マルチパス"),
    ("vl_bf_render", "-- 5) GPU マルチパス", None),
]


def split_phases(body: str) -> str:
    positions = []
    for _name, start_m, _end_m in PHASES:
        if start_m is None:
            positions.append(0)
        else:
            p = body.find(start_m)
            if p < 0:
                raise SystemExit(f"phase marker missing: {start_m}")
            # rewind to line start
            positions.append(body.rfind("\n", 0, p) + 1)
    positions.append(len(body))
    chunks = []
    calls = []
    for i, (name, _s, _e) in enumerate(PHASES):
        chunk = body[positions[i]:positions[i + 1]]
        if not chunk.strip():
            raise SystemExit(f"empty phase {name}")
        chunk = convert_phase_returns(chunk)
        if not chunk.endswith("\n"):
            chunk += "\n"
        chunks.append(f"local function {name}()\n{chunk}end\n")
        calls.append(f"    {name}()\n    if VL_BF._abort then return end\n")
    orchestrator = (
        "local function beam_frame()\n"
        "    vl_bf_reset()\n"
        + "".join(calls)
        + "end\n"
    )
    return "\n".join(chunks) + "\n" + orchestrator


def transform_beam_frame(src: str) -> str:
    sig = "local function beam_frame()"
    start = src.find(sig)
    if start < 0:
        raise SystemExit("beam_frame missing")
    kw = src.find("function", start)
    end_pos = matching_end(src, kw)
    # function text includes 'local function ... end'
    func_text = src[start:end_pos]
    nl = src.find("\n", start)
    body = src[nl + 1:end_pos - len("end")]
    # drop a trailing newline belonging to the line before end? end_pos is just after 'end'.
    # body currently includes the newline before `end` and the spaces before end? 
    # src[nl+1 : end_pos-3] should be the body without the final `end`.
    end_kw = func_text.rfind("end")
    body = func_text[len(sig) + 1:end_kw]
    if body.startswith("\n"):
        body = body[1:]
    lines = body.split("\n")
    # the last line may be the indent before `end` which we excluded. Good.
    names = collect_top_locals(lines)
    name_set = set(names)
    new_lines = []
    for ln in lines:
        if re.match(r"    local\s+", ln) and "function" not in ln.split("=", 1)[0]:
            new_lines.append(rewrite_decl_line(ln, name_set))
        else:
            new_lines.append(ln)
    rewritten = "\n".join(new_lines)
    rewritten = rename_idents(rewritten, name_set)
    # safety: a promoted name must not remain as a bare local at 4-space indent
    for n in names:
        if re.search(r"(?m)^    local\s+" + re.escape(n) + r"\b", rewritten):
            raise SystemExit(f"decl rewrite missed {n}")
    keys = ", ".join(f'"{n}"' for n in names)
    header = (
        "local VL_BF = {}\n"
        f"local VL_BF_KEYS = {{ {keys} }}\n"
        "local function vl_bf_reset()\n"
        "    for vl_i = 1, #VL_BF_KEYS do\n"
        "        VL_BF[VL_BF_KEYS[vl_i]] = nil\n"
        "    end\n"
        "    VL_BF._abort = false\n"
        "    VL_BF._discard = nil\n"
        "end\n\n"
    )
    phases = split_phases(rewritten if rewritten.endswith("\n") else rewritten + "\n")
    replacement = header + phases
    # replace from start through the original end keyword
    return src[:start] + replacement + src[end_pos:]


def apply_patches(src: str) -> str:
    src = src.replace("\r\n", "\n")
    src = replace_function(src, "pe_find_export_addr", PE_FN)
    src = replace_function(src, "scan_live_modelfile_instances", SCAN_FN)

    src = replace_once(
        src,
        '            local nsec   = ffi.cast("const uint16_t*", nt + 6)[0]\n'
        '            local opt_sz = ffi.cast("const uint16_t*", nt + 20)[0]\n'
        '            local sec_p  = nt + 24 + opt_sz\n',
        '            local nsec   = ffi.cast("const uint16_t*", nt + 6)[0]\n'
        '            local opt_sz = tonumber(ffi.cast("const uint16_t*", nt + 20)[0]) or 0\n'
        '            local hdr_lim = math.min(4096, tonumber(st.nrd[0]) or 0)\n'
        '            local sec_ok = (opt_sz <= 1024 and (lfanew + 24 + opt_sz + math.min(tonumber(nsec) or 0, 16) * 40) <= hdr_lim)\n'
        '            local sec_p  = sec_ok and (nt + 24 + opt_sz) or nt\n',
        "resolve opt_sz",
    )
    src = replace_once(
        src,
        "            for si = 0, math.min(tonumber(nsec) - 1, 15) do\n",
        "            for si = 0, (sec_ok and math.min(tonumber(nsec) - 1, 15) or -1) do\n",
        "resolve for bound",
    )
    src = replace_once(
        src,
        '                        local nsec   = ffi.cast("const uint16_t*", b + pe_off + 6)[0]\n'
        '                        local opt_sz = ffi.cast("const uint16_t*", b + pe_off + 20)[0]\n'
        '                        local sec_p  = b + pe_off + 24 + opt_sz\n'
        '                        for si = 0, math.min(nsec, 12) - 1 do\n',
        '                        local nsec   = ffi.cast("const uint16_t*", b + pe_off + 6)[0]\n'
        '                        local opt_sz = tonumber(ffi.cast("const uint16_t*", b + pe_off + 20)[0]) or 0\n'
        '                        local sec_ok = (opt_sz >= 0x60 and opt_sz <= 1024 and (pe_off + 24 + opt_sz + math.min(tonumber(nsec) or 0, 12) * 40) <= 4096)\n'
        '                        local sec_p  = sec_ok and (b + pe_off + 24 + opt_sz) or b\n'
        '                        for si = 0, (sec_ok and math.min(nsec, 12) or 0) - 1 do\n',
        "editcam opt_sz",
    )
    src = replace_once(
        src,
        "                                local stride = p_bv.byteStride or 12\n"
        "                                local p_base = (p_bv.byteOffset or 0) + (p_acc.byteOffset or 0)\n"
        "                                if p_base >= 0 and p_base + (vcnt - 1) * stride + 12 <= bin_len then\n",
        "                                local stride = p_bv.byteStride or 12\n"
        "                                local p_base = (p_bv.byteOffset or 0) + (p_acc.byteOffset or 0)\n"
        "                                if type(vcnt) == \"number\" and vcnt >= 3 and vcnt <= 5000000\n"
        "                                    and type(stride) == \"number\" and stride >= 12 and stride <= 4096 and (stride % 4) == 0\n"
        "                                    and type(p_base) == \"number\" and p_base >= 0 and p_base + (vcnt - 1) * stride + 12 <= bin_len then\n",
        "glb stride",
    )
    src = replace_once(
        src,
        "            if nv >= 3 and nt >= 1 then\n"
        "                raw_mesh = { vx = vx, vy = vy, vz = vz, nv = nv, i0 = i0, i1 = i1, i2 = i2, nt = nt }\n"
        "            end\n",
        "            if nv >= 3 and nt >= 1 then\n"
        "                local fvx = ffi.new(\"float[?]\", nv + 1)\n"
        "                local fvy = ffi.new(\"float[?]\", nv + 1)\n"
        "                local fvz = ffi.new(\"float[?]\", nv + 1)\n"
        "                local fi0 = ffi.new(\"int32_t[?]\", nt + 1)\n"
        "                local fi1 = ffi.new(\"int32_t[?]\", nt + 1)\n"
        "                local fi2 = ffi.new(\"int32_t[?]\", nt + 1)\n"
        "                for k = 1, nv do fvx[k], fvy[k], fvz[k] = vx[k], vy[k], vz[k] end\n"
        "                for k = 1, nt do fi0[k], fi1[k], fi2[k] = i0[k], i1[k], i2[k] end\n"
        "                raw_mesh = { indexed = true, vx = fvx, vy = fvy, vz = fvz, nv = nv, i0 = fi0, i1 = fi1, i2 = fi2, nt = nt }\n"
        "            end\n",
        "glb ffi cache",
    )
    src = replace_once(
        src,
        "    local mx, my, mz = scale_mul * sx_f, scale_mul * sy_f, scale_mul * sz_f\n"
        "    local svx, svy, svz = {}, {}, {}\n"
        "    local rvx, rvy, rvz = raw_mesh.vx, raw_mesh.vy, raw_mesh.vz\n"
        "    local nv = raw_mesh.nv\n"
        "    for k = 1, nv do\n"
        "        svx[k] = rvx[k] * mx\n"
        "        svy[k] = rvy[k] * my\n"
        "        svz[k] = rvz[k] * mz\n"
        "    end\n"
        "    return {\n"
        "        indexed = true,\n"
        "        vx = svx, vy = svy, vz = svz, nv = nv,\n"
        "        i0 = raw_mesh.i0, i1 = raw_mesh.i1, i2 = raw_mesh.i2, nt = raw_mesh.nt,\n"
        "    }\n",
        "    local mx, my, mz = scale_mul * sx_f, scale_mul * sy_f, scale_mul * sz_f\n"
        "    local scale_key = base_key .. \"|s=\" .. tostring(mx) .. \",\" .. tostring(my) .. \",\" .. tostring(mz)\n"
        "    local scaled = GLB_MESH_CACHE[scale_key]\n"
        "    if scaled == nil then\n"
        "        local ok_sc, ffi_sc = pcall(require, \"ffi\")\n"
        "        if not ok_sc or ffi_sc == nil then return nil end\n"
        "        local nv = raw_mesh.nv\n"
        "        local svx = ffi_sc.new(\"float[?]\", nv + 1)\n"
        "        local svy = ffi_sc.new(\"float[?]\", nv + 1)\n"
        "        local svz = ffi_sc.new(\"float[?]\", nv + 1)\n"
        "        local rvx, rvy, rvz = raw_mesh.vx, raw_mesh.vy, raw_mesh.vz\n"
        "        for k = 1, nv do\n"
        "            svx[k] = rvx[k] * mx\n"
        "            svy[k] = rvy[k] * my\n"
        "            svz[k] = rvz[k] * mz\n"
        "        end\n"
        "        scaled = {\n"
        "            indexed = true,\n"
        "            vx = svx, vy = svy, vz = svz, nv = nv,\n"
        "            i0 = raw_mesh.i0, i1 = raw_mesh.i1, i2 = raw_mesh.i2, nt = raw_mesh.nt,\n"
        "        }\n"
        "        GLB_MESH_CACHE[scale_key] = scaled\n"
        "    end\n"
        "    return scaled\n",
        "glb scaled view",
    )
    src = src.replace(
        "            local h_entry = VRM_POSE_CACHE[oln]\n",
        "            local cache_slot = tostring(_aup2_cache.active_scene_id or 0) .. \":\" .. tostring(oln)\n"
        "            local h_entry = VRM_POSE_CACHE[cache_slot]\n",
        1,
    )
    src = src.replace(
        "                VRM_POSE_CACHE[oln] = h_entry\n",
        "                VRM_POSE_CACHE[cache_slot] = h_entry\n",
        1,
    )
    if "VRM_POSE_CACHE[oln]" in src:
        raise SystemExit("VRM cache key not fully rewritten")

    src = replace_once(
        src,
        '            local ptr = obj.getpixeldata("cache:vl3d/pool")\n'
        "            if ptr ~= nil then\n",
        '            local ptr, pw, ph = obj.getpixeldata("cache:vl3d/pool", "rgba")\n'
        "            if ptr ~= nil and pw == gw and ph == gh then\n",
        "pool size check",
    )
    src = replace_once(
        src,
        '                            local p_obj = obj.getpixeldata("object", "rgba")\n'
        "                            if p_obj ~= nil then\n",
        '                            local p_obj, ow_c, oh_c = obj.getpixeldata("object", "rgba")\n'
        "                            if p_obj ~= nil and ow_c == fb_w and oh_c == fb_h then\n",
        "fb grab size check",
    )
    src = replace_once(
        src,
        "        if suppress_deferred and out.count > 0 then\n"
        "            ffi.cast(\"uint64_t*\", gbuf_addr + 0xA0)[0] = ffi.cast(\"uint64_t\", lb_addr)\n"
        "            out.suppressed = true\n"
        "        end\n",
        "        -- [M-01] 严禁覆写宿主 GBuffer _Mylast。模式 2 改为只读峰值增益补偿，VRM/OBJ 照明保持原样。\n"
        "        out.suppressed = false\n"
        "        out.suppress_requested = suppress_deferred and true or false\n",
        "remove gbuf write",
    )
    src = replace_once(
        src,
        "        if suppress_deferred then tl.suppressed = true end\n",
        "        if suppress_deferred then\n"
        "            tl.suppress_requested = true\n"
        "            tl.suppressed = false\n"
        "        end\n",
        "test hook no suppress",
    )
    src = wrap_handle_closes(src)
    src = src.replace(
        '    "cache:vl3d/camocc",\n}',
        '    "cache:vl3d/camocc",\n    "cache:vl3d/fb_bak",\n}',
        1,
    )

    # Bridge client + call sites
    anchor = "-- =====================================================================\n-- 決定的 O(1) ライブ・シーングラフ直読エンジン"
    if anchor not in src:
        raise SystemExit("scene-graph banner missing")
    src = src.replace(anchor, BRIDGE_CLIENT + anchor, 1)
    src = replace_once(
        src,
        "local function resolve_live_scene_layer_object(oln, cur_frame)\n"
        "    local api = get_w32_api()\n",
        "local function resolve_live_scene_layer_object(oln, cur_frame)\n"
        "    local br = vl3d_bridge()\n"
        "    if br ~= nil and type(br.resolve_layer) == \"function\" then\n"
        "        local ok_b, st, fx, path, adj, scene_id, wcol, tier = pcall(br.resolve_layer, oln, cur_frame or 0)\n"
        "        if ok_b and type(st) == \"string\" and st ~= \"\" and st ~= \"UNAVAILABLE\" then\n"
        "            if type(scene_id) == \"number\" then _aup2_cache.active_scene_id = scene_id end\n"
        "            return {\n"
        "                status = st,\n"
        "                fx_name = type(fx) == \"string\" and fx or \"\",\n"
        "                path = type(path) == \"string\" and path or \"\",\n"
        "                adj = tonumber(adj) or 0,\n"
        "                scene_id = tonumber(scene_id) or 0,\n"
        "                water_color = tonumber(wcol) or -1,\n"
        "                source_tier = type(tier) == \"string\" and tier or \"BRIDGE\",\n"
        "            }\n"
        "        end\n"
        "    end\n"
        "    local api = get_w32_api()\n",
        "bridge resolve",
    )
    src = replace_once(
        src,
        "        return tl\n"
        "    end\n"
        "    local out = { count = 0, unlit = 1.0, amb_r = 0.0, amb_g = 0.0, amb_b = 0.0, primary = nil, peak_gain = 1.0, suppressed = false }\n",
        "        return tl\n"
        "    end\n"
        "    local br_l = vl3d_bridge()\n"
        "    if br_l ~= nil and type(br_l.get_camera_lights) == \"function\" then\n"
        "        local ok_l, count, unlit, ar, ag, ab, peak, has_pri, ltype, dx, dy, dz, lr, lg, lb, lum, px, py, pz, cos_ang =\n"
        "            pcall(br_l.get_camera_lights)\n"
        "        if ok_l and type(count) == \"number\" then\n"
        "            local out_b = {\n"
        "                count = count,\n"
        "                unlit = tonumber(unlit) or 1.0,\n"
        "                amb_r = tonumber(ar) or 0.0,\n"
        "                amb_g = tonumber(ag) or 0.0,\n"
        "                amb_b = tonumber(ab) or 0.0,\n"
        "                peak_gain = tonumber(peak) or 1.0,\n"
        "                suppressed = false,\n"
        "                suppress_requested = suppress_deferred and true or false,\n"
        "                primary = nil,\n"
        "                source_tier = \"BRIDGE\",\n"
        "            }\n"
        "            if has_pri == true then\n"
        "                out_b.primary = {\n"
        "                    ltype = tonumber(ltype) or 0,\n"
        "                    dx = tonumber(dx) or 0.0, dy = tonumber(dy) or 0.0, dz = tonumber(dz) or 1.0,\n"
        "                    r = tonumber(lr) or 0.0, g = tonumber(lg) or 0.0, b = tonumber(lb) or 0.0,\n"
        "                    lum = tonumber(lum) or 0.0,\n"
        "                    px = tonumber(px) or 0.0, py = tonumber(py) or 0.0, pz = tonumber(pz) or 0.0,\n"
        "                    cos_ang = tonumber(cos_ang) or 0.0,\n"
        "                }\n"
        "            end\n"
        "            return out_b\n"
        "        end\n"
        "    end\n"
        "    local out = { count = 0, unlit = 1.0, amb_r = 0.0, amb_g = 0.0, amb_b = 0.0, primary = nil, peak_gain = 1.0, suppressed = false }\n",
        "bridge lights",
    )
    # The lights function's early Windows check may not match if the return table differs.
    # Fall back: insert after the test-hook end by a smaller unique string if the above failed.
    src = replace_once(
        src,
        "    if type(_G.VL3D_TEST_EDIT_CAM) == \"table\" then\n"
        "        return _G.VL3D_TEST_EDIT_CAM\n"
        "    end\n",
        "    if type(_G.VL3D_TEST_EDIT_CAM) == \"table\" then\n"
        "        return _G.VL3D_TEST_EDIT_CAM\n"
        "    end\n"
        "    local br_c = vl3d_bridge()\n"
        "    if br_c ~= nil and type(br_c.get_edit_camera) == \"function\" then\n"
        "        local ok_c, okcam, x, y, z, tx, ty, tz, ux, uy, uz, rz, d = pcall(br_c.get_edit_camera)\n"
        "        if ok_c and okcam == true then\n"
        "            return { x = x, y = y, z = z, tx = tx, ty = ty, tz = tz, ux = ux, uy = uy, uz = uz, rz = rz, d = d }\n"
        "        end\n"
        "        if type(br_c.get_scene_camera) == \"function\" then\n"
        "            local ok2, okc2, x2, y2, z2, tx2, ty2, tz2, ux2, uy2, uz2, rz2, d2 =\n"
        "                pcall(br_c.get_scene_camera, 64, type(obj.frame) == \"number\" and obj.frame or 0)\n"
        "            if ok2 and okc2 == true then\n"
        "                return { x = x2, y = y2, z = z2, tx = tx2, ty = ty2, tz = tz2, ux = ux2, uy = uy2, uz = uz2, rz = rz2, d = d2 }\n"
        "            end\n"
        "        end\n"
        "    end\n",
        "bridge edit cam",
    )
    src = replace_once(
        src,
        "            local w_col  = tonumber((get_fx_val(ln, wfx_l, WATER_COL_ITEMS, false))) or tonumber(P.light_color) or 0x66c8ff\n",
        "            local w_col = tonumber((get_fx_val(ln, wfx_l, WATER_COL_ITEMS, false))) or tonumber(P.light_color)\n"
        "            if w_col == nil then\n"
        "                local br_w = vl3d_bridge()\n"
        "                if br_w ~= nil and type(br_w.get_water_color) == \"function\" then\n"
        "                    local ok_wc, wc = pcall(br_w.get_water_color, ln, type(obj.frame) == \"number\" and obj.frame or 0)\n"
        "                    if ok_wc and type(wc) == \"number\" and wc >= 0 then w_col = wc end\n"
        "                end\n"
        "            end\n"
        "            if w_col == nil then w_col = 0x66c8ff end\n",
        "bridge water color",
    )
    src = replace_once(
        src,
        "    local cam_comp    = 1.0\n"
        "    if (P.cam_light_mode == 0 or P.cam_light_mode == 1)\n"
        "        and (not cam_light_info.suppressed)\n"
        "        and cam_light_info.count > 0\n"
        "        and cam_light_info.peak_gain > 1.05 then\n"
        "        cam_comp = 1.0 / math.min(cam_light_info.peak_gain, 4.0)\n"
        "    end\n",
        "    local cam_comp = 1.0\n"
        "    local cam_mode2_note = \"\"\n"
        "    if cam_light_info.count > 0 and (cam_light_info.peak_gain or 0) > 1.05 then\n"
        "        local allow_comp = false\n"
        "        if P.cam_light_mode == 2 then\n"
        "            -- 不写宿主。按只读峰值衰减光束，避免与摄像机照明叠加过曝，同时保留同场模型灯光。\n"
        "            allow_comp = true\n"
        "            cam_mode2_note = \" mode2=peak-comp\"\n"
        "        elseif (P.cam_light_mode == 0 or P.cam_light_mode == 1) and not cam_light_info.suppressed then\n"
        "            allow_comp = true\n"
        "        end\n"
        "        if allow_comp then\n"
        "            cam_comp = 1.0 / math.min(cam_light_info.peak_gain, 4.0)\n"
        "        end\n"
        "    end\n",
        "mode2 comp",
    )
    src = replace_once(
        src,
        "                tostring(ps_ok), src_desc, occ_desc, aw or 0, ah or 0, n_chunks, total_sl, dz, total_v, base_ratio, peak_m\n"
        "            ))\n",
        "                tostring(ps_ok), src_desc, occ_desc, aw or 0, ah or 0, n_chunks, total_sl, dz, total_v, base_ratio, peak_m\n"
        "            ) .. (cam_mode2_note or \"\"))\n",
        "log note",
    )
    src = replace_once(
        src,
        "            local fb_save, fb_w, fb_h = nil, 0, 0\n"
        "            if ok_ffi_fb and ffi_fb ~= nil and type(obj.getpixeldata) == \"function\" then\n",
        "            local fb_save, fb_w, fb_h = nil, 0, 0\n"
        "            local fb_gpu = false\n"
        "            pcall(function()\n"
        "                if type(obj.copybuffer) ~= \"function\" then return end\n"
        "                local sw = (type(obj.screen_w) == \"number\" and obj.screen_w > 1) and math.floor(obj.screen_w) or 1920\n"
        "                local sh = (type(obj.screen_h) == \"number\" and obj.screen_h > 1) and math.floor(obj.screen_h) or 1080\n"
        "                obj.clearbuffer(\"cache:vl3d/fb_bak\", sw, sh)\n"
        "                if obj.copybuffer(\"cache:vl3d/fb_bak\", \"framebuffer\") == false then return end\n"
        "                if obj.clearbuffer(\"framebuffer\", sw, sh) == false then\n"
        "                    obj.copybuffer(\"framebuffer\", \"cache:vl3d/fb_bak\")\n"
        "                    return\n"
        "                end\n"
        "                fb_gpu = true\n"
        "                fb_w, fb_h = sw, sh\n"
        "            end)\n"
        "            if (not fb_gpu) and ok_ffi_fb and ffi_fb ~= nil and type(obj.getpixeldata) == \"function\" then\n",
        "copybuffer backup",
    )
    src = replace_once(
        src,
        "            local function restore_fb_now()\n"
        "                if fb_save ~= nil and fb_w > 0 and fb_h > 0 and type(obj.putpixeldata) == \"function\" then\n",
        "            local function restore_fb_now()\n"
        "                if fb_gpu then\n"
        "                    pcall(function() obj.copybuffer(\"framebuffer\", \"cache:vl3d/fb_bak\") end)\n"
        "                    return\n"
        "                end\n"
        "                if fb_save ~= nil and fb_w > 0 and fb_h > 0 and type(obj.putpixeldata) == \"function\" then\n",
        "copybuffer restore",
    )

    # version strings outside comments
    lines = []
    for line in src.split("\n"):
        if line.startswith("--information:"):
            line = "--information:体積光（3D）v2.90-bridge"
        elif not line.lstrip().startswith("--") and "v2.86" in line:
            line = line.replace("v2.86", "v2.90")
        lines.append(line)
    src = "\n".join(lines)
    banner = (
        "-- v2.90-bridge 分支（不并入 v2.86 主线）：\n"
        "--   · 独立 VL3DBridge.aux2 只读桥接（PE TimeDateStamp/SHA-256 白名单，不匹配即降级）\n"
        "--   · 删除 gbuf+0xA0 宿主写；模式 2 改为峰值增益补偿\n"
        "--   · Lua 回退路径合入 M-02..M-12；帧缓冲优先 obj.copybuffer\n"
        "--   · P0-8：beam_frame() 拆为 6 个阶段函数，活跃 local 远低于 60\n"
        "--\n"
    )
    src = src.replace(
        "--information:体積光（3D）v2.90-bridge\n",
        "--information:体積光（3D）v2.90-bridge\n" + banner,
        1,
    )
    if "gbuf_addr + 0xA0)[0] =" in src:
        raise SystemExit("host write still present")
    return src


def main() -> None:
    raw = SRC.read_text(encoding="utf-8")
    src = apply_patches(raw)
    src = transform_beam_frame(src)
    sys.path.insert(0, str(ROOT / "sandbox"))
    from apply_vl_drag_fix import apply as apply_drag_fix
    src = apply_drag_fix(src)
    if "v2.91" not in src or "-- [P0-drag]" not in src:
        raise SystemExit("drag fix was not applied")
    if "local function beam_frame()" not in src:
        raise SystemExit("orchestrator missing")
    for phase in ("vl_bf_prepare", "vl_bf_capture", "vl_bf_geometry", "vl_bf_mip", "vl_bf_occlusion", "vl_bf_render", "vl_bf_reset"):
        if f"local function {phase}(" not in src:
            raise SystemExit(f"missing {phase}")
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    OUT.write_bytes(src.replace("\n", "\r\n").encode("utf-8"))
    r = subprocess.run(["luajit", "-bl", str(OUT)], capture_output=True, text=True)
    if r.returncode != 0:
        err = (r.stderr or r.stdout).strip().splitlines()
        raise SystemExit("luajit failed:\n" + "\n".join(err[-30:]))
    print(f"wrote {OUT} bytes={OUT.stat().st_size}")
    # report beam_frame bytecode span
    for line in r.stdout.splitlines():
        if "beam_frame" in line or "vl_bf_" in line:
            print(line)


if __name__ == "__main__":
    main()
