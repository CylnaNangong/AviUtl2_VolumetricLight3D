#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Behavioral checks for the v2.91 drag/scale occlusion budget.

Runs the real branch script under LuaJIT with a stub host. Does not modify
v2.86, and does not write the branch script.
"""
from __future__ import annotations

import json
import subprocess
import textwrap
from pathlib import Path

ROOT = Path("/home/user")
BRANCH = ROOT / "scripts/pkg1/体积光（3D）/development/branch_v2.90_aux2_bridge/Script/体積光（3D）.obj2"
STABLE = ROOT / "scripts/pkg1/体积光（3D）/stable/Script/体積光（3D）.obj2"
OUT = ROOT / "sandbox/results/drag_fix_report.json"

DRIVER = r'''
local ffi = require("ffi")
local loads = 0
local prints = {}
local released = 0
local buffers = {}
local function buf_for(w, h)
    w = math.max(1, math.floor(w or 1))
    h = math.max(1, math.floor(h or 1))
    local n = w * h * 4
    local key = w .. "x" .. h
    local b = buffers[key]
    if b == nil then
        b = ffi.new("uint8_t[?]", n)
        buffers[key] = b
    end
    return b, w, h
end
local last_wh = {64, 64}

obj.load = function()
    loads = loads + 1
    if _G._REENTER_ON_LOAD then
        vl_run_frame()
    end
end
obj.getpixel = function() return 32, 32 end
obj.pixelshader = function() return true end
obj.clearbuffer = function(name, w, h)
    last_wh[1], last_wh[2] = w or 4, h or 4
    return true
end
obj.getpixeldata = function(name, fmt)
    local w, h = last_wh[1], last_wh[2]
    if type(w) ~= "number" or w < 1 or w > 2048 then w = 64 end
    if type(h) ~= "number" or h < 1 or h > 2048 then h = 64 end
    local b = buf_for(w, h)
    return b, w, h
end
obj.putpixeldata = function() return true end
obj.drawpoly = function() end
obj.draw = function() end
obj.setoption = function() end
obj.copybuffer = function() return true end
obj.getinfo = function() return nil end
obj.getvalue = function(k)
    if k == "layer3" then return true end
    return nil
end
obj.frame = 12
obj.time = 0.4
obj.layer = 6
obj.screen_w = 640
obj.screen_h = 360

local function check(name, ok, detail)
    print(string.format("%s %s %s", ok and "PASS" or "FAIL", name, detail or ""))
end

-- --- drag policy -----------------------------------------------------------
_VL_PERSIST.interact = nil
local q = occ_drag_query
local d1 = q("sigA", 12, 1.0)
local d2 = q("sigB", 12, 1.05)          -- same frame, transform changed
local d3 = q("sigB", 12, 1.10)          -- mouse-up / identical sample
local d4 = q("sigB", 13, 1.20)          -- playback / scrub
local d5 = q("sigC", 13, 9.00)          -- same frame again, even if slow
check("first_sample_full", d1 == false, tostring(d1))
check("same_frame_change_is_drag", d2 == true, tostring(d2))
check("unchanged_xform_settles", d3 == false, tostring(d3))
check("frame_advance_not_drag", d4 == false, tostring(d4))
check("slow_same_frame_still_drag", d5 == true, tostring(d5))

local res, cap, splat, budget = preview_shadow_budget(38012)
check("preview_res_heavy", res == 256, tostring(res))
check("preview_tri_heavy", cap == 4000, tostring(cap))
check("preview_splat", splat == 48, tostring(splat))
check("preview_budget", math.abs(budget - 0.012) < 1e-9, tostring(budget))
local res2 = preview_shadow_budget(1000)
check("preview_res_light", res2 == 320, tostring(res2))

-- --- re-entry must not drop caches ----------------------------------------
local _rel = release_work_caches
release_work_caches = function(...)
    released = released + 1
    return _rel(...)
end
_VL_PERSIST.in_beam = true
_VL_PERSIST.reentered = 0
local nested = vl_run_frame()
check("reenter_returns_false", nested == false, tostring(nested))
check("reenter_counted", (_VL_PERSIST.reentered or 0) >= 1, tostring(_VL_PERSIST.reentered))
check("reenter_no_release", released == 0, tostring(released))
_VL_PERSIST.in_beam = false

-- --- 2D mask reused across a same-frame scale ------------------------------
P.occ_mode = 1
P.occ_3d_mode = 3
P.occ_target = 2
P.occ_list = "3"
P.occ_strength = 80
P.occ_soft = 0
P.res_mode = 1
local scale = 1.0
read_layer_transform = function()
    return 10, 20, 30, 0, 0, 0, scale, scale, 1, 1,
        1, 0, 0, 0, 1, 0, 0, 0, 1
end
resolve_live_scene_layer_object = function()
    return { status = "OK", fx_name = "" }
end
has_3d_or_water_signature = function() return nil end
is_volume_effect_layer = function() return false end
VL_BF.mip_ready = true
VL_BF.mip_dots = 0
VL_BF.peak_cache_dots = 0
VL_BF.ln = 6
VL_BF.self_layer = 6
VL_BF.wx, VL_BF.wy, VL_BF.wz = 0, 0, 0
VL_BF.Wnx, VL_BF.Wny, VL_BF.Wnz = 0, 0, 1
VL_BF.total_sl = 192
VL_BF.s_min = 0
VL_BF.s_max = 1920
VL_BF.is_edit = true
loads = 0
_VL_PERSIST.reentered = 0
local ok1, err1 = pcall(vl_bf_occlusion)
check("occ2d_first_ok", ok1, tostring(err1))
local loads_first = loads
check("occ2d_first_loads", loads_first >= 1, tostring(loads_first))
check("occ2d_saved", _VL_PERSIST.occ2d ~= nil and _VL_PERSIST.occ2d.rgba ~= nil, tostring(_VL_PERSIST.occ2d and _VL_PERSIST.occ2d.key))
scale = 2.4
loads = 0
VL_BF.total_sl = 192
VL_BF.s_min = 0
VL_BF.s_max = 1920
local ok2, err2 = pcall(vl_bf_occlusion)
check("occ2d_drag_ok", ok2, tostring(err2))
check("occ2d_drag_skips_load", loads == 0, "loads=" .. tostring(loads))
check("occ2d_drag_flag", VL_BF.interact_drag == true, tostring(VL_BF.interact_drag))
check("occ2d_uniforms_follow_scale", (VL_BF.occ_flat[1] == 10) and (VL_BF.occ_flat[4] or 1) < 0.02,
    string.format("ox=%s invHx=%s", tostring(VL_BF.occ_flat[1]), tostring(VL_BF.occ_flat[4])))

-- --- slice cap on the same drag call --------------------------------------
P.occ_3d_mode = 0
P.occ_mode = 1
local mesh
do
    local vx = ffi.new("float[4]", 0, 1, 0, 0)
    local vy = ffi.new("float[4]", 0, 0, 1, 0)
    local vz = ffi.new("float[4]", 40, 40, 40, 0)
    mesh = { nt = 1, nv = 3, indexed = false, vx = vx, vy = vy, vz = vz, pose_sig = "t" }
end
try_load_3d_layer_mesh = function()
    return mesh, "OBJ", { status = "OBJ", fx_name = "" }
end
scale = 1.0
_VL_PERSIST.interact = nil
VL_BF.total_sl = 192
VL_BF.s_min = 0.0
VL_BF.s_max = 1920.0
VL_BF.dz = 10.0
VL_BF.is_edit = true
VL_BF.Hx, VL_BF.Hy = 400, 400
VL_BF.Wrx, VL_BF.Wry, VL_BF.Wrz = 1, 0, 0
VL_BF.Wdx, VL_BF.Wdy, VL_BF.Wdz = 0, 1, 0
VL_BF.mode_kind = 0
VL_BF.sx_p, VL_BF.sy_p, VL_BF.sz_p = 0, 0, 1
VL_BF.u_wn, VL_BF.dS_wn, VL_BF.L_tot = 1, 1, 2000
pcall(vl_bf_occlusion) -- establish last_xform, not a drag
scale = 3.0
VL_BF.total_sl = 192
VL_BF.s_min = 0.0
VL_BF.s_max = 1920.0
local ok3, err3 = pcall(vl_bf_occlusion)
check("slice_call_ok", ok3, tostring(err3))
check("slice_capped", VL_BF.total_sl == 64, tostring(VL_BF.total_sl))
check("slice_dz", math.abs((VL_BF.dz or 0) - (1920.0 / 64.0)) < 1e-6, tostring(VL_BF.dz))
check("slice_only_while_drag", VL_BF.interact_drag == true, tostring(VL_BF.interact_drag))

-- settled call restores the caller's slice count (function must not keep the cap)
VL_BF.total_sl = 192
VL_BF.s_min = 0.0
VL_BF.s_max = 1920.0
VL_BF.dz = 10.0
pcall(vl_bf_occlusion)
check("settled_keeps_slices", VL_BF.total_sl == 192, tostring(VL_BF.total_sl))

-- --- shadow preview vs full, 38012 thin wires ------------------------------
do
    local nt = 38012
    local nv = nt * 3
    local vx = ffi.new("float[?]", nv + 1)
    local vy = ffi.new("float[?]", nv + 1)
    local vz = ffi.new("float[?]", nv + 1)
    for ti = 0, nt - 1 do
        local y = -180 + (ti % 400) * 0.9
        local z = 60 + (ti % 7) * 8
        local b = ti * 3 + 1
        vx[b], vy[b], vz[b] = -180, y, z
        vx[b+1], vy[b+1], vz[b+1] = 180, y, z
        vx[b+2], vy[b+2], vz[b+2] = 180, y + 0.04, z
    end
    local cage = {
        nt = nt, nv = nv, indexed = false,
        vx = vx, vy = vy, vz = vz, pose_sig = "cage",
    }
    local md = {
        layer = 3, kind = "OBJ", mesh = cage, alpha = 1,
        ox = 0, oy = 0, oz = 0,
        ozx = 1, ozy = 1, ozz = 1,
        Orx = 1, Ory = 0, Orz = 0,
        Odx = 0, Ody = 1, Odz = 0,
        Onx = 0, Ony = 0, Onz = 1,
    }
    local pres, tcap, scap, bud = preview_shadow_budget(nt)
    local t0 = os.clock()
    local okp, np = build_3d_shadow_map(
        { md }, pres, 0, 0, 0, 400, 400,
        1, 0, 0, 0, 1, 0, 0, 0, 1,
        0, 0, 0, 1, 1, 1, 2000,
        { tri_cap = tcap, splat_cap = scap, budget = bud }
    )
    local tp = os.clock() - t0
    -- force a full rebuild: different resolution, same transform
    local t1 = os.clock()
    local okf, nf = build_3d_shadow_map(
        { md }, 1280, 0, 0, 0, 400, 400,
        1, 0, 0, 0, 1, 0, 0, 0, 1,
        0, 0, 0, 1, 1, 1, 2000,
        nil
    )
    local tf = os.clock() - t1
    local st = _VL_PERSIST.occ_stats or {}
    check("preview_ran", okp == true and (np or 0) > 0, string.format("ok=%s n=%s", tostring(okp), tostring(np)))
    check("preview_under_50ms", tp < 0.050, string.format("%.4f", tp))
    check("full_drew", (nf or 0) > (np or 0), string.format("full=%s preview=%s", tostring(nf), tostring(np)))
    check("full_slower", tf > tp * 3, string.format("full=%.4f preview=%.4f", tf, tp))
    print(string.format("BENCH preview_s=%.6f full_s=%.6f preview_tris=%s full_tris=%s res=%s",
        tp, tf, tostring(np), tostring(nf), tostring(pres)))
end

-- --- log throttle ----------------------------------------------------------
P.log_mode = true
P.show_info = false
P.intensity = 80
P.fog = 0
P.fog_scale = 220
P.wind_dir = 0
P.wind_speed = 0
P.seed = 0
P.res_mode = 1
P.cam_light_mode = 0
VL_BF.mip_ready = false
VL_BF.base_alpha = 1
VL_BF.L_char = 100
VL_BF.need_manual_hint = false
VL_BF.n_occ_active = 0
VL_BF.sh3d_active = 0
VL_BF.camocc_active = 0
VL_BF.peak_cache_dots = 0
VL_BF.sr_x, VL_BF.sr_y, VL_BF.sr_z = 1, 0, 0
VL_BF.sd_x, VL_BF.sd_y, VL_BF.sd_z = 0, 1, 0
VL_BF.hw, VL_BF.hh = 80, 80
VL_BF.cam_x, VL_BF.cam_y, VL_BF.cam_z = 0, 0, -400
VL_BF.mid_x, VL_BF.mid_y, VL_BF.mid_z = 0, 0, 0
VL_BF.sf_x, VL_BF.sf_y, VL_BF.sf_z = 0, 0, 1
VL_BF.s_min = 0
VL_BF.src_desc = "src"
VL_BF.occ_desc = "L3(OBJ)(m1,tri:9),preview"
VL_BF.total_sl = 64
VL_BF.dz = 30
VL_BF.base_ratio = 1
VL_BF.cam_mode2_note = ""
VL_BF.cam_light_info = { count = 0 }
VL_BF.interact_drag = true
_VL_PERSIST.last_log = nil
_VL_PERSIST.last_log_t = nil
local nprint = 0
local _print = print
print = function(...)
    if select(1, ...) == "@info" then nprint = nprint + 1 end
    return _print(...)
end
-- call only the tail by invoking render; if it errors before the log, report it
local okr, errr = pcall(vl_bf_render)
if not okr then
    check("log_render_reached", false, tostring(errr))
else
    local n1 = nprint
    local okr2 = pcall(vl_bf_render)
    check("log_prints_once_per_window", n1 == 1 and nprint == 1, string.format("first=%d second=%d", n1, nprint))
    check("log_second_render", okr2, "")
end
print = _print
'''


def main() -> None:
    script = BRANCH.read_text(encoding="utf-8").replace("\r\n", "\n")
    if not script.rstrip().endswith("vl_run_frame()"):
        raise SystemExit("unexpected script footer")
    body = script[: script.rfind("vl_run_frame()")]
    prelude = textwrap.dedent(
        """\
        local obj = {
            layer = 6, frame = 12, time = 0.4, screen_w = 640, screen_h = 360,
            getinfo = function() return nil end,
            getvalue = function() return nil end,
            getoption = function() return nil end,
            setoption = function() end,
            clearbuffer = function() return true end,
            pixelshader = function() return true end,
            load = function() end,
            draw = function() end,
            drawpoly = function() end,
            copybuffer = function() return true end,
            module = function() return nil end,
            getpixel = function() return 32, 32 end,
            getpixeldata = function() return nil, 0, 0 end,
            putpixeldata = function() return true end,
        }
        _G.obj = obj
        """
    )
    src = prelude + "\n" + body + "\n" + DRIVER
    tmp = Path("/tmp/vl_drag_driver.lua")
    tmp.write_text(src, encoding="utf-8")
    r = subprocess.run(["luajit", str(tmp)], capture_output=True, text=True, timeout=120)
    print(r.stdout)
    if r.stderr:
        print(r.stderr)
    lines = [ln for ln in r.stdout.splitlines() if ln.startswith("PASS ") or ln.startswith("FAIL ")]
    bench = {}
    for ln in r.stdout.splitlines():
        if ln.startswith("BENCH "):
            for part in ln.split()[1:]:
                k, v = part.split("=")
                bench[k] = float(v) if v.replace(".", "", 1).isdigit() else v
    report = {
        "exit": r.returncode,
        "checks": [{"name": ln.split()[1], "ok": ln.startswith("PASS"), "detail": " ".join(ln.split()[2:])} for ln in lines],
        "bench": bench,
        "stable_head": STABLE.read_text(encoding="utf-8").splitlines()[0],
    }
    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    failed = [c for c in report["checks"] if not c["ok"]]
    print(f"{len(report['checks']) - len(failed)}/{len(report['checks'])} passed")
    if r.returncode != 0 or failed:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
