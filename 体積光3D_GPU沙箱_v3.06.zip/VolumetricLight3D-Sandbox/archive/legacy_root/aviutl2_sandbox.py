#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
AviUtl2 (.obj2) Full LuaJIT 2.1 + Vulkan (wgpu + glslang SPIR-V) Sandbox Engine
Executes unmodified AviUtl2 .obj2 scripts (LuaJIT FFI + embedded HLSL ps_5_0 shaders + 3D Camera Control + Shader #118 OIT).
"""

import ctypes
import hashlib
import math
import os
import pathlib
import re
import subprocess
import time
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
from PIL import Image, ImageDraw, ImageFont
import wgpu
from lupa.luajit21 import LuaRuntime


SPV_CACHE_DIR = pathlib.Path("/home/user/sandbox/spv_cache")
SPV_CACHE_DIR.mkdir(parents=True, exist_ok=True)


def rot_xyz_np(pts: np.ndarray, rx_deg: float, ry_deg: float, rz_deg: float) -> np.ndarray:
    """AviUtl2 Euler rotation order: X -> Y -> Z (matches rot_xyz in all 3 scripts)."""
    rx = math.radians(rx_deg)
    ry = math.radians(ry_deg)
    rz = math.radians(rz_deg)
    cx, sx = math.cos(rx), math.sin(rx)
    cy, sy = math.cos(ry), math.sin(ry)
    cz, sz = math.cos(rz), math.sin(rz)

    x = pts[..., 0]
    y = pts[..., 1]
    z = pts[..., 2]

    y1 = y * cx - z * sx
    z1 = y * sx + z * cx
    x2 = x * cy + z1 * sy
    z2 = -x * sy + z1 * cy
    x3 = x2 * cz - y1 * sz
    y3 = x2 * sz + y1 * cz
    return np.stack([x3, y3, z2], axis=-1)


def parse_camera_basis(cam: Optional[Dict[str, float]], screen_w: int, screen_h: int):
    """Exact AviUtl2 camera basis (cam_pos, r_axis, d_axis, f_axis, focal_d)."""
    focal_d = 1024.0
    if not cam:
        return (
            np.array([0.0, 0.0, -focal_d], dtype=np.float64),
            np.array([1.0, 0.0, 0.0], dtype=np.float64),
            np.array([0.0, 1.0, 0.0], dtype=np.float64),
            np.array([0.0, 0.0, 1.0], dtype=np.float64),
            focal_d,
        )
    cam_pos = np.array([cam.get("x", 0.0), cam.get("y", 0.0), cam.get("z", -1024.0)], dtype=np.float64)
    tgt = np.array([cam.get("tx", 0.0), cam.get("ty", 0.0), cam.get("tz", 0.0)], dtype=np.float64)
    if cam.get("d", 1024.0) > 1.0:
        focal_d = float(cam["d"])

    v = tgt - cam_pos
    vl = float(np.linalg.norm(v))
    f = v / vl if vl > 1e-8 else np.array([0.0, 0.0, 1.0], dtype=np.float64)

    up = np.array([cam.get("ux", 0.0), cam.get("uy", -1.0), cam.get("uz", 0.0)], dtype=np.float64)
    if float(np.linalg.norm(up)) < 1e-6:
        up = np.array([0.0, -1.0, 0.0], dtype=np.float64)

    # AviUtl2 convention: r = normalize(cross(f, up)) where default up = (0,-1,0) -> cross((0,0,1),(0,-1,0)) = (1,0,0)
    r = np.cross(f, up)
    rl = float(np.linalg.norm(r))
    r = r / rl if rl > 1e-6 else np.array([1.0, 0.0, 0.0], dtype=np.float64)

    # d (screen down +Y) = normalize(cross(f, r)) -> cross((0,0,1),(1,0,0)) = (0,1,0)
    d = np.cross(f, r)
    dl = float(np.linalg.norm(d))
    d = d / dl if dl > 1e-6 else np.array([0.0, 1.0, 0.0], dtype=np.float64)

    rz = float(cam.get("rz", 0.0))
    if abs(rz) > 1e-7:
        rad = math.radians(rz)
        cr, sr = math.cos(rad), math.sin(rad)
        r_new = r * cr + d * sr
        d_new = -r * sr + d * cr
        r, d = r_new, d_new

    return cam_pos, r, d, f, focal_d


@dataclass
class CompiledHLSL:
    name: str
    spv_bytes: bytes
    module: Any
    has_cbuffer: bool
    tex_slots: List[int]
    has_sampler: bool


@dataclass
class GpuBufferTex:
    name: str
    w: int
    h: int
    texture: Any
    view: Any
    cpu_dirty: bool = False


class VulkanGpuBackend:
    """Shared Vulkan WGPU device + pipeline cache."""

    _instance = None

    @classmethod
    def get(cls) -> "VulkanGpuBackend":
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    def __init__(self):
        self.adapter = wgpu.gpu.request_adapter_sync(power_preference="high-performance")
        self.device = self.adapter.request_device_sync()
        self.shader_cache: Dict[str, CompiledHLSL] = {}
        self.ps_pipeline_cache: Dict[Tuple[str, str], Tuple[Any, Any]] = {}
        self._init_common_resources()

    def _init_common_resources(self):
        vs_fs_quad = """
        struct VSOut {
            @builtin(position) pos: vec4<f32>,
        };
        @vertex
        fn vs_main(@builtin(vertex_index) vi: u32) -> VSOut {
            var p = array<vec2<f32>, 3>(
                vec2<f32>(-1.0,  1.0),
                vec2<f32>( 3.0,  1.0),
                vec2<f32>(-1.0, -3.0)
            );
            var out: VSOut;
            out.pos = vec4<f32>(p[vi], 0.0, 1.0);
            return out;
        }
        """
        self.fs_quad_vs = self.device.create_shader_module(code=vs_fs_quad)

        # 3D / 2D polygon shader matching AviUtl2 drawpoly & Shader #118 OIT semantics
        poly_wgsl = """
        struct PolyUniforms {
            mode_flags: vec4<f32>, // x: shader118_none(1/0), y: poly_alpha, z: cam_light_r, w: cam_light_g
            extra: vec4<f32>,      // x: cam_light_b, y: opaque_pass(1/0), z: unused, w: unused
        };
        @group(0) @binding(0) var<uniform> u: PolyUniforms;
        @group(0) @binding(1) var t_src: texture_2d<f32>;
        @group(0) @binding(2) var s_src: sampler;

        struct VSIn {
            @location(0) clip_pos: vec4<f32>,
            @location(1) uv: vec2<f32>,
            @location(2) vcol: vec4<f32>,
        };
        struct VSOut {
            @builtin(position) pos: vec4<f32>,
            @location(0) uv: vec2<f32>,
            @location(1) vcol: vec4<f32>,
        };

        @vertex
        fn vs_poly(in: VSIn) -> VSOut {
            var out: VSOut;
            out.pos = in.clip_pos;
            out.uv = in.uv;
            out.vcol = in.vcol;
            return out;
        }

        @fragment
        fn fs_poly(in: VSOut) -> @location(0) vec4<f32> {
            let tex = textureSample(t_src, s_src, in.uv);
            let poly_a = u.mode_flags.y;
            if (u.extra.y > 0.5) {
                // Untextured premultiplied vertex color mode ({x,y,z, r,g,b,a [,nx,ny,nz]})
                let out_rgb = in.vcol.rgb * poly_a;
                let out_a = in.vcol.a * poly_a;
                if (out_a <= 1.0e-6 && dot(out_rgb, vec3<f32>(1.0)) <= 1.0e-6) {
                    discard;
                }
                return vec4<f32>(out_rgb, out_a);
            }
            let pa = poly_a * in.vcol.a;
            if (u.mode_flags.x > 0.5) {
                // AviUtl2 Shader #118 (0x1404404b0) blend="none":
                // r4 = tex.rgba * poly_alpha -> 9.89-bit effective precision (0.27 / 255 quantum) in float16 OIT!
                let a118 = tex.a * pa;
                if (a118 <= 0.001) {
                    discard;
                }
                let gain = vec3<f32>(u.mode_flags.z, u.mode_flags.w, u.extra.x);
                return vec4<f32>(tex.rgb * in.vcol.rgb * pa * gain, a118);
            }
            // Standard AviUtl2 premultiplied texture * poly_alpha * vcol
            let out_a = tex.a * pa;
            if (out_a <= 1.0e-6 && dot(tex.rgb, vec3<f32>(1.0)) <= 1.0e-6) {
                discard;
            }
            return vec4<f32>(tex.rgb * in.vcol.rgb * pa, out_a);
        }
        """
        self.poly_mod = self.device.create_shader_module(code=poly_wgsl)
        self.poly_bgl = self.device.create_bind_group_layout(
            entries=[
                {"binding": 0, "visibility": wgpu.ShaderStage.FRAGMENT, "buffer": {"type": "uniform"}},
                {"binding": 1, "visibility": wgpu.ShaderStage.FRAGMENT, "texture": {"sample_type": "float", "view_dimension": "2d"}},
                {"binding": 2, "visibility": wgpu.ShaderStage.FRAGMENT, "sampler": {"type": "filtering"}},
            ]
        )
        self.poly_layout = self.device.create_pipeline_layout(bind_group_layouts=[self.poly_bgl])
        self.poly_pipes: Dict[Tuple[str, bool, bool], Any] = {}

        self.samplers = {
            "clamp": self.device.create_sampler(
                address_mode_u="clamp-to-edge", address_mode_v="clamp-to-edge",
                mag_filter="linear", min_filter="linear",
            ),
            "dot": self.device.create_sampler(
                address_mode_u="clamp-to-edge", address_mode_v="clamp-to-edge",
                mag_filter="nearest", min_filter="nearest",
            ),
            "loop": self.device.create_sampler(
                address_mode_u="repeat", address_mode_v="repeat",
                mag_filter="linear", min_filter="linear",
            ),
        }
        self.dummy_tex = self.device.create_texture(
            size=(1, 1, 1), format="rgba8unorm",
            usage=wgpu.TextureUsage.TEXTURE_BINDING | wgpu.TextureUsage.COPY_DST,
        )
        self.device.queue.write_texture(
            {"texture": self.dummy_tex}, b"\x00\x00\x00\x00",
            {"bytes_per_row": 4, "rows_per_image": 1}, (1, 1, 1),
        )
        self.dummy_view = self.dummy_tex.create_view()

    def get_poly_pipeline(self, blend_key: str, use_depth: bool, depth_write: bool, target_fmt: str = "rgba8unorm"):
        key = (blend_key, use_depth, depth_write, target_fmt)
        if key in self.poly_pipes:
            return self.poly_pipes[key]

        if blend_key in ("normal", "none_oit"):
            blend_state = {
                "color": {"src_factor": "one", "dst_factor": "one-minus-src-alpha", "operation": "add"},
                "alpha": {"src_factor": "one", "dst_factor": "one-minus-src-alpha", "operation": "add"},
            }
        elif blend_key == "none_opaque":
            blend_state = {
                "color": {"src_factor": "one", "dst_factor": "zero", "operation": "add"},
                "alpha": {"src_factor": "one", "dst_factor": "zero", "operation": "add"},
            }
        elif blend_key == "add":
            blend_state = {
                "color": {"src_factor": "one", "dst_factor": "one", "operation": "add"},
                "alpha": {"src_factor": "zero", "dst_factor": "one", "operation": "add"},
            }
        elif blend_key == "screen":
            blend_state = {
                "color": {"src_factor": "one", "dst_factor": "one-minus-src", "operation": "add"},
                "alpha": {"src_factor": "one", "dst_factor": "one-minus-src-alpha", "operation": "add"},
            }
        else:
            blend_state = {
                "color": {"src_factor": "one", "dst_factor": "one-minus-src-alpha", "operation": "add"},
                "alpha": {"src_factor": "one", "dst_factor": "one-minus-src-alpha", "operation": "add"},
            }

        depth_stencil = None
        if use_depth:
            depth_stencil = {
                "format": "depth32float",
                "depth_write_enabled": depth_write,
                "depth_compare": "less-equal",
            }

        pipe = self.device.create_render_pipeline(
            layout=self.poly_layout,
            vertex={
                "module": self.poly_mod,
                "entry_point": "vs_poly",
                "buffers": [
                    {
                        "array_stride": 40,  # 10 float32s: clip(4) + uv(2) + vcol(4)
                        "step_mode": "vertex",
                        "attributes": [
                            {"format": "float32x4", "offset": 0, "shader_location": 0},
                            {"format": "float32x2", "offset": 16, "shader_location": 1},
                            {"format": "float32x4", "offset": 24, "shader_location": 2},
                        ],
                    }
                ],
            },
            fragment={
                "module": self.poly_mod,
                "entry_point": "fs_poly",
                "targets": [{"format": target_fmt, "blend": blend_state}],
            },
            primitive={"topology": "triangle-list", "cull_mode": "none"},
            depth_stencil=depth_stencil,
        )
        self.poly_pipes[key] = pipe
        return pipe

    def compile_hlsl(self, name: str, hlsl_code: str) -> CompiledHLSL:
        h = hashlib.sha256((name + "::" + hlsl_code).encode("utf-8")).hexdigest()[:24]
        if h in self.shader_cache:
            return self.shader_cache[h]

        spv_path = SPV_CACHE_DIR / f"{name}_{h}.spv"
        if not spv_path.exists():
            hlsl_path = SPV_CACHE_DIR / f"{name}_{h}.hlsl"
            hlsl_path.write_text(hlsl_code, encoding="utf-8")
            cmd = [
                "glslangValidator", "-D", "-S", "frag", "-e", name,
                "--hlsl-offsets", "--hlsl-iomap",
                "--shift-cbuffer-binding", "0",
                "--shift-texture-binding", "10",
                "--shift-sampler-binding", "20",
                "-V", str(hlsl_path), "-o", str(spv_path),
            ]
            res = subprocess.run(cmd, capture_output=True, text=True)
            if res.returncode != 0:
                raise RuntimeError(f"HLSL compile failed for {name}:\n{res.stdout}\n{res.stderr}")

        spv_bytes = spv_path.read_bytes()
        mod = self.device.create_shader_module(code=spv_bytes)

        # Strip comments before inspecting active registers
        clean = re.sub(r"//.*", "", hlsl_code)
        clean = re.sub(r"/\*.*?\*/", "", clean, flags=re.S)
        has_cbuffer = bool(re.search(r"register\s*\(\s*b0\s*\)", clean))
        tex_slots = sorted({int(m.group(1)) for m in re.finditer(r"register\s*\(\s*t(\d+)\s*\)", clean)})
        has_sampler = bool(re.search(r"register\s*\(\s*s0\s*\)", clean))

        comp = CompiledHLSL(
            name=name, spv_bytes=spv_bytes, module=mod,
            has_cbuffer=has_cbuffer, tex_slots=tex_slots, has_sampler=has_sampler,
        )
        self.shader_cache[h] = comp
        return comp

    def get_ps_pipeline(self, comp: CompiledHLSL, spv_hash_key: str, blend_mode: str, uses_nearest_sampler: bool):
        key = (spv_hash_key, blend_mode, uses_nearest_sampler)
        if key in self.ps_pipeline_cache:
            return self.ps_pipeline_cache[key]

        entries = []
        if comp.has_cbuffer:
            entries.append({"binding": 0, "visibility": wgpu.ShaderStage.FRAGMENT, "buffer": {"type": "uniform"}})
        for slot in comp.tex_slots:
            entries.append({
                "binding": 10 + slot,
                "visibility": wgpu.ShaderStage.FRAGMENT,
                "texture": {"sample_type": "float", "view_dimension": "2d"},
            })
        if comp.has_sampler:
            entries.append({
                "binding": 20,
                "visibility": wgpu.ShaderStage.FRAGMENT,
                "sampler": {"type": "non-filtering" if uses_nearest_sampler else "filtering"},
            })

        bgl = self.device.create_bind_group_layout(entries=entries)
        layout = self.device.create_pipeline_layout(bind_group_layouts=[bgl])

        if blend_mode == "copy":
            blend_state = None
        elif blend_mode == "add":
            blend_state = {
                "color": {"src_factor": "one", "dst_factor": "one", "operation": "add"},
                "alpha": {"src_factor": "one", "dst_factor": "one", "operation": "add"},
            }
        else:
            blend_state = {
                "color": {"src_factor": "one", "dst_factor": "one-minus-src-alpha", "operation": "add"},
                "alpha": {"src_factor": "one", "dst_factor": "one-minus-src-alpha", "operation": "add"},
            }

        target = {"format": "rgba8unorm"}
        if blend_state is not None:
            target["blend"] = blend_state

        pipe = self.device.create_render_pipeline(
            layout=layout,
            vertex={"module": self.fs_quad_vs, "entry_point": "vs_main"},
            fragment={"module": comp.module, "entry_point": comp.name, "targets": [target]},
            primitive={"topology": "triangle-list"},
        )
        self.ps_pipeline_cache[key] = (bgl, pipe)
        return bgl, pipe


def parse_obj2_script(path: str) -> Tuple[Dict[str, Any], Dict[str, str], str]:
    """
    Parse AviUtl2 .obj2 header declarations (--track, --check, --color, --select, --value, --figure, --file)
    and embedded --[[pixelshader@name: ... ]] blocks.
    Returns (default_params, shaders_dict, full_lua_source).
    """
    src = pathlib.Path(path).read_text(encoding="utf-8")
    defaults: Dict[str, Any] = {}

    for line in src.splitlines():
        s = line.strip()
        if not s.startswith("--"):
            continue
        m_track = re.match(r"^--track\d*@([A-Za-z0-9_]+):[^,]*,([^,]+),([^,]+),([^,]+)", s)
        if m_track:
            defaults[m_track.group(1)] = float(m_track.group(4))
            continue
        m_check = re.match(r"^--check\d*@([A-Za-z0-9_]+):[^,]*,(true|false|[01])", s, re.I)
        if m_check:
            cv = m_check.group(2).lower()
            if cv in ("true", "false"):
                defaults[m_check.group(1)] = (cv == "true")
            else:
                defaults[m_check.group(1)] = 1 if cv == "1" else 0
            continue
        m_str = re.match(r"^--string@([A-Za-z0-9_]+):[^,]*,(.*)", s)
        if m_str:
            defaults[m_str.group(1)] = m_str.group(2)
            continue
        m_color = re.match(r"^--color\d*@([A-Za-z0-9_]+):[^,]*,(.*)", s)
        if m_color:
            val_s = m_color.group(2).strip()
            if val_s == "" or val_s.lower() == "nil":
                defaults[m_color.group(1)] = None
            else:
                defaults[m_color.group(1)] = int(val_s, 0)
            continue
        m_select = re.match(r"^--select@([A-Za-z0-9_]+):[^=,]*=([0-9]+)", s)
        if m_select:
            defaults[m_select.group(1)] = int(m_select.group(2))
            continue
        m_val = re.match(r"^--value@([A-Za-z0-9_]+):[^,]*,(.*)", s)
        if m_val:
            val_s = m_val.group(2).strip()
            try:
                defaults[m_val.group(1)] = float(val_s) if "." in val_s else int(val_s)
            except ValueError:
                defaults[m_val.group(1)] = val_s.strip('"')
            continue
        m_fig = re.match(r"^--figure@([A-Za-z0-9_]+):[^,]*,(.*)", s)
        if m_fig:
            defaults[m_fig.group(1)] = m_fig.group(2).strip()
            continue
        m_file = re.match(r"^--file@([A-Za-z0-9_]+):", s)
        if m_file:
            defaults[m_file.group(1)] = ""
            continue

    shaders = dict(re.findall(r"--\[\[pixelshader@([A-Za-z0-9_]+):\s*(.*?)\]\]", src, re.S))
    return defaults, shaders, src


@dataclass
class SceneLayer:
    layer_id: int
    x: float = 0.0
    y: float = 0.0
    z: float = 0.0
    rx: float = 0.0
    ry: float = 0.0
    rz: float = 0.0
    cx: float = 0.0
    cy: float = 0.0
    cz: float = 0.0
    zoom: float = 100.0
    alpha: float = 1.0
    aspect: float = 0.0
    sx: Optional[float] = None
    sy: Optional[float] = None
    sz: Optional[float] = None
    rgba_image: Optional[np.ndarray] = None  # Premultiplied RGBA8 (H, W, 4) for 2D/source layers
    effects: Dict[str, Dict[str, Any]] = field(default_factory=dict)  # fx_name -> {item_name: value}
    render_in_3d: bool = True  # Whether our scene host draws this 2D card in 3D before script
    opaque_3d_mesh: Optional[Dict[str, Any]] = None  # {"verts": (N,3), "tris": (M,3), "color": (3,)}


class AviUtl2Sandbox:
    """Complete AviUtl2 single-scene 3D + 2D + HLSL + LuaJIT FFI execution environment."""

    def __init__(self, screen_w: int = 1280, screen_h: int = 720):
        self.gpu = VulkanGpuBackend.get()
        self.screen_w = screen_w
        self.screen_h = screen_h
        self.buffers: Dict[str, GpuBufferTex] = {}
        self.depth_tex = self.gpu.device.create_texture(
            size=(screen_w, screen_h, 1),
            format="depth32float",
            usage=wgpu.TextureUsage.RENDER_ATTACHMENT,
        )
        self.depth_view = self.depth_tex.create_view()
        self.layers: Dict[int, SceneLayer] = {}
        self.camera_mode: int = 1
        self.camera_param: Optional[Dict[str, float]] = {
            "x": 0.0, "y": 0.0, "z": -1024.0,
            "tx": 0.0, "ty": 0.0, "tz": 0.0,
            "ux": 0.0, "uy": -1.0, "uz": 0.0,
            "rz": 0.0, "d": 1024.0,
        }
        self.cam_light_gain: Tuple[float, float, float] = (1.0, 1.0, 1.0)
        self.peak_cache_dots: int = 0
        self.stats: Dict[str, Any] = {}
        self.reset_framebuffer()

    def reset_framebuffer(self, bg_rgba: Tuple[int, int, int, int] = (0, 0, 0, 255)):
        fb = self.ensure_buffer("framebuffer", self.screen_w, self.screen_h, clear=False)
        enc = self.gpu.device.create_command_encoder()
        rp = enc.begin_render_pass(
            color_attachments=[{
                "view": fb.view,
                "load_op": "clear",
                "store_op": "store",
                "clear_value": (bg_rgba[0] / 255.0, bg_rgba[1] / 255.0, bg_rgba[2] / 255.0, bg_rgba[3] / 255.0),
            }],
            depth_stencil_attachment={
                "view": self.depth_view,
                "depth_load_op": "clear",
                "depth_store_op": "store",
                "depth_clear_value": 1.0,
            },
        )
        rp.end()
        self.gpu.device.queue.submit([enc.finish()])

    def ensure_buffer(self, name: str, w: int, h: int, clear: bool = False) -> GpuBufferTex:
        w = max(1, int(w))
        h = max(1, int(h))
        fmt = "rgba16float" if (name == "framebuffer" and w * h <= 16_000_000) else "rgba8unorm"
        cur = self.buffers.get(name)
        if cur is None or cur.w != w or cur.h != h:
            tex = self.gpu.device.create_texture(
                size=(w, h, 1),
                format=fmt,
                usage=(
                    wgpu.TextureUsage.RENDER_ATTACHMENT
                    | wgpu.TextureUsage.TEXTURE_BINDING
                    | wgpu.TextureUsage.COPY_SRC
                    | wgpu.TextureUsage.COPY_DST
                ),
            )
            cur = GpuBufferTex(name=name, w=w, h=h, texture=tex, view=tex.create_view())
            self.buffers[name] = cur
            clear = True

        if clear:
            enc = self.gpu.device.create_command_encoder()
            rp = enc.begin_render_pass(
                color_attachments=[{
                    "view": cur.view, "load_op": "clear", "store_op": "store",
                    "clear_value": (0.0, 0.0, 0.0, 0.0),
                }]
            )
            rp.end()
            self.gpu.device.queue.submit([enc.finish()])

        self._update_cache_dots()
        return cur

    def _update_cache_dots(self):
        dots = sum(b.w * b.h for k, b in self.buffers.items() if k.startswith("cache:"))
        if dots > self.peak_cache_dots:
            self.peak_cache_dots = dots

    def upload_numpy(self, name: str, arr: np.ndarray) -> GpuBufferTex:
        assert arr.ndim == 3 and arr.shape[2] == 4 and arr.dtype == np.uint8
        h, w, _ = arr.shape
        buf = self.ensure_buffer(name, w, h, clear=False)
        if name == "framebuffer" and w * h <= 16_000_000:
            f16 = (arr.astype(np.float32) / 255.0).astype(np.float16)
            contig = np.ascontiguousarray(f16)
            self.gpu.device.queue.write_texture(
                {"texture": buf.texture},
                contig.tobytes(),
                {"bytes_per_row": w * 8, "rows_per_image": h},
                (w, h, 1),
            )
        else:
            contig = np.ascontiguousarray(arr)
            self.gpu.device.queue.write_texture(
                {"texture": buf.texture},
                contig.tobytes(),
                {"bytes_per_row": w * 4, "rows_per_image": h},
                (w, h, 1),
            )
        return buf

    def read_numpy(self, name: str = "framebuffer") -> np.ndarray:
        buf = self.buffers[name]
        if name == "framebuffer" and buf.w * buf.h <= 16_000_000:
            raw = self.gpu.device.queue.read_texture(
                {"texture": buf.texture},
                {"bytes_per_row": buf.w * 8, "rows_per_image": buf.h},
                (buf.w, buf.h, 1),
            )
            f16 = np.frombuffer(raw, dtype=np.float16).reshape(buf.h, buf.w, 4)
            out_u8 = np.empty((buf.h, buf.w, 4), dtype=np.uint8)
            for y0 in range(0, buf.h, 256):
                y1 = min(buf.h, y0 + 256)
                out_u8[y0:y1] = np.clip(np.round(f16[y0:y1].astype(np.float32) * 255.0), 0.0, 255.0).astype(np.uint8)
            return out_u8
        raw = self.gpu.device.queue.read_texture(
            {"texture": buf.texture},
            {"bytes_per_row": buf.w * 4, "rows_per_image": buf.h},
            (buf.w, buf.h, 1),
        )
        return np.frombuffer(raw, dtype=np.uint8).reshape(buf.h, buf.w, 4).copy()

    def project_world_triangles(
        self, world_tris: np.ndarray, uvs: np.ndarray, vcols: np.ndarray
    ) -> Optional[np.ndarray]:
        """
        Clip 3D world-space triangles (N, 3, 3) against camera near plane zc >= z_near,
        project to WebGPU clip space (x_clip, y_clip, z_clip, w_clip=zc), and return (M*3, 10) float32 array.
        """
        if world_tris.shape[0] == 0:
            return None
        cam_pos, r_ax, d_ax, f_ax, focal_d = parse_camera_basis(
            self.camera_param if self.camera_mode != 0 else None, self.screen_w, self.screen_h
        )
        z_near = 2.0
        z_far = 65536.0

        rel = world_tris - cam_pos[None, None, :]
        xc = np.einsum("ntk,k->nt", rel, r_ax)
        yc = np.einsum("ntk,k->nt", rel, d_ax)
        zc = np.einsum("ntk,k->nt", rel, f_ax)

        # Fast path when all vertices are in front of z_near
        all_front = bool((zc >= z_near).all())
        all_behind = bool((zc < z_near).all())
        if all_behind:
            return None

        if not all_front:
            # Sutherland-Hodgman clip against zc >= z_near for straddling triangles
            out_pos = []
            out_uv = []
            out_col = []
            for i in range(world_tris.shape[0]):
                zi = zc[i]
                if (zi < z_near).all():
                    continue
                if (zi >= z_near).all():
                    for k in range(3):
                        out_pos.append((xc[i, k], yc[i, k], zc[i, k]))
                        out_uv.append(uvs[i, k])
                        out_col.append(vcols[i, k])
                    continue
                poly = [
                    (xc[i, k], yc[i, k], zc[i, k], uvs[i, k], vcols[i, k])
                    for k in range(3)
                ]
                clipped = []
                prev = poly[-1]
                prev_in = prev[2] >= z_near
                for cur in poly:
                    cur_in = cur[2] >= z_near
                    if cur_in:
                        if not prev_in:
                            t = (z_near - prev[2]) / (cur[2] - prev[2])
                            clipped.append((
                                prev[0] + (cur[0] - prev[0]) * t,
                                prev[1] + (cur[1] - prev[1]) * t,
                                z_near,
                                prev[3] + (cur[3] - prev[3]) * t,
                                prev[4] + (cur[4] - prev[4]) * t,
                            ))
                        clipped.append(cur)
                    elif prev_in:
                        t = (z_near - prev[2]) / (cur[2] - prev[2])
                        clipped.append((
                            prev[0] + (cur[0] - prev[0]) * t,
                            prev[1] + (cur[1] - prev[1]) * t,
                            z_near,
                            prev[3] + (cur[3] - prev[3]) * t,
                            prev[4] + (cur[4] - prev[4]) * t,
                        ))
                    prev, prev_in = cur, cur_in
                for k in range(1, len(clipped) - 1):
                    for vtx in (clipped[0], clipped[k], clipped[k + 1]):
                        out_pos.append((vtx[0], vtx[1], vtx[2]))
                        out_uv.append(vtx[3])
                        out_col.append(vtx[4])
            if not out_pos:
                return None
            pos_arr = np.array(out_pos, dtype=np.float64)
            uv_arr = np.array(out_uv, dtype=np.float32)
            col_arr = np.array(out_col, dtype=np.float32)
            xc_f, yc_f, zc_f = pos_arr[:, 0], pos_arr[:, 1], pos_arr[:, 2]
        else:
            xc_f = xc.reshape(-1)
            yc_f = yc.reshape(-1)
            zc_f = zc.reshape(-1)
            uv_arr = uvs.reshape(-1, 2).astype(np.float32)
            col_arr = vcols.reshape(-1, 4).astype(np.float32)

        # Perspective clip coords with w = zc so GPU interpolates UV perspective-correctly!
        sx_scale = focal_d / (0.5 * self.screen_w)
        sy_scale = focal_d / (0.5 * self.screen_h)
        clip_x = xc_f * sx_scale
        clip_y = -yc_f * sy_scale
        # Hyperbolic depth in [0, 1]: z_ndc = (z_far / (z_far - z_near)) * (1 - z_near / zc)
        # -> clip_z = z_ndc * zc = (z_far / (z_far - z_near)) * (zc - z_near)
        k_z = z_far / (z_far - z_near)
        clip_z = k_z * (zc_f - z_near)
        clip_w = zc_f

        vbuf = np.empty((xc_f.shape[0], 10), dtype=np.float32)
        vbuf[:, 0] = clip_x
        vbuf[:, 1] = clip_y
        vbuf[:, 2] = clip_z
        vbuf[:, 3] = clip_w
        vbuf[:, 4:6] = uv_arr
        vbuf[:, 6:10] = col_arr
        return vbuf

    def render_scene_3d_layers(
        self,
        pass_kind: str = "opaque_and_cards",
        light_dir: Tuple[float, float, float] = (-0.35, -0.55, 0.75),
    ):
        """
        Render scene's 3D opaque meshes (into framebuffer + hardware Z-buffer) and 2D card layers in 3D space,
        matching AviUtl2 Camera Control's G-Buffer + transparent card order.
        """
        ld = np.array(light_dir, dtype=np.float64)
        ld /= max(1e-8, float(np.linalg.norm(ld)))

        # 1) Opaque 3D meshes first (writes hardware Z-buffer!)
        white = np.full((2, 2, 4), 255, dtype=np.uint8)
        self.upload_numpy("__white2x2", white)
        for ln in sorted(self.layers.keys()):
            lay = self.layers[ln]
            if lay.opaque_3d_mesh is None or not lay.render_in_3d:
                continue
            m = lay.opaque_3d_mesh
            verts = np.asarray(m["verts"], dtype=np.float64)
            tris = np.asarray(m["tris"], dtype=np.int32)
            base_col = np.asarray(m.get("color", (0.82, 0.84, 0.88)), dtype=np.float64)

            # Scale -> Rotate -> Translate
            zs = lay.zoom / 100.0
            sx = lay.sx if lay.sx is not None else zs
            sy = lay.sy if lay.sy is not None else zs
            sz = lay.sz if lay.sz is not None else zs
            v_loc = (verts - np.array([lay.cx, lay.cy, lay.cz])) * np.array([sx, sy, sz])
            v_rot = rot_xyz_np(v_loc, lay.rx, lay.ry, lay.rz)
            v_wld = v_rot + np.array([lay.x, lay.y, lay.z])

            tri_w = v_wld[tris]  # (M, 3, 3)
            e1 = tri_w[:, 1] - tri_w[:, 0]
            e2 = tri_w[:, 2] - tri_w[:, 0]
            nrm = np.cross(e1, e2)
            nl = np.linalg.norm(nrm, axis=-1, keepdims=True)
            nrm = nrm / np.maximum(nl, 1e-8)
            ndotl = np.abs(np.einsum("mk,k->m", nrm, -ld))
            shade = 0.34 + 0.66 * ndotl
            rgb = np.clip(shade[:, None] * base_col[None, :], 0.0, 1.0)
            vcols = np.ones((tris.shape[0], 3, 4), dtype=np.float32)
            vcols[:, :, 0] = rgb[:, 0:1]
            vcols[:, :, 1] = rgb[:, 1:2]
            vcols[:, :, 2] = rgb[:, 2:3]
            uvs = np.full((tris.shape[0], 3, 2), 0.5, dtype=np.float32)

            vbuf_data = self.project_world_triangles(tri_w, uvs, vcols)
            if vbuf_data is not None:
                self._submit_poly_draw(
                    target_name="framebuffer",
                    src_name="__white2x2",
                    vbuf_data=vbuf_data,
                    blend_key="none_opaque",
                    shader118_none=False,
                    poly_alpha=1.0,
                    use_depth=True,
                    depth_write=True,
                )

        # 2) 2D image/card layers placed in 3D space (e.g., stained-glass window at z=400, 2D cutout at z=-150)
        card_layers = []
        cam_pos, _, _, f_ax, _ = parse_camera_basis(self.camera_param, self.screen_w, self.screen_h)
        for ln, lay in self.layers.items():
            if lay.rgba_image is not None and lay.render_in_3d:
                zc_l = float(np.dot(np.array([lay.x, lay.y, lay.z]) - cam_pos, f_ax))
                card_layers.append((zc_l, ln, lay))
        # Back-to-front for 2D cards
        card_layers.sort(key=lambda t: t[0], reverse=True)
        for _, ln, lay in card_layers:
            img = lay.rgba_image
            ih, iw, _ = img.shape
            tname = f"__scene_layer_{ln}"
            self.upload_numpy(tname, img)
            zs = lay.zoom / 100.0
            sx = lay.sx if lay.sx is not None else zs
            sy = lay.sy if lay.sy is not None else zs
            hx, hy = 0.5 * iw * sx, 0.5 * ih * sy
            quad_loc = np.array([
                [-hx - lay.cx * sx, -hy - lay.cy * sy, -lay.cz],
                [ hx - lay.cx * sx, -hy - lay.cy * sy, -lay.cz],
                [ hx - lay.cx * sx,  hy - lay.cy * sy, -lay.cz],
                [-hx - lay.cx * sx,  hy - lay.cy * sy, -lay.cz],
            ], dtype=np.float64)
            quad_w = rot_xyz_np(quad_loc, lay.rx, lay.ry, lay.rz) + np.array([lay.x, lay.y, lay.z])
            tri_w = np.stack([quad_w[[0, 1, 2]], quad_w[[0, 2, 3]]], axis=0)
            uv_q = np.array([
                [[0.0, 0.0], [1.0, 0.0], [1.0, 1.0]],
                [[0.0, 0.0], [1.0, 1.0], [0.0, 1.0]],
            ], dtype=np.float32)
            vcols = np.ones((2, 3, 4), dtype=np.float32)
            vbuf_data = self.project_world_triangles(tri_w, uv_q, vcols)
            if vbuf_data is not None:
                self._submit_poly_draw(
                    target_name="framebuffer",
                    src_name=tname,
                    vbuf_data=vbuf_data,
                    blend_key="normal",
                    shader118_none=False,
                    poly_alpha=lay.alpha,
                    use_depth=True,
                    depth_write=False,
                )

    def _submit_poly_draw(
        self,
        target_name: str,
        src_name: str,
        vbuf_data: np.ndarray,
        blend_key: str,
        shader118_none: bool,
        poly_alpha: float,
        use_depth: bool,
        depth_write: bool,
        sampler_mode: str = "clamp",
        untextured_vcol: bool = False,
    ):
        dst = self.buffers[target_name]
        if "__white2x2" not in self.buffers:
            self.upload_numpy("__white2x2", np.full((2, 2, 4), 255, dtype=np.uint8))
        src = self.buffers["__white2x2"] if untextured_vcol else self.buffers[src_name]
        target_fmt = "rgba16float" if (target_name == "framebuffer" and dst.w * dst.h <= 16_000_000) else "rgba8unorm"
        pipe = self.gpu.get_poly_pipeline(blend_key, use_depth, depth_write, target_fmt=target_fmt)

        u_arr = np.array([
            1.0 if shader118_none else 0.0,
            float(poly_alpha),
            float(self.cam_light_gain[0]),
            float(self.cam_light_gain[1]),
            float(self.cam_light_gain[2]),
            1.0 if untextured_vcol else 0.0,
            0.0, 0.0,
        ], dtype=np.float32)
        ubuf = self.gpu.device.create_buffer_with_data(data=u_arr, usage=wgpu.BufferUsage.UNIFORM)
        vbuf = self.gpu.device.create_buffer_with_data(data=vbuf_data, usage=wgpu.BufferUsage.VERTEX)
        smp = self.gpu.samplers.get(sampler_mode, self.gpu.samplers["clamp"])
        bg = self.gpu.device.create_bind_group(
            layout=self.gpu.poly_bgl,
            entries=[
                {"binding": 0, "resource": {"buffer": ubuf}},
                {"binding": 1, "resource": src.view},
                {"binding": 2, "resource": smp},
            ],
        )
        enc = self.gpu.device.create_command_encoder()
        ds_att = None
        if use_depth and target_name == "framebuffer":
            ds_att = {
                "view": self.depth_view,
                "depth_load_op": "load",
                "depth_store_op": "store",
            }
        rp = enc.begin_render_pass(
            color_attachments=[{"view": dst.view, "load_op": "load", "store_op": "store"}],
            depth_stencil_attachment=ds_att,
        )
        rp.set_pipeline(pipe)
        rp.set_bind_group(0, bg)
        rp.set_vertex_buffer(0, vbuf)
        rp.draw(vbuf_data.shape[0])
        rp.end()
        self.gpu.device.queue.submit([enc.finish()])

    @staticmethod
    def render_figure_rgba(fig_name: str, color_hex: int, size: int) -> np.ndarray:
        """High-precision 8x supersampled premultiplied RGBA8 generator for AviUtl2 standard figures."""
        size = max(1, int(size))
        r = ((color_hex >> 16) & 0xFF) / 255.0
        g = ((color_hex >> 8) & 0xFF) / 255.0
        b = (color_hex & 0xFF) / 255.0

        yy, xx = np.mgrid[0:size, 0:size].astype(np.float32)
        u = (xx + 0.5) / size * 2.0 - 1.0
        v = (yy + 0.5) / size * 2.0 - 1.0
        aa = max(2.0 / size, 1e-3)

        fn = (fig_name or "円").strip()
        if fn in ("四角形", "Square", "方形", "背景"):
            d = np.maximum(np.abs(u), np.abs(v)) - 1.0
            cov = np.clip(0.5 - d / aa, 0.0, 1.0)
        elif fn in ("三角形", "Triangle"):
            # Equilateral-ish upward triangle inscribed in [-1,1]^2
            img = Image.new("L", (size * 4, size * 4), 0)
            dr = ImageDraw.Draw(img)
            S = size * 4
            dr.polygon([(S * 0.5, S * 0.06), (S * 0.94, S * 0.90), (S * 0.06, S * 0.90)], fill=255)
            cov = np.asarray(img.resize((size, size), Image.Resampling.BOX), dtype=np.float32) / 255.0
        elif fn in ("五角形", "六角形", "星型", "Star", "Hexagon", "Pentagon"):
            img = Image.new("L", (size * 4, size * 4), 0)
            dr = ImageDraw.Draw(img)
            S = size * 4
            cx, cy = S * 0.5, S * 0.5
            pts = []
            if "星" in fn or fn == "Star":
                for k in range(10):
                    ang = -math.pi / 2 + k * math.pi / 5
                    rad = S * (0.46 if k % 2 == 0 else 0.19)
                    pts.append((cx + math.cos(ang) * rad, cy + math.sin(ang) * rad))
            else:
                n_sides = 6 if ("六" in fn or fn == "Hexagon") else 5
                for k in range(n_sides):
                    ang = -math.pi / 2 + k * 2 * math.pi / n_sides
                    pts.append((cx + math.cos(ang) * S * 0.46, cy + math.sin(ang) * S * 0.46))
            dr.polygon(pts, fill=255)
            cov = np.asarray(img.resize((size, size), Image.Resampling.BOX), dtype=np.float32) / 255.0
        else:
            # Default: 円 (Circle)
            dist = np.sqrt(u * u + v * v)
            cov = np.clip((1.0 - dist) / aa + 0.5, 0.0, 1.0)

        out = np.zeros((size, size, 4), dtype=np.uint8)
        out[..., 0] = np.round(r * cov * 255.0).astype(np.uint8)
        out[..., 1] = np.round(g * cov * 255.0).astype(np.uint8)
        out[..., 2] = np.round(b * cov * 255.0).astype(np.uint8)
        out[..., 3] = np.round(cov * 255.0).astype(np.uint8)
        return out

    def run_obj2(
        self,
        script_path: str,
        param_overrides: Optional[Dict[str, Any]] = None,
        obj_props: Optional[Dict[str, Any]] = None,
        lua_globals_extra: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """
        Execute an AviUtl2 .obj2 script for one frame on this sandbox's current framebuffer & 3D scene.
        Returns execution metrics + rendered framebuffer numpy array.
        """
        t0 = time.perf_counter()
        defaults, shaders_src, lua_code = parse_obj2_script(script_path)
        compiled_shaders: Dict[str, Tuple[str, CompiledHLSL]] = {}
        for sname, scode in shaders_src.items():
            h = hashlib.sha256((sname + "::" + scode).encode("utf-8")).hexdigest()[:24]
            compiled_shaders[sname] = (h, self.gpu.compile_hlsl(sname, scode))

        params = dict(defaults)
        if param_overrides:
            for k, v in param_overrides.items():
                if k in defaults and isinstance(defaults[k], bool) and isinstance(v, (int, float)):
                    params[k] = bool(v)
                else:
                    params[k] = v

        # Fresh LuaJIT 2.1 VM (or reusable)
        lua = LuaRuntime(unpack_returned_tuples=True)
        g = lua.globals()

        # Allocate C-side pixeldata staging helper inside LuaJIT FFI
        lua.execute("""
        local ffi = require("ffi")
        _SANDBOX_PIXBUF = {}
        function _sandbox_alloc_pix(name, nbytes)
            local b = _SANDBOX_PIXBUF[name]
            if b == nil or b.n < nbytes then
                b = { cdata = ffi.new("uint8_t[?]", nbytes), n = nbytes }
                _SANDBOX_PIXBUF[name] = b
            end
            return b.cdata, tonumber(ffi.cast("uintptr_t", b.cdata))
        end
        function _sandbox_ptr_addr(p)
            return tonumber(ffi.cast("uintptr_t", p))
        end
        """)
        alloc_pix_lua = g._sandbox_alloc_pix
        ptr_addr_lua = g._sandbox_ptr_addr
        pix_ptrs: Dict[str, Tuple[Any, int, int, int]] = {}

        # Current object state
        state = {
            "drawtarget": "framebuffer",
            "blend": 0,
            "billboard": 0,
            "antialias": 1,
            "culling": 0,
            "sampler": "clamp",
            "font_name": "Noto Sans CJK JP",
            "font_size": 24,
            "font_type": 0,
            "font_col1": 0xFFFFFF,
            "font_col2": 0x000000,
            "pixelshader_calls": 0,
            "drawpoly_calls": 0,
            "drawpoly_verts": 0,
            "loaded_texts": [],
        }

        props = {
            "x": 0.0, "y": 0.0, "z": 0.0,
            "ox": 0.0, "oy": 0.0, "oz": 0.0,
            "rx": 0.0, "ry": 0.0, "rz": 0.0,
            "cx": 0.0, "cy": 0.0, "cz": 0.0,
            "zoom": 1.0,  # Note: obj.zoom in AviUtl2 is 1.0 = 100%, whereas getvalue("zoom") is 100.0!
            "alpha": 1.0,
            "aspect": 0.0,
            "time": 1.5,
            "totaltime": 10.0,
            "frame": 45,
            "totalframe": 300,
            "framerate": 30,
            "layer": 1,
            "index": 0,
            "num": 1,
            # Critical AviUtl2 fidelity: custom objects start with obj.w = 0, obj.h = 0 BEFORE obj.load / clearbuffer("object")!
            "w": 0,
            "h": 0,
            "screen_w": self.screen_w,
            "screen_h": self.screen_h,
        }
        if obj_props:
            props.update(obj_props)

        # Ensure default 1x1 "object" buffer exists internally, though obj.w/h remain 0 until loaded
        self.ensure_buffer("object", 1, 1, clear=True)

        obj_tbl = lua.table()
        for k, v in props.items():
            obj_tbl[k] = v

        def sync_obj_wh(w: int, h: int):
            obj_tbl["w"] = int(w)
            obj_tbl["h"] = int(h)

        def lua_table_to_floats(ltbl) -> List[float]:
            if ltbl is None:
                return []
            out = []
            idx = 1
            while True:
                v = ltbl[idx]
                if v is None:
                    break
                out.append(float(v))
                idx += 1
            return out

        def lua_table_to_strings(ltbl) -> List[str]:
            if ltbl is None:
                return []
            out = []
            idx = 1
            while True:
                v = ltbl[idx]
                if v is None:
                    break
                out.append(str(v))
                idx += 1
            return out

        def api_getvalue(*args):
            if len(args) == 1:
                key = str(args[0])
                if key == "zoom":
                    return float(obj_tbl["zoom"]) * 100.0
                if key in ("x", "y", "z", "rx", "ry", "rz", "cx", "cy", "cz", "alpha", "aspect"):
                    return float(obj_tbl[key])
                m_ex = re.match(r"^layer(\d+)$", key)
                if m_ex:
                    return int(m_ex.group(1)) in self.layers
                m = re.match(r"^layer(\d+)\.([a-zA-Z0-9_]+)$", key)
                if m:
                    ln = int(m.group(1))
                    attr = m.group(2)
                    lay = self.layers.get(ln)
                    if lay is None:
                        return None
                    if attr == "time":
                        return float(obj_tbl["time"])
                    return getattr(lay, attr, None)
                return None
            elif len(args) >= 3:
                ln_arg, fx_name, item_name = args[0], str(args[1]), str(args[2])
                if isinstance(ln_arg, str) and ln_arg.startswith("layer"):
                    ln = int(ln_arg.replace("layer", ""))
                else:
                    ln = int(ln_arg)
                lay = self.layers.get(ln)
                if lay is None:
                    return None
                fx = lay.effects.get(fx_name)
                if fx is None:
                    return None
                val = fx.get(item_name)
                # AviUtl2 realism: --color items are NOT returned by obj.getvalue unless explicitly numeric
                return val
            return None

        def api_getoption(name, *args):
            nm = str(name)
            if nm == "camera_mode":
                return self.camera_mode
            if nm == "camera_param":
                if self.camera_param is None:
                    return None
                t = lua.table()
                for k, v in self.camera_param.items():
                    t[k] = float(v)
                return t
            if nm == "multi_object":
                return False
            return None

        def api_setoption(name, val=None, *args):
            nm = str(name)
            if nm == "drawtarget":
                state["drawtarget"] = str(val)
            elif nm == "blend":
                state["blend"] = val
            elif nm == "billboard":
                state["billboard"] = int(val) if isinstance(val, (int, float)) else 0
            elif nm == "antialias":
                state["antialias"] = int(val) if isinstance(val, (int, float)) else 1
            elif nm == "culling":
                state["culling"] = int(val) if isinstance(val, (int, float)) else 0
            elif nm == "sampler":
                state["sampler"] = str(val)
            return True

        def api_clearbuffer(target, w=None, h=None, color=None):
            tname = str(target)
            if w is not None and h is not None:
                buf = self.ensure_buffer(tname, int(w), int(h), clear=True)
            else:
                cur = self.buffers.get(tname)
                bw = cur.w if cur else self.screen_w
                bh = cur.h if cur else self.screen_h
                buf = self.ensure_buffer(tname, bw, bh, clear=True)
            if tname == "object":
                sync_obj_wh(buf.w, buf.h)
            return True

        def api_copybuffer(dst_name, src_name):
            dn, sn = str(dst_name), str(src_name)
            src = self.buffers.get(sn)
            if src is None:
                return False
            if (dn == "framebuffer") != (sn == "framebuffer"):
                arr = self.read_numpy(sn)
                dst = self.upload_numpy(dn, arr)
            else:
                dst = self.ensure_buffer(dn, src.w, src.h, clear=False)
                enc = self.gpu.device.create_command_encoder()
                enc.copy_texture_to_texture(
                    {"texture": src.texture},
                    {"texture": dst.texture},
                    (src.w, src.h, 1),
                )
                self.gpu.device.queue.submit([enc.finish()])
            if dn == "object":
                sync_obj_wh(dst.w, dst.h)
            return True

        def api_getpixel():
            ob = self.buffers.get("object")
            if ob is None or int(obj_tbl["w"]) <= 0:
                return 0, 0
            return ob.w, ob.h

        def api_getpixeldata(target="object", fmt="rgba"):
            tname = str(target)
            buf = self.buffers.get(tname)
            if buf is None:
                return None, 0, 0
            arr = self.read_numpy(tname)
            nbytes = buf.w * buf.h * 4
            cdata, addr = alloc_pix_lua(tname, nbytes)
            ctypes.memmove(addr, arr.ctypes.data, nbytes)
            pix_ptrs[tname] = (cdata, addr, buf.w, buf.h)
            return cdata, buf.w, buf.h

        def api_putpixeldata(target, data_ptr, w=None, h=None, fmt="rgba"):
            tname = str(target)
            buf = self.buffers.get(tname)
            bw = int(w) if w is not None else (buf.w if buf else 0)
            bh = int(h) if h is not None else (buf.h if buf else 0)
            if bw <= 0 or bh <= 0:
                return False
            addr = int(ptr_addr_lua(data_ptr))
            nbytes = bw * bh * 4
            arr = np.empty((bh, bw, 4), dtype=np.uint8)
            ctypes.memmove(arr.ctypes.data, addr, nbytes)
            self.upload_numpy(tname, arr)
            if tname == "object":
                sync_obj_wh(bw, bh)
            return True

        def api_setfont(name="Noto Sans CJK JP", size=24, ftype=0, col1=0xFFFFFF, col2=0x000000):
            state["font_name"] = str(name)
            state["font_size"] = max(8, int(size))
            state["font_type"] = int(ftype) if ftype is not None else 0
            state["font_col1"] = int(col1) if col1 is not None else 0xFFFFFF
            state["font_col2"] = int(col2) if col2 is not None else 0x000000

        def api_load(kind, *args):
            k = str(kind)
            if k == "figure":
                fig_name = str(args[0]) if len(args) >= 1 else "円"
                col = int(args[1]) if len(args) >= 2 and args[1] is not None else 0xFFFFFF
                sz = int(args[2]) if len(args) >= 3 and args[2] is not None else 100
                arr = self.render_figure_rgba(fig_name, col, sz)
                self.upload_numpy("object", arr)
                sync_obj_wh(sz, sz)
                return True
            elif k == "layer":
                ln = int(args[0])
                lay = self.layers.get(ln)
                if lay is None or lay.rgba_image is None:
                    sync_obj_wh(0, 0)
                    return False
                self.upload_numpy("object", lay.rgba_image)
                sync_obj_wh(lay.rgba_image.shape[1], lay.rgba_image.shape[0])
                return True
            elif k == "image":
                p = str(args[0])
                if not os.path.isfile(p):
                    sync_obj_wh(0, 0)
                    return False
                im = Image.open(p).convert("RGBA")
                arr = np.asarray(im, dtype=np.float32)
                a = arr[..., 3:4] / 255.0
                arr[..., :3] = np.round(arr[..., :3] * a)
                u8 = np.clip(arr, 0, 255).astype(np.uint8)
                self.upload_numpy("object", u8)
                sync_obj_wh(u8.shape[1], u8.shape[0])
                return True
            elif k == "tempbuffer":
                tb = self.buffers.get("tempbuffer")
                if tb is None:
                    return False
                api_copybuffer("object", "tempbuffer")
                return True
            elif k == "text":
                txt = str(args[0]) if args else ""
                state["loaded_texts"].append(txt)
                lines = txt.splitlines() or [""]
                fsz = state["font_size"]
                try:
                    font = ImageFont.truetype("/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc", fsz)
                except Exception:
                    font = ImageFont.load_default()
                dummy = Image.new("RGBA", (8, 8), (0, 0, 0, 0))
                dd = ImageDraw.Draw(dummy)
                bboxes = [dd.textbbox((0, 0), ln_s, font=font) for ln_s in lines]
                tw = max(16, max((b[2] - b[0] for b in bboxes), default=16) + 12)
                th = max(16, len(lines) * (fsz + 6) + 10)
                im = Image.new("RGBA", (tw, th), (0, 0, 0, 0))
                dr = ImageDraw.Draw(im)
                c1 = state["font_col1"]
                r1, g1, b1 = (c1 >> 16) & 0xFF, (c1 >> 8) & 0xFF, c1 & 0xFF
                c2 = state["font_col2"]
                r2, g2, b2 = (c2 >> 16) & 0xFF, (c2 >> 8) & 0xFF, c2 & 0xFF
                y_cur = 4
                for ln_s in lines:
                    if state["font_type"] > 0:
                        for ox, oy in ((-1, 0), (1, 0), (0, -1), (0, 1)):
                            dr.text((6 + ox, y_cur + oy), ln_s, font=font, fill=(r2, g2, b2, 230))
                    dr.text((6, y_cur), ln_s, font=font, fill=(r1, g1, b1, 255))
                    y_cur += fsz + 6
                arr = np.asarray(im, dtype=np.float32)
                a = arr[..., 3:4] / 255.0
                arr[..., :3] = np.round(arr[..., :3] * a)
                u8 = np.clip(arr, 0, 255).astype(np.uint8)
                self.upload_numpy("object", u8)
                sync_obj_wh(tw, th)
                return True
            return False

        def api_pixelshader(ps_name, dst_name, res_tbl=None, const_tbl=None, blend_mode="copy", sampler_mode="clamp"):
            sname = str(ps_name)
            if sname not in compiled_shaders:
                return False
            spv_key, comp = compiled_shaders[sname]
            dst = self.buffers.get(str(dst_name))
            if dst is None:
                return False

            res_names = lua_table_to_strings(res_tbl)
            consts = lua_table_to_floats(const_tbl)
            bmode = str(blend_mode) if blend_mode is not None else "copy"
            smode = str(sampler_mode) if sampler_mode is not None else "clamp"
            uses_nearest = smode == "dot"
            bgl, pipe = self.gpu.get_ps_pipeline(comp, spv_key, bmode, uses_nearest)

            bg_entries = []
            if comp.has_cbuffer:
                # Pad uniform buffer to at least 64 float4s (1024 bytes) so any cbuffer size fits safely
                n_f = max(256, ((len(consts) + 3) // 4) * 4)
                carr = np.zeros(n_f, dtype=np.float32)
                if consts:
                    carr[: len(consts)] = consts
                cbuf = self.gpu.device.create_buffer_with_data(data=carr, usage=wgpu.BufferUsage.UNIFORM)
                bg_entries.append({"binding": 0, "resource": {"buffer": cbuf}})

            for slot in comp.tex_slots:
                if slot < len(res_names) and res_names[slot] in self.buffers:
                    tview = self.buffers[res_names[slot]].view
                else:
                    tview = self.gpu.dummy_view
                bg_entries.append({"binding": 10 + slot, "resource": tview})

            if comp.has_sampler:
                smp = self.gpu.samplers.get(smode, self.gpu.samplers["clamp"])
                bg_entries.append({"binding": 20, "resource": smp})

            bg = self.gpu.device.create_bind_group(layout=bgl, entries=bg_entries)
            enc = self.gpu.device.create_command_encoder()
            rp = enc.begin_render_pass(
                color_attachments=[{"view": dst.view, "load_op": "load", "store_op": "store"}]
            )
            rp.set_pipeline(pipe)
            rp.set_bind_group(0, bg)
            rp.draw(3)
            rp.end()
            self.gpu.device.queue.submit([enc.finish()])
            state["pixelshader_calls"] += 1
            return True

        def _resolve_blend():
            b = state["blend"]
            if b == "none":
                return "none_oit", True
            if b in (1, "add", "alpha_add"):
                return "add", False
            if b in (3, "screen"):
                return "screen", False
            return "normal", False

        def api_drawpoly(*args):
            if not args:
                return
            ob = self.buffers.get("object")
            if ob is None:
                return
            tw, th = max(1.0, float(ob.w)), max(1.0, float(ob.h))

            tris_pos = []
            tris_uv = []
            tris_col = []
            untextured_vcol = False
            poly_alpha = float(obj_tbl["alpha"])
            n_input_verts = 0

            if not isinstance(args[0], (int, float)):
                # AviUtl2 table overload: obj.drawpoly(verts_table [, n_prim=4 [, alpha=1.0]])
                vtbl = args[0]
                n_prim = int(args[1]) if len(args) >= 2 and args[1] is not None else 4
                if n_prim not in (3, 4):
                    n_prim = 4
                if len(args) >= 3 and args[2] is not None:
                    poly_alpha *= float(args[2])

                raw_verts = []
                idx = 1
                while True:
                    v = vtbl[idx]
                    if v is None:
                        break
                    raw_verts.append(v)
                    idx += 1
                n_input_verts = len(raw_verts)
                n_groups = n_input_verts // n_prim
                if n_groups <= 0:
                    return

                # Inspect first vertex length to detect {x,y,z,u,v} vs {x,y,z,r,g,b,a[,nx,ny,nz]} vs {x,y,z}
                v0 = raw_verts[0]
                vlen = 0
                while v0[vlen + 1] is not None:
                    vlen += 1

                if vlen >= 7:
                    untextured_vcol = True

                default_uvs4 = [(0.0, 0.0), (1.0, 0.0), (1.0, 1.0), (0.0, 1.0)]
                default_uvs3 = [(0.0, 0.0), (1.0, 0.0), (1.0, 1.0)]
                tri_indices = [(0, 1, 2), (0, 2, 3)] if n_prim == 4 else [(0, 1, 2)]

                for gi in range(n_groups):
                    gp = []
                    gu = []
                    gc = []
                    base_i = gi * n_prim
                    for k in range(n_prim):
                        vk = raw_verts[base_i + k]
                        gp.append((float(vk[1]), float(vk[2]), float(vk[3])))
                        if vlen >= 7:
                            gu.append((0.5, 0.5))
                            gc.append((float(vk[4]), float(vk[5]), float(vk[6]), float(vk[7])))
                        elif vlen >= 5:
                            # Table overload uses normalized [0, 1] UV coordinates!
                            gu.append((float(vk[4]), float(vk[5])))
                            gc.append((1.0, 1.0, 1.0, 1.0))
                        else:
                            gu.append(default_uvs4[k] if n_prim == 4 else default_uvs3[k])
                            gc.append((1.0, 1.0, 1.0, 1.0))
                    for i0, i1, i2 in tri_indices:
                        tris_pos.append((gp[i0], gp[i1], gp[i2]))
                        tris_uv.append((gu[i0], gu[i1], gu[i2]))
                        tris_col.append((gc[i0], gc[i1], gc[i2]))
            else:
                # Legacy scalar single-quad form: 12, 20, or 21 args (UVs in pixels 0..tw, 0..th)
                nums = [float(x) for x in args]
                qp = [
                    (nums[0], nums[1], nums[2]),
                    (nums[3], nums[4], nums[5]),
                    (nums[6], nums[7], nums[8]),
                    (nums[9], nums[10], nums[11]),
                ]
                if len(nums) >= 20:
                    qu = [
                        (nums[12] / tw, nums[13] / th),
                        (nums[14] / tw, nums[15] / th),
                        (nums[16] / tw, nums[17] / th),
                        (nums[18] / tw, nums[19] / th),
                    ]
                    if len(nums) >= 21:
                        poly_alpha *= nums[20]
                else:
                    qu = [(0.0, 0.0), (1.0, 0.0), (1.0, 1.0), (0.0, 1.0)]
                    if len(nums) >= 13:
                        poly_alpha *= nums[12]
                qc = [(1.0, 1.0, 1.0, 1.0)] * 4
                for i0, i1, i2 in ((0, 1, 2), (0, 2, 3)):
                    tris_pos.append((qp[i0], qp[i1], qp[i2]))
                    tris_uv.append((qu[i0], qu[i1], qu[i2]))
                    tris_col.append((qc[i0], qc[i1], qc[i2]))
                n_input_verts = 4

            tri_pos_np = np.array(tris_pos, dtype=np.float64)  # (T, 3, 3)
            tri_uv_np = np.array(tris_uv, dtype=np.float32)    # (T, 3, 2)
            tri_col_np = np.array(tris_col, dtype=np.float32)  # (T, 3, 4)

            target_name = state["drawtarget"]
            if target_name not in self.buffers:
                self.ensure_buffer(target_name, self.screen_w, self.screen_h, clear=True)
            dst_buf = self.buffers[target_name]

            blend_key, shader118_none = _resolve_blend()
            ox = float(obj_tbl["x"]) + float(obj_tbl["ox"] or 0.0)
            oy = float(obj_tbl["y"]) + float(obj_tbl["oy"] or 0.0)
            oz = float(obj_tbl["z"]) + float(obj_tbl["oz"] or 0.0)

            if target_name != "framebuffer" or self.camera_mode == 0:
                # 2D canvas coordinates centered at (dst_w/2, dst_h/2)
                zm = float(obj_tbl["zoom"])
                px = tri_pos_np[..., 0] * zm + ox
                py = tri_pos_np[..., 1] * zm + oy
                ndc_x = px / (0.5 * dst_buf.w)
                ndc_y = -py / (0.5 * dst_buf.h)
                clip4 = np.zeros((tri_pos_np.shape[0], 3, 4), dtype=np.float32)
                clip4[..., 0] = ndc_x
                clip4[..., 1] = ndc_y
                clip4[..., 2] = 0.0
                clip4[..., 3] = 1.0
                vbuf_data = np.concatenate(
                    [clip4.reshape(-1, 4), tri_uv_np.reshape(-1, 2), tri_col_np.reshape(-1, 4)], axis=-1
                ).astype(np.float32)
                self._submit_poly_draw(
                    target_name=target_name, src_name="object", vbuf_data=vbuf_data,
                    blend_key=blend_key, shader118_none=shader118_none, poly_alpha=poly_alpha,
                    use_depth=False, depth_write=False, sampler_mode=state["sampler"],
                    untextured_vcol=untextured_vcol,
                )
            else:
                # 3D world transformation matching AviUtl2
                rx, ry, rz = float(obj_tbl["rx"]), float(obj_tbl["ry"]), float(obj_tbl["rz"])
                cx, cy, cz = float(obj_tbl["cx"]), float(obj_tbl["cy"]), float(obj_tbl["cz"])
                zm = float(obj_tbl["zoom"])

                loc = (tri_pos_np - np.array([cx, cy, cz])) * zm
                if state["billboard"] == 3:
                    _, cam_r, cam_d, cam_f, _ = parse_camera_basis(self.camera_param, self.screen_w, self.screen_h)
                    wld = (
                        loc[..., 0:1] * cam_r[None, None, :]
                        + loc[..., 1:2] * cam_d[None, None, :]
                        + loc[..., 2:3] * cam_f[None, None, :]
                        + np.array([ox, oy, oz])[None, None, :]
                    )
                else:
                    wld = rot_xyz_np(loc, rx, ry, rz) + np.array([ox, oy, oz])[None, None, :]

                vbuf_data = self.project_world_triangles(wld, tri_uv_np, tri_col_np)
                if vbuf_data is not None:
                    self._submit_poly_draw(
                        target_name="framebuffer", src_name="object", vbuf_data=vbuf_data,
                        blend_key=blend_key, shader118_none=shader118_none, poly_alpha=poly_alpha,
                        use_depth=True, depth_write=False, sampler_mode=state["sampler"],
                        untextured_vcol=untextured_vcol,
                    )

            state["drawpoly_calls"] += 1
            state["drawpoly_verts"] += n_input_verts

        def api_draw(dx=0.0, dy=0.0, dz=0.0, zoom=1.0, alpha=1.0, rx=0.0, ry=0.0, rz=0.0):
            ob = self.buffers.get("object")
            if ob is None or int(obj_tbl["w"]) <= 0:
                return
            hw = 0.5 * ob.w * float(zoom)
            hh = 0.5 * ob.h * float(zoom)
            x0, y0 = float(dx) - hw, float(dy) - hh
            x1, y1 = float(dx) + hw, float(dy) + hh
            z0 = float(dz)
            saved_cam = self.camera_mode
            # HUD text draws in 2D screen space when called after setfont/load("text")
            self.camera_mode = 0
            try:
                api_drawpoly(
                    x0, y0, z0, x1, y0, z0, x1, y1, z0, x0, y1, z0,
                    0.0, 0.0, ob.w, 0.0, ob.w, ob.h, 0.0, ob.h, float(alpha),
                )
            finally:
                self.camera_mode = saved_cam

        def api_module(mod_name):
            return None

        def api_rand(st_min, st_max, seed=0, frame=0):
            lo, hi = int(st_min), int(st_max)
            if hi <= lo:
                return lo
            h = ((int(seed) * 1103515245 + int(frame) * 12345 + int(obj_tbl["index"]) * 2654435761) & 0x7FFFFFFF)
            return lo + (h % (hi - lo + 1))

        wrap_lua_fn = lua.eval("function(pyfn) return function(...) return pyfn(...) end end")
        obj_tbl["getvalue"] = wrap_lua_fn(api_getvalue)
        obj_tbl["getoption"] = wrap_lua_fn(api_getoption)
        obj_tbl["setoption"] = wrap_lua_fn(api_setoption)
        obj_tbl["clearbuffer"] = wrap_lua_fn(api_clearbuffer)
        obj_tbl["copybuffer"] = wrap_lua_fn(api_copybuffer)
        obj_tbl["getpixel"] = wrap_lua_fn(api_getpixel)
        obj_tbl["getpixeldata"] = wrap_lua_fn(api_getpixeldata)
        obj_tbl["putpixeldata"] = wrap_lua_fn(api_putpixeldata)
        obj_tbl["setfont"] = wrap_lua_fn(api_setfont)
        obj_tbl["load"] = wrap_lua_fn(api_load)
        obj_tbl["pixelshader"] = wrap_lua_fn(api_pixelshader)
        obj_tbl["drawpoly"] = wrap_lua_fn(api_drawpoly)
        obj_tbl["draw"] = wrap_lua_fn(api_draw)
        obj_tbl["module"] = wrap_lua_fn(api_module)
        obj_tbl["rand"] = wrap_lua_fn(api_rand)

        g["obj"] = obj_tbl
        for k, v in params.items():
            g[k] = v
        if lua_globals_extra:
            for k, v in lua_globals_extra.items():
                g[k] = v

        lua.execute(lua_code)
        dt_ms = (time.perf_counter() - t0) * 1000.0
        fb = self.read_numpy("framebuffer")
        return {
            "framebuffer": fb,
            "elapsed_ms": dt_ms,
            "pixelshader_calls": state["pixelshader_calls"],
            "drawpoly_calls": state["drawpoly_calls"],
            "drawpoly_verts": state["drawpoly_verts"],
            "loaded_texts": state["loaded_texts"],
            "peak_cache_dots": self.peak_cache_dots,
        }
