#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v3.06 patch: silhouette audit + dual-mode load fallback for 2D occluders.
Byte-exact CRLF-preserving replacements with strict count assertions."""
import pathlib
import sys

SRC = pathlib.Path("/home/user/GitHub_VolumetricLight3D/Script/体積光（3D）.obj2")
txt = SRC.read_bytes().decode("utf-8")

def rep(old, new, count=1):
    global txt
    n = txt.count(old)
    assert n == count, f"anchor x{n} (want {count}): {old[:80]!r}"
    txt = txt.replace(old, new)

# ---------- P1: information header version ----------
rep("--information:体積光（3D）v3.05\r\n", "--information:体積光（3D）v3.06\r\n")

# ---------- P2: Japanese file-header update notes (standing rule) ----------
rep(
    "-- v3.05 更新点（2026-10-24・非0フレーム開始クリップ＆サブシーンにおける遮蔽判定「0hit」不具合の根治）：\r\n",
    "-- v3.06 更新点（2026-10-24・特定レイヤー構成で遮蔽影が矩形黒塊・輪郭崩れ・点滅する不具合への多層防御）：\r\n"
    "--   1. 【遮蔽マスク「シルエット監査」と自動フォールバック（audit_object_alpha）】\r\n"
    "--      ・公式 Lua リファレンス既知の制限「obj.load(\"layer\", no, effect) は個別オブジェクト等の\r\n"
    "--        エフェクト側で描画処理が入る場合は上手く動作しない場合がある」への実用的な防御。\r\n"
    "--        効果付き読み込み（effect=true）の結果がほぼ全面不透明のベタ矩形（αカバレッジ ≥ 98.5%）だった\r\n"
    "--        場合のみ効果なし読み込み（effect=false）を自動再試行し、シルエットが有意に改善する\r\n"
    "--        （カバレッジ差 ≥ 12%）なら効果なし側を採用。どちらも同程度に不透明なら「本当に不透明な画像」と\r\n"
    "--        して従来通り扱い、HUD の遮蔽表示に `,opq` フラグを追加（自分で原因を特定できる！）。\r\n"
    "--      ・監査は obj.getpixeldata ポインタの疎格子サンプリング（最大 64x64 点・pcall 完全防護）で、\r\n"
    "--        監査不能な環境では従来挙動のまま完全に透過的（定常コストほぼゼロ）。\r\n"
    "--   2. 【ドラッグキャッシュ整合強化】\r\n"
    "--      ・occ2d キャッシュキーへ読み込みモード（fx/raw）を、保存タイルへ load_mode を反映し、\r\n"
    "--        読み込みモードが変化した際の古いマスク誤復元（ドラッグ中の点滅）を防止。\r\n"
    "--\r\n"
    "-- v3.05 更新点（2026-10-24・非0フレーム開始クリップ＆サブシーンにおける遮蔽判定「0hit」不具合の根治）：\r\n"
)

# ---------- P3: audit_object_alpha function ----------
rep(
    "local function preview_shadow_budget(nt)\r\n",
    "-- v3.06: 現在の \"object\" バッファの α カバレッジを疎格子サンプリングで推定するシルエット監査。\r\n"
    "-- 公式ドキュメント既知の「obj.load(\"layer\", no, effect) がエフェクト側描画で不正な結果を返す」ケース\r\n"
    "-- （全面不透明のベタ矩形化など）を検出する。監査不能時は nil を返し挙動は従来通り。\r\n"
    "local function audit_object_alpha(ow, oh)\r\n"
    "    if type(obj.getpixeldata) ~= \"function\" then return nil end\r\n"
    "    local ok_a, cov = pcall(function()\r\n"
    "        local ok_ffi, ffi = pcall(require, \"ffi\")\r\n"
    "        if not ok_ffi or ffi == nil then return nil end\r\n"
    "        local p, pw, ph = obj.getpixeldata(\"object\", \"rgba\")\r\n"
    "        if p == nil then return nil end\r\n"
    "        local w = (type(pw) == \"number\" and pw > 0) and pw or ow\r\n"
    "        local h = (type(ph) == \"number\" and ph > 0) and ph or oh\r\n"
    "        if type(w) ~= \"number\" or type(h) ~= \"number\" or w < 4 or h < 4 or w * h > 268435456 then return nil end\r\n"
    "        local px = ffi.cast(\"const uint8_t*\", p)\r\n"
    "        local nx = w < 64 and w or 64\r\n"
    "        local ny = h < 64 and h or 64\r\n"
    "        local hit, tot = 0, 0\r\n"
    "        for j = 0, ny - 1 do\r\n"
    "            local row = math.floor((j + 0.5) * h / ny) * w * 4\r\n"
    "            for i = 0, nx - 1 do\r\n"
    "                local a = px[row + math.floor((i + 0.5) * w / nx) * 4 + 3]\r\n"
    "                tot = tot + 1\r\n"
    "                if a > 12 then hit = hit + 1 end\r\n"
    "            end\r\n"
    "        end\r\n"
    "        return hit / tot\r\n"
    "    end)\r\n"
    "    if ok_a and type(cov) == \"number\" then return cov end\r\n"
    "    return nil\r\n"
    "end\r\n"
    "\r\n"
    "local function preview_shadow_budget(nt)\r\n"
)

# ---------- P4: occ2d_key gains load_mode ----------
rep(
    "        parts[#parts + 1] = string.format(\"%d:%.3f:%d:%.2f:%.2f:%.1f:%.1f\",\r\n"
    "            c.layer, c.alpha or 1, c.is_text and 1 or 0,\r\n"
    "            c.align_fx or 0, c.align_fy or 0, c.pad_r or 0, c.pad_b or 0)\r\n",
    "        parts[#parts + 1] = string.format(\"%d:%.3f:%d:%.2f:%.2f:%.1f:%.1f:%s\",\r\n"
    "            c.layer, c.alpha or 1, c.is_text and 1 or 0,\r\n"
    "            c.align_fx or 0, c.align_fy or 0, c.pad_r or 0, c.pad_b or 0, c.load_mode or \"fx\")\r\n"
)

# ---------- P5: per-occluder load + audit + fallback ----------
rep(
    "                    local ow, oh = cd.pre_w or 0, cd.pre_h or 0\r\n"
    "                    if ow <= 0 then\r\n"
    "                        pcall(function() obj.load(\"layer\", cd.layer, true) end)\r\n"
    "                        pcall(function() ow, oh = obj.getpixel() end)\r\n"
    "                        if type(ow) ~= \"number\" or ow <= 0 then\r\n"
    "                            pcall(function() obj.load(\"layer\", cd.layer) end)\r\n"
    "                            pcall(function() ow, oh = obj.getpixel() end)\r\n"
    "                        end\r\n"
    "                    end\r\n"
    "                    if type(ow) == \"number\" and ow > 0 and type(oh) == \"number\" and oh > 0 then\r\n"
    "                        local ti = packed_n\r\n",
    "                    local ow, oh = cd.pre_w or 0, cd.pre_h or 0\r\n"
    "                    local load_src = \"fx\"\r\n"
    "                    if ow <= 0 then\r\n"
    "                        pcall(function() obj.load(\"layer\", cd.layer, true) end)\r\n"
    "                        pcall(function() ow, oh = obj.getpixel() end)\r\n"
    "                        if type(ow) ~= \"number\" or ow <= 0 then\r\n"
    "                            pcall(function() obj.load(\"layer\", cd.layer) end)\r\n"
    "                            pcall(function() ow, oh = obj.getpixel() end)\r\n"
    "                            load_src = \"raw\"\r\n"
    "                        end\r\n"
    "                    end\r\n"
    "                    if type(ow) == \"number\" and ow > 0 and type(oh) == \"number\" and oh > 0 then\r\n"
    "                        -- v3.06: シルエット監査 —— effect=true 読み込みがほぼ全面不透明のベタ矩形を返した\r\n"
    "                        -- 場合（公式既知のエフェクト側描画の不定挙動）、効果なし読み込みへ自動フォールバック！\r\n"
    "                        local cov_cur = audit_object_alpha(ow, oh)\r\n"
    "                        if cov_cur ~= nil and cov_cur >= 0.985 and load_src == \"fx\" then\r\n"
    "                            local rw, rh = 0, 0\r\n"
    "                            pcall(function() obj.load(\"layer\", cd.layer) end)\r\n"
    "                            pcall(function() rw, rh = obj.getpixel() end)\r\n"
    "                            if type(rw) == \"number\" and rw > 0 and type(rh) == \"number\" and rh > 0 then\r\n"
    "                                local cov_raw = audit_object_alpha(rw, rh)\r\n"
    "                                if cov_raw ~= nil and cov_raw <= cov_cur - 0.12 then\r\n"
    "                                    ow, oh = rw, rh\r\n"
    "                                    load_src = \"raw\"\r\n"
    "                                    occ_stat(\"opaque_rect_fallback\")\r\n"
    "                                end\r\n"
    "                            end\r\n"
    "                            if load_src == \"fx\" then\r\n"
    "                                pcall(function() obj.load(\"layer\", cd.layer, true) end)\r\n"
    "                                pcall(function() ow, oh = obj.getpixel() end)\r\n"
    "                            end\r\n"
    "                        end\r\n"
    "                        cd.load_mode = load_src\r\n"
    "                        if cov_cur ~= nil and cov_cur >= 0.985 and load_src == \"fx\" then\r\n"
    "                            cd.opq_hint = true\r\n"
    "                        end\r\n"
    "                        local ti = packed_n\r\n"
)

# ---------- P6: drag path pre-stamps load_mode from saved tiles ----------
rep(
    "        local reused_2d = false\r\n"
    "        if dragging and VL_BF.want_2d_occ and #cands_2d > 0 then\r\n"
    "            local slot = try_restore_occ2d(cands_2d, cur_frame)\r\n",
    "        local reused_2d = false\r\n"
    "        if dragging and VL_BF.want_2d_occ and #cands_2d > 0 then\r\n"
    "            -- v3.06: 前回保存時の読み込みモード（fx/raw）を候補へ事前スタンプし、キャッシュキー不一致に\r\n"
    "            -- よるドラッグ中のマスク再構築ラグ（点滅）を防止。\r\n"
    "            local slot_pre = _VL_PERSIST.occ2d\r\n"
    "            if type(slot_pre) == \"table\" and type(slot_pre.tiles) == \"table\" then\r\n"
    "                for ci = 1, #cands_2d do\r\n"
    "                    for ti2 = 1, #slot_pre.tiles do\r\n"
    "                        if slot_pre.tiles[ti2].layer == cands_2d[ci].layer then\r\n"
    "                            cands_2d[ci].load_mode = slot_pre.tiles[ti2].load_mode\r\n"
    "                            break\r\n"
    "                        end\r\n"
    "                    end\r\n"
    "                end\r\n"
    "            end\r\n"
    "            local slot = try_restore_occ2d(cands_2d, cur_frame)\r\n"
)

# ---------- P7: saved tiles carry load_mode ----------
rep(
    "                            saved_tiles[#saved_tiles + 1] = {\r\n"
    "                                layer = cd.layer, ow = ow, oh = oh, w_raw = w_raw, h_raw = h_raw,\r\n"
    "                                x0 = x0, y0 = y0,\r\n"
    "                                tile_ox = tile_ox, tile_oy = tile_oy,\r\n"
    "                                inner_ox = inner_ox, inner_oy = inner_oy,\r\n"
    "                                atl_ox = atl_ox, atl_oy = atl_oy,\r\n"
    "                            }\r\n",
    "                            saved_tiles[#saved_tiles + 1] = {\r\n"
    "                                layer = cd.layer, ow = ow, oh = oh, w_raw = w_raw, h_raw = h_raw,\r\n"
    "                                x0 = x0, y0 = y0,\r\n"
    "                                tile_ox = tile_ox, tile_oy = tile_oy,\r\n"
    "                                inner_ox = inner_ox, inner_oy = inner_oy,\r\n"
    "                                atl_ox = atl_ox, atl_oy = atl_oy,\r\n"
    "                                load_mode = cd.load_mode or \"fx\",\r\n"
    "                            }\r\n"
)

# ---------- P8: HUD ,opq flag + raw * marker ----------
rep(
    "        else\r\n"
    "            VL_BF.occ_desc = \"0hit\"\r\n"
    "        end\r\n"
    "        if dragging and sh_tris_drawn > 0 then\r\n",
    "        else\r\n"
    "            VL_BF.occ_desc = \"0hit\"\r\n"
    "        end\r\n"
    "        -- v3.06: ほぼ全面不透明のマスク（本来のシルエットが取得できていない可能性）を HUD で可視化。\r\n"
    "        if #hit_names > 0 then\r\n"
    "            local any_opq = false\r\n"
    "            for qi = 1, #cands_2d do\r\n"
    "                if cands_2d[qi].opq_hint then any_opq = true end\r\n"
    "            end\r\n"
    "            if any_opq then VL_BF.occ_desc = VL_BF.occ_desc .. \",opq\" end\r\n"
    "        end\r\n"
    "        if dragging and sh_tris_drawn > 0 then\r\n"
)

rep('hit_names[#hit_names + 1] = "L" .. tostring(cd.layer)',
    'hit_names[#hit_names + 1] = "L" .. tostring(cd.layer) .. ((cd.load_mode == "raw") and "*" or "")',
    count=2)

# ---------- P9: remaining version strings ----------
for a, b in [
    ("[体積光 3D v3.05]", "[体積光 3D v3.06]"),
    ("[体积光 3D v3.05]", "[体积光 3D v3.06]"),
    ("[Volumetric Light 3D v3.05]", "[Volumetric Light 3D v3.06]"),
    ("[Volumenlicht 3D v3.05]", "[Volumenlicht 3D v3.06]"),
    ("体積光（3D）v3.05", "体積光（3D）v3.06"),
    ("体积光（3D）v3.05", "体积光（3D）v3.06"),
    ("Volumetric Light (3D) v3.05", "Volumetric Light (3D) v3.06"),
    ("Volumenlicht (3D) v3.05", "Volumenlicht (3D) v3.06"),
]:
    rep(a, b, count=txt.count(a))

out = txt.encode("utf-8")
SRC.write_bytes(out)
print("patched OK, bytes:", len(out))
print("bare LF count:", txt.replace("\r\n", "").count("\n"))
print("remaining v3.05 mentions:", txt.count("v3.05"))
