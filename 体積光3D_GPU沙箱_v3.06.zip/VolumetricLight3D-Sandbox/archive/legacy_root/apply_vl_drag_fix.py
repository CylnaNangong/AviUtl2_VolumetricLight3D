#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Patch the v2.90-bridge script so foreground-occlusion drags do not freeze AviUtl2.

Idempotent: a second run is a no-op once the marker is present.
Does not touch the v2.86 mainline.
"""
from __future__ import annotations

import pathlib
import sys

ROOT = pathlib.Path("/home/user")
SCRIPT = ROOT / "scripts/pkg1/体积光（3D）/development/branch_v2.90_aux2_bridge/Script/体積光（3D）.obj2"
MARKER = "-- [P0-drag] interactive occlusion budget"

HELPERS = r'''
-- [P0-drag] interactive occlusion budget
-- Dragging/scaling a foreground occluder invalidates the shadow signature on every
-- mouse sample. A full 1280^2 wire splat of a 30k+ triangle cage is hundreds of
-- milliseconds on the UI thread, and AviUtl2 does not coalesce those samples, so
-- Windows reports "Not Responding". While the same frame is being edited rapidly,
-- build a coarse preview (and reuse the 2D mask instead of obj.load). The first
-- non-drag call — mouse-up refresh, pause, scrub, playback — rebuilds full quality.
local function ensure_interact()
    local st = _VL_PERSIST.interact
    if type(st) ~= "table" then
        st = { last_t = -999.0, last_frame = nil, last_xform = nil, hot = false }
        _VL_PERSIST.interact = st
    end
    if type(_VL_PERSIST.occ2d) ~= "table" then
        _VL_PERSIST.occ2d = { key = nil, rgba = nil, w = 0, h = 0, cap = 0, tiles = nil }
    end
    if type(_VL_PERSIST.occ_stats) ~= "table" then
        _VL_PERSIST.occ_stats = {}
    end
    return st
end

local function occ_stat(key)
    local s = ensure_interact() and _VL_PERSIST.occ_stats
    s[key] = (s[key] or 0) + 1
end

local function occ_xform_sig(models_3d, cands_2d)
    local parts = {}
    for i = 1, #models_3d do
        local m = models_3d[i]
        parts[#parts + 1] = string.format(
            "3:%d:%.2f,%.2f,%.2f:%.3f,%.3f,%.3f:%.3f,%.3f,%.3f",
            m.layer, m.ox, m.oy, m.oz, m.Orx, m.Ory, m.Orz, m.ozx, m.ozy, m.ozz)
    end
    for i = 1, #cands_2d do
        local c = cands_2d[i]
        parts[#parts + 1] = string.format(
            "2:%d:%.2f,%.2f,%.2f:%.3f,%.3f,%.3f:%.3f,%.3f:%.3f",
            c.layer, c.ox, c.oy, c.oz, c.Orx, c.Ory, c.Orz, c.ozx, c.ozy, c.alpha or 1)
    end
    return table.concat(parts, ";")
end

local function occ2d_key(cands, frame)
    local parts = { tostring(frame or -1) }
    for i = 1, #cands do
        parts[#parts + 1] = string.format("%d:%.3f", cands[i].layer, cands[i].alpha or 1)
    end
    return table.concat(parts, "|")
end

-- now_opt is for tests; the host path uses os.clock().
local function occ_drag_query(xform_sig, cur_frame, now_opt)
    local st = ensure_interact()
    local now = now_opt
    if type(now) ~= "number" then
        now = (type(os) == "table" and type(os.clock) == "function") and os.clock() or 0.0
    end
    local same_frame = (cur_frame ~= nil and cur_frame == st.last_frame)
    local changed = (xform_sig ~= st.last_xform)
    -- Any same-frame transform edit is a drag. Playback and scrub change the frame
    -- and stay on the full-quality path. A later call with the same transform
    -- (mouse-up refresh, pause, play) also rebuilds at full quality.
    local dragging = same_frame and changed and st.last_xform ~= nil
    st.last_t = now
    st.last_frame = cur_frame
    st.last_xform = xform_sig
    st.hot = dragging
    return dragging
end

local function preview_shadow_budget(nt)
    nt = nt or 0
    local res = (nt > 25000) and 256 or 320
    local tri_cap = (nt > 20000) and 4000 or 7000
    return res, tri_cap, 48, 0.012
end

local function save_occ2d_atlas(src_name, w, h, key, tiles, uv_span_x, uv_span_y)
    local ok_ffi, ffi = pcall(require, "ffi")
    if not (ok_ffi and ffi ~= nil) or type(obj.getpixeldata) ~= "function" then return false end
    local saved = false
    pcall(function()
        local p, pw, ph = obj.getpixeldata(src_name, "rgba")
        if p == nil then return end
        local ww = (type(pw) == "number" and pw > 0) and pw or w
        local hh = (type(ph) == "number" and ph > 0) and ph or h
        if ww < 1 or hh < 1 or ww > 4096 or hh > 4096 then return end
        local nbytes = ww * hh * 4
        local slot = _VL_PERSIST.occ2d
        if (slot.cap or 0) < nbytes then
            slot.rgba = ffi.new("uint8_t[?]", nbytes)
            slot.cap = nbytes
        end
        ffi.copy(slot.rgba, p, nbytes)
        slot.w, slot.h = ww, hh
        slot.key = key
        slot.tiles = tiles
        slot.uv_span_x = uv_span_x
        slot.uv_span_y = uv_span_y
        saved = true
    end)
    return saved
end

local function try_restore_occ2d(cands, frame)
    local slot = _VL_PERSIST.occ2d
    if type(slot) ~= "table" or slot.rgba == nil or slot.key ~= occ2d_key(cands, frame) then
        return nil
    end
    if not upload_rgba_to_cache("cache:vl3d/occ_a", slot.rgba, slot.w, slot.h) then
        return nil
    end
    return slot
end

_G._VL3D_OCC_API = {
    drag_query = occ_drag_query,
    xform_sig = occ_xform_sig,
    occ2d_key = occ2d_key,
    preview_budget = preview_shadow_budget,
    ensure_interact = ensure_interact,
}

'''


def replace_once(src: str, old: str, new: str, label: str) -> str:
    n = src.count(old)
    if n != 1:
        raise SystemExit(f"{label}: expected 1 occurrence, found {n}")
    return src.replace(old, new, 1)


def apply(src: str) -> str:
    src = src.replace("\r\n", "\n")
    if MARKER in src:
        return src

    src = replace_once(
        src,
        "    return ok_up\nend\n\n-- 純 LuaJIT FFI 2D 三角形 MAX-proximity ラスタライザ",
        "    return ok_up\nend\n" + HELPERS + "\n-- 純 LuaJIT FFI 2D 三角形 MAX-proximity ラスタライザ",
        "insert helpers",
    )

    src = replace_once(
        src,
        "local function rasterize_tri_max(zbuf, row_min, row_max, w, h, x0, y0, p0, x1, y1, p1, x2, y2, p2, tag_bias, allow_wire_splat)",
        "local function rasterize_tri_max(zbuf, row_min, row_max, w, h, x0, y0, p0, x1, y1, p1, x2, y2, p2, tag_bias, allow_wire_splat, splat_cap)",
        "raster signature",
    )
    src = replace_once(
        src,
        "        local n_step = math.min(2048, math.max(1, math.ceil(math.max(math.abs(bx_e - ax), math.abs(by_e - ay)))))",
        "        local n_step = math.min(splat_cap or 2048, math.max(1, math.ceil(math.max(math.abs(bx_e - ax), math.abs(by_e - ay)))))",
        "splat cap",
    )

    src = replace_once(
        src,
        "    Wrx, Wry, Wrz, Wdx, Wdy, Wdz, Wnx, Wny, Wnz,\n    mode_kind, sx_p, sy_p, sz_p, u_wn, dS_wn, L_tot)\n",
        "    Wrx, Wry, Wrz, Wdx, Wdy, Wdz, Wnx, Wny, Wnz,\n    mode_kind, sx_p, sy_p, sz_p, u_wn, dS_wn, L_tot, preview_opt)\n",
        "shadow signature",
    )

    src = replace_once(
        src,
        "        return x_s, y_s, prox, z_front\n    end\n\n    local total_tris_in = 0\n    local max_nv = 0\n",
        """        return x_s, y_s, prox, z_front
    end

    local total_tris_in = 0
    local max_nv = 0
    local preview = (type(preview_opt) == "table")
    local preview_abort = false
    local t_stop = nil
    if preview and type(preview_opt.budget) == "number" and type(os) == "table" and type(os.clock) == "function" then
        t_stop = os.clock() + preview_opt.budget
    end
""",
        "preview clock",
    )

    src = replace_once(
        src,
        """        -- .obj の細いワイヤー等は間引かず全三角形描画、超高ポリ VRM のみ必要に応じて間引き
        local m_stride = (md.kind == "OBJ" and nt <= 60000) and 1 or stride

        for ti = 1, nt, m_stride do
""",
        """        -- .obj の細いワイヤー等は間引かず全三角形描画、超高ポリ VRM のみ必要に応じて間引き
        if preview_abort then break end
        local m_stride = (md.kind == "OBJ" and nt <= 60000) and 1 or stride
        local splat_cap = nil
        if preview then
            local cap_n = preview_opt.tri_cap or 6000
            m_stride = math.max(1, m_stride, math.ceil(nt / math.max(1, cap_n)))
            splat_cap = preview_opt.splat_cap or 48
        end

        for ti = 1, nt, m_stride do
            if t_stop ~= nil and (ti % 256 == 1) and os.clock() > t_stop then
                preview_abort = true
                break
            end
""",
        "preview stride",
    )

    # Only the two shadow-map raster calls (indented 28 spaces), not the camera-depth ones.
    old_call = "                            rasterize_tri_max(zbuf, row_min, row_max, sh_res, sh_res,"
    new_call = "                            rasterize_tri_max(zbuf, row_min, row_max, sh_res, sh_res, splat_cap,"
    # Wait, that would shift arguments. Pass splat_cap as the last extra arg at the call site instead.
    # Revert that idea — do not use new_call. We'll append splat_cap to the existing call's last line.

    src = replace_once(
        src,
        """                            rasterize_tri_max(zbuf, row_min, row_max, sh_res, sh_res,
                                px_arr[a], py_arr[a], pp_arr[a],
                                px_arr[b], py_arr[b], pp_arr[b],
                                px_arr[c], py_arr[c], pp_arr[c], 0.0, true)
""",
        """                            rasterize_tri_max(zbuf, row_min, row_max, sh_res, sh_res,
                                px_arr[a], py_arr[a], pp_arr[a],
                                px_arr[b], py_arr[b], pp_arr[b],
                                px_arr[c], py_arr[c], pp_arr[c], 0.0, true, splat_cap)
""",
        "shadow rast direct",
    )
    src = replace_once(
        src,
        """                                rasterize_tri_max(zbuf, row_min, row_max, sh_res, sh_res,
                                    q0x, q0y, q0p, q1x, q1y, q1p, q2x, q2y, q2p, 0.0, true)
""",
        """                                rasterize_tri_max(zbuf, row_min, row_max, sh_res, sh_res,
                                    q0x, q0y, q0p, q1x, q1y, q1p, q2x, q2y, q2p, 0.0, true, splat_cap)
""",
        "shadow rast clipped",
    )

    src = replace_once(
        src,
        "    if ok_up then\n        _rast_ws.sh_sig  = cur_sig\n",
        """    if preview then occ_stat("shadow_preview") else occ_stat("shadow_full") end
    if _VL_PERSIST.occ_stats ~= nil then
        _VL_PERSIST.occ_stats.last_sh_res = sh_res
        _VL_PERSIST.occ_stats.last_tris = tri_drawn
        _VL_PERSIST.occ_stats.last_preview = preview
    end
    if ok_up then
        _rast_ws.sh_sig  = cur_sig
""",
        "shadow stats",
    )

    if "_G._VL3D_OCC_API.build_shadow" not in src:
        src = replace_once(
            src,
            "-- カメラ視点深度マップ（純 LuaJIT FFI 32bit Z バッファ・VRM キャラクター識別フラグ付き）",
            "_G._VL3D_OCC_API.build_shadow = build_3d_shadow_map\n\n-- カメラ視点深度マップ（純 LuaJIT FFI 32bit Z バッファ・VRM キャラクター識別フラグ付き）",
            "export build_shadow",
        )

    src = replace_once(
        src,
        '"eff_occ_mode", "peak_m" }',
        '"eff_occ_mode", "peak_m", "interact_drag" }',
        "interact key",
    )
    src = replace_once(
        src,
        "local function vl_bf_occlusion()\n    -- 4) 複数前景オブジェクト",
        "local function vl_bf_occlusion()\n    VL_BF.interact_drag = false\n    -- 4) 複数前景オブジェクト",
        "clear drag flag",
    )

    src = replace_once(
        src,
        "        local live_occ_dots = 0\n\n        -- 4A) 2D レイヤー遮蔽アトラス構築\n        if VL_BF.want_2d_occ and #cands_2d > 0 then\n",
        """        local live_occ_dots = 0

        local xform_sig = occ_xform_sig(models_3d, cands_2d)
        local dragging = occ_drag_query(xform_sig, cur_frame)
        VL_BF.interact_drag = dragging

        -- 4A) 2D レイヤー遮蔽アトラス構築
        -- ドラッグ中は同一フレームのマスク画素を再利用し、obj.load("layer") を呼ばない。
        -- 位置・回転・拡縮は occ_flat のユニフォーム側で追従する（画素自体は変わらない）。
        local reused_2d = false
        if dragging and VL_BF.want_2d_occ and #cands_2d > 0 then
            local slot = try_restore_occ2d(cands_2d, cur_frame)
            if slot ~= nil and type(slot.tiles) == "table" then
                local by_layer = {}
                for ti = 1, #slot.tiles do
                    by_layer[slot.tiles[ti].layer] = slot.tiles[ti]
                end
                local packed_n = 0
                for idx = 1, #cands_2d do
                    local cd = cands_2d[idx]
                    local tile = by_layer[cd.layer]
                    if tile ~= nil and tile.inner_ox > 0 and tile.inner_oy > 0 and tile.atl_ox > 0 and tile.atl_oy > 0 then
                        packed_n = packed_n + 1
                        local OHx_eff = math.max(2.0, 0.5 * tile.ow * cd.ozx) * (tile.tile_ox / tile.inner_ox)
                        local OHy_eff = math.max(2.0, 0.5 * tile.oh * cd.ozy) * (tile.tile_oy / tile.inner_oy)
                        local b = (packed_n - 1) * 16
                        VL_BF.occ_flat[b + 1],  VL_BF.occ_flat[b + 2],  VL_BF.occ_flat[b + 3],  VL_BF.occ_flat[b + 4]  = cd.ox, cd.oy, cd.oz, 1.0 / (2.0 * OHx_eff)
                        VL_BF.occ_flat[b + 5],  VL_BF.occ_flat[b + 6],  VL_BF.occ_flat[b + 7],  VL_BF.occ_flat[b + 8]  = cd.Orx, cd.Ory, cd.Orz, 1.0 / (2.0 * OHy_eff)
                        VL_BF.occ_flat[b + 9],  VL_BF.occ_flat[b + 10], VL_BF.occ_flat[b + 11], VL_BF.occ_flat[b + 12] = cd.Odx, cd.Ody, cd.Odz, tile.x0 / tile.atl_ox
                        VL_BF.occ_flat[b + 13], VL_BF.occ_flat[b + 14], VL_BF.occ_flat[b + 15], VL_BF.occ_flat[b + 16] = cd.Onx, cd.Ony, cd.Onz, tile.y0 / tile.atl_oy
                        hit_names[#hit_names + 1] = "L" .. tostring(cd.layer)
                    end
                end
                if packed_n > 0 then
                    VL_BF.occ_tex_name = "cache:vl3d/occ_a"
                    VL_BF.n_occ_active = packed_n
                    VL_BF.uv_span_x = slot.uv_span_x or 1.0
                    VL_BF.uv_span_y = slot.uv_span_y or 1.0
                    live_occ_dots = live_occ_dots + slot.w * slot.h
                    reused_2d = true
                    occ_stat("layer_load_skipped")
                end
            end
        end
        if (not reused_2d) and VL_BF.want_2d_occ and #cands_2d > 0 then
""",
        "2d drag reuse",
    )

    src = replace_once(
        src,
        "                local packed_n = 0\n                for idx = 1, #cands_2d do\n                    local cd = cands_2d[idx]\n                    local ow, oh = cd.pre_w or 0, cd.pre_h or 0\n",
        "                local packed_n = 0\n                local saved_tiles = {}\n                for idx = 1, #cands_2d do\n                    local cd = cands_2d[idx]\n                    local ow, oh = cd.pre_w or 0, cd.pre_h or 0\n",
        "saved tiles",
    )
    src = replace_once(
        src,
        """                            hit_names[#hit_names + 1] = "L" .. tostring(cd.layer)
                        end
                    end
                end
""",
        """                            hit_names[#hit_names + 1] = "L" .. tostring(cd.layer)
                            saved_tiles[#saved_tiles + 1] = {
                                layer = cd.layer, ow = ow, oh = oh, x0 = x0, y0 = y0,
                                tile_ox = tile_ox, tile_oy = tile_oy,
                                inner_ox = inner_ox, inner_oy = inner_oy,
                                atl_ox = atl_ox, atl_oy = atl_oy,
                            }
                        end
                    end
                end
""",
        "record tiles",
    )
    src = replace_once(
        src,
        """                    VL_BF.uv_span_x    = tile_ox / atl_ox
                    VL_BF.uv_span_y    = tile_oy / atl_oy
                else
""",
        """                    VL_BF.uv_span_x    = tile_ox / atl_ox
                    VL_BF.uv_span_y    = tile_oy / atl_oy
                    if (_VL_PERSIST.reentered or 0) == 0 then
                        save_occ2d_atlas(src_p, atl_ox, atl_oy, occ2d_key(cands_2d, cur_frame), saved_tiles, VL_BF.uv_span_x, VL_BF.uv_span_y)
                    else
                        VL_BF.n_occ_active = 0
                        occ_stat("layer_load_reentered")
                    end
                    occ_stat("layer_load")
                else
""",
        "save atlas",
    )

    src = replace_once(
        src,
        """                local want_sh = (P.res_mode == 0) and 1536 or ((P.res_mode == 2) and 896 or 1280)
                local ok_sh, n_tr = build_3d_shadow_map(
                    models_3d, want_sh, VL_BF.wx, VL_BF.wy, VL_BF.wz, VL_BF.Hx, VL_BF.Hy,
                    VL_BF.Wrx, VL_BF.Wry, VL_BF.Wrz, VL_BF.Wdx, VL_BF.Wdy, VL_BF.Wdz, VL_BF.Wnx, VL_BF.Wny, VL_BF.Wnz,
                    VL_BF.mode_kind, VL_BF.sx_p, VL_BF.sy_p, VL_BF.sz_p, VL_BF.u_wn, VL_BF.dS_wn, VL_BF.L_tot
                )
""",
        """                local want_sh = (P.res_mode == 0) and 1536 or ((P.res_mode == 2) and 896 or 1280)
                local preview_opt = nil
                if dragging then
                    local nt_all = 0
                    for mi = 1, #models_3d do
                        nt_all = nt_all + (models_3d[mi].mesh.nt or 0)
                    end
                    local pres, tri_cap, splat_cap, budget = preview_shadow_budget(nt_all)
                    if want_sh > pres then want_sh = pres end
                    preview_opt = { tri_cap = tri_cap, splat_cap = splat_cap, budget = budget }
                end
                local ok_sh, n_tr = build_3d_shadow_map(
                    models_3d, want_sh, VL_BF.wx, VL_BF.wy, VL_BF.wz, VL_BF.Hx, VL_BF.Hy,
                    VL_BF.Wrx, VL_BF.Wry, VL_BF.Wrz, VL_BF.Wdx, VL_BF.Wdy, VL_BF.Wdz, VL_BF.Wnx, VL_BF.Wny, VL_BF.Wnz,
                    VL_BF.mode_kind, VL_BF.sx_p, VL_BF.sy_p, VL_BF.sz_p, VL_BF.u_wn, VL_BF.dS_wn, VL_BF.L_tot,
                    preview_opt
                )
""",
        "preview call",
    )

    src = replace_once(
        src,
        """        else
            VL_BF.occ_desc = "0hit"
        end
    end
    end
""",
        """        else
            VL_BF.occ_desc = "0hit"
        end
        if dragging and sh_tris_drawn > 0 then
            VL_BF.occ_desc = VL_BF.occ_desc .. ",preview"
        end
    end
    end

    -- ドラッグ中はスライスを 1 チャンクに抑え、GPU パスもマウスサンプルに追いつかせる。
    -- 停止・再生・スクラブの次呼び出しは interact_drag が立たないのでフルスライスに戻る。
    if VL_BF.interact_drag and type(VL_BF.total_sl) == "number" and VL_BF.total_sl > 64
        and type(VL_BF.s_max) == "number" and type(VL_BF.s_min) == "number" then
        VL_BF.total_sl = 64
        VL_BF.dz = math.max(1.0, (VL_BF.s_max - VL_BF.s_min) / VL_BF.total_sl)
    end
""",
        "slice cap",
    )

    src = replace_once(
        src,
        """            print("@info", string.format(
                log_fmt,
                tostring(VL_BF.ps_ok), VL_BF.src_desc, VL_BF.occ_desc, VL_BF.aw or 0, VL_BF.ah or 0, VL_BF.n_chunks, VL_BF.total_sl, VL_BF.dz, VL_BF.total_v, VL_BF.base_ratio, VL_BF.peak_m
            ) .. (VL_BF.cam_mode2_note or ""))
""",
        """            local msg = string.format(
                log_fmt,
                tostring(VL_BF.ps_ok), VL_BF.src_desc, VL_BF.occ_desc, VL_BF.aw or 0, VL_BF.ah or 0, VL_BF.n_chunks, VL_BF.total_sl, VL_BF.dz, VL_BF.total_v, VL_BF.base_ratio, VL_BF.peak_m
            ) .. (VL_BF.cam_mode2_note or "")
            -- 同一文の連続出力はログ窓の再描画だけで UI を止める（ドラッグ中に実測で洪水になる）。
            local now_l = (type(os) == "table" and type(os.clock) == "function") and os.clock() or 0.0
            local recent = (now_l - (_VL_PERSIST.last_log_t or -999.0)) < 0.40
            local same = (_VL_PERSIST.last_log == msg)
            -- Identical lines, and any line during a drag, print at most once per 0.4s.
            if not ((same or VL_BF.interact_drag) and recent) then
                print("@info", msg)
                _VL_PERSIST.last_log = msg
                _VL_PERSIST.last_log_t = now_l
            end
""",
        "log throttle",
    )

    src = replace_once(
        src,
        """local ok, err = pcall(beam_frame)
if not ok then
    release_work_caches()
    pcall(function() obj.setoption("draw_state", true) end)
    pcall(function() print("@error", "Volumetric Light (3D) v2.90 error: " .. tostring(err)) end)
end
""",
        """local function vl_run_frame()
    -- obj.load("layer") / framebuffer 取样がドラッグ中に自分自身を再入させない。
    if _VL_PERSIST.in_beam then
        _VL_PERSIST.reentered = (_VL_PERSIST.reentered or 0) + 1
        return false
    end
    _VL_PERSIST.in_beam = true
    _VL_PERSIST.reentered = 0
    local ok, err = pcall(beam_frame)
    _VL_PERSIST.in_beam = false
    if not ok then
        release_work_caches()
        pcall(function() obj.setoption("draw_state", true) end)
        pcall(function() print("@error", "Volumetric Light (3D) v2.91 error: " .. tostring(err)) end)
    end
    return ok
end

vl_run_frame()
""",
        "reentrancy wrapper",
    )

    src = src.replace("v2.90", "v2.91")
    # Version bump rewrites the builder banner. Replace that short banner with the
    # same 更新点 block the delivered script carries. Keep the literal v2.90 heading.
    banner = (
        "-- v2.91-bridge 分支（不并入 v2.86 主线）：\n"
        "--   · 独立 VL3DBridge.aux2 只读桥接（PE TimeDateStamp/SHA-256 白名单，不匹配即降级）\n"
        "--   · 删除 gbuf+0xA0 宿主写；模式 2 改为峰值增益补偿\n"
        "--   · Lua 回退路径合入 M-02..M-12；帧缓冲优先 obj.copybuffer\n"
        "--   · P0-8：beam_frame() 拆为 6 个阶段函数，活跃 local 远低于 60\n"
        "--\n"
    )
    header = open("/home/user/sandbox/vl_v291_header.txt", encoding="utf-8").read()
    if not header.endswith("\n"):
        header += "\n"
    if banner not in src:
        raise SystemExit("branch banner missing; header history was not written")
    src = src.replace(banner, header, 1)
    if "v2.91 更新点" not in src or "v2.90-bridge 更新点" not in src:
        raise SystemExit("update history header missing")
    if MARKER not in src:
        raise SystemExit("marker missing after patch")
    if "vl_run_frame" not in src:
        raise SystemExit("wrapper missing")
    return src


def main() -> None:
    raw = SCRIPT.read_bytes()
    text = raw.decode("utf-8").replace("\r\n", "\n")
    patched = apply(text)
    if patched != text:
        SCRIPT.write_bytes(patched.replace("\n", "\r\n").encode("utf-8"))
        print(f"patched {SCRIPT} bytes={SCRIPT.stat().st_size}")
    else:
        print("already patched")


if __name__ == "__main__":
    main()
