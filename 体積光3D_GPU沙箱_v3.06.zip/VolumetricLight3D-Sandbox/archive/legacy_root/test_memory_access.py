#!/usr/bin/env python3
"""
AviUtl2 三款 3D 脚本 — 硬件级内存访问安全审计与沙盒实证测试套件
==================================================================
使用真实 LuaJIT 2.1 FFI + Linux 内核 MMU 硬件保护页 (mmap + mprotect PROT_NONE/PROT_READ)
+ 内核态安全拷贝 (process_vm_readv 镜像 Windows NtReadVirtualMemory/ReadProcessMemory)
+ pthread 并发页解映射 (复现多线程 TOCTOU 竞争崩溃)
对《体积光（3D）》v2.81 / v2.85_未完成草稿、《体积雾（3D）》v2.01、《雪（3D）》v1.15/v1.18
的全部内存访问路径进行逐项实证测试与补丁前后对比验证。
"""

import json
import os
import re
import signal
import struct
import subprocess
import tempfile
import time
from pathlib import Path

ROOT = Path("/home/user")
SANDBOX = ROOT / "sandbox"
LIBGUARD = SANDBOX / "libguard_w32.so"
VL_V281 = ROOT / "scripts/pkg1/体积光（3D）/stable/Script/体積光（3D）.obj2"
VL_V285 = ROOT / "scripts/pkg1/体积光（3D）/development/禁止安装_未完成草稿/体積光（3D）_v2.85_未完成草稿.obj2"
FOG_V201 = ROOT / "scripts/pkg2/体积雾（3D）/stable/Script/体積霧（3D）.obj2"
SNOW_V115 = ROOT / "scripts/pkg3/雪（3D）/stable/Script/雪（3D）.obj2"
SNOW_V118 = ROOT / "scripts/pkg3/雪（3D）/development/雪（3D）_v1.18_修正候选.obj2"
OUT_JSON = SANDBOX / "results/memory_audit_metrics.json"


def build_vl_harness_lua(obj2_path: Path, is_v285: bool = False) -> str:
    """Slice exact unmodified Lua memory/FFI subsystem from 体積光（3D）.obj2 up to beam_frame()."""
    lines = obj2_path.read_text(encoding="utf-8", errors="replace").splitlines()
    start_idx = None
    end_idx = None
    for idx, ln in enumerate(lines):
        if start_idx is None and ln.startswith("local obj, math = obj, math"):
            start_idx = idx
        if ln.startswith("local function beam_frame()"):
            end_idx = idx
            break
    assert start_idx is not None and end_idx is not None, f"Slice markers missing in {obj2_path}"
    core = "\n".join(lines[start_idx:end_idx])
    extra_exports = "is_hardware_shadow_pass = is_hardware_shadow_pass," if is_v285 else ""
    prelude = r'''
local ffi = require("ffi")
ffi.os = "Windows"
ffi.cdef[[
typedef struct {
    uintptr_t raw_map;
    size_t    raw_len;
    uintptr_t usable_base;
    size_t    usable_len;
    uintptr_t ptr;
} guard_alloc_t;

void      gw_reset_regions(void);
void      gw_set_exe_base(uintptr_t base);
void      gw_register_region(uintptr_t base, size_t size, uint32_t state, uint32_t protect, uint32_t type);
int       gw_guard_alloc(size_t exact_len, int align_end, guard_alloc_t* out);
int       gw_protect(uintptr_t addr, size_t len, int prot_flags);
void      gw_guard_free(const guard_alloc_t* a);
void      gw_arm_toctou(uintptr_t target_base, uintptr_t decommit_ptr, size_t decommit_len, int delay_us);
int       gw_did_toctou_fire(void);

size_t    mock_VirtualQuery(const void* lpAddress, void* lpBuffer, size_t dwLength);
intptr_t  mock_GetCurrentProcess(void);
uintptr_t mock_GetModuleHandleW(const uint16_t* name);
int32_t   mock_ReadProcessMemory(intptr_t hProcess, const void* lpBaseAddress, void* lpBuffer, size_t nSize, size_t* lpNumberOfBytesRead);

void      gw_reset_handles(int64_t mock_file_sz);
int       gw_get_open_handles(void);
int       gw_get_closed_handles(void);
intptr_t  mock_CreateFileW(const uint16_t* path, uint32_t acc, uint32_t share, void* sa, uint32_t disp, uint32_t attr, void* tmpl);
int32_t   mock_GetFileSizeEx(intptr_t h, int64_t* sz_out);
int32_t   mock_ReadFile(intptr_t h, void* buf, uint32_t to_read, uint32_t* rd_out, void* ov);
int32_t   mock_CloseHandle(intptr_t h);
]]
local GW = ffi.load("/home/user/sandbox/libguard_w32.so")
_G._GW = GW

_G.obj = _G.obj or {
    layer = 2, frame = 10, totalframe = 300, time = 0.33,
    screen_w = 1920, screen_h = 1080,
    x = 0, y = 0, z = 0, rx = 0, ry = 0, rz = 0, zoom = 1.0, alpha = 1.0,
    getinfo = function(k)
        if k == "clock" then return os.clock() end
        if k == "script_path" then return "/home/user/sandbox/" end
        return nil
    end,
    getoption = function(k)
        if k == "camera_mode" then return 2 end
        return nil
    end,
    getvalue = function(_) return nil end,
    clearbuffer = function() return true end,
    pixelshader = function() return true end,
    setoption = function() end,
    load = function() end,
    draw = function() end,
    drawpoly = function() end,
}

_G.VL3D_TEST_W32_API = {
    ffi                = ffi,
    VirtualQuery       = GW.mock_VirtualQuery,
    GetCurrentProcess  = GW.mock_GetCurrentProcess,
    GetModuleHandleW   = GW.mock_GetModuleHandleW,
    ReadProcessMemory  = GW.mock_ReadProcessMemory,
    CreateFileW        = GW.mock_CreateFileW,
    GetFileSizeEx      = GW.mock_GetFileSizeEx,
    ReadFile           = GW.mock_ReadFile,
    CloseHandle        = GW.mock_CloseHandle,
}
'''
    footer = f'''
_G._VL_EXPORT = {{
    _VL_PERSIST = _VL_PERSIST,
    pe_find_export_addr = pe_find_export_addr,
    utf8_to_utf16le_array = utf8_to_utf16le_array,
    utf16le_ptr_to_utf8 = utf16le_ptr_to_utf8,
    win32_read_file_wide_from_utf8 = win32_read_file_wide_from_utf8,
    list_dir_files_utf8 = list_dir_files_utf8,
    scan_ascii_float = scan_ascii_float,
    scan_ascii_int = scan_ascii_int,
    load_wavefront_obj_mesh = load_wavefront_obj_mesh,
    load_glb_vrm_fallback = load_glb_vrm_fallback,
    load_vrm_layer_mesh = load_vrm_layer_mesh,
    scan_live_modelfile_instances = scan_live_modelfile_instances,
    resolve_live_scene_layer_object = resolve_live_scene_layer_object,
    inspect_or_suppress_camera_lights = inspect_or_suppress_camera_lights,
    try_read_live_edit_camera = try_read_live_edit_camera,
    scan_pool_from_object = scan_pool_from_object,
    rasterize_tri_max = rasterize_tri_max,
    build_3d_shadow_map = build_3d_shadow_map,
    build_3d_cam_depth_map = build_3d_cam_depth_map,
    upload_rgba_to_cache = upload_rgba_to_cache,
    {extra_exports}
}}
'''
    return prelude + "\n" + core + "\n" + footer


HARNESS_V281 = build_vl_harness_lua(VL_V281, is_v285=False)
HARNESS_V285 = build_vl_harness_lua(VL_V285, is_v285=True)


def run_luajit_isolated(test_body: str, use_v285: bool = False, timeout: float = 15.0) -> dict:
    """Execute LuaJIT code in a fresh OS process so hardware SIGSEGV (-11) is captured cleanly."""
    src = (HARNESS_V285 if use_v285 else HARNESS_V281) + "\n" + test_body
    with tempfile.NamedTemporaryFile("w", suffix=".lua", delete=False, encoding="utf-8") as tf:
        tf.write(src)
        tf_path = tf.name
    t0 = time.perf_counter()
    try:
        proc = subprocess.run(
            ["luajit", tf_path],
            capture_output=True,
            text=True,
            timeout=timeout,
        )
        dt_ms = (time.perf_counter() - t0) * 1000.0
        rc = proc.returncode
        sig_name = None
        if rc < 0:
            try:
                sig_name = signal.Signals(-rc).name
            except Exception:
                sig_name = f"SIG({-rc})"
        elif rc >= 128:
            try:
                sig_name = signal.Signals(rc - 128).name
            except Exception:
                sig_name = f"EXIT({rc})"
        return {
            "returncode": rc,
            "crashed_sigsegv": (rc == -signal.SIGSEGV or rc == 128 + signal.SIGSEGV),
            "signal": sig_name,
            "elapsed_ms": round(dt_ms, 3),
            "stdout": proc.stdout.strip(),
            "stderr": proc.stderr.strip(),
        }
    finally:
        try:
            os.unlink(tf_path)
        except OSError:
            pass


# =========================================================================
# Static Cross-Script Memory Surface Inventory
# =========================================================================
def audit_static_surface() -> dict:
    scripts = {
        "体積光（3D）_v2.81": VL_V281,
        "体積光（3D）_v2.85_draft": VL_V285,
        "体積霧（3D）_v2.01": FOG_V201,
        "雪（3D）_v1.15": SNOW_V115,
        "雪（3D）_v1.18": SNOW_V118,
    }
    patterns = {
        "ffi_cast": r"\bffi[_\w]*\.cast\s*\(",
        "ffi_new": r"\bffi[_\w]*\.new\s*\(",
        "ffi_copy_fill": r"\bffi[_\w]*\.(?:copy|fill)\s*\(",
        "ffi_string": r"\bffi[_\w]*\.string\s*\(",
        "win32_rpm_vq": r"\b(?:ReadProcessMemory|VirtualQuery)\b",
        "pixeldata_rw": r"\b(?:getpixeldata|putpixeldata)\b",
        "pcall_blocks": r"\bpcall\s*\(",
    }
    out = {}
    for name, path in scripts.items():
        txt = path.read_text(encoding="utf-8", errors="replace")
        counts = {k: len(re.findall(pat, txt)) for k, pat in patterns.items()}
        counts["lines"] = len(txt.splitlines())
        out[name] = counts
    return out


# =========================================================================
# T1: Fundamental Proof — LuaJIT pcall/xpcall CANNOT catch hardware SIGSEGV
# =========================================================================
def test_t1_pcall_vs_sigsegv() -> dict:
    res = run_luajit_isolated(r'''
local ffi = require("ffi")
local GW = _G._GW
local ga = ffi.new("guard_alloc_t[1]")
assert(GW.gw_guard_alloc(64, 1, ga) == 0)
local guard_page_addr = ga[0].ptr + 64 -- exact first byte of trailing PROT_NONE page
print("BEFORE_PCALL")
io.stdout:flush()
local caught = false
local ok, err = xpcall(function()
    pcall(function()
        local v = ffi.cast("const uint8_t*", guard_page_addr)[0]
        print("UNREACHABLE_READ=", v)
    end)
end, function(e)
    caught = true
    return e
end)
print("AFTER_PCALL ok=", ok, "caught=", caught, "err=", tostring(err))
''')
    return res


# =========================================================================
# T2: Live Process Memory WRITE Audit (inspect_or_suppress_camera_lights, M-01)
# =========================================================================
def test_t2_live_camera_light_mutation() -> dict:
    # (2a) Normal v2.1.14 layout: mode=1 read-only vs mode=2 live C++ std::vector::_Mylast overwrite
    normal_and_mutate = run_luajit_isolated(r'''
local ffi = require("ffi")
local GW = _G._GW
local E = _G._VL_EXPORT

-- Build synthetic aviutl2.exe memory layout (exe_base + 0x58AAB8 -> lctx -> rctx -> gbuf -> 3x CameraLight64)
local exe_ga = ffi.new("guard_alloc_t[1]")
local heap_ga = ffi.new("guard_alloc_t[1]")
assert(GW.gw_guard_alloc(0x600000, 0, exe_ga) == 0)
assert(GW.gw_guard_alloc(0x10000,  0, heap_ga) == 0)

local exe_base = exe_ga[0].ptr
local heap_base = heap_ga[0].ptr
GW.gw_reset_regions()
GW.gw_set_exe_base(exe_base)
GW.gw_register_region(exe_base,  0x600000, 0x1000, 0x04, 0x1000000)
GW.gw_register_region(heap_base, 0x10000,  0x1000, 0x04, 0x20000)

-- Minimal valid MZ + PE64 header with .data section so resolve_live_scene_layer_object populates st.cands
local b = ffi.cast("uint8_t*", exe_base)
b[0], b[1] = 0x4D, 0x5A
ffi.cast("int32_t*", b + 0x3C)[0] = 0x80
local nt = b + 0x80
nt[0], nt[1] = 0x50, 0x45
ffi.cast("uint16_t*", nt + 6)[0]  = 1      -- NumberOfSections = 1
ffi.cast("uint16_t*", nt + 20)[0] = 0xF0   -- SizeOfOptionalHeader = 240
ffi.cast("uint32_t*", nt + 0x50)[0] = 0x600000
local sh = nt + 24 + 0xF0
ffi.copy(sh, ".data\0\0\0", 8)
ffi.cast("uint32_t*", sh + 8)[0]  = 0x20000  -- VirtualSize
ffi.cast("uint32_t*", sh + 12)[0] = 0x580000 -- VirtualAddress
ffi.cast("uint32_t*", sh + 36)[0] = 0xC0000040 -- IMAGE_SCN_MEM_READ | WRITE

local lctx = heap_base + 0x1000
local rctx = heap_base + 0x2000
local gbuf = heap_base + 0x3000
local lvec = heap_base + 0x4000

ffi.cast("uint64_t*", exe_base + 0x58AAB8)[0] = lctx
ffi.cast("uint64_t*", lctx + 0x88)[0] = rctx
ffi.cast("uint64_t*", rctx + 0xD0)[0] = gbuf

-- gbuf fields: +0x48 unlit=0.25, +0x50..58 amb=(0.1,0.1,0.15), +0x98..A8 vector of 3 lights (192 bytes)
ffi.cast("float*", gbuf + 0x48)[0] = 0.25
ffi.cast("float*", gbuf + 0x50)[0] = 0.10
ffi.cast("float*", gbuf + 0x54)[0] = 0.10
ffi.cast("float*", gbuf + 0x58)[0] = 0.15
ffi.cast("uint64_t*", gbuf + 0x98)[0] = lvec
ffi.cast("uint64_t*", gbuf + 0xA0)[0] = lvec + 192
ffi.cast("uint64_t*", gbuf + 0xA8)[0] = lvec + 256

-- Populate 2 lights (1 ambient ltype=1, 1 point/spot ltype=3) + 1 directional ltype=2
local f0 = ffi.cast("float*", lvec)
ffi.cast("int32_t*", lvec)[0] = 3 -- point/spot
f0[1], f0[2], f0[3] = 0.0, 0.5, 0.866
f0[4], f0[5], f0[6] = 2.0, 1.5, 1.0
f0[12], f0[13], f0[14], f0[15] = 100.0, -300.0, 800.0, 0.85

local f1 = ffi.cast("float*", lvec + 64)
ffi.cast("int32_t*", lvec + 64)[0] = 2 -- directional
f1[1], f1[2], f1[3] = 0.0, 1.0, 0.0
f1[4], f1[5], f1[6] = 0.8, 0.8, 0.9

local f2 = ffi.cast("float*", lvec + 128)
ffi.cast("int32_t*", lvec + 128)[0] = 1 -- ambient
f2[4], f2[5], f2[6] = 0.2, 0.2, 0.2

local before_mylast = tonumber(ffi.cast("uint64_t*", gbuf + 0xA0)[0])
local info_ro = E.inspect_or_suppress_camera_lights(false)
local after_ro_mylast = tonumber(ffi.cast("uint64_t*", gbuf + 0xA0)[0])

local info_wr = E.inspect_or_suppress_camera_lights(true)
local after_wr_mylast = tonumber(ffi.cast("uint64_t*", gbuf + 0xA0)[0])
local info_after_suppress = E.inspect_or_suppress_camera_lights(false)

print(string.format("RO_COUNT=%d PEAK=%.4f MYLAST_DELTA_RO=%d SUPPRESSED=%s MYLAST_DELTA_WR=%d AFTER_COUNT=%d",
    info_ro.count, info_ro.peak_gain, after_ro_mylast - before_mylast,
    tostring(info_wr.suppressed), after_wr_mylast - tonumber(lvec), info_after_suppress.count))
''')

    # (2b) Read-only gbuf page: ReadProcessMemory succeeds, raw write crashes with SIGSEGV!
    ro_page_crash = run_luajit_isolated(r'''
local ffi = require("ffi")
local GW = _G._GW
local E = _G._VL_EXPORT

local exe_ga  = ffi.new("guard_alloc_t[1]")
local heap_ga = ffi.new("guard_alloc_t[1]")
local gbuf_ga = ffi.new("guard_alloc_t[1]")
assert(GW.gw_guard_alloc(0x600000, 0, exe_ga) == 0)
assert(GW.gw_guard_alloc(0x8000,   0, heap_ga) == 0)
assert(GW.gw_guard_alloc(4096,     0, gbuf_ga) == 0)

local exe_base = exe_ga[0].ptr
local heap_base = heap_ga[0].ptr
local gbuf = gbuf_ga[0].ptr
GW.gw_reset_regions()
GW.gw_set_exe_base(exe_base)

local b = ffi.cast("uint8_t*", exe_base)
b[0], b[1] = 0x4D, 0x5A
ffi.cast("int32_t*", b + 0x3C)[0] = 0x80
local nt = b + 0x80
nt[0], nt[1] = 0x50, 0x45
ffi.cast("uint16_t*", nt + 6)[0]  = 1
ffi.cast("uint16_t*", nt + 20)[0] = 0xF0
local sh = nt + 24 + 0xF0
ffi.copy(sh, ".data\0\0\0", 8)
ffi.cast("uint32_t*", sh + 8)[0]  = 0x20000
ffi.cast("uint32_t*", sh + 12)[0] = 0x580000
ffi.cast("uint32_t*", sh + 36)[0] = 0xC0000040

local lctx = heap_base + 0x1000
local rctx = heap_base + 0x2000
local lvec = heap_base + 0x3000
ffi.cast("uint64_t*", exe_base + 0x58AAB8)[0] = lctx
ffi.cast("uint64_t*", lctx + 0x88)[0] = rctx
ffi.cast("uint64_t*", rctx + 0xD0)[0] = gbuf
ffi.cast("float*", gbuf + 0x48)[0] = 1.0
ffi.cast("uint64_t*", gbuf + 0x98)[0] = lvec
ffi.cast("uint64_t*", gbuf + 0xA0)[0] = lvec + 64
ffi.cast("uint64_t*", gbuf + 0xA8)[0] = lvec + 64

-- Mark gbuf hardware page READ-ONLY (PROT_READ = 1): RPM succeeds, raw pointer write faults!
assert(GW.gw_protect(gbuf_ga[0].usable_base, gbuf_ga[0].usable_len, 1) == 0)
E.inspect_or_suppress_camera_lights(true)
print("UNEXPECTED_SURVIVAL")
''')

    # (2c) Simulated aviutl2.exe +8B ABI drift: corrupts unrelated C++ pointer at gbuf + 0xA0!
    abi_drift_corrupt = run_luajit_isolated(r'''
local ffi = require("ffi")
local GW = _G._GW
local E = _G._VL_EXPORT

local exe_ga  = ffi.new("guard_alloc_t[1]")
local heap_ga = ffi.new("guard_alloc_t[1]")
assert(GW.gw_guard_alloc(0x600000, 0, exe_ga) == 0)
assert(GW.gw_guard_alloc(0x10000,  0, heap_ga) == 0)

local exe_base = exe_ga[0].ptr
local heap_base = heap_ga[0].ptr
GW.gw_reset_regions()
GW.gw_set_exe_base(exe_base)

local b = ffi.cast("uint8_t*", exe_base)
b[0], b[1] = 0x4D, 0x5A
ffi.cast("int32_t*", b + 0x3C)[0] = 0x80
local nt = b + 0x80
nt[0], nt[1] = 0x50, 0x45
ffi.cast("uint16_t*", nt + 6)[0]  = 1
ffi.cast("uint16_t*", nt + 20)[0] = 0xF0
local sh = nt + 24 + 0xF0
ffi.copy(sh, ".data\0\0\0", 8)
ffi.cast("uint32_t*", sh + 8)[0]  = 0x20000
ffi.cast("uint32_t*", sh + 12)[0] = 0x580000
ffi.cast("uint32_t*", sh + 36)[0] = 0xC0000040

local lctx = heap_base + 0x1000
local rctx = heap_base + 0x2000
local gbuf = heap_base + 0x3000
ffi.cast("uint64_t*", exe_base + 0x58AAB8)[0] = lctx
ffi.cast("uint64_t*", lctx + 0x88)[0] = rctx
ffi.cast("uint64_t*", rctx + 0xD0)[0] = gbuf

-- Suppose aviutl2.exe v2.2 shifted gbuf by +8B:
-- +0x98 holds d3d11_srv_ptr (0x50001000), +0xA0 holds c++_vtable_or_cbuf_ptr (0x50001080, diff=128 == 2*64!)
-- +0xA8 holds another heap ptr (0x50001100 >= le)
local d3d_srv_ptr = heap_base + 0x5000
local critical_cpp_ptr = heap_base + 0x5080 -- diff = 128 (divisible by 64!)
ffi.cast("float*", gbuf + 0x48)[0] = 0.0
ffi.cast("uint64_t*", gbuf + 0x98)[0] = d3d_srv_ptr
ffi.cast("uint64_t*", gbuf + 0xA0)[0] = critical_cpp_ptr
ffi.cast("uint64_t*", gbuf + 0xA8)[0] = heap_base + 0x5100

E.inspect_or_suppress_camera_lights(true)
local after_ptr = tonumber(ffi.cast("uint64_t*", gbuf + 0xA0)[0])
print(string.format("ABI_DRIFT_CORRUPTED=%s ORIG=0x%x AFTER=0x%x",
    tostring(after_ptr ~= tonumber(critical_cpp_ptr)), tonumber(critical_cpp_ptr), after_ptr))
''')
    return {
        "normal_and_mutate": normal_and_mutate,
        "readonly_gbuf_crash": ro_page_crash,
        "abi_drift_heap_corruption": abi_drift_corrupt,
    }


# =========================================================================
# T3: PE64 SizeOfOptionalHeader (opt_sz) OOB Heap & Guard-Page Read (M-02)
# =========================================================================
def test_t3_pe_optsz_oob() -> dict:
    # (3a) try_read_live_edit_camera: is_readable_ptr(base, 4096) passes on 4096B page before PROT_NONE,
    #      opt_sz = 0x2000 jumps +8KB right into PROT_NONE guard page -> SIGSEGV!
    edit_cam_crash = run_luajit_isolated(r'''
local ffi = require("ffi")
local GW = _G._GW
local E = _G._VL_EXPORT

local ga = ffi.new("guard_alloc_t[1]")
assert(GW.gw_guard_alloc(4096, 1, ga) == 0) -- 4096B flush before trailing PROT_NONE page
local base = ga[0].ptr
GW.gw_reset_regions()
GW.gw_set_exe_base(base)
GW.gw_register_region(base, 4096, 0x1000, 0x20, 0x1000000)

local b = ffi.cast("uint8_t*", base)
b[0], b[1] = 0x4D, 0x5A
ffi.cast("int32_t*", b + 0x3C)[0] = 0x100     -- passes pe_off > 64 and pe_off < 2048
b[0x100], b[0x101] = 0x50, 0x45               -- "PE"
ffi.cast("uint16_t*", b + 0x100 + 6)[0]  = 4  -- nsec = 4 (<= 12)
ffi.cast("uint16_t*", b + 0x100 + 20)[0] = 0x2000 -- opt_sz = 8192 (UNCHECKED! sec_p = base + 0x2118 -> in PROT_NONE!)

E.try_read_live_edit_camera()
print("UNEXPECTED_SURVIVAL")
''')

    # (3b) Measure exact max OOB offset in resolve_live_scene_layer_object's uint8_t[4096] stack/GC buffer
    resolve_oob_calc = run_luajit_isolated(r'''
local ffi = require("ffi")
local GW = _G._GW
local E = _G._VL_EXPORT

-- Allocate 4096B exe header where lfanew=0x800, nsec=16, opt_sz=0xFFFF
-- In resolve_live_scene_layer_object: hdr = ffi.new("uint8_t[4096]"), max byte read is:
-- lfanew(2048) + 24 + opt_sz(65535) + 15*40 + 40 = 68247 (64,151 bytes OOB past hdr[4095]!)
local ga = ffi.new("guard_alloc_t[1]")
assert(GW.gw_guard_alloc(4096, 1, ga) == 0)
local base = ga[0].ptr
GW.gw_reset_regions()
GW.gw_set_exe_base(base)
GW.gw_register_region(base, 4096, 0x1000, 0x04, 0x1000000)

local b = ffi.cast("uint8_t*", base)
b[0], b[1] = 0x4D, 0x5A
ffi.cast("int32_t*", b + 0x3C)[0] = 0x800
b[0x800], b[0x801] = 0x50, 0x45
ffi.cast("uint16_t*", b + 0x800 + 6)[0]  = 16
ffi.cast("uint16_t*", b + 0x800 + 20)[0] = 0xFFFF

-- Run unmodified resolve_live_scene_layer_object: reads 64 KB past its 4096-byte LuaJIT GC buffer!
local r = E.resolve_live_scene_layer_object(1, nil)
local max_off = 0x800 + 24 + 0xFFFF + 15 * 40 + 40
print(string.format("OOB_HEAP_READ_EXECUTED=true HDR_BUF=4096 MAX_READ_END=%d OOB_BYTES=%d", max_off, max_off - 4096))
''')

    # (3c) Verify hardened PE section header bounds check on the exact same guard-page-backed input
    patched_safe = run_luajit_isolated(r'''
local ffi = require("ffi")
local GW = _G._GW

local ga = ffi.new("guard_alloc_t[1]")
assert(GW.gw_guard_alloc(4096, 1, ga) == 0)
local base = ga[0].ptr
local b = ffi.cast("uint8_t*", base)
b[0], b[1] = 0x4D, 0x5A
ffi.cast("int32_t*", b + 0x3C)[0] = 0x100
b[0x100], b[0x101] = 0x50, 0x45
ffi.cast("uint16_t*", b + 0x100 + 6)[0]  = 4
ffi.cast("uint16_t*", b + 0x100 + 20)[0] = 0x2000

-- Hardened check: pe_off + 24 + opt_sz + nsec_cap * 40 <= readable_bytes
local readable_bytes = 4096
local pe_off = ffi.cast("const int32_t*", b + 0x3C)[0]
local safe = false
if pe_off >= 0x40 and pe_off + 24 <= readable_bytes and b[pe_off] == 0x50 and b[pe_off + 1] == 0x45 then
    local nsec = math.min(tonumber(ffi.cast("const uint16_t*", b + pe_off + 6)[0]) or 0, 16)
    local opt_sz = tonumber(ffi.cast("const uint16_t*", b + pe_off + 20)[0]) or 0
    if opt_sz <= 1024 and (pe_off + 24 + opt_sz + nsec * 40) <= readable_bytes then
        safe = true
    end
end
print("PATCHED_REJECTED_SAFELY=", tostring(not safe))
''')
    return {
        "edit_cam_guard_crash": edit_cam_crash,
        "resolve_layer_heap_oob": resolve_oob_calc,
        "patched_bounds_safe": patched_safe,
    }


# =========================================================================
# T4: scan_live_modelfile_instances Triple Hazard (e_lfanew + page_ok(32) + TOCTOU) (M-03)
# =========================================================================
def test_t4_modelfile_scanner_hazards() -> dict:
    # (4a) Unchecked signed e_lfanew in scan_live_modelfile_instances (line 3246)
    lfanew_crash = run_luajit_isolated(r'''
local ffi = require("ffi")
local GW = _G._GW
local E = _G._VL_EXPORT

local ga = ffi.new("guard_alloc_t[1]")
assert(GW.gw_guard_alloc(4096, 1, ga) == 0)
local base = ga[0].ptr
GW.gw_reset_regions()
GW.gw_set_exe_base(base)
GW.gw_register_region(base, 4096, 0x1000, 0x04, 0x1000000)

local b = ffi.cast("uint8_t*", base)
b[0], b[1] = 0x4D, 0x5A
ffi.cast("int32_t*", b + 0x3C)[0] = 0x1800 -- > 4096, hits trailing PROT_NONE guard page!
E.scan_live_modelfile_instances()
print("UNEXPECTED_SURVIVAL")
''')

    # (4b) Fake ModelfileInstance Heap-Spoofing Hazard: an ordinary user heap buffer (e.g. plugin/string buffer)
    #      containing pointers into exe image + L"モデルファイル" pointer is misidentified as a C++ ModelfileInstance!
    heap_spoof = run_luajit_isolated(r'''
local ffi = require("ffi")
local GW = _G._GW
local E = _G._VL_EXPORT

local exe_ga  = ffi.new("guard_alloc_t[1]")
local rdat_ga = ffi.new("guard_alloc_t[1]")
local heap_ga = ffi.new("guard_alloc_t[1]")
assert(GW.gw_guard_alloc(4096, 0, exe_ga) == 0)
assert(GW.gw_guard_alloc(4096, 0, rdat_ga) == 0)
assert(GW.gw_guard_alloc(8192, 0, heap_ga) == 0)

local exe_base  = exe_ga[0].ptr
local rdat_base = exe_base + 0x1000 -- note: guard_alloc has trailing guard at +4096, so use a single 8KB exe block!
GW.gw_guard_free(exe_ga); GW.gw_guard_free(rdat_ga)
assert(GW.gw_guard_alloc(8192, 0, exe_ga) == 0)
exe_base  = exe_ga[0].ptr
rdat_base = exe_base + 0x1000
local heap_base = heap_ga[0].ptr

GW.gw_reset_regions()
GW.gw_set_exe_base(exe_base)
GW.gw_register_region(exe_base,  4096, 0x1000, 0x20, 0x1000000) -- .text / header
GW.gw_register_region(rdat_base, 4096, 0x1000, 0x02, 0x1000000) -- .rdata (PAGE_READONLY = 2)
GW.gw_register_region(heap_base, 8192, 0x1000, 0x04, 0x20000)   -- MEM_PRIVATE RW heap

local b = ffi.cast("uint8_t*", exe_base)
b[0], b[1] = 0x4D, 0x5A
ffi.cast("int32_t*", b + 0x3C)[0] = 0x80
b[0x80], b[0x81] = 0x50, 0x45
ffi.cast("uint32_t*", b + 0x80 + 0x50)[0] = 8192

-- Place L"モデルファイル\0" in .rdata
local wstr_addr = rdat_base + 0x100
local pw = ffi.cast("uint16_t*", wstr_addr)
local chars = { 0x30E2, 0x30C7, 0x30EB, 0x30D5, 0x30A1, 0x30A4, 0x30EB, 0x0000 }
for idx = 1, #chars do pw[idx - 1] = chars[idx] end

-- Place an unrelated data buffer on heap that mimics vtable range + SSO wstring "spoof.obj"
local fake = heap_base + 0x200
ffi.cast("uint64_t*", fake + 0x00)[0] = exe_base + 0x500 -- vt0 in (exe_base, exe_base+16MB)
ffi.cast("uint64_t*", fake + 0x40)[0] = wstr_addr        -- [inst + 0x40] == wstr_target
ffi.cast("uint64_t*", fake + 0x68)[0] = exe_base + 0x520 -- vt1 in (exe_base, exe_base+16MB)
ffi.cast("uint64_t*", fake + 0xB8)[0] = 7                -- slen = 7
ffi.cast("uint64_t*", fake + 0xC0)[0] = 7                -- scap = 7 (<8 => SSO at inst+0xA8)
local sso = ffi.cast("uint16_t*", fake + 0xA8)
local fn_c = { 0x61, 0x2E, 0x6F, 0x62, 0x6A, 0, 0, 0 }   -- "a.obj"
ffi.cast("uint64_t*", fake + 0xB8)[0] = 5
for idx = 1, #fn_c do sso[idx - 1] = fn_c[idx] end
ffi.cast("uint8_t*", fake + 0x108)[0] = 1

local list = E.scan_live_modelfile_instances()
print(string.format("SPOOFED_COUNT=%d PATH=%s ADJ=%s",
    #list, tostring(list[1] and list[1].path), tostring(list[1] and list[1].adj)))
''')

    # (4c) Real multithreaded pthread TOCTOU race: worker thread decommits tail 14MB of 16MB heap region
    #      150us after VirtualQuery returns MEM_COMMIT -> raw qw[i] scan crashes with SIGSEGV!
    toctou_race_crash = run_luajit_isolated(r'''
local ffi = require("ffi")
local GW = _G._GW
local E = _G._VL_EXPORT

local exe_ga  = ffi.new("guard_alloc_t[1]")
local race_ga = ffi.new("guard_alloc_t[1]")
local REGION_SZ = 32 * 1024 * 1024 -- 32 MB (~4M QWORD iterations in Lua)
assert(GW.gw_guard_alloc(8192,      0, exe_ga) == 0)
assert(GW.gw_guard_alloc(REGION_SZ, 0, race_ga) == 0)

local exe_base  = exe_ga[0].ptr
local rdat_base = exe_base + 0x1000
local race_base = race_ga[0].ptr

GW.gw_reset_regions()
GW.gw_set_exe_base(exe_base)
GW.gw_register_region(exe_base,  4096,      0x1000, 0x20, 0x1000000)
GW.gw_register_region(rdat_base, 4096,      0x1000, 0x02, 0x1000000) -- PAGE_READONLY .rdata!
GW.gw_register_region(race_base, REGION_SZ, 0x1000, 0x04, 0x20000)   -- MEM_PRIVATE RW heap!

local b = ffi.cast("uint8_t*", exe_base)
b[0], b[1] = 0x4D, 0x5A
ffi.cast("int32_t*", b + 0x3C)[0] = 0x80
b[0x80], b[0x81] = 0x50, 0x45
ffi.cast("uint32_t*", b + 0x80 + 0x50)[0] = 8192

local wstr_addr = rdat_base + 0x100
local pw = ffi.cast("uint16_t*", wstr_addr)
local chars = { 0x30E2, 0x30C7, 0x30EB, 0x30D5, 0x30A1, 0x30A4, 0x30EB, 0x0000 }
for idx = 1, #chars do pw[idx - 1] = chars[idx] end

-- Arm pthread TOCTOU worker: 100us after VirtualQuery(race_base) succeeds, decommit [race_base+1MB .. +32MB]
GW.gw_arm_toctou(race_base, race_base + 1024 * 1024, REGION_SZ - 1024 * 1024, 100)
E.scan_live_modelfile_instances()
print("TOCTOU_FIRED=", GW.gw_did_toctou_fire(), "SURVIVED")
''')

    # (4d) Patched chunked-ReadProcessMemory scanner under the EXACT SAME pthread TOCTOU race!
    toctou_rpm_safe = run_luajit_isolated(r'''
local ffi = require("ffi")
local GW = _G._GW

local race_ga = ffi.new("guard_alloc_t[1]")
local REGION_SZ = 16 * 1024 * 1024
assert(GW.gw_guard_alloc(REGION_SZ, 0, race_ga) == 0)
local race_base = race_ga[0].ptr
GW.gw_reset_regions()
GW.gw_register_region(race_base, REGION_SZ, 0x1000, 0x04, 0x20000)
GW.gw_arm_toctou(race_base, race_base + 512 * 1024, REGION_SZ - 512 * 1024, 100)

-- Query VirtualQuery (triggers concurrent decommit thread!) then scan via kernel-safe ReadProcessMemory chunks
local mbi = ffi.new("uint8_t[64]")
assert(GW.mock_VirtualQuery(ffi.cast("const void*", race_base), mbi, 48) == 48)
local chunk = ffi.new("uint64_t[8192]") -- 64 KB reusable chunk
local nrd = ffi.new("size_t[1]")
local ok_chunks, aborted_safely = 0, false
local off = 0
while off < REGION_SZ do
    local step = math.min(65536, REGION_SZ - off)
    if GW.mock_ReadProcessMemory(-1, ffi.cast("const void*", race_base + off), chunk, step, nrd) == 0 or nrd[0] < 8 then
        aborted_safely = true
        break
    end
    ok_chunks = ok_chunks + 1
    off = off + tonumber(nrd[0])
end
print(string.format("RPM_SURVIVED=true TOCTOU_FIRED=%d OK_CHUNKS=%d ABORTED_CLEANLY=%s",
    GW.gw_did_toctou_fire(), ok_chunks, tostring(aborted_safely)))
''')
    return {
        "unchecked_lfanew_crash": lfanew_crash,
        "heap_spoof_false_positive": heap_spoof,
        "multithread_toctou_raw_ptr_crash": toctou_race_crash,
        "patched_rpm_chunked_toctou_safe": toctou_rpm_safe,
    }


# =========================================================================
# T5: pe_find_export_addr Malformed/Hooked PE64 Export Fuzzing (M-04)
# =========================================================================
def test_t5_pe_export_fuzzer() -> dict:
    # (5a) Export name RVA out-of-bounds past image into PROT_NONE guard page
    rva_oob = run_luajit_isolated(r'''
local ffi = require("ffi")
local GW = _G._GW
local E = _G._VL_EXPORT

local ga = ffi.new("guard_alloc_t[1]")
assert(GW.gw_guard_alloc(4096, 1, ga) == 0)
local base = ga[0].ptr
local b = ffi.cast("uint8_t*", base)
b[0], b[1] = 0x4D, 0x5A
ffi.cast("int32_t*", b + 0x3C)[0] = 0x80
local nt = b + 0x80
nt[0], nt[1] = 0x50, 0x45
ffi.cast("uint16_t*", nt + 0x18)[0] = 0x020B -- PE32+
ffi.cast("uint32_t*", nt + 0x50)[0] = 4096   -- SizeOfImage = 4096
ffi.cast("uint32_t*", nt + 0x88)[0] = 0x200  -- Export RVA
ffi.cast("uint32_t*", nt + 0x8C)[0] = 0x100  -- Export Size
local exp = b + 0x200
ffi.cast("uint32_t*", exp + 0x14)[0] = 1     -- n_funcs
ffi.cast("uint32_t*", exp + 0x18)[0] = 1     -- n_names
ffi.cast("uint32_t*", exp + 0x1C)[0] = 0x300 -- rva_fn
ffi.cast("uint32_t*", exp + 0x20)[0] = 0x310 -- rva_nm
ffi.cast("uint32_t*", exp + 0x24)[0] = 0x320 -- rva_ord
ffi.cast("uint32_t*", b + 0x310)[0]  = 0x1500 -- names[0] > SizeOfImage -> in PROT_NONE!

E.pe_find_export_addr(ffi, base, "GetProcAddress")
print("UNEXPECTED_SURVIVAL")
''')

    # (5b) Unterminated export name at end of page (unbounded ffi.string) -> SIGSEGV
    unterm_name = run_luajit_isolated(r'''
local ffi = require("ffi")
local GW = _G._GW
local E = _G._VL_EXPORT

local ga = ffi.new("guard_alloc_t[1]")
assert(GW.gw_guard_alloc(4096, 1, ga) == 0)
local base = ga[0].ptr
local b = ffi.cast("uint8_t*", base)
b[0], b[1] = 0x4D, 0x5A
ffi.cast("int32_t*", b + 0x3C)[0] = 0x80
local nt = b + 0x80
nt[0], nt[1] = 0x50, 0x45
ffi.cast("uint16_t*", nt + 0x18)[0] = 0x020B
ffi.cast("uint32_t*", nt + 0x88)[0] = 0x200
ffi.cast("uint32_t*", nt + 0x8C)[0] = 0x100
local exp = b + 0x200
ffi.cast("uint32_t*", exp + 0x14)[0] = 1
ffi.cast("uint32_t*", exp + 0x18)[0] = 1
ffi.cast("uint32_t*", exp + 0x1C)[0] = 0x300
ffi.cast("uint32_t*", exp + 0x20)[0] = 0x310
ffi.cast("uint32_t*", exp + 0x24)[0] = 0x320
ffi.cast("uint32_t*", b + 0x310)[0]  = 4088 -- 8 bytes before PROT_NONE, filled with non-NUL 'A'
for i = 4088, 4095 do b[i] = 0x41 end

E.pe_find_export_addr(ffi, base, "GetProcAddress")
print("UNEXPECTED_SURVIVAL")
''')

    # (5c) Ordinal >= NumberOfFunctions OOB read into PROT_NONE guard page
    ord_oob = run_luajit_isolated(r'''
local ffi = require("ffi")
local GW = _G._GW
local E = _G._VL_EXPORT

local ga = ffi.new("guard_alloc_t[1]")
assert(GW.gw_guard_alloc(4096, 1, ga) == 0)
local base = ga[0].ptr
local b = ffi.cast("uint8_t*", base)
b[0], b[1] = 0x4D, 0x5A
ffi.cast("int32_t*", b + 0x3C)[0] = 0x80
local nt = b + 0x80
nt[0], nt[1] = 0x50, 0x45
ffi.cast("uint16_t*", nt + 0x18)[0] = 0x020B
ffi.cast("uint32_t*", nt + 0x88)[0] = 0x200
ffi.cast("uint32_t*", nt + 0x8C)[0] = 0x100
local exp = b + 0x200
ffi.cast("uint32_t*", exp + 0x14)[0] = 1      -- NumberOfFunctions = 1
ffi.cast("uint32_t*", exp + 0x18)[0] = 1      -- NumberOfNames = 1
ffi.cast("uint32_t*", exp + 0x1C)[0] = 0xF00  -- funcs table near end of page
ffi.cast("uint32_t*", exp + 0x20)[0] = 0x310
ffi.cast("uint32_t*", exp + 0x24)[0] = 0x320
ffi.cast("uint32_t*", b + 0x310)[0]  = 0x340
ffi.copy(b + 0x340, "GetProcAddress\0", 15)
ffi.cast("uint16_t*", b + 0x320)[0]  = 500    -- ord = 500 >= n_funcs(1), funcs[500] = 0xF00 + 2000 > 4096!

E.pe_find_export_addr(ffi, base, "GetProcAddress")
print("UNEXPECTED_SURVIVAL")
''')

    # (5d) Valid PE64 export binary search + forwarder detection verification
    valid_pe = run_luajit_isolated(r'''
local ffi = require("ffi")
local GW = _G._GW
local E = _G._VL_EXPORT

local ga = ffi.new("guard_alloc_t[1]")
assert(GW.gw_guard_alloc(4096, 1, ga) == 0)
local base = ga[0].ptr
local b = ffi.cast("uint8_t*", base)
b[0], b[1] = 0x4D, 0x5A
ffi.cast("int32_t*", b + 0x3C)[0] = 0x80
local nt = b + 0x80
nt[0], nt[1] = 0x50, 0x45
ffi.cast("uint16_t*", nt + 0x18)[0] = 0x020B
ffi.cast("uint32_t*", nt + 0x88)[0] = 0x200
ffi.cast("uint32_t*", nt + 0x8C)[0] = 0x100
local exp = b + 0x200
ffi.cast("uint32_t*", exp + 0x14)[0] = 3
ffi.cast("uint32_t*", exp + 0x18)[0] = 3
ffi.cast("uint32_t*", exp + 0x1C)[0] = 0x300
ffi.cast("uint32_t*", exp + 0x20)[0] = 0x320
ffi.cast("uint32_t*", exp + 0x24)[0] = 0x340

-- Sorted names: CreateFileW (ord 0 -> 0x700), GetProcAddress (ord 1 -> 0x740), HeapAlloc (ord 2 -> 0x280 inside export dir = forwarded!)
ffi.copy(b + 0x400, "CreateFileW\0", 12)
ffi.copy(b + 0x420, "GetProcAddress\0", 15)
ffi.copy(b + 0x440, "HeapAlloc\0", 10)
ffi.cast("uint32_t*", b + 0x320)[0] = 0x400
ffi.cast("uint32_t*", b + 0x320)[1] = 0x420
ffi.cast("uint32_t*", b + 0x320)[2] = 0x440
ffi.cast("uint16_t*", b + 0x340)[0] = 0
ffi.cast("uint16_t*", b + 0x340)[1] = 1
ffi.cast("uint16_t*", b + 0x340)[2] = 2
ffi.cast("uint32_t*", b + 0x300)[0] = 0x700
ffi.cast("uint32_t*", b + 0x300)[1] = 0x740
ffi.cast("uint32_t*", b + 0x300)[2] = 0x280 -- inside [0x200, 0x300) => forwarded!

local a_cf  = E.pe_find_export_addr(ffi, base, "CreateFileW")
local a_gpa = E.pe_find_export_addr(ffi, base, "GetProcAddress")
local a_fwd = E.pe_find_export_addr(ffi, base, "HeapAlloc")
print(string.format("CF_RVA=0x%x GPA_RVA=0x%x FWD_RET=%d",
    tonumber(a_cf - base), tonumber(a_gpa - base), tonumber(a_fwd)))
''')
    return {
        "name_rva_oob_crash": rva_oob,
        "unterminated_name_crash": unterm_name,
        "ordinal_oob_crash": ord_oob,
        "valid_and_forwarded_check": valid_pe,
    }


# =========================================================================
# T6: GLB/VRM Negative byteStride Guard-Page Underflow & Per-Frame GC Churn (M-06 & M-11)
# =========================================================================
def make_malicious_neg_stride_glb() -> bytes:
    doc = {
        "asset": {"version": "2.0"},
        "nodes": [{"mesh": 0}],
        "meshes": [{"primitives": [{"attributes": {"POSITION": 0}, "mode": 4}]}],
        "accessors": [{"bufferView": 0, "byteOffset": 0, "componentType": 5126, "count": 8192, "type": "VEC3"}],
        "bufferViews": [{"buffer": 0, "byteOffset": 16, "byteLength": 64, "byteStride": -1048576}],
    }
    jb = json.dumps(doc, separators=(",", ":")).encode("utf-8")
    while len(jb) % 4 != 0:
        jb += b" "
    bb = b"\x00" * 64
    total = 12 + 8 + len(jb) + 8 + len(bb)
    return (
        struct.pack("<III", 0x46546C67, 2, total)
        + struct.pack("<II", len(jb), 0x4E4F534A)
        + jb
        + struct.pack("<II", len(bb), 0x004E4942)
        + bb
    )


def make_benchmark_glb(n_verts: int = 30000) -> bytes:
    n_tris = n_verts // 3
    pos_bytes = bytearray(n_verts * 12)
    idx_bytes = bytearray(n_tris * 3 * 4)
    for i in range(n_verts):
        struct.pack_into("<fff", pos_bytes, i * 12, float(i % 100) * 0.01, float(i // 100) * 0.01, 0.5)
    for i in range(n_tris * 3):
        struct.pack_into("<I", idx_bytes, i * 4, i)
    bb = bytes(pos_bytes + idx_bytes)
    doc = {
        "asset": {"version": "2.0"},
        "nodes": [{"mesh": 0}],
        "meshes": [{"primitives": [{"attributes": {"POSITION": 0}, "indices": 1, "mode": 4}]}],
        "accessors": [
            {"bufferView": 0, "byteOffset": 0, "componentType": 5126, "count": n_verts, "type": "VEC3"},
            {"bufferView": 1, "byteOffset": 0, "componentType": 5125, "count": n_tris * 3, "type": "SCALAR"},
        ],
        "bufferViews": [
            {"buffer": 0, "byteOffset": 0, "byteLength": len(pos_bytes), "byteStride": 12},
            {"buffer": 0, "byteOffset": len(pos_bytes), "byteLength": len(idx_bytes)},
        ],
    }
    jb = json.dumps(doc, separators=(",", ":")).encode("utf-8")
    while len(jb) % 4 != 0:
        jb += b" "
    total = 12 + 8 + len(jb) + 8 + len(bb)
    return (
        struct.pack("<III", 0x46546C67, 2, total)
        + struct.pack("<II", len(jb), 0x4E4F534A)
        + jb
        + struct.pack("<II", len(bb), 0x004E4942)
        + bb
    )


def test_t6_glb_stride_and_gc_churn() -> dict:
    with tempfile.NamedTemporaryFile("wb", suffix=".glb", delete=False) as mf:
        mf.write(make_malicious_neg_stride_glb())
        mal_path = mf.name
    with tempfile.NamedTemporaryFile("wb", suffix=".glb", delete=False) as bf:
        bf.write(make_benchmark_glb(36000))
        bench_path = bf.name

    try:
        # (6a) Negative byteStride (-4096 * 4095 = -16 MB backwards walk before Lua string -> SIGSEGV!)
        neg_stride_crash = run_luajit_isolated(f'''
local E = _G._VL_EXPORT
_G.VL3D_TEST_W32_API = nil -- use standard io.open binary read on Linux
E._VL_PERSIST.w32_api = false
E.load_glb_vrm_fallback({json.dumps(mal_path)}, 100.0, 1.0, 1.0, 1.0)
print("SURVIVED_WITHOUT_SEGV")
''')

        # (6b) Exact guard-page verification of unmodified GLB stride formula vs hardened check
        guard_neg_stride = run_luajit_isolated(r'''
local ffi = require("ffi")
local GW = _G._GW
local ga = ffi.new("guard_alloc_t[1]")
assert(GW.gw_guard_alloc(64, 0, ga) == 0) -- 64B placed at start of page right AFTER leading PROT_NONE page!
local bin_ptr = ffi.cast("const uint8_t*", ga[0].ptr)
local bin_len = 64
local p_base, vcnt, stride = 16, 64, -128
-- Exact condition from 体積光（3D）.obj2 line 2547:
if p_base >= 0 and p_base + (vcnt - 1) * stride + 12 <= bin_len then
    for k = 0, vcnt - 1 do
        local fp = ffi.cast("const float*", bin_ptr + p_base + k * stride)
        local _ = fp[0] + fp[1] + fp[2]
    end
end
print("UNEXPECTED_SURVIVAL")
''')

        # (6c) Per-frame GC allocation churn benchmark on 36,000-vertex GLB over 60 frames
        gc_churn = run_luajit_isolated(f'''
local ffi = require("ffi")
local E = _G._VL_EXPORT
_G.VL3D_TEST_W32_API = nil
E._VL_PERSIST.w32_api = false

-- Warmup initial parse into GLB_MESH_CACHE
local m0 = E.load_glb_vrm_fallback({json.dumps(bench_path)}, 100.0, 1.0, 1.0, 1.0)
assert(m0 ~= nil and m0.nv == 36000)

collectgarbage("collect")
collectgarbage("collect")
collectgarbage("stop")
local kb_before = collectgarbage("count")
local t0 = os.clock()
for f = 1, 60 do
    local mf = E.load_glb_vrm_fallback({json.dumps(bench_path)}, 100.0, 1.0, 1.0, 1.0)
    assert(mf.nv == 36000)
end
local dt_unpatched_ms = (os.clock() - t0) * 1000.0
local kb_after = collectgarbage("count")
local alloc_mb_60f = (kb_after - kb_before) / 1024.0
collectgarbage("restart")
collectgarbage("collect")

-- Compare with patched FFI float[?] cached mesh + O(1) scale return
local fvx = ffi.new("float[?]", m0.nv + 1)
local fvy = ffi.new("float[?]", m0.nv + 1)
local fvz = ffi.new("float[?]", m0.nv + 1)
for k = 1, m0.nv do fvx[k], fvy[k], fvz[k] = m0.vx[k], m0.vy[k], m0.vz[k] end
local cached_ffi_mesh = {{ indexed = true, vx = fvx, vy = fvy, vz = fvz, nv = m0.nv, i0 = m0.i0, i1 = m0.i1, i2 = m0.i2, nt = m0.nt }}

collectgarbage("collect")
collectgarbage("stop")
local kb_b2 = collectgarbage("count")
local t1 = os.clock()
for f = 1, 60 do
    local mf2 = cached_ffi_mesh -- scale folded into md.ozx/ozy/ozz in O(1)
    assert(mf2.nv == 36000)
end
local dt_patched_ms = (os.clock() - t1) * 1000.0
local kb_a2 = collectgarbage("count")
collectgarbage("restart")

print(string.format("NV=%d UNPATCHED_60F_MB=%.3f PER_FRAME_MB=%.3f UNPATCHED_MS=%.2f PATCHED_60F_KB=%.3f PATCHED_MS=%.4f",
    m0.nv, alloc_mb_60f, alloc_mb_60f / 60.0, dt_unpatched_ms, kb_a2 - kb_b2, dt_patched_ms))
''')
        return {
            "malicious_glb_neg_stride": neg_stride_crash,
            "guard_page_neg_stride_proof": guard_neg_stride,
            "per_frame_gc_churn_benchmark": gc_churn,
        }
    finally:
        for p in (mal_path, bench_path):
            try:
                os.unlink(p)
            except OSError:
                pass


# =========================================================================
# T7: scan_pool_from_object & fb_save Pixel Buffer OOB + HDR Clamping (M-07 & M-08)
# =========================================================================
def test_t7_pixeldata_bounds_and_hdr() -> dict:
    # (7a) scan_pool_from_object ignores pw, ph from getpixeldata("cache:vl3d/pool") -> OOB read past 1x1 (4B) buffer!
    pool_oob_crash = run_luajit_isolated(r'''
local ffi = require("ffi")
local GW = _G._GW
local E = _G._VL_EXPORT

local ga = ffi.new("guard_alloc_t[1]")
assert(GW.gw_guard_alloc(4, 1, ga) == 0) -- 1x1 RGBA (4 bytes) flush before trailing PROT_NONE page!
local stale_1x1_ptr = ffi.cast("void*", ga[0].ptr)

_G.obj.getpixeldata = function(target, fmt)
    -- Simulate TemporaryImageCacheSize cap exhaustion: cache:vl3d/pool stayed 1x1 (pw=1, ph=1)
    return stale_1x1_ptr, 1, 1
end

-- Unmodified scan_pool_from_object(1920, 1080, 0.15) computes gw=64, gh=34 (8,704 bytes) and ignores pw=1,ph=1!
E.scan_pool_from_object(1920, 1080, 0.15)
print("UNEXPECTED_SURVIVAL")
''')

    # (7b) fb_save fallback: check_and_grab_fb_draw ignores pw_obj, ph_obj of "object" -> OOB WRITE overflow!
    fb_obj_write_crash = run_luajit_isolated(r'''
local ffi = require("ffi")
local GW = _G._GW

local fb_ga  = ffi.new("guard_alloc_t[1]")
local obj_ga = ffi.new("guard_alloc_t[1]")
local fb_bytes  = 1920 * 1080 * 4
local obj_bytes = 512 * 512 * 4 -- "object" capped smaller than framebuffer, flush before PROT_NONE!
assert(GW.gw_guard_alloc(fb_bytes,  0, fb_ga) == 0)
assert(GW.gw_guard_alloc(obj_bytes, 1, obj_ga) == 0)

local pf_c  = ffi.cast("void*", fb_ga[0].ptr)
local p_obj = ffi.cast("void*", obj_ga[0].ptr)
ffi.cast("uint32_t*", pf_c)[0] = 0xFFFFFFFF

-- Exact logic from check_and_grab_fb_draw (lines 4802-4816): ignores returned pw, ph on "object"
local total_px = 1920 * 1080
ffi.copy(p_obj, pf_c, total_px * 4) -- OOB WRITE past 512x512 buffer into PROT_NONE!
print("UNEXPECTED_SURVIVAL")
''')

    # (7c) Quantify RGBA16Float HDR highlight destruction + PCIe/RAM bandwidth of fb_save roundtrip
    hdr_loss = run_luajit_isolated(r'''
local ffi = require("ffi")
-- Simulate 1920x1080 RGBA16Float HDR framebuffer containing sky/bloom highlights [3.50, 2.20, 0.85, 1.0]
local hdr_in = { 3.50, 2.20, 0.85, 1.00 }
local u8_clamped = {}
for c = 1, 4 do
    local q = math.floor(math.max(0.0, math.min(1.0, hdr_in[c])) * 255.0 + 0.5)
    u8_clamped[c] = q / 255.0
end
local peak_loss_pct = (1.0 - u8_clamped[1] / hdr_in[1]) * 100.0
local copy_bytes_per_frame = 1920 * 1080 * 4 * 4 -- save + zero-fill + grab + restore = 4 full-frame ops
print(string.format("HDR_IN_R=%.2f HDR_OUT_R=%.4f PEAK_LOSS_PCT=%.2f BW_MB_PER_FRAME=%.2f",
    hdr_in[1], u8_clamped[1], peak_loss_pct, copy_bytes_per_frame / (1024.0 * 1024.0)))
''')
    return {
        "scan_pool_stale_1x1_oob_crash": pool_oob_crash,
        "fb_grab_object_write_overflow_crash": fb_obj_write_crash,
        "fb_save_hdr_clamping_and_bw": hdr_loss,
    }


# =========================================================================
# T8: rasterize_tri_max NaN / Inf Coordinate -> cvttsd2si -2147483648 OOB Crash (M-09)
# =========================================================================
def test_t8_rasterizer_nan_inf() -> dict:
    nan_test = run_luajit_isolated(r'''
local ffi = require("ffi")
local GW = _G._GW
local E = _G._VL_EXPORT

local w, h = 128, 128
local zbuf_ga = ffi.new("guard_alloc_t[1]")
local rmin_ga = ffi.new("guard_alloc_t[1]")
local rmax_ga = ffi.new("guard_alloc_t[1]")
assert(GW.gw_guard_alloc(w * h * 4, 0, zbuf_ga) == 0)
assert(GW.gw_guard_alloc(h * 4,     0, rmin_ga) == 0)
assert(GW.gw_guard_alloc(h * 4,     0, rmax_ga) == 0)

local zbuf    = ffi.cast("float*",   zbuf_ga[0].ptr)
local row_min = ffi.cast("int32_t*", rmin_ga[0].ptr)
local row_max = ffi.cast("int32_t*", rmax_ga[0].ptr)
for y = 0, h - 1 do row_min[y] = w; row_max[y] = -1 end

-- Test 1: NaN vertex coordinate
local nan = 0.0 / 0.0
E.rasterize_tri_max(zbuf, row_min, row_max, w, h, nan, 10.0, 0.5, 20.0, 10.0, 0.5, 20.0, 20.0, 0.5, 0.0, true)

-- Test 2: +Inf / -Inf vertex coordinate (e.g. float overflow 1e38 * 100 in GLB/OBJ)
local inf = math.huge
E.rasterize_tri_max(zbuf, row_min, row_max, w, h, -inf, 10.0, 0.5, inf, 10.0, 0.5, 20.0, 11.0, 0.5, 0.0, true)

print("NAN_INF_FINISHED rmin10=", row_min[10], "rmax10=", row_max[10])
''')
    return nan_test


# =========================================================================
# T9: utf8_to_utf16le_array Null-Byte Injection & Win32 Handle Leak on OOM (M-10)
# =========================================================================
def test_t9_utf16_and_handle_leak() -> dict:
    utf16_fuzz = run_luajit_isolated(r'''
local ffi = require("ffi")
local E = _G._VL_EXPORT
E._VL_PERSIST.w32_mb2wc_fn = nil -- test pure-Lua fallback path (lines 1625-1668)

-- Case A: GBK/Shift-JIS sequence 0xC1 0x40 inside "C:\Models\<0xC1 0x40>\cage.obj"
local malicious_gbk = "C:\\Models\\\193\64\\cage.obj"
local warr, wlen = E.utf8_to_utf16le_array(ffi, malicious_gbk)
local decoded = E.utf16le_ptr_to_utf8(warr, wlen + 1)

-- Case B: Overlong Modified-UTF8 NUL 0xC0 0x80 inside "C:\Safe\..\0xC0\0x80\secret.obj"
local overlong_nul = "C:\\Models\\\192\128\\secret.obj"
local warr2, wlen2 = E.utf8_to_utf16le_array(ffi, overlong_nul)
local decoded2 = E.utf16le_ptr_to_utf8(warr2, wlen2 + 1)

-- Case C: Invalid 0xFF 0xFE BOM / raw bytes -> produces out-of-range UTF-16 code unit > 0xDFFF or wraps!
local bad_hi = "\247\191\191\191" -- cp = 7*262144 + 63*4096 + 63*64 + 63 = 2,097,151 (> 0x10FFFF!)
local warr3, wlen3 = E.utf8_to_utf16le_array(ffi, bad_hi)

print(string.format("GBK_IN_LEN=%d WLEN=%d DECODED='%s' TRUNCATED=%s OVERLONG_DECODED='%s' BAD_SURROGATE_HI=0x%04X",
    #malicious_gbk, wlen, decoded, tostring(#decoded < 15), decoded2, tonumber(warr3[0])))
''')

    handle_leak = run_luajit_isolated(r'''
local ffi = require("ffi")
local GW = _G._GW
local E = _G._VL_EXPORT

-- Simulate ReadFile / ffi.new throwing an OOM error inside win32_read_file_wide_from_utf8 after CreateFileW succeeds!
-- Inject a temporary hook on ReadFile that raises a Lua error (simulating LuaJIT OOM in ffi.new/ffi.string)
GW.gw_reset_handles(1024 * 1024)
_G.VL3D_TEST_W32_API.ReadFile = function(...)
    error("not enough memory")
end
for i = 1, 10 do
    E.win32_read_file_wide_from_utf8("C:\\test\\model_" .. i .. ".vrm")
end
local opened = GW.gw_get_open_handles()
local closed = GW.gw_get_closed_handles()
print(string.format("OPENED=%d CLOSED=%d LEAKED_HANDLES=%d", opened, closed, opened - closed))
''')
    return {
        "utf16_null_injection_and_surrogate": utf16_fuzz,
        "win32_handle_leak_on_error": handle_leak,
    }


# =========================================================================
# T10: Cross-Script Footprint, v2.85 New Memory Readers, & VRM_POSE_CACHE Churn (M-11 & M-12)
# =========================================================================
def test_t10_cross_version_and_caches() -> dict:
    # (10a) Test v2.85_未完成草稿's TWO new reverse-engineered memory readers:
    #       1) EffectItem [fx0 + 0x90..0x98] -> ip+0x08 (0x0A Color), ip+0x38..0x3A (R,G,B)
    #       2) is_hardware_shadow_pass() [rctx + 0xC0] == 30 (0x1e)
    v285_readers = run_luajit_isolated(r'''
local ffi = require("ffi")
local GW = _G._GW
local E = _G._VL_EXPORT

local exe_ga  = ffi.new("guard_alloc_t[1]")
local heap_ga = ffi.new("guard_alloc_t[1]")
assert(GW.gw_guard_alloc(0x600000, 0, exe_ga) == 0)
assert(GW.gw_guard_alloc(0x20000,  0, heap_ga) == 0)

local exe_base  = exe_ga[0].ptr
local heap_base = heap_ga[0].ptr
GW.gw_reset_regions()
GW.gw_set_exe_base(exe_base)
GW.gw_register_region(exe_base,  0x600000, 0x1000, 0x04, 0x1000000)
GW.gw_register_region(heap_base, 0x20000,  0x1000, 0x04, 0x20000)

local b = ffi.cast("uint8_t*", exe_base)
b[0], b[1] = 0x4D, 0x5A
ffi.cast("int32_t*", b + 0x3C)[0] = 0x80
local nt = b + 0x80
nt[0], nt[1] = 0x50, 0x45
ffi.cast("uint16_t*", nt + 6)[0]  = 1
ffi.cast("uint16_t*", nt + 20)[0] = 0xF0
local sh = nt + 24 + 0xF0
ffi.copy(sh, ".data\0\0\0", 8)
ffi.cast("uint32_t*", sh + 8)[0]  = 0x20000
ffi.cast("uint32_t*", sh + 12)[0] = 0x580000
ffi.cast("uint32_t*", sh + 36)[0] = 0xC0000040

-- Build complete Scene -> Layer -> Object -> Effect -> EffectItem graph in synthetic aviutl2.exe memory!
local lctx       = heap_base + 0x1000
local rctx       = heap_base + 0x2000
local gbuf       = heap_base + 0x3000
local sptr       = heap_base + 0x4000
local layers_vec = heap_base + 0x5000
local layer5_ptr = heap_base + 0x6000
local obj_vec16  = heap_base + 0x7000
local eobj       = heap_base + 0x8000
local fx_vec     = heap_base + 0x8800
local fx0        = heap_base + 0x9000
local wname      = heap_base + 0xA100
local item_vec   = heap_base + 0xB000
local item_col   = heap_base + 0xB200

ffi.cast("uint64_t*", exe_base + 0x58AAB8)[0] = lctx
ffi.cast("uint64_t*", lctx + 0x88)[0]  = rctx
ffi.cast("uint64_t*", rctx + 0x00)[0]  = sptr -- active Scene*
ffi.cast("int32_t*",  rctx + 0x0C)[0]  = 10   -- current frame = 10
ffi.cast("int32_t*",  rctx + 0xC0)[0]  = 0    -- normal render pass first
ffi.cast("uint64_t*", rctx + 0xD0)[0]  = gbuf

-- Scene: +0x00 = scene_id(0), +0x08..0x10 = layers vector (5 layers)
ffi.cast("int32_t*",  sptr + 0x00)[0]  = 0
ffi.cast("uint64_t*", sptr + 0x08)[0]  = layers_vec
ffi.cast("uint64_t*", sptr + 0x10)[0]  = layers_vec + 5 * 8
ffi.cast("uint64_t*", layers_vec + 4 * 8)[0] = layer5_ptr -- oln=5 => index 4

-- Layer: +0x00..0x08 = 16-byte stride object entry vector
ffi.cast("uint64_t*", layer5_ptr + 0x00)[0] = obj_vec16
ffi.cast("uint64_t*", layer5_ptr + 0x08)[0] = obj_vec16 + 16
ffi.cast("uint64_t*", obj_vec16)[0]         = eobj

-- Timeline object: +0x50=fstart(0), +0x54=fend(300), +0x18..0x20=fx_vec
ffi.cast("int32_t*",  eobj + 0x50)[0] = 0
ffi.cast("int32_t*",  eobj + 0x54)[0] = 300
ffi.cast("uint64_t*", eobj + 0x18)[0] = fx_vec
ffi.cast("uint64_t*", eobj + 0x20)[0] = fx_vec + 8
ffi.cast("uint64_t*", fx_vec)[0]      = fx0

-- fx0: +0x40 = wchar_t* fx_name (L"水面"), +0x5A = disabled(0)
ffi.cast("uint64_t*", fx0 + 0x40)[0]  = wname
ffi.cast("uint8_t*",  fx0 + 0x5A)[0]  = 0
local wp = ffi.cast("uint16_t*", wname)
wp[0], wp[1], wp[2] = 0x6C34, 0x9762, 0 -- "水面"

-- EffectItem vector [fx0 + 0x90..0x98]: item_col with type 0x0A (Color), RGB = (0xFF, 0x88, 0x22)
ffi.cast("uint64_t*", fx0 + 0x90)[0] = item_vec
ffi.cast("uint64_t*", fx0 + 0x98)[0] = item_vec + 8
ffi.cast("uint64_t*", item_vec)[0]   = item_col
ffi.cast("uint8_t*",  item_col + 0x08)[0] = 0x0A
ffi.cast("uint8_t*",  item_col + 0x38)[0] = 0xFF
ffi.cast("uint8_t*",  item_col + 0x39)[0] = 0x88
ffi.cast("uint8_t*",  item_col + 0x3A)[0] = 0x22

local r_layer = E.resolve_live_scene_layer_object(5, 10)
local sh_normal = E.is_hardware_shadow_pass()
ffi.cast("int32_t*", rctx + 0xC0)[0] = 30 -- 0x1e shadow map pass!
local sh_active = E.is_hardware_shadow_pass()

print(string.format("STATUS=%s FX=%s COLOR_HEX=0x%06X SHADOW_NORMAL=%s SHADOW_30=%s",
    tostring(r_layer and r_layer.status), tostring(r_layer and r_layer.fx_name),
    tonumber(r_layer and r_layer.color_hex or 0), tostring(sh_normal), tostring(sh_active)))
''', use_v285=True)

    # (10b) VRM_POSE_CACHE[oln] Multi-Scene Collision + Unclosed Native Handle Leak Proof
    vrm_cache_churn = run_luajit_isolated(r'''
local E = _G._VL_EXPORT
local open_calls, close_calls, active_handles = 0, 0, 0
local cur_vrm_path = "C:\\Models\\alice.vrm"

_G.obj.module = function(name)
    if name == "VRMToolkitBridge" then
        return {
            open_model = function(path, max_t, anim)
                open_calls = open_calls + 1
                active_handles = active_handles + 1
                return 100 + open_calls
            end,
            close_model = function(h)
                close_calls = close_calls + 1
                active_handles = active_handles - 1
            end,
            requires_time_update = function(_) return false end,
            prepare_frame = function() end,
            get_group_count = function() return 1 end,
            get_group_mode = function() return "color" end,
            get_group_triangle_count = function() return 1 end,
            get_group_color_chunk = function()
                return { 0,0,0, 1,1,1,1,  1,0,0, 1,1,1,1,  0,1,0, 1,1,1,1 }
            end,
        }
    end
    return nil
end

-- Simulate 30 frames where Scene 0 and Sub-Scene 1 both render a VRM on Layer 5 (oln=5):
for frame = 1, 30 do
    cur_vrm_path = "C:\\Models\\scene0_alice.vrm"
    E.load_vrm_layer_mesh(5, cur_vrm_path)
    cur_vrm_path = "C:\\Models\\scene1_bob.vrm"
    E.load_vrm_layer_mesh(5, cur_vrm_path)
end
print(string.format("FRAMES=30 OPEN_CALLS=%d CLOSE_CALLS=%d UNCLOSED_AT_EXIT=%d",
    open_calls, close_calls, active_handles))
''')

    # (10c) win32_read_file_wide Peak RAM Amplification Measurement (buf + ffi.string simultaneous peak)
    peak_ram = run_luajit_isolated(r'''
local ffi = require("ffi")
local GW = _G._GW
local E = _G._VL_EXPORT

-- Simulate reading a 64 MB .vrm file via win32_read_file_wide_from_utf8
local FILE_SZ = 64 * 1024 * 1024
GW.gw_reset_handles(FILE_SZ)
collectgarbage("collect")
collectgarbage("stop")
local kb0 = collectgarbage("count")
local s = E.win32_read_file_wide_from_utf8("C:\\Models\\heavy_64mb.vrm")
local kb_peak = collectgarbage("count") -- both `buf` (64MB cdata) and `s` (64MB Lua string) allocated in GC arena!
collectgarbage("restart")
collectgarbage("collect")
local kb_retained = collectgarbage("count")
s = nil
collectgarbage("collect")
local kb_after_free = collectgarbage("count")

print(string.format("FILE_MB=64.0 PEAK_DELTA_MB=%.2f RETAINED_MB=%.2f RATIO=%.2fx AFTER_FREE_MB=%.2f",
    (kb_peak - kb0) / 1024.0, (kb_retained - kb0) / 1024.0,
    ((kb_peak - kb0) / 1024.0) / 64.0, (kb_after_free - kb0) / 1024.0))
''')
    return {
        "v285_new_live_readers": v285_readers,
        "vrm_pose_cache_multiscene_churn": vrm_cache_churn,
        "win32_file_read_peak_ram_amplification": peak_ram,
    }


def main():
    print("=" * 78)
    print("Running Hardware-Guarded Memory Access Audit Suite (T1..T10)...")
    print("=" * 78)
    results = {
        "static_surface": audit_static_surface(),
        "T1_pcall_vs_sigsegv": test_t1_pcall_vs_sigsegv(),
        "T2_live_camera_light_mutation": test_t2_live_camera_light_mutation(),
        "T3_pe_optsz_oob": test_t3_pe_optsz_oob(),
        "T4_modelfile_scanner_hazards": test_t4_modelfile_scanner_hazards(),
        "T5_pe_export_fuzzer": test_t5_pe_export_fuzzer(),
        "T6_glb_stride_and_gc_churn": test_t6_glb_stride_and_gc_churn(),
        "T7_pixeldata_bounds_and_hdr": test_t7_pixeldata_bounds_and_hdr(),
        "T8_rasterizer_nan_inf": test_t8_rasterizer_nan_inf(),
        "T9_utf16_and_handle_leak": test_t9_utf16_and_handle_leak(),
        "T10_cross_version_and_caches": test_t10_cross_version_and_caches(),
    }
    OUT_JSON.parent.mkdir(parents=True, exist_ok=True)
    OUT_JSON.write_text(json.dumps(results, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(results, ensure_ascii=False, indent=2))
    print(f"\nSaved complete empirical metrics -> {OUT_JSON}")


if __name__ == "__main__":
    main()
