#!/usr/bin/env python3
"""One-page figure for the v2.91 drag-freeze fix. Numbers are from the LuaJIT run."""
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import font_manager

font_manager.fontManager.addfont("/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc")
plt.rcParams["font.family"] = "Noto Sans CJK JP"
plt.rcParams["axes.unicode_minus"] = False

OUT = Path("/home/user/sandbox/results/figures/fig13_drag_freeze_fix.png")
OUT.parent.mkdir(parents=True, exist_ok=True)

bg = "#10141c"
card = "#1a2130"
ink = "#f4f1ea"
muted = "#9aa8b8"
gold = "#f0c14d"
red = "#e15a4a"
green = "#3ddc97"
line = "#2c384c"

fig = plt.figure(figsize=(14.4, 8.4), facecolor=bg)
fig.suptitle("体積光（3D）v2.91 分支  ·  前景遮蔽拖动不再卡死", color=ink, fontsize=18, y=0.97)
fig.text(
    0.5, 0.925,
    "未并入 v2.86 主线。播放与静止画面仍走全质量。下面的时间是同一只 38012 三角细线笼的实测。",
    ha="center", color=muted, fontsize=11,
)

ax = fig.add_axes([0.06, 0.16, 0.46, 0.68])
ax.set_facecolor(card)
for sp in ax.spines.values():
    sp.set_color(line)
ax.tick_params(colors=muted)
ax.set_title("UI 线程阴影光栅", color=ink, fontsize=13, pad=10)
labels = ["拖动前\n1280² 全三角形", "拖动中\n256² 预览"]
vals = [269.4, 10.0]
bars = ax.bar(labels, vals, color=[red, green], width=0.62, zorder=3)
ax.set_ylabel("毫秒 / 次鼠标采样", color=muted)
ax.set_ylim(0, 340)
ax.yaxis.grid(True, color=line, zorder=0)
ax.set_axisbelow(True)
for bar, v, extra in zip(bars, vals, ["38012 三角", "3802 三角 · splat≤48"]):
    ax.text(bar.get_x() + bar.get_width() / 2, v + 8, f"{v:.1f} ms\n{extra}",
            ha="center", va="bottom", color=ink, fontsize=11)
ax.axhline(50, color=gold, ls="--", lw=1)
ax.text(1.45, 58, "50 ms", color=gold, fontsize=9, ha="right")

ax2 = fig.add_axes([0.58, 0.16, 0.38, 0.68])
ax2.set_facecolor(card)
ax2.set_xlim(0, 1)
ax2.set_ylim(0, 1)
ax2.axis("off")
ax2.set_title("这一帧里实际改了什么", color=ink, fontsize=13, pad=10)
rows = [
    (green, "拖动 / 缩放", "同一帧、变换变了 → 预览。切片压到 64。"),
    (green, "2D 遮罩", "按帧+图层+透明度复用，不再 obj.load。"),
    (green, "日志", "拖动中最多 0.4 秒一条，不再刷死日志窗。"),
    (green, "重入", "obj.load 再进脚本时直接返回，不释放缓存。"),
    (gold, "松开 / 暂停 / 播放", "变换不变或帧变了 → 恢复 1280 与原切片。"),
    (muted, "没改", "v2.86 主线、静止画质、C++ 插件光栅。"),
]
for i, (c, title, body) in enumerate(rows):
    y = 0.90 - i * 0.145
    ax2.add_patch(plt.Circle((0.04, y + 0.02), 0.018, color=c, transform=ax2.transAxes))
    ax2.text(0.09, y + 0.035, title, color=ink, fontsize=12, fontweight="medium", transform=ax2.transAxes)
    ax2.text(0.09, y - 0.02, body, color=muted, fontsize=10, transform=ax2.transAxes)

fig.text(0.06, 0.04, "LuaJIT 2.1  ·  分支脚本内的 build_3d_shadow_map  ·  31/31 拖动测试通过", color=muted, fontsize=9)
fig.savefig(OUT, dpi=140, facecolor=bg)
print(OUT)
