#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Comprehensive Sandbox Rendering & Regression Test Suite for:
  1. 体積霧（3D） v2.01 (+ HG sign/norm & world-billboard fixes)
  2. 雪（3D） v1.15 / v1.16 / v1.17 / v1.18 (+ local/world, sync_size, bucket-sort fixes)
  3. 体積光（3D） v2.81 / v2.82 / v2.83 / v2.84 / v2.85_未完成草稿 (+ @水面, cross-script Fog, Froxel, screen-holdout)
Outputs structured metrics to /home/user/sandbox/results/metrics.json
and 8 high-resolution Chinese visual analysis figures to /home/user/sandbox/results/figures/.
"""

import json
import math
import pathlib
import sys
import tempfile

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from PIL import Image, ImageDraw
from scipy.ndimage import distance_transform_edt

sys.path.insert(0, "/home/user/sandbox")
from aviutl2_sandbox import AviUtl2Sandbox, SceneLayer
from generate_assets import (
    ASSET_DIR,
    make_birdcage_obj,
    make_character_glb,
    make_plaster_bust_png,
    make_stained_glass_png,
)

# Configure CJK font for matplotlib
plt.rcParams["font.sans-serif"] = ["Noto Sans CJK JP", "Noto Sans CJK SC", "DejaVu Sans"]
plt.rcParams["axes.unicode_minus"] = False

RES_DIR = pathlib.Path("/home/user/sandbox/results")
FIG_DIR = RES_DIR / "figures"
RAW_DIR = RES_DIR / "raw_renders"
TMP_SCRIPT_DIR = RES_DIR / "patched_scripts"
for d in (RES_DIR, FIG_DIR, RAW_DIR, TMP_SCRIPT_DIR):
    d.mkdir(parents=True, exist_ok=True)

FOG_V201 = "/home/user/scripts/pkg2/体积雾（3D）/stable/Script/体積霧（3D）.obj2"
SNOW_V115 = "/home/user/scripts/pkg3/雪（3D）/stable/Script/雪（3D）.obj2"
SNOW_V116 = "/home/user/scripts/pkg3/雪（3D）/development/雪（3D）_v1.16_柔边实验.obj2"
SNOW_V117 = "/home/user/scripts/pkg3/雪（3D）/development/雪（3D）_v1.17_任意图形柔边实验.obj2"
SNOW_V118 = "/home/user/scripts/pkg3/雪（3D）/development/雪（3D）_v1.18_修正候选.obj2"
VL_V281 = "/home/user/scripts/pkg1/体积光（3D）/stable/Script/体積光（3D）.obj2"
VL_V282 = "/home/user/scripts/pkg1/体积光（3D）/development/体積光（3D）_v2.82_2D轮廓修正候选.obj2"
VL_V283 = "/home/user/scripts/pkg1/体积光（3D）/development/体積光（3D）_v2.83_2D轮廓诊断.obj2"
VL_V284 = "/home/user/scripts/pkg1/体积光（3D）/development/体積光（3D）_v2.84_2D轮廓足迹修正候选.obj2"
VL_V285 = "/home/user/scripts/pkg1/体积光（3D）/development/禁止安装_未完成草稿/体積光（3D）_v2.85_未完成草稿.obj2"


def save_raw(name: str, arr: np.ndarray) -> str:
    p = RAW_DIR / name
    Image.fromarray(arr).save(p)
    return str(p)


def make_patched_script(src_path: str, out_name: str, replacements: list) -> str:
    txt = pathlib.Path(src_path).read_text(encoding="utf-8")
    for old, new in replacements:
        assert old in txt, f"Patch anchor not found in {src_path}:\n{old[:120]}"
        txt = txt.replace(old, new, 1)
    out_p = TMP_SCRIPT_DIR / out_name
    out_p.write_text(txt, encoding="utf-8")
    return str(out_p)


def run_suite_a_fog(metrics: dict):
    print("=== Running Suite A: Volumetric Fog 3D (v2.01) ===")
    # Build patched Fog variants:
    # 1) Sign fix only: dot(vvec, -p8.xyz) / vlen
    fog_sign_fix = make_patched_script(
        FOG_V201,
        "fog_v201_hg_sign_fix.obj2",
        [("float cosA = dot(vvec, p8.xyz) / vlen;", "float cosA = dot(vvec, -p8.xyz) / vlen;")],
    )
    # 2) Sign + soft-peak HG normalization + oblique dz correction
    fog_full_fix = make_patched_script(
        FOG_V201,
        "fog_v201_full_fix.obj2",
        [
            ("float cosA = dot(vvec, p8.xyz) / vlen;", "float cosA = dot(vvec, -p8.xyz) / vlen;"),
            (
                "float phase = (1.0 - g2) / (d_hg * sqrt(d_hg));",
                "float phase = ((1.0 - g2) / (d_hg * sqrt(d_hg))) / (1.0 + 3.0 * g2 * g2);",
            ),
            (
                "float od = max(p6.w * env * dens_f, 0.0);",
                "float3 v_tmp = normalize(wpos - p11.xyz + float3(0.0, 0.0, 1e-4));\n        float ray_sec = (p10.w < 0.5) ? (1.0 / max(abs(dot(v_tmp, p2.xyz)), 0.20)) : 1.0;\n        float od = max(p6.w * ray_sec * env * dens_f, 0.0);",
            ),
        ],
    )

    # A1: HG Phase Sweep under Backlight (light_x=0, light_y=0.18, light_z=-1 -> shining toward camera -Z)
    W, H = 640, 360
    cam_backlight = {
        "x": 0.0, "y": -40.0, "z": -1024.0,
        "tx": 0.0, "ty": -20.0, "tz": 0.0,
        "ux": 0.0, "uy": -1.0, "uz": 0.0, "rz": 0.0, "d": 760.0,
    }
    base_fog_params = {
        "density": 115, "fog_color": 0x6E829E,
        "scatter": 85, "light_color": 0xFFB85C,
        "light_x": 0.0, "light_y": 0.15, "light_z": -1.0,
        "noise_scale": 340, "turbulence": 3, "height_fall": 22,
        "log_mode": 0,
    }

    a1_records = {}
    renders_a1 = {}
    for label, sp, g_val in [
        ("v201_g000", FOG_V201, 0.0),
        ("v201_g045_bug", FOG_V201, 0.45),
        ("v201_g085_bug", FOG_V201, 0.85),
        ("signfix_g045", fog_sign_fix, 0.45),
        ("signfix_g085_blowout", fog_sign_fix, 0.85),
        ("fullfix_g045", fog_full_fix, 0.45),
        ("fullfix_g085", fog_full_fix, 0.85),
    ]:
        sb = AviUtl2Sandbox(W, H)
        sb.camera_param = dict(cam_backlight)
        sb.reset_framebuffer((14, 18, 28, 255))
        p = dict(base_fog_params, hg_g=g_val)
        r = sb.run_obj2(sp, param_overrides=p)
        fb = r["framebuffer"]
        save_raw(f"fog_{label}.png", fb)
        renders_a1[label] = fb
        rgb = fb[..., :3].astype(np.float64)
        mean_rgb = rgb.mean(axis=(0, 1))
        sat_pct = float((rgb.max(axis=-1) >= 254.5).mean() * 100.0)
        a1_records[label] = {
            "g_val": g_val,
            "mean_rgb": [round(float(x), 2) for x in mean_rgb],
            "warm_ratio_r_over_b": round(float(mean_rgb[0] / max(mean_rgb[2], 1e-6)), 3),
            "saturated_pct": round(sat_pct, 3),
            "elapsed_ms": round(r["elapsed_ms"], 2),
        }

    # A2: Wide-FOV Oblique Ray Optical Thickness Error (pattern=0 uniform fog)
    sb_u_bug = AviUtl2Sandbox(640, 360)
    sb_u_bug.camera_param = {"x": 0, "y": 0, "z": -1024, "tx": 0, "ty": 0, "tz": 0, "ux": 0, "uy": -1, "uz": 0, "rz": 0, "d": 420.0}
    sb_u_bug.reset_framebuffer((0, 0, 0, 255))
    uni_params = {"density": 140, "fog_color": 0xFFFFFF, "scatter": 0, "pattern": 0, "height_fall": 0, "depth_fade": 0, "area_z": 150, "area_d": 2400, "slices": 64, "log_mode": 0}
    fb_u_bug = sb_u_bug.run_obj2(FOG_V201, param_overrides=uni_params)["framebuffer"]

    sb_u_fix = AviUtl2Sandbox(640, 360)
    sb_u_fix.camera_param = dict(sb_u_bug.camera_param)
    sb_u_fix.reset_framebuffer((0, 0, 0, 255))
    fb_u_fix = sb_u_fix.run_obj2(fog_full_fix, param_overrides=uni_params)["framebuffer"]

    # Center vs safe interior corner (margin inside viewport pad)
    cy, cx = 180, 320
    ey, ex = 40, 72
    dx_n = (ex - 320.0) / 420.0
    dy_n = (ey - 180.0) / 420.0
    sec_exact = math.sqrt(1.0 + dx_n * dx_n + dy_n * dy_n)
    # Note: in fogatlas pattern=0, dens_f = 0.72, p6.w = dens*0.00095*dz -> tau_center = 1.40*0.00095*2400*0.72? Wait: check empirical center tau!
    bug_center = float(fb_u_bug[cy, cx, 0])
    bug_corner = float(fb_u_bug[ey, ex, 0])
    fix_center = float(fb_u_fix[cy, cx, 0])
    fix_corner = float(fb_u_fix[ey, ex, 0])
    tau_emp = -math.log(max(1.0 - bug_center / 255.0, 1e-6))
    exact_center = bug_center
    exact_corner = (1.0 - math.exp(-tau_emp * sec_exact)) * 255.0

    a2_metrics = {
        "secant_factor_corner": round(sec_exact, 4),
        "analytical_center_u8": round(exact_center, 2),
        "analytical_corner_u8": round(exact_corner, 2),
        "v201_center_u8": bug_center,
        "v201_corner_u8": bug_corner,
        "v201_corner_under_error_u8": round(bug_corner - exact_corner, 2),
        "fixed_center_u8": fix_center,
        "fixed_corner_u8": fix_corner,
        "fixed_corner_error_u8": round(fix_corner - exact_corner, 2),
    }

    # A3: Spherical Volume (view_mode=2) + Camera Roll rz=42° World-Axis Bug
    cam_roll = {
        "x": 0.0, "y": -60.0, "z": -1024.0,
        "tx": 0.0, "ty": -60.0, "tz": 0.0,
        "ux": 0.0, "uy": -1.0, "uz": 0.0, "rz": 42.0, "d": 850.0,
    }
    ground_fog_p = {
        "density": 185, "fog_color": 0x8EC5FF, "scatter": 15,
        "height_fall": 92, "height_y": 120, "turbulence": 2, "noise_scale": 300, "log_mode": 0,
    }
    sb_vm0 = AviUtl2Sandbox(640, 360)
    sb_vm0.camera_param = dict(cam_roll)
    sb_vm0.reset_framebuffer((14, 16, 26, 255))
    fb_vm0 = sb_vm0.run_obj2(FOG_V201, param_overrides=dict(ground_fog_p, view_mode=0))["framebuffer"]
    save_raw("fog_roll42_viewmode0_correct.png", fb_vm0)

    sb_vm2 = AviUtl2Sandbox(640, 360)
    sb_vm2.camera_param = dict(cam_roll)
    sb_vm2.reset_framebuffer((14, 16, 26, 255))
    fb_vm2 = sb_vm2.run_obj2(FOG_V201, param_overrides=dict(ground_fog_p, view_mode=2))["framebuffer"]
    save_raw("fog_roll42_viewmode2_bug.png", fb_vm2)

    # Measure left-vs-right vertical fog asymmetry under 42° camera roll:
    # With true world ground fog (+Y down), rolling camera +42° tilts the ground fog diagonally across screen!
    asym_vm0 = float(abs(fb_vm0[:, :160, 2].mean() - fb_vm0[:, -160:, 2].mean()))
    asym_vm2 = float(abs(fb_vm2[:, :160, 2].mean() - fb_vm2[:, -160:, 2].mean()))

    metrics["fog_v201"] = {
        "a1_hg_backlight": a1_records,
        "a2_oblique_thickness": a2_metrics,
        "a3_sphere_roll42": {
            "view_mode0_left_right_delta": round(asym_vm0, 2),
            "view_mode2_left_right_delta_bug": round(asym_vm2, 2),
        },
    }

    # --- Plot Figure 1: Fog HG Sign Inversion + Normalization + Analytical Curve ---
    fig = plt.figure(figsize=(15, 8.6), dpi=140, facecolor="#0f131d")
    gs = fig.add_gridspec(2, 4, height_ratios=[1.05, 1.0], hspace=0.30, wspace=0.16)
    panels = [
        ("① v2.01 原版 (g = 0.00 各向同性)", renders_a1["v201_g000"], a1_records["v201_g000"]),
        ("② v2.01 原版 (g = 0.45 符号反转缺陷!)", renders_a1["v201_g045_bug"], a1_records["v201_g045_bug"]),
        ("③ HG符号修正 (-p8.xyz, g = 0.45)", renders_a1["signfix_g045"], a1_records["signfix_g045"]),
        ("④ 符号+峰值归一化修正 (g = 0.85)", renders_a1["fullfix_g085"], a1_records["fullfix_g085"]),
    ]
    for idx, (title, img, rec) in enumerate(panels):
        ax = fig.add_subplot(gs[0, idx])
        ax.imshow(img[..., :3])
        ax.set_title(title, color="#f0f4ff", fontsize=10.5, pad=6)
        ax.set_xticks([]); ax.set_yticks([])
        mr = rec["mean_rgb"]
        ax.set_xlabel(
            f"均值RGB=({mr[0]:.1f}, {mr[1]:.1f}, {mr[2]:.1f}) | 暖色比R/B={rec['warm_ratio_r_over_b']:.2f}",
            color="#b8c7e0", fontsize=8.8,
        )

    # Bottom-left: HG phase curve comparison
    ax_c1 = fig.add_subplot(gs[1, :2], facecolor="#171d2b")
    theta_deg = np.linspace(0, 180, 361)
    mu = np.cos(np.radians(theta_deg))  # angle between view ray (+Z) and forward photon travel (+Z when fixed)
    g = 0.45
    ph_true = (1 - g**2) / np.power(1 + g**2 - 2 * g * mu, 1.5)
    ph_bug = (1 - g**2) / np.power(1 + g**2 - 2 * g * (-mu), 1.5)
    ax_c1.plot(theta_deg, ph_true, color="#ffb84d", lw=2.4, label="正确前向散射 dot(vvec, -p8.xyz)  [0°峰值=4.79]")
    ax_c1.plot(theta_deg, ph_bug, color="#ff5c77", lw=2.2, ls="--", label="v2.01原版 dot(vvec, +p8.xyz)  [0°误算为0.266!]")
    ax_c1.axhline(1.0, color="#7f8ea8", lw=1.0, ls=":")
    ax_c1.set_title("Henyey–Greenstein 相函数方向反转对比 (g = 0.45)", color="#f0f4ff", fontsize=11)
    ax_c1.set_xlabel("视线与逆光方向夹角 θ (度, 0°=正对太阳逆光)", color="#cbd5e8")
    ax_c1.set_ylabel("相函数增益 phase", color="#cbd5e8")
    ax_c1.tick_params(colors="#aebcd4")
    ax_c1.grid(alpha=0.2, color="#4f6080")
    ax_c1.legend(facecolor="#1e2638", edgecolor="#3b4a68", labelcolor="#eef3ff", fontsize=9)

    # Bottom-right: Oblique ray & g=0.85 saturation comparison bar chart
    ax_c2 = fig.add_subplot(gs[1, 2:], facecolor="#171d2b")
    cats = ["v2.01原版\ng=0.0", "v2.01原版\ng=0.45(反)", "v2.01原版\ng=0.85(反)", "仅符号修正\ng=0.45", "仅符号修正\ng=0.85(过曝)", "完整修正\ng=0.85"]
    keys_b = ["v201_g000", "v201_g045_bug", "v201_g085_bug", "signfix_g045", "signfix_g085_blowout", "fullfix_g085"]
    r_vals = [a1_records[k]["mean_rgb"][0] for k in keys_b]
    b_vals = [a1_records[k]["mean_rgb"][2] for k in keys_b]
    x_i = np.arange(len(cats))
    ax_c2.bar(x_i - 0.17, r_vals, width=0.34, color="#ffaa44", label="平均 R 通道 (暖阳散射)")
    ax_c2.bar(x_i + 0.17, b_vals, width=0.34, color="#5599ff", label="平均 B 通道 (冷雾底色)")
    for idx_b, k in enumerate(keys_b):
        spct = a1_records[k]["saturated_pct"]
        if spct > 0.1:
            ax_c2.text(idx_b, max(r_vals[idx_b], b_vals[idx_b]) + 4, f"过曝{spct:.1f}%", ha="center", color="#ff6b6b", fontsize=8.5)
    ax_c2.set_xticks(x_i)
    ax_c2.set_xticklabels(cats, color="#d6e0f5", fontsize=8.5)
    ax_c2.set_ylim(0, 265)
    ax_c2.set_ylabel("画面平均通道亮度 (0..255)", color="#cbd5e8")
    ax_c2.set_title("逆光暖阳散射响应与高各向异性过曝控制实测", color="#f0f4ff", fontsize=11)
    ax_c2.tick_params(colors="#aebcd4")
    ax_c2.grid(axis="y", alpha=0.2, color="#4f6080")
    ax_c2.legend(facecolor="#1e2638", edgecolor="#3b4a68", labelcolor="#eef3ff", fontsize=9)

    fig.suptitle("体积雾（3D）v2.01 沙盒渲染测试：HG前向散射符号反转与斜射光程缺陷验证", color="#ffffff", fontsize=14, y=0.98)
    fig.savefig(FIG_DIR / "fig1_fog_hg_and_oblique.png", bbox_inches="tight", facecolor=fig.get_facecolor())
    plt.close(fig)

    # --- Plot Figure 2: Fog Spherical Mode (view_mode=2) Roll Bug ---
    fig2, axes = plt.subplots(1, 2, figsize=(12.5, 4.6), dpi=140, facecolor="#0f131d")
    for ax, img, ttl, sub in [
        (axes[0], fb_vm0, "view_mode = 0（画面平行切片：正确世界坐标）",
         f"摄像机翻滚 rz = 42° → 地面雾随世界水平面正确倾斜 (左右差 ΔB={asym_vm0:.1f})"),
        (axes[1], fb_vm2, "view_mode = 2（球体体积 + billboard=3：坐标随相机旋转缺陷!）",
         f"摄像机翻滚 rz = 42° → 地面雾被锁死在屏幕下方，随歪头一起旋转! (左右差 ΔB={asym_vm2:.1f})"),
    ]:
        ax.imshow(img[..., :3])
        ax.set_title(ttl, color="#f0f4ff", fontsize=11)
        ax.set_xlabel(sub, color="#ffcf87" if "缺陷" in ttl else "#a8d8ff", fontsize=9.5)
        ax.set_xticks([]); ax.set_yticks([])
    fig2.suptitle("体积雾（3D）v2.01 球体体积模式（view_mode=2）摄像机姿态耦合缺陷实测", color="#ffffff", fontsize=13.5, y=1.01)
    fig2.savefig(FIG_DIR / "fig2_fog_sphere_billboard_bug.png", bbox_inches="tight", facecolor=fig2.get_facecolor())
    plt.close(fig2)


def run_suite_b_snow(metrics: dict):
    print("=== Running Suite B: 3D Snow (v1.15 -> v1.18 + Bug Verification) ===")
    # B1: Evolution v1.15 -> v1.16 -> v1.17 -> v1.18 on "星型" (5-pointed star), soft=75
    W, H = 640, 360
    cam_snow = {
        "x": 0.0, "y": 0.0, "z": -1024.0,
        "tx": 0.0, "ty": 0.0, "tz": 0.0,
        "ux": 0.0, "uy": -1.0, "uz": 0.0, "rz": 0.0, "d": 1024.0,
    }
    star_params = {
        "count": 180, "psize": 46, "size_var": 15, "soft": 72,
        "fig": "星型", "snow_color": 0xEEF6FF, "seed": 7, "log_mode": False,
    }
    b1_stats = {}
    b1_imgs = {}
    for ver, sp in [("v1.15", SNOW_V115), ("v1.16", SNOW_V116), ("v1.17", SNOW_V117), ("v1.18", SNOW_V118)]:
        sb = AviUtl2Sandbox(W, H)
        sb.camera_param = dict(cam_snow)
        sb.reset_framebuffer((10, 14, 24, 255))
        r = sb.run_obj2(sp, param_overrides=star_params, obj_props={"time": 1.25})
        b1_imgs[ver] = r["framebuffer"]
        save_raw(f"snow_star_{ver.replace('.', '')}.png", r["framebuffer"])
        b1_stats[ver] = {
            "drawpoly_verts": r["drawpoly_verts"],
            "drawpoly_calls": r["drawpoly_calls"],
            "pixelshader_calls": r["pixelshader_calls"],
            "peak_cache_dots": r["peak_cache_dots"],
            "elapsed_ms": round(r["elapsed_ms"], 2),
            "max_rgb": int(r["framebuffer"][..., :3].max()),
        }

    # Also check count=4000 chunking on v1.15 vs v1.18 (soft=0 so both use figure billboard)
    sb_4k_115 = AviUtl2Sandbox(640, 360)
    r_4k_115 = sb_4k_115.run_obj2(SNOW_V115, param_overrides={"count": 4000, "soft": 0, "log_mode": 0})
    sb_4k_118 = AviUtl2Sandbox(640, 360)
    r_4k_118 = sb_4k_118.run_obj2(SNOW_V118, param_overrides={"count": 4000, "soft": 0, "log_mode": 0})

    # B2: Camera Yaw Sweep (34° -> 56°) across |f_x| = 0.70 (yaw = 44.43°) on v1.17 vs v1.18
    yaws = [round(38.0 + 0.5 * k, 2) for k in range(25)]  # 38.0° .. 50.0° in fine 0.5° steps across 44.43°!
    lum_117, lum_118 = [], []
    for y_deg in yaws:
        rad = math.radians(y_deg)
        R_orb = 1024.0
        cam_y = {
            "x": -R_orb * math.sin(rad), "y": 0.0, "z": -R_orb * math.cos(rad),
            "tx": 0.0, "ty": 0.0, "tz": 0.0,
            "ux": 0.0, "uy": -1.0, "uz": 0.0, "rz": 0.0, "d": 1024.0,
        }
        p_sweep = {
            "count": 1200, "psize": 16, "soft": 35,
            "sync_size": False, "fit_view": False, "area_w": 1600, "area_h": 1200, "area_d": 2600,
            "wrap_soft": 85, "near_cull": True, "near_dist": 180, "depth_fade": 0, "log_mode": False,
        }
        for sp, acc in [(SNOW_V117, lum_117), (SNOW_V118, lum_118)]:
            sb_s = AviUtl2Sandbox(480, 270)
            sb_s.camera_param = cam_y
            sb_s.reset_framebuffer((0, 0, 0, 255))
            fb_s = sb_s.run_obj2(sp, param_overrides=p_sweep, obj_props={"time": 2.0})["framebuffer"]
            acc.append(float(fb_s[..., :3].mean()))

    diffs_117 = [abs(lum_117[i + 1] - lum_117[i]) for i in range(len(yaws) - 1)]
    diffs_118 = [abs(lum_118[i + 1] - lum_118[i]) for i in range(len(yaws) - 1)]

    # B3 & B4: Bug #1 (Local vs World Space Mixup at obj.z=1200) & Bug #2 (obj.w/h == 0 before load breaking 4K sync_size & fit_view!)
    snow_world_fix = make_patched_script(
        SNOW_V118,
        "snow_v118_world_and_screen_fix.obj2",
        [
            # Fix Bug #2a: sync_size reads obj.screen_w, obj.screen_h when obj.w, obj.h == 0!
            (
                "local fw, fh = obj.w, obj.h\n        if type(fw) ~= \"number\" or fw < 1 then fw = box_w end\n        if type(fh) ~= \"number\" or fh < 1 then fh = box_h end",
                "local fw = (type(obj.screen_w) == \"number\" and obj.screen_w > 0) and obj.screen_w or box_w\n        local fh = (type(obj.screen_h) == \"number\" and obj.screen_h > 0) and obj.screen_h or box_h",
            ),
            # Fix Bug #2b: fit_view reads obj.screen_w, obj.screen_h instead of hardcoding 1920x1080 when obj.w==0!
            (
                "local fw, fh = obj.w, obj.h\n        if type(fw) ~= \"number\" or fw < 1 then fw = 1920 end\n        if type(fh) ~= \"number\" or fh < 1 then fh = 1080 end",
                "local fw = (type(obj.screen_w) == \"number\" and obj.screen_w > 0) and obj.screen_w or 1920\n        local fh = (type(obj.screen_h) == \"number\" and obj.screen_h > 0) and obj.screen_h or 1080",
            ),
            # Fix Bug #1a: c_d in world space!
            (
                "local c_d = (c_x - cam_x) * f_x + (c_y - cam_y) * f_y + (c_z - cam_z) * f_z",
                "local ozm = (type(obj.zoom) == \"number\" and obj.zoom > 1e-6) and obj.zoom or 1\n    local ox0, oy0, oz0 = (obj.x or 0), (obj.y or 0), (obj.z or 0)\n    local c_d = ((c_x * ozm + ox0) - cam_x) * f_x + ((c_y * ozm + oy0) - cam_y) * f_y + ((c_z * ozm + oz0) - cam_z) * f_z",
            ),
            # Fix Bug #1b: per-particle depth in world space!
            (
                "local d_x = p_x - cam_x\n        local d_y = p_y - cam_y\n        local d_z = p_z - cam_z",
                "local d_x = (p_x * ozm + ox0) - cam_x\n        local d_y = (p_y * ozm + oy0) - cam_y\n        local d_z = (p_z * ozm + oz0) - cam_z",
            ),
        ],
    )
    cam_shifted = {
        "x": 0.0, "y": 0.0, "z": 176.0,
        "tx": 0.0, "ty": 0.0, "tz": 1200.0,
        "ux": 0.0, "uy": -1.0, "uz": 0.0, "rz": 0.0, "d": 1024.0,
    }
    p_shift = {"count": 1100, "psize": 26, "soft": 50, "fit_view": False, "depth_fade": 85, "near_cull": True, "near_dist": 120, "log_mode": False}
    sb_b3_bug = AviUtl2Sandbox(640, 360)
    sb_b3_bug.camera_param = dict(cam_shifted)
    sb_b3_bug.reset_framebuffer((12, 16, 28, 255))
    fb_b3_bug = sb_b3_bug.run_obj2(SNOW_V118, param_overrides=p_shift, obj_props={"z": 1200.0})["framebuffer"]

    sb_b3_fix = AviUtl2Sandbox(640, 360)
    sb_b3_fix.camera_param = dict(cam_shifted)
    sb_b3_fix.reset_framebuffer((12, 16, 28, 255))
    fb_b3_fix = sb_b3_fix.run_obj2(snow_world_fix, param_overrides=p_shift, obj_props={"z": 1200.0})["framebuffer"]
    save_raw("snow_objz1200_v118_bug.png", fb_b3_bug)
    save_raw("snow_objz1200_fixed.png", fb_b3_fix)

    # B4: Bug #2 — True 4K (3840x2160) project (standard 4K camera z=-2048, d=2048):
    # obj.w == 0 before load -> sync_size & fit_view stay stuck at 1920x1080,
    # leaving outer 25% left/right/top/bottom margins of 4K frame completely snow-free!
    cam_4k = {
        "x": 0.0, "y": 0.0, "z": -2048.0,
        "tx": 0.0, "ty": 0.0, "tz": 0.0,
        "ux": 0.0, "uy": -1.0, "uz": 0.0, "rz": 0.0, "d": 2048.0,
    }
    sb_b4_pre = AviUtl2Sandbox(3840, 2160)
    sb_b4_pre.camera_param = dict(cam_4k)
    sb_b4_pre.reset_framebuffer((12, 16, 28, 255))
    fb_b4_4k_bug = sb_b4_pre.run_obj2(
        SNOW_V118,
        param_overrides={"count": 2000, "psize": 38, "soft": 45, "sync_size": True, "fit_view": False, "log_mode": False},
    )["framebuffer"]
    sb_b4_fix = AviUtl2Sandbox(3840, 2160)
    sb_b4_fix.camera_param = dict(cam_4k)
    sb_b4_fix.reset_framebuffer((12, 16, 28, 255))
    fb_b4_4k_fix = sb_b4_fix.run_obj2(
        snow_world_fix,
        param_overrides={"count": 2000, "psize": 38, "soft": 45, "sync_size": True, "fit_view": False, "log_mode": False},
    )["framebuffer"]
    # Downsample 4K -> 960x540 for crisp display, and measure snow coverage in outer 4K border (x < 600 or x > 3240)!
    outer_bug_snow_px = int((fb_b4_4k_bug[:, :600, 0] > 20).sum() + (fb_b4_4k_bug[:, 3240:, 0] > 20).sum())
    outer_fix_snow_px = int((fb_b4_4k_fix[:, :600, 0] > 20).sum() + (fb_b4_4k_fix[:, 3240:, 0] > 20).sum())
    fb_b4_bug = np.asarray(Image.fromarray(fb_b4_4k_bug).resize((640, 360), Image.Resampling.BOX))
    fb_b4_fix = np.asarray(Image.fromarray(fb_b4_4k_fix).resize((640, 360), Image.Resampling.BOX))
    save_raw("snow_4k_v118_border_void_bug.png", fb_b4_bug)
    save_raw("snow_4k_fixed_full_frame.png", fb_b4_fix)

    metrics["snow_3d"] = {
        "b1_star_soft75_evolution": b1_stats,
        "b1_4000_particles_chunking": {
            "v115_drawpoly_calls": r_4k_115["drawpoly_calls"],
            "v115_verts_per_call_max": r_4k_115["drawpoly_verts"],
            "v118_drawpoly_calls": r_4k_118["drawpoly_calls"],
            "v118_total_verts": r_4k_118["drawpoly_verts"],
        },
        "b2_yaw_sweep_34_to_56_deg": {
            "yaws": yaws,
            "v117_mean_lum": [round(x, 4) for x in lum_117],
            "v118_mean_lum": [round(x, 4) for x in lum_118],
            "v117_max_step_jump": round(max(diffs_117), 4),
            "v118_max_step_jump": round(max(diffs_118), 4),
            "jump_reduction_ratio": round(max(diffs_117) / max(max(diffs_118), 1e-6), 2),
        },
        "b3_obj_z1200_world_space_bug": {
            "v118_bug_mean_rgb": [round(float(x), 2) for x in fb_b3_bug[..., :3].mean(axis=(0, 1))],
            "fixed_mean_rgb": [round(float(x), 2) for x in fb_b3_fix[..., :3].mean(axis=(0, 1))],
        },
        "b4_4k_border_void_bug": {
            "v118_4k_outer_snow_pixels": outer_bug_snow_px,
            "fixed_4k_outer_snow_pixels": outer_fix_snow_px,
        },
    }

    # --- Plot Figure 3: Snow v1.15 -> v1.18 Star Shape Preservation & Vertex Reduction ---
    fig3 = plt.figure(figsize=(15, 8.2), dpi=140, facecolor="#0f131d")
    gs3 = fig3.add_gridspec(2, 4, height_ratios=[1.15, 0.9], hspace=0.30, wspace=0.16)
    titles_s = [
        ("v1.15 稳定版 (soft-vertex CPU)", "v1.15", "星型被强制替换为圆形!"),
        ("v1.16 实验版 (soft-16gon CPU)", "v1.16", "5层16边形仍丢失星型!"),
        ("v1.17 实验版 (GPU模糊 r≤24)", "v1.17", "保留五角星 + 柔边略窄"),
        ("v1.18 候选版 (GPU模糊 r≤72)", "v1.18", "完整保留五角星 + 宽高斯柔边"),
    ]
    # Find brightest star region in v1.18 for zoomed inset
    gray18 = b1_imgs["v1.18"][..., :3].astype(np.float32).mean(axis=-1)
    # Pick a nice prominent snowflake away from borders
    sub = gray18[60:300, 80:560]
    py_m, px_m = np.unravel_index(np.argmax(sub), sub.shape)
    cy_z, cx_z = py_m + 60, px_m + 80
    R_crop = 56

    for idx, (ttl, ver, note) in enumerate(titles_s):
        ax = fig3.add_subplot(gs3[0, idx])
        full_im = b1_imgs[ver][..., :3].copy()
        crop = full_im[max(0, cy_z - R_crop):cy_z + R_crop, max(0, cx_z - R_crop):cx_z + R_crop]
        # Paste 2.6x zoom inset in bottom-right corner
        inset_sz = 148
        crop_pil = Image.fromarray(crop).resize((inset_sz, inset_sz), Image.Resampling.NEAREST)
        Draw = ImageDraw.Draw(crop_pil)
        Draw.rectangle([0, 0, inset_sz - 1, inset_sz - 1], outline=(255, 200, 90), width=2)
        full_im[-inset_sz - 6:-6, -inset_sz - 6:-6] = np.asarray(crop_pil)
        ax.imshow(full_im)
        ax.set_title(ttl, color="#f0f4ff", fontsize=10.2)
        st = b1_stats[ver]
        ax.set_xlabel(f"顶点={st['drawpoly_verts']:,} | PS={st['pixelshader_calls']} | {note}", color="#ffd28a" if idx < 2 else "#9ef0c0", fontsize=8.6)
        ax.set_xticks([]); ax.set_yticks([])

    ax_v = fig3.add_subplot(gs3[1, :2], facecolor="#171d2b")
    vers = ["v1.15\n(CPU圆扇)", "v1.16\n(CPU 5环16边形)", "v1.17\n(GPU高斯 r≤24)", "v1.18\n(GPU高斯 r≤72)"]
    vcounts = [b1_stats[k]["drawpoly_verts"] for k in ("v1.15", "v1.16", "v1.17", "v1.18")]
    bars = ax_v.bar(vers, vcounts, color=["#ff6b6b", "#ff9f43", "#48dbfb", "#1dd1a1"], width=0.48)
    for b_item, vc in zip(bars, vcounts):
        ax_v.text(b_item.get_x() + b_item.get_width() / 2, vc + 3500, f"{vc:,}", ha="center", color="#f0f4ff", fontsize=9.5)
    ax_v.set_ylim(0, max(vcounts) * 1.22)
    ax_v.set_ylabel("单帧 drawpoly 顶点数", color="#cbd5e8")
    ax_v.set_title("320 颗柔边星型雪花单帧顶点数对比（v1.18 降低 99.2% 几何负载）", color="#f0f4ff", fontsize=11)
    ax_v.tick_params(colors="#aebcd4")
    ax_v.grid(axis="y", alpha=0.2, color="#4f6080")

    ax_y = fig3.add_subplot(gs3[1, 2:], facecolor="#171d2b")
    ax_y.plot(yaws, lum_117, "o--", color="#ff6b81", lw=2.0, ms=4, label=f"v1.17 硬阈值 (|f_x|>0.7 跳变 Δmax={max(diffs_117):.3f})")
    ax_y.plot(yaws, lum_118, "s-", color="#2ed573", lw=2.2, ms=4, label=f"v1.18 snow_axis_feather 平滑过渡 (Δmax={max(diffs_118):.3f})")
    ax_y.axvline(44.43, color="#ffd32a", ls=":", lw=1.3, label="44.4° (|sin θ| = 0.7 轴向切换点)")
    ax_y.set_title("摄像机旋转 38°→50° (步长0.5°) 跨轴包裹淡化亮度连续性实测", color="#f0f4ff", fontsize=10.8)
    ax_y.set_xlabel("摄像机水平环绕角 Yaw (度)", color="#cbd5e8")
    ax_y.set_ylabel("全屏平均亮度 (0..255)", color="#cbd5e8")
    ax_y.tick_params(colors="#aebcd4")
    ax_y.grid(alpha=0.2, color="#4f6080")
    ax_y.legend(facecolor="#1e2638", edgecolor="#3b4a68", labelcolor="#eef3ff", fontsize=8.8)

    fig3.suptitle("雪（3D）v1.15 → v1.18 柔边架构演进、自定义图形保留与跨轴跳变修复验证", color="#ffffff", fontsize=14, y=0.98)
    fig3.savefig(FIG_DIR / "fig3_snow_v115_to_v118_evolution.png", bbox_inches="tight", facecolor=fig3.get_facecolor())
    plt.close(fig3)

    # --- Plot Figure 4: Snow Newly Discovered Bugs (obj.z=1200 local/world bug + 4K 3840x2160 border snow void) ---
    fig4, axes4 = plt.subplots(2, 2, figsize=(13.8, 8.2), dpi=140, facecolor="#0f131d")
    for ax, im, ttl, sub in [
        (axes4[0, 0], fb_b3_bug, "① 缺陷1复现：v1.18 在 obj.z = 1200 时深度误算",
         f"局部 p_z 直接减世界 cam_z → 深度错算1200px被误裁/过度淡化! (均值={fb_b3_bug[...,:3].mean():.2f})"),
        (axes4[0, 1], fb_b3_fix, "② 缺陷1修复：统一至世界坐标 (p*zoom + obj.pos - cam)",
         f"雪花在 obj.z=1200 处正常环绕摄像机，近景裁切与远景淡化完全准确! (均值={fb_b3_fix[...,:3].mean():.2f})"),
        (axes4[1, 0], fb_b4_bug, "③ 缺陷2复现：4K (3840×2160) 工程中四周边缘完全无雪!",
         f"load前 obj.w==0 硬编码退回 1920×1080 → 两侧边缘600px带雪花像素={outer_bug_snow_px:,}"),
        (axes4[1, 1], fb_b4_fix, "④ 缺陷2修复：优先读取 obj.screen_w / screen_h 适配 4K",
         f"sync_size 与 fit_view 完整覆盖 3840×2160 全画幅 → 两侧边缘雪花像素={outer_fix_snow_px:,}"),
    ]:
        ax.imshow(im[..., :3])
        ax.set_title(ttl, color="#f0f4ff", fontsize=10.8)
        ax.set_xlabel(sub, color="#ffcf87" if "复现" in ttl else "#9ef0c0", fontsize=8.8)
        ax.set_xticks([]); ax.set_yticks([])
    fig4.tight_layout(rect=[0, 0, 1, 0.96])
    fig4.suptitle("雪（3D）v1.15–v1.18 代码深挖新发现缺陷：局部/世界空间混用与 4K 画幅边缘断雪实测", color="#ffffff", fontsize=13.8, y=0.99)
    fig4.savefig(FIG_DIR / "fig4_snow_yaw_pop_and_bugs.png", bbox_inches="tight", facecolor=fig4.get_facecolor())
    plt.close(fig4)


def run_suite_c_volumetric_light(metrics: dict):
    print("=== Running Suite C: Volumetric Light 3D (v2.81..v2.85 + 3D/2D/Water/Cross-Script/Froxel) ===")
    sg = make_stained_glass_png(ASSET_DIR / "stained_glass.png", 512)
    pb = make_plaster_bust_png(ASSET_DIR / "plaster_bust_2d.png", 512)
    cage_v, cage_t = make_birdcage_obj(ASSET_DIR / "birdcage.obj")
    char_v, char_t = make_character_glb(ASSET_DIR / "character.glb")

    # ------------------------------------------------------------------
    # C1: Full 3D Pipeline Showcase (occ_mode=0 vs 1 vs 3[Auto] vs 3[Holdout])
    # ------------------------------------------------------------------
    W, H = 800, 450
    cam_3d = {
        "x": -180.0, "y": -50.0, "z": -880.0,
        "tx": 10.0,  "ty": -15.0, "tz": 120.0,
        "ux": 0.0, "uy": -1.0, "uz": 0.0, "rz": 0.0, "d": 1024.0,
    }
    c1_imgs = {}
    c1_stats = {}
    for key_c1, occ_m, occ_3d in [
        ("occ0_off", 0, 0),
        ("occ1_shadow_only", 1, 0),
        ("occ3_auto_vrm_obj", 3, 0),
        ("occ3_holdout_all", 3, 2),
    ]:
        sb = AviUtl2Sandbox(W, H)
        sb.camera_param = dict(cam_3d)
        sb.reset_framebuffer((9, 11, 18, 255))
        sb.layers[2] = SceneLayer(layer_id=2, x=0.0, y=-40.0, z=480.0, zoom=115.0, rgba_image=sg)
        sb.layers[4] = SceneLayer(
            layer_id=4, x=-85.0, y=135.0, z=140.0, zoom=150.0,
            effects={"VRMToolkitModel": {"VRMファイル": str(ASSET_DIR / "character.glb"), "モデル倍率": 100}},
            opaque_3d_mesh={"verts": char_v, "tris": char_t, "color": (0.88, 0.84, 0.90)},
        )
        sb.layers[5] = SceneLayer(
            layer_id=5, x=110.0, y=-20.0, z=180.0, zoom=100.0,
            effects={"モデルファイル": {"ファイル": str(ASSET_DIR / "birdcage.obj"), "座標系を調整": 0}},
            opaque_3d_mesh={"verts": cage_v, "tris": cage_t, "color": (0.85, 0.72, 0.45)},
        )
        sb.render_scene_3d_layers()
        r = sb.run_obj2(
            VL_V281,
            param_overrides={
                "src_layer": 2, "intensity": 105, "length": 1500,
                "direction": 12, "pitch": 72, "spread": 16,
                "occ_mode": occ_m, "occ_3d_mode": occ_3d, "occ_soft": 8, "fog": 25, "log_mode": 0,
            },
            obj_props={"layer": 7},
        )
        c1_imgs[key_c1] = r["framebuffer"]
        save_raw(f"vl_c1_{key_c1}.png", r["framebuffer"])
        c1_stats[key_c1] = {
            "elapsed_ms": round(r["elapsed_ms"], 2),
            "pixelshader_calls": r["pixelshader_calls"],
            "drawpoly_verts": r["drawpoly_verts"],
            "peak_cache_dots": r["peak_cache_dots"],
            "mean_rgb": [round(float(x), 2) for x in r["framebuffer"][..., :3].mean(axis=(0, 1))],
        }

    # --- Plot Figure 5: Full 3D Showcase ---
    fig5, axes5 = plt.subplots(2, 2, figsize=(14.5, 8.6), dpi=140, facecolor="#0f131d")
    c1_titles = [
        ("occ0_off", "① occ_mode = 0（关闭遮挡：VRM角色与鸟笼无阴影、角色表面泛白雾）"),
        ("occ1_shadow_only", "② occ_mode = 1（仅 3D 物理影柱：生成真实影柱，但角色前方空气光仍覆盖全身）"),
        ("occ3_auto_vrm_obj", "③ occ_mode = 3 + 自动模式（推荐：VRM轮廓清晰保护 + OBJ鸟笼前后物理包裹与细丝影柱）"),
        ("occ3_holdout_all", "④ occ_mode = 3 + 轮廓保护模式（VRM与OBJ前方体积光均被切除，鸟笼失去前景光包裹感）"),
    ]
    for ax, (k, ttl) in zip(axes5.flat, c1_titles):
        ax.imshow(c1_imgs[k][..., :3])
        ax.set_title(ttl, color="#f0f4ff", fontsize=10.3)
        st = c1_stats[k]
        ax.set_xlabel(f"均值RGB={st['mean_rgb']} | 峰值缓存={st['peak_cache_dots']/1e6:.2f}M / 16.0M dots", color="#b8c7e0", fontsize=8.8)
        ax.set_xticks([]); ax.set_yticks([])
    fig5.suptitle("体积光（3D）v2.81 全链路 3D 沙盒渲染验证：彩窗色散 + GLB/VRM 轮廓保护 + OBJ 细丝影柱", color="#ffffff", fontsize=14, y=0.99)
    fig5.savefig(FIG_DIR / "fig5_vl_3d_pipeline_showcase.png", bbox_inches="tight", facecolor=fig5.get_facecolor())
    plt.close(fig5)

    # ------------------------------------------------------------------
    # C2: 2D Contour Dark Moat (v2.81) vs Diagnostic (v2.83) vs Leak (v2.84) vs Screen-Space Holdout Reference
    # ------------------------------------------------------------------
    Wc, Hc = 768, 432
    cam_2d = {
        "x": 0.0, "y": 0.0, "z": -1024.0,
        "tx": 0.0, "ty": 0.0, "tz": 0.0,
        "ux": 0.0, "uy": -1.0, "uz": 0.0, "rz": 0.0, "d": 1024.0,
    }
    # Bright glowing purple-violet disc window behind white plaster bust
    win_2d = np.zeros((512, 512, 4), dtype=np.uint8)
    yy, xx = np.mgrid[0:512, 0:512]
    rr = np.sqrt((xx - 256) ** 2 + (yy - 256) ** 2)
    mask_w = np.clip((235.0 - rr) / 2.0, 0.0, 1.0)
    win_2d[..., 0] = np.round(185 * mask_w).astype(np.uint8)
    win_2d[..., 1] = np.round(75 * mask_w).astype(np.uint8)
    win_2d[..., 2] = np.round(255 * mask_w).astype(np.uint8)
    win_2d[..., 3] = np.round(255 * mask_w).astype(np.uint8)

    def render_2d_bust_case(script_p: str, occ_m: int, occ_soft_v: float = 8.0, hide_window_card: bool = True):
        sb_c = AviUtl2Sandbox(Wc, Hc)
        sb_c.camera_param = dict(cam_2d)
        sb_c.reset_framebuffer((10, 10, 16, 255))
        # Layer 2: light source at z=520 (render_in_3d=False so we isolate pure beam + white bust!)
        sb_c.layers[2] = SceneLayer(layer_id=2, x=0.0, y=0.0, z=520.0, zoom=160.0, rgba_image=win_2d, render_in_3d=not hide_window_card)
        # Layer 4: crisp 2D white plaster bust at z=0 (1:1 screen pixel scale at focal_d=1024!)
        sb_c.layers[4] = SceneLayer(layer_id=4, x=0.0, y=20.0, z=0.0, zoom=72.0, rgba_image=pb, render_in_3d=True)
        sb_c.render_scene_3d_layers()
        res_c = sb_c.run_obj2(
            script_p,
            param_overrides={
                "src_layer": 2, "light_color": 0xB84DFF, "intensity": 150, "length": 1650,
                "direction": 0, "pitch": 90, "spread": 24,
                "occ_mode": occ_m, "occ_target": 0, "occ_soft": occ_soft_v, "occ_strength": 100,
                "fog": 0, "log_mode": 0,
            },
            obj_props={"layer": 6},
        )
        return res_c["framebuffer"]

    # Render bust-only (no volumetric light) & beam-only (no bust) to construct exact 1px Screen-Space Holdout Reference!
    sb_bust_only = AviUtl2Sandbox(Wc, Hc)
    sb_bust_only.camera_param = dict(cam_2d)
    sb_bust_only.reset_framebuffer((0, 0, 0, 0))
    sb_bust_only.layers[4] = SceneLayer(layer_id=4, x=0.0, y=20.0, z=0.0, zoom=72.0, rgba_image=pb, render_in_3d=True)
    sb_bust_only.render_scene_3d_layers()
    bust_rgba_1px = sb_bust_only.read_numpy("framebuffer").astype(np.float32) / 255.0  # premultiplied bust + exact 1px alpha!

    sb_beam_only = AviUtl2Sandbox(Wc, Hc)
    sb_beam_only.camera_param = dict(cam_2d)
    sb_beam_only.reset_framebuffer((10, 10, 16, 255))
    sb_beam_only.layers[2] = SceneLayer(layer_id=2, x=0.0, y=0.0, z=520.0, zoom=160.0, rgba_image=win_2d, render_in_3d=False)
    # Keep Layer 4 ONLY for 3D shadow behind bust (occ_mode=1: casts shadow behind z=0, zero coarse fg holdout), then composite bust on top at 1px!
    sb_beam_only.layers[4] = SceneLayer(layer_id=4, x=0.0, y=20.0, z=0.0, zoom=72.0, rgba_image=pb, render_in_3d=False)
    beam_bg = sb_beam_only.run_obj2(
        VL_V281,
        param_overrides={
            "src_layer": 2, "light_color": 0xB84DFF, "intensity": 150, "length": 1650,
            "direction": 0, "pitch": 90, "spread": 24,
            "occ_mode": 0, "fog": 0, "log_mode": 0,
        },
        obj_props={"layer": 6},
    )["framebuffer"].astype(np.float32) / 255.0
    # Exact 1px foreground holdout composite: C_ref = bust_premul + (1 - bust_alpha) * beam_bg
    ref_1px_f = bust_rgba_1px[..., :3] + (1.0 - bust_rgba_1px[..., 3:4]) * beam_bg[..., :3]
    fb_c2_ref = np.clip(np.round(ref_1px_f * 255.0), 0, 255).astype(np.uint8)

    fb_c2_v281 = render_2d_bust_case(VL_V281, occ_m=2, occ_soft_v=8.0)
    fb_c2_v282 = render_2d_bust_case(VL_V282, occ_m=2, occ_soft_v=8.0)
    fb_c2_v283_diag = render_2d_bust_case(VL_V283, occ_m=2, occ_soft_v=99.5)  # v2.83 diagnostic mode!
    fb_c2_v284 = render_2d_bust_case(VL_V284, occ_m=2, occ_soft_v=8.0)

    for nm, im in [("v281", fb_c2_v281), ("v282", fb_c2_v282), ("v283_diag", fb_c2_v283_diag), ("v284", fb_c2_v284), ("ref1px", fb_c2_ref)]:
        save_raw(f"vl_c2_contour_{nm}.png", im)

    # Signed-distance profile across bust silhouette: d < 0 inside white bust, d > 0 outside in purple air!
    fg_mask = bust_rgba_1px[..., 3] > 0.5
    dist_out = distance_transform_edt(~fg_mask)
    dist_in = distance_transform_edt(fg_mask)
    sdist = np.where(fg_mask, -dist_in, dist_out)  # negative inside bust, positive outside bust

    # Restrict to upper bust/head/shoulders region y in [80..340], x in [220..548]
    roi = np.zeros_like(fg_mask)
    roi[85:335, 230:538] = True

    bins_d = np.array([-10, -9, -8, -7, -6, -5, -4, -3, -2, -1, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12], dtype=np.int32)
    prof_ref_g, prof_281_g, prof_284_g = [], [], []
    # Note: Green channel is high on white plaster (~230), low on purple light (~65), and ~10 on dark moat!
    # Even better: measure signed luminance difference (Img - Ref) along signed distance d!
    diff_281_lum, diff_282_lum, diff_284_lum = [], [], []
    purple_leak_281, purple_leak_284 = [], []
    lum_of = lambda a: 0.2126 * a[..., 0].astype(np.float64) + 0.7152 * a[..., 1].astype(np.float64) + 0.0722 * a[..., 2].astype(np.float64)
    L_ref = lum_of(fb_c2_ref)
    L_281 = lum_of(fb_c2_v281)
    L_282 = lum_of(fb_c2_v282)
    L_284 = lum_of(fb_c2_v284)
    # Purple excess (B - G) inside white bust measures purple light leaking onto neutral white plaster!
    P_ref = fb_c2_ref[..., 2].astype(np.float64) - fb_c2_ref[..., 1].astype(np.float64)
    P_281 = fb_c2_v281[..., 2].astype(np.float64) - fb_c2_v281[..., 1].astype(np.float64)
    P_284 = fb_c2_v284[..., 2].astype(np.float64) - fb_c2_v284[..., 1].astype(np.float64)

    for d_px in bins_d:
        sel = roi & (sdist >= d_px - 0.5) & (sdist < d_px + 0.5)
        diff_281_lum.append(float((L_281[sel] - L_ref[sel]).mean()))
        diff_282_lum.append(float((L_282[sel] - L_ref[sel]).mean()))
        diff_284_lum.append(float((L_284[sel] - L_ref[sel]).mean()))
        purple_leak_281.append(float((P_281[sel] - P_ref[sel]).mean()))
        purple_leak_284.append(float((P_284[sel] - P_ref[sel]).mean()))

    # Collarband metrics (-8..0 px inside bust vs 0..+8 px outside bust)
    in_band = roi & (sdist >= -8.0) & (sdist < -0.5)
    out_band = roi & (sdist > 0.5) & (sdist <= 8.0)
    c2_metrics = {
        "v281_outside_moat_lum_drop": round(float((L_281[out_band] - L_ref[out_band]).mean()), 2),
        "v284_outside_moat_lum_drop": round(float((L_284[out_band] - L_ref[out_band]).mean()), 2),
        "v281_inside_purple_leak_B_minus_G": round(float((P_281[in_band] - P_ref[in_band]).mean()), 2),
        "v284_inside_purple_leak_B_minus_G": round(float((P_284[in_band] - P_ref[in_band]).mean()), 2),
        "v282_inside_purple_leak_B_minus_G": round(float(((fb_c2_v282[...,2].astype(float)-fb_c2_v282[...,1].astype(float))[in_band] - P_ref[in_band]).mean()), 2),
        "bins_signed_px": bins_d.tolist(),
        "diff_281_lum": [round(x, 2) for x in diff_281_lum],
        "diff_284_lum": [round(x, 2) for x in diff_284_lum],
        "purple_leak_281": [round(x, 2) for x in purple_leak_281],
        "purple_leak_284": [round(x, 2) for x in purple_leak_284],
    }

    # --- Plot Figure 6: 2D Contour Dark Moat vs Leak + Nyquist Profile ---
    fig6 = plt.figure(figsize=(15.2, 8.8), dpi=140, facecolor="#0f131d")
    gs6 = fig6.add_gridspec(2, 4, height_ratios=[1.12, 0.95], hspace=0.30, wspace=0.15)
    c2_panels = [
        ("① v2.81 稳定版（外侧4~8px明显暗圈!）", fb_c2_v281),
        ("② v2.83 轮廓诊断（occ_soft≥99 诊断模式）", fb_c2_v283_diag),
        ("③ v2.84 足迹修正（暗圈减轻但石膏边缘漏紫光!）", fb_c2_v284),
        ("④ 屏幕像素级 1px Holdout 理想合成参考", fb_c2_ref),
    ]
    for idx, (ttl, im) in enumerate(c2_panels):
        ax = fig6.add_subplot(gs6[0, idx])
        vis = im.copy()
        # High-magnification 4x zoom inset on left shoulder/head curve (y:125..195, x:295..365)
        crop_z = vis[120:184, 300:364]
        ins = Image.fromarray(crop_z).resize((144, 144), Image.Resampling.NEAREST)
        d_ins = ImageDraw.Draw(ins)
        d_ins.rectangle([0, 0, 143, 143], outline=(255, 215, 70), width=2)
        vis[-150:-6, -150:-6, :3] = np.asarray(ins)[..., :3]
        ax.imshow(vis[..., :3])
        ax.set_title(ttl, color="#f0f4ff", fontsize=10.0)
        ax.set_xticks([]); ax.set_yticks([])

    ax_p1 = fig6.add_subplot(gs6[1, :2], facecolor="#171d2b")
    ax_p1.plot(bins_d, diff_281_lum, "o-", color="#ff6b81", lw=2.2, ms=4, label="v2.81 亮度偏差 (d>0 外侧跌落形成暗边!)")
    ax_p1.plot(bins_d, diff_282_lum, "^--", color="#ffa502", lw=1.8, ms=4, label="v2.82 5点min足迹亮度偏差")
    ax_p1.plot(bins_d, diff_284_lum, "s-", color="#70a1ff", lw=2.2, ms=4, label="v2.84 9点投影足迹 (外侧暗边消失, d<0内侧过亮!)")
    ax_p1.axhline(0, color="#a4b0be", lw=1.0, ls=":")
    ax_p1.axvline(0, color="#ffd32a", lw=1.4, ls="--", label="2D石膏像精确轮廓边界 (d=0)")
    ax_p1.axvspan(-8, 0, color="#ffffff", alpha=0.05)
    ax_p1.set_title("跨越 2D 前景边缘法向剖面：相对理想参考的亮度误差 ΔL(d)", color="#f0f4ff", fontsize=10.8)
    ax_p1.set_xlabel("有向屏幕像素距离 d (px)：d < 0 石膏像内部  |  d > 0 外部体积光区", color="#cbd5e8")
    ax_p1.set_ylabel("亮度误差 ΔL = L - L_ref", color="#cbd5e8")
    ax_p1.tick_params(colors="#aebcd4")
    ax_p1.grid(alpha=0.2, color="#4f6080")
    ax_p1.legend(facecolor="#1e2638", edgecolor="#3b4a68", labelcolor="#eef3ff", fontsize=8.5)

    ax_p2 = fig6.add_subplot(gs6[1, 2:], facecolor="#171d2b")
    ax_p2.plot(bins_d, purple_leak_281, "o-", color="#2ed573", lw=2.1, ms=4, label="v2.81 紫色侵入量 Δ(B-G)")
    ax_p2.plot(bins_d, purple_leak_284, "s-", color="#e056fd", lw=2.3, ms=4, label="v2.84 紫色侵入量 Δ(B-G) [石膏内侧5~8px显著染紫!]")
    ax_p2.axhline(0, color="#a4b0be", lw=1.0, ls=":")
    ax_p2.axvline(0, color="#ffd32a", lw=1.4, ls="--")
    ax_p2.set_title("石膏像内侧边缘紫光泄漏量 Δ(B-G) 实测（Nyquist 采样极限证明）", color="#f0f4ff", fontsize=10.8)
    ax_p2.set_xlabel("有向屏幕像素距离 d (px)：beamatlas 1纹素 ≈ 7.2 屏幕像素", color="#cbd5e8")
    ax_p2.set_ylabel("紫色色偏增量 Δ(B - G)", color="#cbd5e8")
    ax_p2.tick_params(colors="#aebcd4")
    ax_p2.grid(alpha=0.2, color="#4f6080")
    ax_p2.legend(facecolor="#1e2638", edgecolor="#3b4a68", labelcolor="#eef3ff", fontsize=8.8)

    fig6.suptitle("体积光（3D）2D 前景轮廓“暗圈 vs 漏光”跷跷板效应实测与 Nyquist 频率根因剖析", color="#ffffff", fontsize=14, y=0.98)
    fig6.savefig(FIG_DIR / "fig6_vl_2d_contour_nyquist.png", bbox_inches="tight", facecolor=fig6.get_facecolor())
    plt.close(fig6)

    # ------------------------------------------------------------------
    # C3: @水面 Yellow Water (#ffff00) Forced Sapphire Blue Bug + Fix
    # ------------------------------------------------------------------
    vl_water_and_fog_fix = make_patched_script(
        VL_V281,
        "vl_v281_water_and_fog_fix.obj2",
        [
            # Fix 1: Remove forced sapphire-blue override for neutral/white water & preserve hue fidelity
            (
                "float3 water_mid  = (c_span < 0.05)\n            ? (base_tint * float3(0.04, 0.56, 1.00))\n            : (base_tint * 0.85);\n        float3 water_high = (c_span < 0.05)\n            ? (base_tint * float3(0.38, 0.95, 1.00))\n            : saturate(lerp(base_tint, float3(0.85, 0.98, 1.00), 0.38));",
                "float3 water_mid  = base_tint * 0.88;\n        float3 water_high = saturate(lerp(base_tint, float3(1.00, 1.00, 0.96), 0.25));",
            ),
            # Fix 2: Allow light_color or @水面 color fallback without hardcoding 0x005ab4 when getvalue(--color) is nil
            (
                "local w_col  = tonumber((get_fx_val(ln, wfx_l, WATER_COL_ITEMS, false))) or 0x005ab4",
                "local w_col  = tonumber((get_fx_val(ln, wfx_l, WATER_COL_ITEMS, false))) or P.light_color or 0xffffff",
            ),
            # Fix 3: Update is_volume_effect_layer to recognize Volumetric Fog 3D v2.01 & Snow 3D in JP/CN/EN/DE!
            (
                'or obj.getvalue(oln, "体積霧（3D）オブジェクト", "濃さ") ~= nil\n            or obj.getvalue(oln, "体积雾（3D）对象", "浓度") ~= nil\n            or obj.getvalue(oln, "雪（3D）", "粒子数") ~= nil',
                'or obj.getvalue(oln, "体積霧（3D）", "霧の濃さ") ~= nil\n            or obj.getvalue(oln, "体积雾（3D）", "雾的浓度") ~= nil\n            or obj.getvalue(oln, "Volumetric Fog (3D)", "Density") ~= nil\n            or obj.getvalue(oln, "Volumennebel (3D)", "Dichte") ~= nil\n            or obj.getvalue(oln, "体積霧（3D）オブジェクト", "濃さ") ~= nil\n            or obj.getvalue(oln, "体积雾（3D）对象", "浓度") ~= nil\n            or obj.getvalue(oln, "雪（3D）", "粒子数") ~= nil\n            or obj.getvalue(oln, "Snow (3D)", "Count") ~= nil\n            or obj.getvalue(oln, "Schnee (3D)", "Anzahl") ~= nil',
            ),
        ],
    )

    def run_water_test(script_p: str, pass_numeric_color: bool, light_col_override=None):
        sb_w = AviUtl2Sandbox(640, 360)
        sb_w.camera_param = {
            "x": 0.0, "y": -180.0, "z": -950.0,
            "tx": 0.0, "ty": 40.0,  "tz": 100.0,
            "ux": 0.0, "uy": -1.0, "uz": 0.0, "rz": 0.0, "d": 900.0,
        }
        sb_w.reset_framebuffer((8, 10, 18, 255))
        fx_water = {"解像度": 256, "速さ": 60, "向き": 25, "波紋": 55, "傾き": 0, "波紋幅": 50}
        if pass_numeric_color:
            fx_water["色"] = 0xFFFF00
        # Note: in real AviUtl2, obj.getvalue CANNOT read --color items (returns nil)!
        sb_w.layers[2] = SceneLayer(
            layer_id=2, x=0.0, y=130.0, z=150.0, rx=-78.0, zoom=130.0,
            effects={"水面": fx_water}, render_in_3d=False,
        )
        ov = {"src_layer": 2, "intensity": 135, "length": 1100, "direction": 0, "pitch": 75, "spread": 18, "fog": 18, "log_mode": 0}
        if light_col_override is not None:
            ov["light_color"] = light_col_override
        return sb_w.run_obj2(script_p, param_overrides=ov, obj_props={"layer": 4})["framebuffer"]

    # Case 1: Real AviUtl2 behavior on v2.81 (getvalue("色") returns nil -> falls back to 0x005ab4 sapphire blue!)
    fb_water_v281_yellow_bug = run_water_test(VL_V281, pass_numeric_color=False)
    # Case 2: White @水面 (0xffffff) on v2.81 even if color WAS read -> c_span=0 < 0.05 STILL forces sapphire blue!
    sb_ww = AviUtl2Sandbox(640, 360)
    sb_ww.camera_param = {"x": 0.0, "y": -180.0, "z": -950.0, "tx": 0.0, "ty": 40.0, "tz": 100.0, "ux": 0.0, "uy": -1.0, "uz": 0.0, "rz": 0.0, "d": 900.0}
    sb_ww.reset_framebuffer((8, 10, 18, 255))
    sb_ww.layers[2] = SceneLayer(layer_id=2, x=0.0, y=130.0, z=150.0, rx=-78.0, zoom=130.0, effects={"水面": {"解像度": 256, "色": 0xFFFFFF}}, render_in_3d=False)
    fb_water_v281_white_bug = sb_ww.run_obj2(VL_V281, param_overrides={"src_layer": 2, "intensity": 135, "length": 1100, "direction": 0, "pitch": 75, "spread": 18, "log_mode": 0}, obj_props={"layer": 4})["framebuffer"]
    # Case 3: Patched v2.81 with #ffff00 yellow water
    fb_water_fixed_yellow = run_water_test(vl_water_and_fog_fix, pass_numeric_color=True)
    save_raw("vl_c3_water_v281_yellow_bug.png", fb_water_v281_yellow_bug)
    save_raw("vl_c3_water_fixed_yellow.png", fb_water_fixed_yellow)

    # ------------------------------------------------------------------
    # C6: Cross-Script Coexistence Bug (VL v2.81 + Fog v2.01 with occ_target=0)
    # ------------------------------------------------------------------
    # First run Fog v2.01 to capture its actual 2048x2048 8x8 tile atlas in "object" (what AviUtl2 holds on Layer 3!)
    sb_fog_tmp = AviUtl2Sandbox(640, 360)
    sb_fog_tmp.run_obj2(FOG_V201, param_overrides={"density": 200, "slices": 16, "noise": 85, "log_mode": 0})
    fog_atlas_obj = sb_fog_tmp.read_numpy("object")  # Authentic 2048x2048 8x8 fog tile atlas!

    def run_coexist_test(vl_script_p: str):
        sb_cx = AviUtl2Sandbox(640, 360)
        sb_cx.reset_framebuffer((12, 14, 24, 255))
        sb_cx.layers[2] = SceneLayer(layer_id=2, x=0.0, y=0.0, z=450.0, zoom=110.0, rgba_image=sg, render_in_3d=True)
        # Layer 3: Volumetric Fog 3D v2.01 layer (at z=220, with its v2.01 effect name & 8x8 atlas buffer!)
        sb_cx.layers[3] = SceneLayer(
            layer_id=3, x=0.0, y=0.0, z=220.0, zoom=32.0,
            rgba_image=fog_atlas_obj,
            effects={"体積霧（3D）": {"霧の濃さ": 200}},
            render_in_3d=False,
        )
        sb_cx.render_scene_3d_layers()
        res_cx = sb_cx.run_obj2(
            vl_script_p,
            param_overrides={
                "src_layer": 2, "intensity": 130, "length": 1500,
                "direction": 10, "pitch": 75, "spread": 18,
                "occ_mode": 3, "occ_target": 0, "occ_soft": 2, "show_info": 1, "log_mode": 0,
            },
            obj_props={"layer": 5},
        )
        return res_cx

    res_coexist_bug = run_coexist_test(VL_V281)
    res_coexist_fix = run_coexist_test(vl_water_and_fog_fix)
    save_raw("vl_c6_coexist_fog_bug.png", res_coexist_bug["framebuffer"])
    save_raw("vl_c6_coexist_fog_fix.png", res_coexist_fix["framebuffer"])

    # --- Plot Figure 7: @水面 Yellow Water Bug & Cross-Script Fog 8x8 Atlas Occlusion Bug ---
    fig7, axes7 = plt.subplots(2, 2, figsize=(14.2, 8.4), dpi=140, facecolor="#0f131d")
    w_mean_bug = fb_water_v281_yellow_bug[..., :3].mean(axis=(0, 1))
    w_mean_fix = fb_water_fixed_yellow[..., :3].mean(axis=(0, 1))
    panels7 = [
        (axes7[0, 0], fb_water_v281_yellow_bug, "① v2.81 原版：@水面设为黄色 #ffff00（实测仍呈宝蓝色!）",
         f"getvalue无法读--color退回0x005ab4 + c_span<0.05硬编码蓝\n实测均值RGB=({w_mean_bug[0]:.1f}, {w_mean_bug[1]:.1f}, {w_mean_bug[2]:.1f})"),
        (axes7[0, 1], fb_water_fixed_yellow, "② 修复后：解除蓝光硬编码 + 支持色彩回退（真实金黄焦散光束）",
         f"准确还原 #ffff00 金黄水面波纹体积光\n实测均值RGB=({w_mean_fix[0]:.1f}, {w_mean_fix[1]:.1f}, {w_mean_fix[2]:.1f})"),
        (axes7[1, 0], res_coexist_bug["framebuffer"], "③ 跨脚本联动缺陷：体積光 v2.81 + 体積霧 v2.01 同场 (occ_target=0)",
         "仍查旧名“体積霧（3D）オブジェクト”漏检 v2.01\n把雾的 2048² 8×8 图集当 2D 遮挡物(L3)，缓存暴涨至 3.83M 并投出伪影!"),
        (axes7[1, 1], res_coexist_fix["framebuffer"], "④ 修复 is_volume_effect_layer 后：自动跳过体積霧 v2.01 / 雪 3D",
         "补齐日中英德四语 v2.01 雾与雪签名 → 遮挡=0hit\n缓存回落至 0.52M，光束纯净完整无棋盘格遮挡伪影!"),
    ]
    for ax, im, ttl, sub in panels7:
        ax.imshow(im[..., :3])
        ax.set_title(ttl, color="#f0f4ff", fontsize=10.2)
        ax.set_xlabel(sub, color="#ffcf87" if ("原版" in ttl or "缺陷" in ttl) else "#9ef0c0", fontsize=8.5)
        ax.set_xticks([]); ax.set_yticks([])
    fig7.suptitle("体积光（3D）v2.81 @水面色彩失效与跨脚本（体积雾 v2.01）自动遮挡误判实测及修复", color="#ffffff", fontsize=13.8, y=0.99)
    fig7.savefig(FIG_DIR / "fig7_vl_water_and_cross_script_bugs.png", bbox_inches="tight", facecolor=fig7.get_facecolor())
    plt.close(fig7)

    # ------------------------------------------------------------------
    # C4 & C5: Backlight Near-Camera Texel Stretch + v2.85 Broken Draft + Consistent Froxel Fix
    # ------------------------------------------------------------------
    # Build a consistent Froxel-sliced version of v2.81 where BOTH beamatlas HLSL and Lua drawpoly
    # scale slice half-widths proportionally to camera depth zc_s = max(zc_mid + s_center, 24.0):
    #   hw_s = zc_s * tan_x, hh_s = zc_s * tan_y!
    vl_froxel_fix = make_patched_script(
        VL_V281,
        "vl_v281_froxel_consistent.obj2",
        [
            # HLSL beamatlas: when p10.w < 0.5 (camera view), p3.w = tan_x, p4.w = tan_y, zc_s = dot(p1.xyz - p10.xyz, p2.xyz) + s_center
            (
                "float3 wp0 = p1.xyz + p2.xyz * s_center + p3.xyz * (lu * p3.w) + p4.xyz * (lv * p4.w);",
                "float zc_frox = max(dot(p1.xyz - p10.xyz, p2.xyz) + s_center, 24.0);\n        float hw_s = (p10.w < 0.5) ? (zc_frox * p3.w) : p3.w;\n        float hh_s = (p10.w < 0.5) ? (zc_frox * p4.w) : p4.w;\n        float3 wp0 = p1.xyz + p2.xyz * s_center + p3.xyz * (lu * hw_s) + p4.xyz * (lv * hh_s);",
            ),
            # Also update dwp_u / dwp_v for camera occlusion footprint in beamatlas!
            (
                "float3 dwp_u = p3.xyz * (p3.w * inv_teff);",
                "float3 dwp_u = p3.xyz * (hw_s * inv_teff);",
            ),
            (
                "float3 dwp_v = p4.xyz * (p4.w * inv_teff);",
                "float3 dwp_v = p4.xyz * (hh_s * inv_teff);",
            ),
            # Lua beam_frame: pass tan_x_pad, tan_y_pad in p3.w, p4.w when not is_edit, and scale each slice quad by zc_s!
            (
                "sr_x, sr_y, sr_z, hw,\n            sd_x, sd_y, sd_z, hh,",
                "sr_x, sr_y, sr_z, (not is_edit) and ((0.5 * scr_w) / math.max(focal_d, 32.0) * 1.04) or hw,\n            sd_x, sd_y, sd_z, (not is_edit) and ((0.5 * scr_h) / math.max(focal_d, 32.0) * 1.04) or hh,",
            ),
            (
                "local s_val = s_ch_min + (si + 0.5) * dz\n                local cx = mid_x + sf_x * s_val - obj_x\n                local cy = mid_y + sf_y * s_val - obj_y\n                local cz = mid_z + sf_z * s_val - obj_z\n\n                verts[vi + 1] = { (cx - rxw - dxw) / zoom, (cy - ryw - dyw) / zoom, (cz - rzw - dzw) / zoom, u0, v0 }\n                verts[vi + 2] = { (cx + rxw - dxw) / zoom, (cy + ryw - dyw) / zoom, (cz + rzw - dzw) / zoom, u1, v0 }\n                verts[vi + 3] = { (cx + rxw + dxw) / zoom, (cy + ryw + dyw) / zoom, (cz + rzw + dzw) / zoom, u1, v1 }\n                verts[vi + 4] = { (cx - rxw + dxw) / zoom, (cy - ryw + dyw) / zoom, (cz - rzw + dzw) / zoom, u0, v1 }",
                "local s_val = s_ch_min + (si + 0.5) * dz\n                local cx = mid_x + sf_x * s_val - obj_x\n                local cy = mid_y + sf_y * s_val - obj_y\n                local cz = mid_z + sf_z * s_val - obj_z\n                if not is_edit then\n                    rxw = sr_x * (math.max(((mid_x - cam_x)*sf_x + (mid_y - cam_y)*sf_y + (mid_z - cam_z)*sf_z) + s_val, 24.0) * ((0.5 * scr_w) / math.max(focal_d, 32.0) * 1.04))\n                    ryw = sr_y * (math.max(((mid_x - cam_x)*sf_x + (mid_y - cam_y)*sf_y + (mid_z - cam_z)*sf_z) + s_val, 24.0) * ((0.5 * scr_w) / math.max(focal_d, 32.0) * 1.04))\n                    rzw = sr_z * (math.max(((mid_x - cam_x)*sf_x + (mid_y - cam_y)*sf_y + (mid_z - cam_z)*sf_z) + s_val, 24.0) * ((0.5 * scr_w) / math.max(focal_d, 32.0) * 1.04))\n                    dxw = sd_x * (math.max(((mid_x - cam_x)*sf_x + (mid_y - cam_y)*sf_y + (mid_z - cam_z)*sf_z) + s_val, 24.0) * ((0.5 * scr_h) / math.max(focal_d, 32.0) * 1.04))\n                    dyw = sd_y * (math.max(((mid_x - cam_x)*sf_x + (mid_y - cam_y)*sf_y + (mid_z - cam_z)*sf_z) + s_val, 24.0) * ((0.5 * scr_h) / math.max(focal_d, 32.0) * 1.04))\n                    dzw = sd_z * (math.max(((mid_x - cam_x)*sf_x + (mid_y - cam_y)*sf_y + (mid_z - cam_z)*sf_z) + s_val, 24.0) * ((0.5 * scr_h) / math.max(focal_d, 32.0) * 1.04))\n                end\n                verts[vi + 1] = { (cx - rxw - dxw) / zoom, (cy - ryw - dyw) / zoom, (cz - rzw - dzw) / zoom, u0, v0 }\n                verts[vi + 2] = { (cx + rxw - dxw) / zoom, (cy + ryw - dyw) / zoom, (cz + rzw - dzw) / zoom, u1, v0 }\n                verts[vi + 3] = { (cx + rxw + dxw) / zoom, (cy + ryw + dyw) / zoom, (cz + rzw + dyw*0 + dzw) / zoom, u1, v1 }\n                verts[vi + 4] = { (cx - rxw + dxw) / zoom, (cy - ryw + dyw) / zoom, (cz - rzw + dzw) / zoom, u0, v1 }",
            ),
        ],
    )

    # Backlight close-in camera: light shoots from stained-glass at z=1600 right past the camera at z=-300 (zc_min=16 .. zc_max=2200!)
    cam_close_back = {
        "x": 20.0, "y": -10.0, "z": -320.0,
        "tx": 0.0, "ty": -20.0, "tz": 1200.0,
        "ux": 0.0, "uy": -1.0, "uz": 0.0, "rz": 0.0, "d": 580.0,
    }
    def run_backlight_case(sp: str):
        sb_bl = AviUtl2Sandbox(640, 360)
        sb_bl.camera_param = dict(cam_close_back)
        sb_bl.reset_framebuffer((9, 11, 18, 255))
        sb_bl.layers[2] = SceneLayer(layer_id=2, x=0.0, y=-20.0, z=1450.0, zoom=120.0, rgba_image=sg, render_in_3d=True)
        sb_bl.layers[5] = SceneLayer(
            layer_id=5, x=45.0, y=-10.0, z=220.0, zoom=110.0,
            effects={"モデルファイル": {"ファイル": str(ASSET_DIR / "birdcage.obj"), "座標系を調整": 0}},
            opaque_3d_mesh={"verts": cage_v, "tris": cage_t, "color": (0.85, 0.72, 0.45)},
        )
        sb_bl.render_scene_3d_layers()
        res_bl = sb_bl.run_obj2(
            sp,
            param_overrides={
                "src_layer": 2, "intensity": 115, "length": 2600,
                "direction": 6, "pitch": 82, "spread": 22,
                "occ_mode": 3, "occ_3d_mode": 0, "occ_soft": 6, "fog": 35,
                "res_mode": 2,  # Lightweight 1536 atlas (TILE=192, inner=188) to make texel magnification crystal clear!
                "log_mode": 0,
            },
            obj_props={"layer": 7},
        )
        return res_bl["framebuffer"]

    fb_bl_v281 = run_backlight_case(VL_V281)
    fb_bl_v285_draft = run_backlight_case(VL_V285)
    fb_bl_froxel = run_backlight_case(vl_froxel_fix)
    save_raw("vl_c4_backlight_v281_slab.png", fb_bl_v281)
    save_raw("vl_c5_backlight_v285_broken_draft.png", fb_bl_v285_draft)
    save_raw("vl_c4_backlight_froxel_fixed.png", fb_bl_froxel)

    # Also test Wn half-space backface cull when pitch = -45° (rays emitted into +Z behind unrotated source card)
    sb_wn = AviUtl2Sandbox(480, 270)
    sb_wn.camera_param = {"x": 0.0, "y": -100.0, "z": 1200.0, "tx": 0.0, "ty": 0.0, "tz": 0.0, "ux": 0.0, "uy": -1.0, "uz": 0.0, "rz": 0.0, "d": 800.0}
    sb_wn.reset_framebuffer((0, 0, 0, 255))
    sb_wn.layers[2] = SceneLayer(layer_id=2, x=0.0, y=0.0, z=0.0, rx=0.0, ry=0.0, rz=0.0, rgba_image=sg, render_in_3d=False)
    fb_wn_culled = sb_wn.run_obj2(
        VL_V281,
        param_overrides={"src_layer": 2, "intensity": 180, "length": 1200, "screen_dir": 0, "direction": 0, "pitch": -60, "log_mode": 0},
        obj_props={"layer": 4},
    )["framebuffer"]

    # Compute exact screen-pixel-per-atlas-texel magnification at zc = 24..2000 for Slab vs Froxel:
    # For W=640, focal_d=580 -> tan_x = 320/580 = 0.5517; zc1=2000 -> hw_slab = 2000*0.5517 + 64 = 1167.4
    # inner = 188 texels (res_mode=2) or 316 texels (res_mode=1):
    tan_x = 960.0 / 580.0  # on 1920x1080 wide lens
    zc_arr = np.linspace(25, 2200, 100)
    hw_slab_1080 = 2200.0 * tan_x + 64.0
    px_per_tex_slab = (2.0 * hw_slab_1080 / 316.0) * (580.0 / zc_arr)
    px_per_tex_frox = np.full_like(zc_arr, (1920.0 * 1.04) / 316.0)

    # --- Plot Figure 8: Backlight Slab Stretch vs v2.85 Broken Draft vs Consistent Froxel ---
    fig8 = plt.figure(figsize=(15.2, 8.4), dpi=140, facecolor="#0f131d")
    gs8 = fig8.add_gridspec(2, 3, height_ratios=[1.1, 0.92], hspace=0.30, wspace=0.16)
    for idx, (ttl, im, sub) in enumerate([
        ("① v2.81 平行切片盒（近景纹素暴涨拉伸模糊!）", fb_bl_v281,
         "共用远端半宽 hw=zc_max·tanθ\n近景每纹素放大数十倍，鸟笼影柱糊化"),
        ("② v2.85 未完成草稿（HLSL/Lua 契约断裂现场!）", fb_bl_v285_draft,
         "HLSL 乘 s_center*p3.w 但 Lua 仍传像素半宽 hw≈1000\n且 s_center 含负值 → 噪声坐标爆炸崩毁!"),
        ("③ 一致性 Froxel 视锥切片原型（同步修正）", fb_bl_froxel,
         "切片半宽随深度 zc·tanθ 线性缩放\n远近景恒定 6.3px/纹素，鸟笼暗影条纹锐利清晰!"),
    ]):
        ax = fig8.add_subplot(gs8[0, idx])
        ax.imshow(im[..., :3])
        ax.set_title(ttl, color="#f0f4ff", fontsize=10.3)
        ax.set_xlabel(sub, color="#ffcf87" if idx < 2 else "#9ef0c0", fontsize=8.4)
        ax.set_xticks([]); ax.set_yticks([])

    ax_f1 = fig8.add_subplot(gs8[1, :2], facecolor="#171d2b")
    ax_f1.plot(zc_arr, px_per_tex_slab, color="#ff6b81", lw=2.4, label="v2.81 平行世界切片盒 (hw = zc_max·tanθ，近镜头暴涨至 >500 px/纹素!)")
    ax_f1.plot(zc_arr, px_per_tex_frox, color="#2ed573", lw=2.4, label="一致性 Froxel 视锥切片 (hw(z) = z·tanθ，全深度恒定 6.3 px/纹素!)")
    ax_f1.set_yscale("log")
    ax_f1.set_title("1080p 逆光穿行场景下 beamatlas 单纹素投影屏幕尺寸对比（对数坐标）", color="#f0f4ff", fontsize=11)
    ax_f1.set_xlabel("切片距摄像机深度 z_c (世界单位 / px)", color="#cbd5e8")
    ax_f1.set_ylabel("单纹素对应屏幕像素宽度 (px / texel)", color="#cbd5e8")
    ax_f1.tick_params(colors="#aebcd4")
    ax_f1.grid(alpha=0.2, which="both", color="#4f6080")
    ax_f1.legend(facecolor="#1e2638", edgecolor="#3b4a68", labelcolor="#eef3ff", fontsize=9)

    ax_f2 = fig8.add_subplot(gs8[1, 2], facecolor="#171d2b")
    # High-freq gradient energy (sharpness of volumetric rays + shadow bars) comparison
    sharp_of = lambda a: float(np.hypot(np.diff(a[..., :3].mean(-1), axis=1)[1:, :], np.diff(a[..., :3].mean(-1), axis=0)[:, 1:]).mean())
    sh_vals = [sharp_of(fb_bl_v281), sharp_of(fb_bl_v285_draft), sharp_of(fb_bl_froxel)]
    b_sh = ax_f2.bar(["v2.81\n平行切片", "v2.85草稿\n(断裂崩坏)", "一致性Froxel\n视锥切片"], sh_vals, color=["#ffa502", "#ff4757", "#2ed573"], width=0.5)
    for bi, sv in zip(b_sh, sh_vals):
        ax_f2.text(bi.get_x() + bi.get_width() / 2, sv + 0.08, f"{sv:.2f}", ha="center", color="#f0f4ff", fontsize=9.5)
    ax_f2.set_ylim(0, max(sh_vals) * 1.25)
    ax_f2.set_ylabel("画面梯度清晰度指标 (Mean |∇I|)", color="#cbd5e8")
    ax_f2.set_title("逆光近景光束与影柱细节锐度实测", color="#f0f4ff", fontsize=11)
    ax_f2.tick_params(colors="#aebcd4")
    ax_f2.grid(axis="y", alpha=0.2, color="#4f6080")

    fig8.suptitle("体积光（3D）逆光穿行纹素拉伸、v2.85 未完成草稿崩坏根因与 Froxel 视锥切片修复验证", color="#ffffff", fontsize=13.8, y=0.98)
    fig8.savefig(FIG_DIR / "fig8_vl_backlight_froxel_and_v285_draft.png", bbox_inches="tight", facecolor=fig8.get_facecolor())
    plt.close(fig8)

    metrics["volumetric_light_3d"] = {
        "c1_3d_pipeline": c1_stats,
        "c2_2d_contour_nyquist": c2_metrics,
        "c3_water_color_bug": {
            "v281_yellow_water_mean_rgb_forced_blue": [round(float(x), 2) for x in w_mean_bug],
            "v281_white_water_mean_rgb_forced_blue": [round(float(x), 2) for x in fb_water_v281_white_bug[..., :3].mean(axis=(0, 1))],
            "fixed_yellow_water_mean_rgb": [round(float(x), 2) for x in w_mean_fix],
        },
        "c4_c5_backlight_and_v285": {
            "v281_slab_near25px_texel_size_1080p": round(float(px_per_tex_slab[0]), 2),
            "froxel_constant_texel_size_1080p": round(float(px_per_tex_frox[0]), 2),
            "v281_backlight_gradient_sharpness": round(sh_vals[0], 3),
            "v285_draft_gradient_sharpness": round(sh_vals[1], 3),
            "froxel_backlight_gradient_sharpness": round(sh_vals[2], 3),
            "wn_backface_cull_pitch_minus60_max_rgb": int(fb_wn_culled[..., :3].max()),
        },
        "c6_cross_script_fog_coexistence": {
            "v281_hud_text": res_coexist_bug["loaded_texts"],
            "fixed_hud_text": res_coexist_fix["loaded_texts"],
            "v281_mean_rgb_with_false_8x8_occlusion": [round(float(x), 2) for x in res_coexist_bug["framebuffer"][..., :3].mean(axis=(0, 1))],
            "fixed_mean_rgb_clean": [round(float(x), 2) for x in res_coexist_fix["framebuffer"][..., :3].mean(axis=(0, 1))],
        },
    }


if __name__ == "__main__":
    all_metrics = {}
    run_suite_a_fog(all_metrics)
    run_suite_b_snow(all_metrics)
    run_suite_c_volumetric_light(all_metrics)
    out_json = RES_DIR / "metrics.json"
    out_json.write_text(json.dumps(all_metrics, ensure_ascii=False, indent=2), encoding="utf-8")
    print("=== ALL SUITES COMPLETED SUCCESSFULLY! Saved to", out_json, "===")
