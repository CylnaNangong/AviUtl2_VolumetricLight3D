#!/usr/bin/env python3
"""
Apply P0 (Items 1-7) patches across all 3 AviUtl2 3D scripts, update language packs,
archive into versions/, build release ZIPs, and verify LuaJIT + HLSL compilation.
Note: Strictly preserves beam_frame() structure in 体積光（3D） without refactoring (per user instruction).
"""

import re
import shutil
import subprocess
import tempfile
import zipfile
from pathlib import Path

ROOT = Path("/home/user")
PKG1 = ROOT / "scripts/pkg1/体积光（3D）"
PKG2 = ROOT / "scripts/pkg2/体积雾（3D）"
PKG3 = ROOT / "scripts/pkg3/雪（3D）"
REL_DIR = ROOT / "releases"


def replace_exact(text: str, old: str, new: str, label: str) -> str:
    if old not in text:
        raise RuntimeError(f"[ASSERT FAILED] Anchor not found for {label}:\n{old[:240]}")
    cnt = text.count(old)
    if cnt != 1:
        raise RuntimeError(f"[ASSERT FAILED] Anchor matched {cnt} times (expected 1) for {label}")
    return text.replace(old, new, 1)


def to_crlf_utf8_nobom(s: str) -> bytes:
    s = s.lstrip("\ufeff")
    s = s.replace("\r\n", "\n").replace("\r", "\n").replace("\n", "\r\n")
    return s.encode("utf-8")


# =========================================================================
# 1. Build 《雪（3D）》 v1.19 Stable (P0 1-2)
# =========================================================================
def build_snow_v119():
    src_obj2 = (PKG3 / "development/雪（3D）_v1.18_修正候选.obj2").read_text(encoding="utf-8").replace("\r\n", "\n")

    # 1a. Version header & log strings v1.18 -> v1.19
    src_obj2 = replace_exact(
        src_obj2,
        "--information:雪（3D）v1.18",
        "--information:雪（3D）v1.19",
        "snow header v1.19",
    )
    for old_v, new_v in [
        ('"雪（3D）v1.18  模式=%s', '"雪（3D）v1.19  模式=%s'),
        ('"Schnee (3D) v1.18  Modus=%s', '"Schnee (3D) v1.19  Modus=%s'),
        ('"Snow (3D) v1.18  mode=%s', '"Snow (3D) v1.19  mode=%s'),
        ('"雪（3D）v1.18  mode=%s', '"雪（3D）v1.19  mode=%s'),
    ]:
        src_obj2 = replace_exact(src_obj2, old_v, new_v, f"snow log {new_v}")

    # 1b. sync_size: prioritize obj.screen_w / obj.screen_h for 4K / custom resolutions
    src_obj2 = replace_exact(
        src_obj2,
        """    if P.sync_size then
        -- 画面（オブジェクト）のサイズに合わせる
        --   4000x4000 の合成でも画面全体に雪が広がる
        local fw, fh = obj.w, obj.h
        if type(fw) ~= "number" or fw < 1 then fw = box_w end
        if type(fh) ~= "number" or fh < 1 then fh = box_h end""",
        """    if P.sync_size then
        -- 画面（合成プロジェクト）のサイズに合わせる（カスタムオブジェクトでは obj.screen_w/h を優先）
        --   3840x2160 や 4000x4000 の合成でも画面全体に雪が広がる
        local fw, fh = obj.screen_w, obj.screen_h
        if type(fw) ~= "number" or fw < 1 then fw = obj.w end
        if type(fh) ~= "number" or fh < 1 then fh = obj.h end
        if type(fw) ~= "number" or fw < 1 then fw = box_w end
        if type(fh) ~= "number" or fh < 1 then fh = box_h end""",
        "snow sync_size screen_w/h",
    )

    # 1c. Local-vs-World coordinate fix for c_d, fit_view, screen_w/h, and fade_d0/fade_span
    src_obj2 = replace_exact(
        src_obj2,
        """    -- 奥行き減衰の基準（領域の手前側〜奥側）
    local c_d = (c_x - cam_x) * f_x + (c_y - cam_y) * f_y + (c_z - cam_z) * f_z

    ------------------------------------------------------------
    -- 画面に見えている範囲（折り返し箱の大きさを決めるのに使う）
    --   drawpoly の座標は「オブジェクトのローカル座標」なので、
    --   画面に写る範囲は 焦点距離 d と オブジェクトの拡大率 zoom と
    --   カメラからの距離で決まる。箱がこれより小さいと、箱の壁
    --   （＝折り返しで薄くなる帯）が画面の中に入って「断层」になる。
    ------------------------------------------------------------
    local vis_w, vis_h = 0, 0
    if cam ~= nil then
        local dz = cam.d or 1024
        if type(dz) ~= "number" or dz < 1 then dz = 1024 end
        local zoom = obj.zoom or 1
        if type(zoom) ~= "number" or zoom < 1e-6 then zoom = 1 end
        local fw, fh = obj.w, obj.h
        if type(fw) ~= "number" or fw < 1 then fw = 1920 end
        if type(fh) ~= "number" or fh < 1 then fh = 1080 end
        local near_s = c_d - box_d * 0.5
        if near_s < 1 then near_s = 1 end
        local far_s = c_d + box_d * 0.5
        if far_s < near_s then far_s = near_s end
        vis_w = fw * far_s / (zoom * dz)
        vis_h = fh * far_s / (zoom * dz)

        -- 壁を画面の外へ
        --   画面に見えている範囲（8 隅）をワールド座標で求めて、
        --   折り返し箱がそれを包むように広げる。縮めはしない。
        if P.fit_view then
            local mnx, mxx = 1e30, -1e30
            local mny, mxy = 1e30, -1e30
            local mnz, mxz = 1e30, -1e30
            for _, sc in ipairs({ near_s, far_s }) do
                local ex = (fw * 0.5 / zoom) * sc / dz
                local ey = (fh * 0.5 / zoom) * sc / dz
                for _, sx in ipairs({ -1, 1 }) do
                    for _, sy in ipairs({ -1, 1 }) do
                        local wx = cam_x + f_x * sc + r_x * ex * sx + u_x * ey * sy
                        local wy = cam_y + f_y * sc + r_y * ex * sx + u_y * ey * sy
                        local wz = cam_z + f_z * sc + r_z * ex * sx + u_z * ey * sy
                        if wx < mnx then mnx = wx end
                        if wx > mxx then mxx = wx end
                        if wy < mny then mny = wy end
                        if wy > mxy then mxy = wy end
                        if wz < mnz then mnz = wz end
                        if wz > mxz then mxz = wz end
                    end
                end
            end
            -- 視線に平行な軸は「奥行き」なので触らない
            if math.abs(f_x) < 0.8 and (mxx - mnx) > box_w then
                box_w = mxx - mnx
                c_x = (mnx + mxx) * 0.5
            end
            if math.abs(f_y) < 0.8 and (mxy - mny) > box_h then
                box_h = mxy - mny
                c_y = (mny + mxy) * 0.5
            end
            if math.abs(f_z) < 0.8 and (mxz - mnz) > box_d then
                box_d = mxz - mnz
                c_z = (mnz + mxz) * 0.5
            end
        end
    end

    -- 進行方向に沿った領域の半径と、横切る距離
    local hw = box_w * 0.5
    local hh = box_h * 0.5
    local hd = box_d * 0.5
    local support = math.abs(d_x) * hw + math.abs(d_y) * hh + math.abs(d_z) * hd
    if support < 1 then support = 1 end
    local travel = 2 * support

    c_d = (c_x - cam_x) * f_x + (c_y - cam_y) * f_y + (c_z - cam_z) * f_z
    local fade_d0 = c_d - box_d * 0.5
    local fade_span = box_d""",
        """    -- オブジェクトのローカル→ワールド変換パラメータ
    local ozm = (type(obj.zoom) == "number" and obj.zoom > 1e-6) and obj.zoom or 1
    local ox0, oy0, oz0 = (obj.x or 0), (obj.y or 0), (obj.z or 0)

    -- 奥行き減衰の基準（ローカル c をワールド座標へ戻してからカメラ距離を算出）
    local c_d = ((c_x * ozm + ox0) - cam_x) * f_x
              + ((c_y * ozm + oy0) - cam_y) * f_y
              + ((c_z * ozm + oz0) - cam_z) * f_z

    ------------------------------------------------------------
    -- 画面に見えている範囲（折り返し箱の大きさを決めるのに使う）
    --   drawpoly の座標は「オブジェクトのローカル座標」なので、
    --   画面に写る範囲は 焦点距離 d と オブジェクトの拡大率 zoom と
    --   カメラからの距離で決まる。箱がこれより小さいと、箱の壁
    --   （＝折り返しで薄くなる帯）が画面の中に入って「断层」になる。
    ------------------------------------------------------------
    local vis_w, vis_h = 0, 0
    if cam ~= nil then
        local dz = cam.d or 1024
        if type(dz) ~= "number" or dz < 1 then dz = 1024 end
        local zoom = ozm
        local fw, fh = obj.screen_w, obj.screen_h
        if type(fw) ~= "number" or fw < 1 then fw = obj.w end
        if type(fh) ~= "number" or fh < 1 then fh = obj.h end
        if type(fw) ~= "number" or fw < 1 then fw = 1920 end
        if type(fh) ~= "number" or fh < 1 then fh = 1080 end
        local world_hd = (box_d * zoom) * 0.5
        local near_s = c_d - world_hd
        if near_s < 1 then near_s = 1 end
        local far_s = c_d + world_hd
        if far_s < near_s then far_s = near_s end
        vis_w = fw * far_s / (zoom * dz)
        vis_h = fh * far_s / (zoom * dz)

        -- 壁を画面の外へ
        --   画面に見えている視錐台（8 隅）をワールド座標で求めて、
        --   ローカル折り返し箱へ逆変換して広げる。縮めはしない。
        if P.fit_view then
            local mnx, mxx = 1e30, -1e30
            local mny, mxy = 1e30, -1e30
            local mnz, mxz = 1e30, -1e30
            for _, sc in ipairs({ near_s, far_s }) do
                local ex = (fw * 0.5) * sc / dz
                local ey = (fh * 0.5) * sc / dz
                for _, sx in ipairs({ -1, 1 }) do
                    for _, sy in ipairs({ -1, 1 }) do
                        local wx = cam_x + f_x * sc + r_x * ex * sx + u_x * ey * sy
                        local wy = cam_y + f_y * sc + r_y * ex * sx + u_y * ey * sy
                        local wz = cam_z + f_z * sc + r_z * ex * sx + u_z * ey * sy
                        if wx < mnx then mnx = wx end
                        if wx > mxx then mxx = wx end
                        if wy < mny then mny = wy end
                        if wy > mxy then mxy = wy end
                        if wz < mnz then mnz = wz end
                        if wz > mxz then mxz = wz end
                    end
                end
            end
            -- 視線に平行な軸は「奥行き」なので触らない（ワールド AABB → ローカル座標へ逆変換）
            if math.abs(f_x) < 0.8 and (mxx - mnx) / zoom > box_w then
                box_w = (mxx - mnx) / zoom
                c_x = ((mnx + mxx) * 0.5 - ox0) / zoom
            end
            if math.abs(f_y) < 0.8 and (mxy - mny) / zoom > box_h then
                box_h = (mxy - mny) / zoom
                c_y = ((mny + mxy) * 0.5 - oy0) / zoom
            end
            if math.abs(f_z) < 0.8 and (mxz - mnz) / zoom > box_d then
                box_d = (mxz - mnz) / zoom
                c_z = ((mnz + mxz) * 0.5 - oz0) / zoom
            end
        end
    end

    -- 進行方向に沿った領域の半径と、横切る距離
    local hw = box_w * 0.5
    local hh = box_h * 0.5
    local hd = box_d * 0.5
    local support = math.abs(d_x) * hw + math.abs(d_y) * hh + math.abs(d_z) * hd
    if support < 1 then support = 1 end
    local travel = 2 * support

    c_d = ((c_x * ozm + ox0) - cam_x) * f_x
        + ((c_y * ozm + oy0) - cam_y) * f_y
        + ((c_z * ozm + oz0) - cam_z) * f_z
    local fade_d0 = c_d - (box_d * ozm) * 0.5
    local fade_span = box_d * ozm""",
        "snow c_d & fit_view local-world fix",
    )

    # 1d. Per-particle depth world-space fix
    src_obj2 = replace_exact(
        src_obj2,
        """        -- カメラからの奥行き
        local d_x = p_x - cam_x
        local d_y = p_y - cam_y
        local d_z = p_z - cam_z
        local depth = d_x * f_x + d_y * f_y + d_z * f_z""",
        """        -- カメラからの奥行き（ローカル p をワールド座標へ戻してから計算）
        local d_x = (p_x * ozm + ox0) - cam_x
        local d_y = (p_y * ozm + oy0) - cam_y
        local d_z = (p_z * ozm + oz0) - cam_z
        local depth = d_x * f_x + d_y * f_y + d_z * f_z""",
        "snow particle depth local-world fix",
    )

    out_bytes = to_crlf_utf8_nobom(src_obj2)
    (PKG3 / "stable/Script/雪（3D）.obj2").write_bytes(out_bytes)
    (PKG3 / "versions/雪（3D）_v1.19.obj2").write_bytes(out_bytes)

    # 1e. Update all 4 .aul2 language packs (CN, EN, DE, community_de) to v1.19
    cn_aul2 = (PKG3 / "development/简体中文.雪（3D）_v1.18_修正候选.aul2").read_text(encoding="utf-8").replace("\r\n", "\n")
    cn_aul2 = cn_aul2.replace("v1.18", "v1.19")
    (PKG3 / "stable/Language/简体中文.雪（3D）.aul2").write_bytes(to_crlf_utf8_nobom(cn_aul2))
    (PKG3 / "versions/简体中文.雪（3D）_v1.19.aul2").write_bytes(to_crlf_utf8_nobom(cn_aul2))

    en_aul2 = (PKG3 / "stable/Language/English.雪（3D）.aul2").read_text(encoding="utf-8").replace("\r\n", "\n")
    en_aul2 = en_aul2.replace("v1.15", "v1.19")
    old_en_soft = "エッジのぼかし=0 = draws the chosen figure texture on GPU as-is (keep at 0 for soft SVGs). Above 0 switches to a soft vertex-gradient dot."
    new_en_soft = "エッジのぼかし=0 = draws the chosen figure as-is (keep at 0 for pre-softened SVGs). Above 0 applies a padded GPU Gaussian blur that preserves any custom/built-in shape outline while softening its edges; falls back to the original shape on error."
    if old_en_soft in en_aul2:
        en_aul2 = replace_exact(en_aul2, old_en_soft, new_en_soft, "snow EN soft tooltip")
    assert new_en_soft in en_aul2, "EN soft tooltip missing!"
    (PKG3 / "stable/Language/English.雪（3D）.aul2").write_bytes(to_crlf_utf8_nobom(en_aul2))
    (PKG3 / "versions/English.雪（3D）_v1.19.aul2").write_bytes(to_crlf_utf8_nobom(en_aul2))

    old_de_soft = "エッジのぼかし=0 = zeichnet die gewählte Formtextur direkt per GPU (für weiche SVGs auf 0 lassen). Über 0 wird ein weicher Vertex-Punkt erzeugt."
    new_de_soft = "エッジのぼかし=0 = zeichnet die gewählte Form unverändert (für weiche SVGs auf 0 lassen). Über 0 erzeugt ein gepolsterter GPU-Gauß-Weichzeichner weiche Kanten unter voller Erhaltung beliebiger Formkonturen; bei Fehler Rückfall auf Originalform."
    for de_name in ["Deutsch.雪（3D）.aul2", "community_de.雪（3D）.aul2"]:
        de_aul2 = (PKG3 / "stable/Language" / de_name).read_text(encoding="utf-8").replace("\r\n", "\n")
        de_aul2 = de_aul2.replace("v1.15", "v1.19")
        if old_de_soft in de_aul2:
            de_aul2 = replace_exact(de_aul2, old_de_soft, new_de_soft, f"snow {de_name} soft tooltip")
        assert new_de_soft in de_aul2, f"{de_name} soft tooltip missing!"
        (PKG3 / "stable/Language" / de_name).write_bytes(to_crlf_utf8_nobom(de_aul2))
        (PKG3 / "versions" / de_name.replace(".雪（3D）.aul2", ".雪（3D）_v1.19.aul2")).write_bytes(to_crlf_utf8_nobom(de_aul2))

    print("[OK] Built 雪（3D） v1.19 stable + 4 updated .aul2 packs")


# =========================================================================
# 2. Build 《体積霧（3D）》 v2.02 Stable (P0 3-4)
# =========================================================================
def build_fog_v202():
    # Always read from clean archived v2.01 in versions/ so script is idempotent
    src_obj2 = (PKG2 / "versions/体積霧（3D）_v2.01.obj2").read_text(encoding="utf-8").replace("\r\n", "\n")

    # 2a. Version strings v2.01 -> v2.02
    src_obj2 = src_obj2.replace("v2.01", "v2.02")

    # 2b. HLSL fogatlas patch: explicit camera basis in sphere mode + oblique secant + HG sign fix + high-g soft norm
    src_obj2 = replace_exact(
        src_obj2,
        """        else
        {
            float r_vol  = p3.w;
            float ry_vol = p4.w;
            float s = p1.w + (si + 0.5) * dz + z_jit;
            float rad_s = max(200.0, sqrt(max(0.0, r_vol * r_vol - s * s)));
            float lx = lu * rad_s;
            float ly = lv * rad_s * (ry_vol / max(r_vol, 1.0));
            wpos = p1.xyz + float3(lx, ly, s);

            float3 dn = float3(lx / max(r_vol, 1.0), ly / max(ry_vol, 1.0), s / max(r_vol, 1.0));
            float tf = saturate((1.0 - length(dn)) / 0.58);
            env = tf * tf * (3.0 - 2.0 * tf);
        }

        float n = fbm4((wpos + p5.xyz) * p5.w, p7.w);
        float c_raw = clamp((n - 0.34) / 0.42, 0.0, 1.6);
        float dens_f = (0.06 + 2.35 * c_raw * sqrt(c_raw)) * p7.x + 0.72 * (1.0 - p7.x);

        if (p9.w > 0.0)
        {
            float h_above = max(0.0, p10.x - wpos.y);
            dens_f *= exp(-h_above * p9.w);
        }

        float od = max(p6.w * env * dens_f, 0.0);
        float alpha = 1.0 - exp(-od);

        float3 vvec = wpos - p11.xyz;
        float vlen = max(length(vvec), 1e-4);
        float cosA = dot(vvec, p8.xyz) / vlen;
        float g = p8.w;
        float g2 = g * g;
        float d_hg = max(1.0 + g2 - 2.0 * g * cosA, 1e-4);
        float phase = (1.0 - g2) / (d_hg * sqrt(d_hg));""",
        """        else
        {
            float r_vol  = p3.w;
            float ry_vol = p4.w;
            float s = p1.w + (si + 0.5) * dz + z_jit;
            float rad_s = max(200.0, sqrt(max(0.0, r_vol * r_vol - s * s)));
            float lx = lu * rad_s;
            float ly = lv * rad_s * (ry_vol / max(r_vol, 1.0));
            wpos = p1.xyz + p2.xyz * s + p3.xyz * lx + p4.xyz * ly;

            float3 rel = wpos - p1.xyz;
            float3 dn = float3(rel.x / max(r_vol, 1.0), rel.y / max(ry_vol, 1.0), rel.z / max(r_vol, 1.0));
            float tf = saturate((1.0 - length(dn)) / 0.58);
            env = tf * tf * (3.0 - 2.0 * tf);
        }

        float n = fbm4((wpos + p5.xyz) * p5.w, p7.w);
        float c_raw = clamp((n - 0.34) / 0.42, 0.0, 1.6);
        float dens_f = (0.06 + 2.35 * c_raw * sqrt(c_raw)) * p7.x + 0.72 * (1.0 - p7.x);

        if (p9.w > 0.0)
        {
            float h_above = max(0.0, p10.x - wpos.y);
            dens_f *= exp(-h_above * p9.w);
        }

        float3 vvec = wpos - p11.xyz;
        float  vlen = max(length(vvec), 1e-4);
        float3 vdir = vvec / vlen;

        // 斜め視線に対するスライス通過厚みの正割補正 sec(theta) = 1 / |dot(vdir, sl_n)|
        float3 sl_n = normalize(p2.xyz);
        float sec_k = 1.0 / max(abs(dot(vdir, sl_n)), 0.25);
        float od = max(p6.w * sec_k * env * dens_f, 0.0);
        float alpha = 1.0 - exp(-od);

        // p8.xyz は「光が進む向き」なので、前向散乱角 cos(theta) は -dot(vdir, p8.xyz)
        float cosA = -dot(vdir, p8.xyz);
        float g = clamp(p8.w, -0.92, 0.92);
        float g2 = g * g;
        float d_hg = max(1.0 + g2 - 2.0 * g * cosA, 1e-4);
        float phase = (1.0 - g2) / (d_hg * sqrt(d_hg));
        // 高 g 時の極端な白飛び・色環断層を滑らかに抑制
        phase = phase / (1.0 + 0.08 * max(phase - 1.0, 0.0));""",
        "fog HLSL HG + secant + sphere basis",
    )

    # 2c. Lua camera roll support + explicit camera basis in view_mode==2 (no billboard=3 roll coupling!)
    src_obj2 = replace_exact(
        src_obj2,
        """        -- 画面の下方向 d_vec = f × r（既定カメラで +Y = 0,+1,0 となり UV の縦方向と完全一致）
        d_x = f_y * r_z - f_z * r_y
        d_y = f_z * r_x - f_x * r_z
        d_z = f_x * r_y - f_y * r_x
        local dl = math.sqrt(d_x * d_x + d_y * d_y + d_z * d_z)
        if dl > 1e-6 then d_x, d_y, d_z = d_x / dl, d_y / dl, d_z / dl end
    end""",
        """        -- 画面の下方向 d_vec = f × r（既定カメラで +Y = 0,+1,0 となり UV の縦方向と完全一致）
        d_x = f_y * r_z - f_z * r_y
        d_y = f_z * r_x - f_x * r_z
        d_z = f_x * r_y - f_y * r_x
        local dl = math.sqrt(d_x * d_x + d_y * d_y + d_z * d_z)
        if dl > 1e-6 then d_x, d_y, d_z = d_x / dl, d_y / dl, d_z / dl end

        if type(cam.rz) == "number" and math.abs(cam.rz) > 1e-5 then
            local cr = math.cos(math.rad(cam.rz))
            local sr = math.sin(math.rad(cam.rz))
            local nr_x, nr_y, nr_z = r_x * cr + d_x * sr, r_y * cr + d_y * sr, r_z * cr + d_z * sr
            local nd_x, nd_y, nd_z = -r_x * sr + d_x * cr, -r_y * sr + d_y * cr, -r_z * sr + d_z * cr
            r_x, r_y, r_z = nr_x, nr_y, nr_z
            d_x, d_y, d_z = nd_x, nd_y, nd_z
        end
    end""",
        "fog cam.rz basis",
    )

    src_obj2 = replace_exact(
        src_obj2,
        """        else
            obj.ox = tx - obj_x
            obj.oy = ty - obj_y
            obj.oz = tz - obj_z
            pcall(function() obj.setoption("billboard", 3) end)

            local r_vol = hw_k
            local ry_ratio = hh_k / r_vol
            for si = n_sl - 1, 0, -1 do
                local tx_i = si % TILES_X
                local ty_i = math.floor(si / TILES_X)
                local u0 = (tx_i * TILE + PAD) / ATLAS
                local u1 = ((tx_i + 1) * TILE - PAD) / ATLAS
                local v0 = (ty_i * TILE + PAD) / ATLAS
                local v1 = ((ty_i + 1) * TILE - PAD) / ATLAS

                local s = start_s + (si + 0.5) * dz
                local sq = r_vol * r_vol - s * s
                local rad_s = sq > 0 and math.sqrt(sq) or 0
                if rad_s < 200 then rad_s = 200 end
                local hx = rad_s / zoom
                local hy = (rad_s * ry_ratio) / zoom
                local sz = s / zoom

                verts[vi + 1] = { -hx, -hy, sz, u0, v0 }
                verts[vi + 2] = {  hx, -hy, sz, u1, v0 }
                verts[vi + 3] = {  hx,  hy, sz, u1, v1 }
                verts[vi + 4] = { -hx,  hy, sz, u0, v1 }
                vi = vi + 4
            end
        end""",
        """        else
            local r_vol = hw_k
            local ry_ratio = hh_k / r_vol
            if cam_mode == 2 then
                -- 視点編集モード（cam==nil）のみマウスドラッグ追従のため billboard=3 を維持
                obj.ox = tx - obj_x
                obj.oy = ty - obj_y
                obj.oz = tz - obj_z
                pcall(function() obj.setoption("billboard", 3) end)
                for si = n_sl - 1, 0, -1 do
                    local tx_i = si % TILES_X
                    local ty_i = math.floor(si / TILES_X)
                    local u0 = (tx_i * TILE + PAD) / ATLAS
                    local u1 = ((tx_i + 1) * TILE - PAD) / ATLAS
                    local v0 = (ty_i * TILE + PAD) / ATLAS
                    local v1 = ((ty_i + 1) * TILE - PAD) / ATLAS

                    local s = start_s + (si + 0.5) * dz
                    local sq = r_vol * r_vol - s * s
                    local rad_s = sq > 0 and math.sqrt(sq) or 0
                    if rad_s < 200 then rad_s = 200 end
                    local hx = rad_s / zoom
                    local hy = (rad_s * ry_ratio) / zoom
                    local sz = s / zoom

                    verts[vi + 1] = { -hx, -hy, sz, u0, v0 }
                    verts[vi + 2] = {  hx, -hy, sz, u1, v0 }
                    verts[vi + 3] = {  hx,  hy, sz, u1, v1 }
                    verts[vi + 4] = { -hx,  hy, sz, u0, v1 }
                    vi = vi + 4
                end
            else
                -- カメラ制御下（view_mode==2 球状モード）では billboard=3 を廃止し、明示的な正規直交基底 (r, d, f) で展開
                pcall(function() obj.setoption("billboard", 0) end)
                for si = n_sl - 1, 0, -1 do
                    local tx_i = si % TILES_X
                    local ty_i = math.floor(si / TILES_X)
                    local u0 = (tx_i * TILE + PAD) / ATLAS
                    local u1 = ((tx_i + 1) * TILE - PAD) / ATLAS
                    local v0 = (ty_i * TILE + PAD) / ATLAS
                    local v1 = ((ty_i + 1) * TILE - PAD) / ATLAS

                    local s = start_s + (si + 0.5) * dz
                    local sq = r_vol * r_vol - s * s
                    local rad_s = sq > 0 and math.sqrt(sq) or 0
                    if rad_s < 200 then rad_s = 200 end
                    local hx_w = rad_s
                    local hy_w = rad_s * ry_ratio

                    local rxw, ryw, rzw = r_x * hx_w, r_y * hx_w, r_z * hx_w
                    local dxw, dyw, dzw = d_x * hy_w, d_y * hy_w, d_z * hy_w
                    local cx = tx + f_x * s - obj_x
                    local cy = ty + f_y * s - obj_y
                    local cz = tz + f_z * s - obj_z

                    verts[vi + 1] = { (cx - rxw - dxw) / zoom, (cy - ryw - dyw) / zoom, (cz - rzw - dzw) / zoom, u0, v0 }
                    verts[vi + 2] = { (cx + rxw - dxw) / zoom, (cy + ryw - dyw) / zoom, (cz + rzw - dzw) / zoom, u1, v0 }
                    verts[vi + 3] = { (cx + rxw + dxw) / zoom, (cy + ryw + dyw) / zoom, (cz + rzw + dzw) / zoom, u1, v1 }
                    verts[vi + 4] = { (cx - rxw + dxw) / zoom, (cy - ryw + dyw) / zoom, (cz - rzw + dzw) / zoom, u0, v1 }
                    vi = vi + 4
                end
            end
        end""",
        "fog sphere explicit quad basis",
    )

    out_bytes = to_crlf_utf8_nobom(src_obj2)
    (PKG2 / "stable/Script/体積霧（3D）.obj2").write_bytes(out_bytes)
    (PKG2 / "versions/体積霧（3D）_v2.02.obj2").write_bytes(out_bytes)

    for aul2_name in [
        "简体中文.体積霧（3D）.aul2",
        "English.体積霧（3D）.aul2",
        "Deutsch.体積霧（3D）.aul2",
        "community_de.体積霧（3D）.aul2",
    ]:
        ver_src_name = aul2_name.replace(".体積霧（3D）.aul2", ".体積霧（3D）_v2.01.aul2")
        txt = (PKG2 / "versions" / ver_src_name).read_text(encoding="utf-8").replace("\r\n", "\n")
        txt = txt.replace("v2.01", "v2.02")
        (PKG2 / "stable/Language" / aul2_name).write_bytes(to_crlf_utf8_nobom(txt))
        (PKG2 / "versions" / ver_src_name.replace("_v2.01.aul2", "_v2.02.aul2")).write_bytes(to_crlf_utf8_nobom(txt))

    print("[OK] Built 体積霧（3D） v2.02 stable + 4 updated .aul2 packs")


# =========================================================================
# 3. Build 《体積光（3D）》 v2.86 Stable Maintenance Update (P0 5-7, NO beam_frame refactor)
# =========================================================================
def build_vl_v286():
    # Read from clean archived v2.81 in versions/ (preserves vnoise3 c011=(0,1,1) fix)
    src_obj2 = (PKG1 / "versions/体積光（3D）_v2.81.obj2").read_text(encoding="utf-8").replace("\r\n", "\n")
    assert "float3(0.0, 1.0, 1.0)" in src_obj2, "vnoise3 c011=(0,1,1) fix missing!"

    # 3a. Update version strings v2.81 -> v2.86
    src_obj2 = src_obj2.replace("v2.81", "v2.86")

    # 3b. HLSL ps_vl_water: unlock neutral/gold/custom colors by removing c_span < 0.05 blue lock
    src_obj2 = replace_exact(
        src_obj2,
        """        float3 base_tint = float3(w3.x, w3.y, w3.z);
        float c_span = max(base_tint.r, max(base_tint.g, base_tint.b))
                     - min(base_tint.r, min(base_tint.g, base_tint.b));
        float3 water_mid  = (c_span < 0.05)
            ? (base_tint * float3(0.04, 0.56, 1.00))
            : (base_tint * 0.85);
        float3 water_high = (c_span < 0.05)
            ? (base_tint * float3(0.38, 0.95, 1.00))
            : saturate(lerp(base_tint, float3(0.85, 0.98, 1.00), 0.38));""",
        """        float3 in_c = clamp(w3.xyz, 0.0, 1.0);
        // ユーザー指定色・光の色（黄色 #ffff00 や純白 #ffffff 等）を忠実に保持
        float3 water_mid  = in_c;
        float3 water_high = lerp(in_c, float3(1.00, 1.00, 1.00), 0.48);""",
        "vl ps_vl_water unlock color",
    )

    # 3c. Complete 4-language volume effect layer filter (Fog v2.01/v2.02 + Snow v1.15-v1.19 + Light)
    src_obj2 = replace_exact(
        src_obj2,
        """local function is_volume_effect_layer(oln)
    local hit = false
    pcall(function()
        if obj.getvalue(oln, "体積光（3D）", "強さ") ~= nil
            or obj.getvalue(oln, "体积光（3D）", "发光强度") ~= nil
            or obj.getvalue(oln, "Volumetric Light (3D)", "Intensity") ~= nil
            or obj.getvalue(oln, "Volumenlicht (3D)", "Intensität") ~= nil
            or obj.getvalue(oln, "体積霧（3D）オブジェクト", "濃さ") ~= nil
            or obj.getvalue(oln, "体积雾（3D）对象", "浓度") ~= nil
            or obj.getvalue(oln, "雪（3D）", "粒子数") ~= nil
            or obj.getvalue(oln, "カメラ制御", "目標レイヤー") ~= nil
            or obj.getvalue(oln, "摄像机控制", "目标图层") ~= nil
            or obj.getvalue(oln, "Camera Control", "Target Layer") ~= nil
            or obj.getvalue(oln, "Kamerasteuerung", "Zielebene") ~= nil then
            hit = true
        end
    end)
    return hit
end""",
        """local function is_volume_effect_layer(oln)
    local hit = false
    pcall(function()
        local lp = "layer" .. tostring(oln) .. "."
        if obj.getvalue(oln, "体積光（3D）", "強さ") ~= nil
            or obj.getvalue(oln, "体积光（3D）", "发光强度") ~= nil
            or obj.getvalue(oln, "体积光（3D）", "强度") ~= nil
            or obj.getvalue(oln, "Volumetric Light (3D)", "Intensity") ~= nil
            or obj.getvalue(oln, "Volumenlicht (3D)", "Intensität") ~= nil
            or obj.getvalue(lp .. "体積光（3D）.強さ") ~= nil
            or obj.getvalue(lp .. "体积光（3D）.发光强度") ~= nil
            or obj.getvalue(oln, "体積霧（3D）", "濃さ") ~= nil
            or obj.getvalue(oln, "体積霧（3D）", "霧の濃さ") ~= nil
            or obj.getvalue(oln, "体积雾（3D）", "雾的浓度") ~= nil
            or obj.getvalue(oln, "Volumetric Fog (3D)", "Density") ~= nil
            or obj.getvalue(oln, "Volumennebel (3D)", "Nebeldichte") ~= nil
            or obj.getvalue(oln, "Volumennebel (3D)", "Dichte") ~= nil
            or obj.getvalue(lp .. "体積霧（3D）.濃さ") ~= nil
            or obj.getvalue(lp .. "体积雾（3D）.雾的浓度") ~= nil
            or obj.getvalue(oln, "体積霧（3D）オブジェクト", "濃さ") ~= nil
            or obj.getvalue(oln, "体積霧(3D)オブジェクト", "濃さ") ~= nil
            or obj.getvalue(oln, "体积雾（3D）对象", "浓度") ~= nil
            or obj.getvalue(oln, "雪（3D）", "粒子数") ~= nil
            or obj.getvalue(oln, "3D雪", "粒子数") ~= nil
            or obj.getvalue(oln, "Snow (3D)", "Particles") ~= nil
            or obj.getvalue(oln, "3D Snow", "Particle Count") ~= nil
            or obj.getvalue(oln, "Schnee (3D)", "Partikelanzahl") ~= nil
            or obj.getvalue(oln, "3D-Schnee", "Partikelanzahl") ~= nil
            or obj.getvalue(lp .. "雪（3D）.粒子数") ~= nil
            or obj.getvalue(oln, "カメラ制御", "目標レイヤー") ~= nil
            or obj.getvalue(oln, "摄像机控制", "目标图层") ~= nil
            or obj.getvalue(oln, "Camera Control", "Target Layer") ~= nil
            or obj.getvalue(oln, "Kamerasteuerung", "Zielebene") ~= nil then
            hit = true
        end
    end)
    return hit
end""",
        "vl is_volume_effect_layer 4-lang filter",
    )

    # 3d. @水面 inherit P.light_color when getvalue("--color") returns nil (0 extra local slots!)
    src_obj2 = replace_exact(
        src_obj2,
        "            local w_col  = tonumber((get_fx_val(ln, wfx_l, WATER_COL_ITEMS, false))) or 0x005ab4",
        "            -- AviUtl2 の getvalue は --color 項目に対して nil を返すため、light_color 指定時は優先継承\n"
        "            local w_col  = tonumber((get_fx_val(ln, wfx_l, WATER_COL_ITEMS, false))) or tonumber(P.light_color) or 0x66c8ff",
        "vl water color light_color fallback",
    )

    out_bytes = to_crlf_utf8_nobom(src_obj2)
    (PKG1 / "stable/Script/体積光（3D）.obj2").write_bytes(out_bytes)
    (PKG1 / "versions/体積光（3D）_v2.86.obj2").write_bytes(out_bytes)

    cn_aul2 = (PKG1 / "versions/简体中文.体積光（3D）_v2.81.aul2").read_text(encoding="utf-8").replace("\r\n", "\n")
    cn_aul2 = cn_aul2.replace("v2.81", "v2.86")
    (PKG1 / "stable/Language/简体中文.体積光（3D）.aul2").write_bytes(to_crlf_utf8_nobom(cn_aul2))
    (PKG1 / "versions/简体中文.体積光（3D）_v2.86.aul2").write_bytes(to_crlf_utf8_nobom(cn_aul2))

    print("[OK] Built 体積光（3D） v2.86 stable + updated CN .aul2 pack (0 beam_frame locals added)")


# =========================================================================
# 4. Syntax + Bytecode + SPIR-V Shader Verification + Release ZIP Packaging
# =========================================================================
def verify_and_package():
    targets = [
        ("雪（3D）_v1.19_稳定版", PKG3 / "stable"),
        ("体積霧（3D）_v2.02_稳定版", PKG2 / "stable"),
        ("体積光（3D）_v2.86_稳定版", PKG1 / "stable"),
    ]
    REL_DIR.mkdir(parents=True, exist_ok=True)

    for rel_name, stable_dir in targets:
        for obj2 in (stable_dir / "Script").glob("*.obj2"):
            raw = obj2.read_bytes()
            assert not raw.startswith(b"\xef\xbb\xbf"), f"BOM found in {obj2}"
            assert b"\r\n" in raw, f"Missing CRLF in {obj2}"
            # Verify LuaJIT bytecode compilation (catches any >200 locals or syntax error!)
            r = subprocess.run(["luajit", "-bl", str(obj2)], stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, text=True)
            if r.returncode != 0:
                raise RuntimeError(f"LuaJIT compile failed for {obj2}: {r.stderr}")

            # Verify every embedded --[[pixelshader@NAME: ... ]] HLSL block with glslangValidator!
            txt = raw.decode("utf-8")
            shaders = re.findall(r"--\[\[pixelshader@([A-Za-z0-9_]+):\s*(.*?)\]\]", txt, flags=re.S)
            for sh_name, hlsl_code in shaders:
                with tempfile.NamedTemporaryFile("w", suffix=".hlsl", delete=False, encoding="utf-8") as hf:
                    hf.write(hlsl_code)
                    hpath = hf.name
                spv_out = hpath + ".spv"
                cmd = [
                    "glslangValidator", "-D", "-V", "-S", "frag", "-e", sh_name,
                    "--hlsl-offsets", "--hlsl-iomap",
                    "--shift-cbuffer-binding", "0",
                    "--shift-texture-binding", "10",
                    "--shift-sampler-binding", "20",
                    "-o", spv_out, hpath,
                ]
                gr = subprocess.run(cmd, capture_output=True, text=True)
                Path(hpath).unlink(missing_ok=True)
                Path(spv_out).unlink(missing_ok=True)
                if gr.returncode != 0:
                    raise RuntimeError(f"HLSL compile failed for {obj2.name}:{sh_name}:\n{gr.stdout}\n{gr.stderr}")
            print(f"[VERIFIED] {obj2.name}: LuaJIT bytecode OK + {len(shaders)} HLSL->SPIR-V shaders OK")

        for aul2 in (stable_dir / "Language").glob("*.aul2"):
            raw = aul2.read_bytes()
            assert not raw.startswith(b"\xef\xbb\xbf"), f"BOM found in {aul2}"
            assert b"\r\n" in raw, f"Missing CRLF in {aul2}"

        # Build clean standalone release folder + ZIP
        out_sub = REL_DIR / rel_name
        if out_sub.exists():
            shutil.rmtree(out_sub)
        shutil.copytree(stable_dir, out_sub)
        zip_path = REL_DIR / f"{rel_name}.zip"
        with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
            for f in sorted(out_sub.rglob("*")):
                if f.is_file():
                    zf.write(f, f.relative_to(out_sub))
        print(f"[PACKAGED] {zip_path} ({zip_path.stat().st_size / 1024:.1f} KB)")

    # Build combined bundle ZIP
    bundle_zip = REL_DIR / "AviUtl2_3D三件套_P0正式发布包_20261023.zip"
    with zipfile.ZipFile(bundle_zip, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
        for rel_name, _ in targets:
            sub = REL_DIR / rel_name
            for f in sorted(sub.rglob("*")):
                if f.is_file():
                    zf.write(f, Path(rel_name) / f.relative_to(sub))
    print(f"[BUNDLE]   {bundle_zip} ({bundle_zip.stat().st_size / 1024:.1f} KB)")


if __name__ == "__main__":
    build_snow_v119()
    build_fog_v202()
    build_vl_v286()
    verify_and_package()
