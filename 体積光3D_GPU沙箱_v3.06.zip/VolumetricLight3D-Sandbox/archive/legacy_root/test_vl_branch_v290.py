#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Full verification of the v2.90-bridge branch. Does not modify v2.86."""
from __future__ import annotations

import ctypes
import json
import os
import signal
import subprocess
import sys
import tempfile
import textwrap
import zipfile
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import font_manager
font_manager.fontManager.addfont("/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc")
import numpy as np
from PIL import Image

sys.path.insert(0, "/home/user/sandbox")
from aviutl2_sandbox import AviUtl2Sandbox, SceneLayer
from generate_assets import ASSET_DIR, make_stained_glass_png, make_birdcage_obj, make_character_glb
from test_memory_access import make_benchmark_glb, make_malicious_neg_stride_glb

ROOT = Path("/home/user")
BRANCH = ROOT / "scripts/pkg1/体积光（3D）/development/branch_v2.90_aux2_bridge/Script/体積光（3D）.obj2"
STABLE = ROOT / "scripts/pkg1/体积光（3D）/stable/Script/体積光（3D）.obj2"
LIBGUARD = ROOT / "sandbox/libguard_w32.so"
LIBBRIDGE = ROOT / "sandbox/libvl3d_bridge_linux.so"
RES = ROOT / "sandbox/results"
FIG = RES / "figures"
FIG.mkdir(parents=True, exist_ok=True)

plt.rcParams["font.sans-serif"] = ["Noto Sans CJK JP", "Noto Sans CJK SC", "DejaVu Sans"]
plt.rcParams["axes.unicode_minus"] = False


def luajit(src: str, timeout: float = 30.0) -> dict:
    with tempfile.NamedTemporaryFile("w", suffix=".lua", delete=False, encoding="utf-8") as tf:
        tf.write(src)
        path = tf.name
    try:
        proc = subprocess.run(["luajit", path], capture_output=True, text=True, timeout=timeout)
    finally:
        os.unlink(path)
    rc = proc.returncode
    crashed = rc == -signal.SIGSEGV or rc == 128 + signal.SIGSEGV
    return {"rc": rc, "crashed": crashed, "out": proc.stdout.strip(), "err": proc.stderr.strip()}


def compiles(src: str) -> bool:
    with tempfile.NamedTemporaryFile("w", suffix=".lua", delete=False, encoding="utf-8") as tf:
        tf.write(src)
        path = tf.name
    try:
        proc = subprocess.run(["luajit", "-bl", path], capture_output=True, text=True)
        return proc.returncode == 0
    finally:
        os.unlink(path)


def inject_locals(path: Path, n: int) -> str:
    text = path.read_text(encoding="utf-8").replace("\r\n", "\n")
    sig = "local function beam_frame()\n"
    i = text.find(sig)
    if i < 0:
        raise RuntimeError("beam_frame missing")
    extra = "".join(f"    local extra_{k} = {k}\n" for k in range(n))
    return text[: i + len(sig)] + extra + text[i + len(sig):]


def harness(extra: str) -> str:
    lines = BRANCH.read_text(encoding="utf-8").splitlines()
    start = end = None
    for i, ln in enumerate(lines):
        if start is None and ln.startswith("local obj, math = obj, math"):
            start = i
        if ln.startswith("local function beam_frame()"):
            end = i
            break
    core = "\n".join(lines[start:end])
    prelude = r'''
local ffi = require("ffi")
ffi.os = "Windows"
ffi.cdef[[
typedef struct { uintptr_t raw_map; size_t raw_len; uintptr_t usable_base; size_t usable_len; uintptr_t ptr; } guard_alloc_t;
void gw_reset_regions(void);
void gw_set_exe_base(uintptr_t base);
void gw_register_region(uintptr_t base, size_t size, uint32_t state, uint32_t protect, uint32_t type);
int gw_guard_alloc(size_t exact_len, int align_end, guard_alloc_t* out);
int gw_protect(uintptr_t addr, size_t len, int prot_flags);
void gw_arm_toctou(uintptr_t target_base, uintptr_t decommit_ptr, size_t decommit_len, int delay_us);
int gw_did_toctou_fire(void);
size_t mock_VirtualQuery(const void* p, void* buf, size_t n);
intptr_t mock_GetCurrentProcess(void);
uintptr_t mock_GetModuleHandleW(const uint16_t* name);
int32_t mock_ReadProcessMemory(intptr_t h, const void* addr, void* dst, size_t n, size_t* out);
void gw_reset_handles(int64_t mock_file_sz);
int gw_get_open_handles(void);
int gw_get_closed_handles(void);
intptr_t mock_CreateFileW(const uint16_t* path, uint32_t acc, uint32_t share, void* sa, uint32_t disp, uint32_t attr, void* tmpl);
int32_t mock_GetFileSizeEx(intptr_t h, int64_t* sz);
int32_t mock_ReadFile(intptr_t h, void* buf, uint32_t n, uint32_t* rd, void* ov);
int32_t mock_CloseHandle(intptr_t h);
]]
local GW = ffi.load("/home/user/sandbox/libguard_w32.so")
_G._GW = GW
_G.obj = {
    layer=2, frame=10, time=0.2, screen_w=640, screen_h=360,
    getinfo=function() return nil end,
    getvalue=function() return nil end,
    getoption=function() return nil end,
    setoption=function() end,
    clearbuffer=function() return true end,
    pixelshader=function() return true end,
    load=function() end, draw=function() end, drawpoly=function() end,
    copybuffer=function() return true end,
    module=function() return nil end,
    getpixeldata=function() return nil, 0, 0 end,
}
_G.VL3D_TEST_W32_API = {
    ffi=ffi,
    VirtualQuery=GW.mock_VirtualQuery,
    GetCurrentProcess=GW.mock_GetCurrentProcess,
    GetModuleHandleW=GW.mock_GetModuleHandleW,
    ReadProcessMemory=GW.mock_ReadProcessMemory,
    CreateFileW=GW.mock_CreateFileW,
    GetFileSizeEx=GW.mock_GetFileSizeEx,
    ReadFile=GW.mock_ReadFile,
    CloseHandle=GW.mock_CloseHandle,
}
'''
    footer = r'''
_G._E = {
    pe_find_export_addr = pe_find_export_addr,
    scan_live_modelfile_instances = scan_live_modelfile_instances,
    resolve_live_scene_layer_object = resolve_live_scene_layer_object,
    inspect_or_suppress_camera_lights = inspect_or_suppress_camera_lights,
    try_read_live_edit_camera = try_read_live_edit_camera,
    load_glb_vrm_fallback = load_glb_vrm_fallback,
    win32_read_file_wide_from_utf8 = win32_read_file_wide_from_utf8,
    _VL_PERSIST = _VL_PERSIST,
}
'''
    return prelude + "\n" + core + "\n" + footer + "\n" + extra


def render(script, w, h, layers_fn, overrides, extra_src=None, bg=(8, 10, 18, 255)):
    sb = AviUtl2Sandbox(w, h)
    sb.reset_framebuffer(bg)
    layers_fn(sb)
    if any(lay.render_in_3d or lay.opaque_3d_mesh or lay.rgba_image is not None for lay in sb.layers.values()):
        sb.render_scene_3d_layers()
    path = script
    if extra_src:
        text = Path(script).read_text(encoding="utf-8").replace("\r\n", "\n")
        text = text.replace("local ok, err = pcall(beam_frame)", extra_src + "\nlocal ok, err = pcall(beam_frame)", 1)
        tmp = Path("/tmp/vl_branch_inject.obj2")
        tmp.write_text(text, encoding="utf-8")
        path = str(tmp)
    return sb.run_obj2(path, param_overrides=overrides, obj_props={"layer": 6})


def main():
    report = {"checks": []}

    def add(name, ok, detail=""):
        report["checks"].append({"name": name, "ok": bool(ok), "detail": detail})
        print(f"[{'PASS' if ok else 'FAIL'}] {name} {detail}")

    # --- P0-8 local pressure ---
    add("branch_compiles", compiles(BRANCH.read_text(encoding="utf-8").replace("\r\n", "\n")))
    add("stable_untouched_still_v286", STABLE.read_text(encoding="utf-8").splitlines()[0].endswith("v2.86"))
    add("inject_200_compiles", compiles(inject_locals(BRANCH, 200)), "beam_frame peak locals = 0")
    add("inject_201_fails", not compiles(inject_locals(BRANCH, 201)))
    stable_text = STABLE.read_text(encoding="utf-8").replace("\r\n", "\n")
    # v2.86 cannot accept 10 extra locals inside beam_frame
    sig = "local function beam_frame()\n"
    i = stable_text.find(sig)
    stable_injected = stable_text[: i + len(sig)] + "".join(f"    local extra_{k}={k}\n" for k in range(10)) + stable_text[i + len(sig):]
    add("stable_still_near_200_limit", not compiles(stable_injected), "v2.86 + 10 locals fails, as audited")

    text = BRANCH.read_text(encoding="utf-8")
    add("no_host_gbuf_write", "gbuf_addr + 0xA0)[0] =" not in text)
    add("bridge_symbol", 'obj.module("VL3DBridge")' in text)
    add("copybuffer_path", "cache:vl3d/fb_bak" in text and "obj.copybuffer" in text)
    add("six_phases", all(f"local function {n}(" in text for n in (
        "vl_bf_prepare", "vl_bf_capture", "vl_bf_geometry", "vl_bf_mip", "vl_bf_occlusion", "vl_bf_render")))

    # --- C++ selftest ---
    lib = ctypes.CDLL(str(LIBBRIDGE))
    lib.vl3d_test_selftest.argtypes = [ctypes.c_char_p, ctypes.c_int]
    lib.vl3d_test_selftest.restype = ctypes.c_int
    buf = ctypes.create_string_buffer(8192)
    rc = lib.vl3d_test_selftest(buf, 8192)
    cpp_log = buf.value.decode()
    add("cpp_selftest", rc == 0, cpp_log.splitlines()[0])
    report["cpp_log"] = cpp_log

    # --- Lua bridge integration ---
    r = luajit(harness(r'''
_G.VL3D_TEST_BRIDGE = {
    resolve_layer = function(oln, frame)
        return "OBJ", "モデルファイル", "C:/models/cage.obj", 1, 9, -1, "SDK"
    end,
    get_camera_lights = function()
        return 2, 0.5, 0.1, 0.2, 0.3, 2.5, true, 2, 0, 1, 0, 1.2, 0.8, 0.4, 1.2, 10, 20, 30, 0.5
    end,
    get_edit_camera = function()
        return true, 1, 2, 3, 4, 5, 6, 0, -1, 0, 12.5, 900
    end,
}
local layer = resolve_live_scene_layer_object(4, 8)
local lights = inspect_or_suppress_camera_lights(true)
local cam = try_read_live_edit_camera()
print(string.format("LAYER=%s PATH=%s SCENE=%d TIER=%s LIGHTS=%d PEAK=%.1f SUP=%s REQ=%s LTYPE=%d CAMZ=%.1f",
    layer.status, layer.path, layer.scene_id, layer.source_tier,
    lights.count, lights.peak_gain, tostring(lights.suppressed), tostring(lights.suppress_requested),
    lights.primary.ltype, cam.z))
'''))
    add("lua_bridge_routes", (not r["crashed"]) and "LAYER=OBJ" in r["out"] and "SUP=false" in r["out"] and "CAMZ=3.0" in r["out"], r["out"] or r["err"])

    # --- M-01 read-only gbuf ---
    r = luajit(harness(r'''
local ffi = require("ffi")
local GW = _G._GW
local E = _G._E
local exe_ga, heap_ga, gbuf_ga = ffi.new("guard_alloc_t[1]"), ffi.new("guard_alloc_t[1]"), ffi.new("guard_alloc_t[1]")
assert(GW.gw_guard_alloc(0x600000, 0, exe_ga) == 0)
assert(GW.gw_guard_alloc(0x8000, 0, heap_ga) == 0)
assert(GW.gw_guard_alloc(4096, 0, gbuf_ga) == 0)
local exe_base, heap_base, gbuf = exe_ga[0].ptr, heap_ga[0].ptr, gbuf_ga[0].ptr
GW.gw_reset_regions(); GW.gw_set_exe_base(exe_base)
GW.gw_register_region(exe_base, 0x600000, 0x1000, 0x04, 0x1000000)
GW.gw_register_region(heap_base, 0x8000, 0x1000, 0x04, 0x20000)
GW.gw_register_region(gbuf, 4096, 0x1000, 0x02, 0x20000)
local b = ffi.cast("uint8_t*", exe_base)
b[0], b[1] = 0x4D, 0x5A
ffi.cast("int32_t*", b + 0x3C)[0] = 0x80
local nt = b + 0x80
nt[0], nt[1] = 0x50, 0x45
ffi.cast("uint16_t*", nt + 6)[0] = 1
ffi.cast("uint16_t*", nt + 20)[0] = 0xF0
ffi.cast("uint32_t*", nt + 0x50)[0] = 0x600000
local lctx, rctx, lvec = heap_base + 0x1000, heap_base + 0x2000, heap_base + 0x3000
ffi.cast("uint64_t*", exe_base + 0x58AAB8)[0] = lctx
ffi.cast("uint64_t*", lctx + 0x88)[0] = rctx
ffi.cast("uint64_t*", rctx + 0xD0)[0] = gbuf
ffi.cast("uint64_t*", gbuf + 0x98)[0] = lvec
local before = tonumber(ffi.cast("uint64_t*", gbuf + 0xA0)[0])
assert(GW.gw_protect(gbuf_ga[0].usable_base, gbuf_ga[0].usable_len, 1) == 0)
local info = E.inspect_or_suppress_camera_lights(true)
local after = tonumber(ffi.cast("uint64_t*", gbuf + 0xA0)[0])
print(string.format("SURVIVED DELTA=%d SUP=%s", after - before, tostring(info.suppressed)))
'''))
    add("m01_readonly_gbuf_survives", (not r["crashed"]) and "SURVIVED" in r["out"] and "DELTA=0" in r["out"], r["out"] or r["err"])

    # --- M-02 edit camera opt_sz ---
    r = luajit(harness(r'''
local ffi = require("ffi")
local GW = _G._GW
local ga = ffi.new("guard_alloc_t[1]")
assert(GW.gw_guard_alloc(4096, 1, ga) == 0)
local base = ga[0].ptr
GW.gw_reset_regions(); GW.gw_set_exe_base(base)
GW.gw_register_region(base, 4096, 0x1000, 0x20, 0x1000000)
local b = ffi.cast("uint8_t*", base)
b[0], b[1] = 0x4D, 0x5A
ffi.cast("int32_t*", b + 0x3C)[0] = 0x100
b[0x100], b[0x101] = 0x50, 0x45
ffi.cast("uint16_t*", b + 0x106)[0] = 4
ffi.cast("uint16_t*", b + 0x114)[0] = 0x2000
local cam = try_read_live_edit_camera()
print("EDITCAM_SURVIVED", tostring(cam))
'''))
    add("m02_optsz_no_crash", (not r["crashed"]) and "EDITCAM_SURVIVED" in r["out"], r["out"] or r["err"])

    # --- M-03 lfanew + TOCTOU ---
    r = luajit(harness(r'''
local ffi = require("ffi")
local GW = _G._GW
local ga = ffi.new("guard_alloc_t[1]")
assert(GW.gw_guard_alloc(4096, 1, ga) == 0)
GW.gw_reset_regions(); GW.gw_set_exe_base(ga[0].ptr)
GW.gw_register_region(ga[0].ptr, 4096, 0x1000, 0x04, 0x1000000)
local b = ffi.cast("uint8_t*", ga[0].ptr)
b[0], b[1] = 0x4D, 0x5A
ffi.cast("int32_t*", b + 0x3C)[0] = 0x1800
local list = scan_live_modelfile_instances()
print("LFANEW_SURVIVED", #list)
'''))
    add("m03_lfanew_no_crash", (not r["crashed"]) and "LFANEW_SURVIVED" in r["out"], r["out"] or r["err"])

    r = luajit(harness(r'''
local ffi = require("ffi")
local GW = _G._GW
local exe_ga, race_ga = ffi.new("guard_alloc_t[1]"), ffi.new("guard_alloc_t[1]")
local REGION = 8 * 1024 * 1024
assert(GW.gw_guard_alloc(8192, 0, exe_ga) == 0)
assert(GW.gw_guard_alloc(REGION, 0, race_ga) == 0)
local exe_base, rdat, race = exe_ga[0].ptr, exe_ga[0].ptr + 0x1000, race_ga[0].ptr
GW.gw_reset_regions(); GW.gw_set_exe_base(exe_base)
GW.gw_register_region(exe_base, 4096, 0x1000, 0x20, 0x1000000)
GW.gw_register_region(rdat, 4096, 0x1000, 0x02, 0x1000000)
GW.gw_register_region(race, REGION, 0x1000, 0x04, 0x20000)
local b = ffi.cast("uint8_t*", exe_base)
b[0], b[1] = 0x4D, 0x5A
ffi.cast("int32_t*", b + 0x3C)[0] = 0x80
b[0x80], b[0x81] = 0x50, 0x45
ffi.cast("uint32_t*", b + 0x80 + 0x50)[0] = 8192
local pw = ffi.cast("uint16_t*", rdat + 0x100)
local chars = {0x30E2,0x30C7,0x30EB,0x30D5,0x30A1,0x30A4,0x30EB,0}
for i = 1, #chars do pw[i-1] = chars[i] end
GW.gw_arm_toctou(race, race + 256 * 1024, REGION - 256 * 1024, 50)
local list = scan_live_modelfile_instances()
print(string.format("TOCTOU_SURVIVED FIRED=%d N=%d", GW.gw_did_toctou_fire(), #list))
'''), timeout=40)
    add("m03_toctou_chunked_survives", (not r["crashed"]) and "TOCTOU_SURVIVED" in r["out"], r["out"] or r["err"])

    # --- M-04 export bounds + valid lookup ---
    r = luajit(harness(r'''
local ffi = require("ffi")
local GW = _G._GW
local ga = ffi.new("guard_alloc_t[1]")
assert(GW.gw_guard_alloc(4096, 1, ga) == 0)
local base = ga[0].ptr
local b = ffi.cast("uint8_t*", base)
b[0], b[1] = 0x4D, 0x5A
ffi.cast("int32_t*", b + 0x3C)[0] = 0x80
local nt = b + 0x80
nt[0], nt[1], nt[2], nt[3] = 0x50, 0x45, 0, 0
ffi.cast("uint16_t*", nt + 0x18)[0] = 0x020B
ffi.cast("uint32_t*", nt + 0x50)[0] = 4096
ffi.cast("uint32_t*", nt + 0x88)[0] = 0x200
ffi.cast("uint32_t*", nt + 0x8C)[0] = 0x100
local exp = b + 0x200
ffi.cast("uint32_t*", exp + 0x14)[0] = 1
ffi.cast("uint32_t*", exp + 0x18)[0] = 1
ffi.cast("uint32_t*", exp + 0x1C)[0] = 0x300
ffi.cast("uint32_t*", exp + 0x20)[0] = 0x310
ffi.cast("uint32_t*", exp + 0x24)[0] = 0x320
ffi.cast("uint32_t*", b + 0x310)[0] = 0x1500
local bad = pe_find_export_addr(ffi, base, "GetProcAddress")
ffi.cast("uint32_t*", b + 0x310)[0] = 4088
for i = 4088, 4095 do b[i] = 0x41 end
local bad2 = pe_find_export_addr(ffi, base, "GetProcAddress")
-- valid export
ffi.fill(b + 0x200, 0x200, 0)
ffi.cast("uint32_t*", exp + 0x14)[0] = 2
ffi.cast("uint32_t*", exp + 0x18)[0] = 2
ffi.cast("uint32_t*", exp + 0x1C)[0] = 0x300
ffi.cast("uint32_t*", exp + 0x20)[0] = 0x320
ffi.cast("uint32_t*", exp + 0x24)[0] = 0x340
ffi.copy(b + 0x400, "CreateFileW\0", 12)
ffi.copy(b + 0x420, "GetProcAddress\0", 15)
ffi.cast("uint32_t*", b + 0x320)[0] = 0x400
ffi.cast("uint32_t*", b + 0x324)[0] = 0x420
ffi.cast("uint16_t*", b + 0x340)[0] = 0
ffi.cast("uint16_t*", b + 0x342)[0] = 1
ffi.cast("uint32_t*", b + 0x300)[0] = 0x700
ffi.cast("uint32_t*", b + 0x304)[0] = 0x740
local a = pe_find_export_addr(ffi, base, "GetProcAddress")
print(string.format("BAD=%d BAD2=%d GPA=0x%x", tonumber(bad), tonumber(bad2), tonumber(a - base)))
'''))
    add("m04_export_bounds_and_valid", (not r["crashed"]) and "BAD=0 BAD2=0 GPA=0x740" in r["out"], r["out"] or r["err"])

    # --- M-06 GLB ---
    with tempfile.NamedTemporaryFile("wb", suffix=".glb", delete=False) as mf:
        mf.write(make_malicious_neg_stride_glb())
        mal = mf.name
    with tempfile.NamedTemporaryFile("wb", suffix=".glb", delete=False) as bf:
        bf.write(make_benchmark_glb(12000))
        bench = bf.name
    try:
        r = luajit(harness(f'''
_G.VL3D_TEST_W32_API = nil
_VL_PERSIST.w32_api = false
local m = load_glb_vrm_fallback({json.dumps(mal)}, 100, 1, 1, 1)
print("NEG_SURVIVED", tostring(m))
local m0 = load_glb_vrm_fallback({json.dumps(bench)}, 100, 1, -1, 1)
assert(m0 and m0.nv == 12000)
collectgarbage("collect"); collectgarbage("collect"); collectgarbage("stop")
local kb0 = collectgarbage("count")
for i = 1, 40 do
    local mf = load_glb_vrm_fallback({json.dumps(bench)}, 100, 1, -1, 1)
    assert(mf.nv == 12000 and mf.vx[1] ~= nil)
end
local kb1 = collectgarbage("count")
collectgarbage("restart")
print(string.format("GC40_KB=%.2f", kb1 - kb0))
'''), timeout=40)
        gc_ok = False
        if "GC40_KB=" in r["out"]:
            kb = float(r["out"].split("GC40_KB=")[1].split()[0])
            gc_ok = kb < 64.0  # unpatched would be tens of MB
            report["glb_gc_kb"] = kb
        add("m06_neg_stride_and_ffi_cache", (not r["crashed"]) and "NEG_SURVIVED" in r["out"] and gc_ok, r["out"] or r["err"])
    finally:
        os.unlink(mal)
        os.unlink(bench)

    # --- M-10 handle close ---
    r = luajit(harness(r'''
local GW = _G._GW
GW.gw_reset_handles(1024 * 1024)
_G.VL3D_TEST_W32_API.ReadFile = function() error("not enough memory") end
for i = 1, 8 do
    win32_read_file_wide_from_utf8("C:\\\\test\\\\m" .. i .. ".vrm")
end
local opened, closed = GW.gw_get_open_handles(), GW.gw_get_closed_handles()
print(string.format("OPENED=%d CLOSED=%d LEAK=%d", opened, closed, opened - closed))
'''))
    add("m10_handle_closed_on_error", (not r["crashed"]) and "LEAK=0" in r["out"], r["out"] or r["err"])

    # --- GPU identity vs v2.86 ---
    sg = make_stained_glass_png(ASSET_DIR / "stained_glass.png", 256)
    W, H = 320, 180

    def glass(sb):
        sb.layers[2] = SceneLayer(layer_id=2, x=0, y=0, z=400, zoom=80, rgba_image=sg, render_in_3d=True)

    ov = {"src_layer": 2, "intensity": 120, "length": 900, "direction": 10, "pitch": 70, "spread": 16, "fog": 0, "log_mode": False, "occ_mode": 0}
    a = render(str(STABLE), W, H, glass, ov)
    b = render(str(BRANCH), W, H, glass, ov)
    diff = np.abs(a["framebuffer"].astype(np.int16) - b["framebuffer"].astype(np.int16))
    add("gpu_stained_glass_identical", int(diff.max()) == 0, f"max={int(diff.max())}")
    Image.fromarray(b["framebuffer"]).save(RES / "branch_v290_stained.png")

    def water(sb):
        sb.layers[2] = SceneLayer(
            layer_id=2, x=0, y=40, z=120, rx=-70, zoom=90,
            effects={"水面": {"解像度": 128, "速さ": 40, "向き": 20, "波紋": 30, "傾き": 0}},
            render_in_3d=False,
        )
    wov = {"src_layer": 2, "intensity": 110, "length": 700, "direction": 0, "pitch": 75, "spread": 12, "fog": 0, "log_mode": False, "light_color": 0xFFFF00}
    wa = render(str(STABLE), W, H, water, wov, bg=(6, 8, 16, 255))
    wb = render(str(BRANCH), W, H, water, wov, bg=(6, 8, 16, 255))
    wdiff = np.abs(wa["framebuffer"].astype(np.int16) - wb["framebuffer"].astype(np.int16))
    add("gpu_water_gold_identical", int(wdiff.max()) == 0, f"max={int(wdiff.max())}")
    Image.fromarray(wb["framebuffer"]).save(RES / "branch_v290_water.png")

    # mode 2 compensation
    inject = '_G.VL3D_TEST_CAM_LIGHTS = {count=2, peak_gain=2.0, suppressed=false, unlit=1.0, amb_r=0.0, amb_g=0.0, amb_b=0.0}'
    m0 = render(str(BRANCH), W, H, glass, {**ov, "cam_light_mode": 0, "log_mode": True}, extra_src=inject)
    m2 = render(str(BRANCH), W, H, glass, {**ov, "cam_light_mode": 2, "log_mode": True}, extra_src=inject)
    m3 = render(str(BRANCH), W, H, glass, {**ov, "cam_light_mode": 3, "log_mode": True}, extra_src=inject)
    # logs go to stdout via print; capture by scanning loaded texts? The sandbox stores print? 
    # Compare brightness instead.
    def luma(res):
        img = res["framebuffer"].astype(np.float32)
        return float(img[..., :3].mean())
    l0, l2, l3 = luma(m0), luma(m2), luma(m3)
    report["mode_luma"] = {"m0": l0, "m2": l2, "m3": l3}
    add("mode2_matches_mode0_compensation", abs(l0 - l2) < 0.05, f"l0={l0:.3f} l2={l2:.3f}")
    add("mode3_brighter_without_comp", l3 > l2 + 1.0, f"l3={l3:.3f} l2={l2:.3f}")

    # joint smoke: VRM+OBJ occlusion still runs
    cage_v, cage_t = make_birdcage_obj(ASSET_DIR / "birdcage.obj")
    char_v, char_t = make_character_glb(ASSET_DIR / "character.glb")

    def joint(sb):
        sb.layers[2] = SceneLayer(layer_id=2, x=0, y=-20, z=420, zoom=90, rgba_image=sg, render_in_3d=True)
        sb.layers[4] = SceneLayer(
            layer_id=4, x=-80, y=40, z=180, zoom=80,
            effects={"VRMToolkitModel": {"VRMファイル": str(ASSET_DIR / "character.glb"), "モデル倍率": 100}},
            opaque_3d_mesh={"verts": char_v, "tris": char_t, "color": (0.88, 0.84, 0.90)},
        )
        sb.layers[5] = SceneLayer(
            layer_id=5, x=60, y=0, z=200, zoom=90,
            effects={"モデルファイル": {"ファイル": str(ASSET_DIR / "birdcage.obj"), "座標系を調整": 0}},
            opaque_3d_mesh={"verts": cage_v, "tris": cage_t, "color": (0.85, 0.72, 0.45)},
        )

    jb = render(str(BRANCH), 480, 270, joint, {
        "src_layer": 2, "intensity": 100, "length": 800, "direction": 15, "pitch": 60, "spread": 18,
        "occ_mode": 3, "occ_target": 0, "log_mode": False, "fog": 0,
    })
    add("joint_scene_renders", jb.get("error") in (None, "") and jb["framebuffer"].shape == (270, 480, 4))
    Image.fromarray(jb["framebuffer"]).save(RES / "branch_v290_joint.png")

    # package
    lang_src = ROOT / "scripts/pkg1/体积光（3D）/stable/Language/简体中文.体積光（3D）.aul2"
    lang_dst = ROOT / "scripts/pkg1/体积光（3D）/development/branch_v2.90_aux2_bridge/Language/简体中文.体積光（3D）.aul2"
    lang_dst.parent.mkdir(parents=True, exist_ok=True)
    lang_dst.write_bytes(lang_src.read_bytes())
    add("drag_budget_present", "-- [P0-drag]" in text and "v2.91-bridge" in text.splitlines()[0])
    add("drag_does_not_touch_stable", STABLE.read_text(encoding="utf-8").splitlines()[0].endswith("v2.86"))
    zip_path = ROOT / "releases/体積光（3D）_v2.91_分支版_VL3DBridge.zip"
    zip_path.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
        base = ROOT / "scripts/pkg1/体积光（3D）/development/branch_v2.90_aux2_bridge"
        for rel in (
            "Script/体積光（3D）.obj2",
            "Plugin/VL3DBridge.aux2",
            "Plugin/VL3DBridge.ini",
            "Language/简体中文.体積光（3D）.aul2",
            "分支说明.txt",
            "更新历史_体積光3D.md",
        ):
            zf.write(base / rel, f"体積光（3D）_v2.91_分支版/{rel}")
    add("zip_written", zip_path.exists() and zip_path.stat().st_size > 100_000, f"{zip_path.stat().st_size} bytes")
    report["zip"] = str(zip_path)

    failed = [c for c in report["checks"] if not c["ok"]]
    report["n_pass"] = sum(1 for c in report["checks"] if c["ok"])
    report["n_fail"] = len(failed)
    (RES / "branch_v290_verification.json").write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")

    # figure
    fig, axes = plt.subplots(2, 2, figsize=(14.2, 8.6), facecolor="#10141c")
    fig.suptitle("体積光（3D） v2.91-bridge 分支验证  ·  未并入 v2.86 主线", color="#f4f1ea", fontsize=16, y=0.98)
    ax = axes[0, 0]
    ax.set_facecolor("#10141c")
    names = ["v2.86\nbeam_frame", "v2.91\nbeam_frame", "LuaJIT\n上限"]
    vals = [196, 0, 200]
    colors = ["#e15a4a", "#3ddc97", "#8aa0b8"]
    bars = ax.bar(names, vals, color=colors, width=0.62)
    ax.axhline(60, color="#f0c14d", ls="--", lw=1, label="审计目标 < 60")
    ax.set_ylim(0, 230)
    ax.set_ylabel("活跃 local", color="#d5dbe3")
    ax.set_title("P0-8  beam_frame() 局部变量", color="#f4f1ea")
    ax.tick_params(colors="#d5dbe3")
    for sp in ax.spines.values():
        sp.set_color("#2c3644")
    ax.legend(facecolor="#1b2330", edgecolor="#2c3644", labelcolor="#f4f1ea", fontsize=8)
    for bar, v in zip(bars, vals):
        ax.text(bar.get_x() + bar.get_width() / 2, v + 4, str(v), ha="center", color="#f4f1ea", fontsize=11)

    ax = axes[0, 1]
    ax.set_facecolor("#10141c")
    ax.axis("off")
    ax.set_title("安全与桥接", color="#f4f1ea", loc="left")
    lines_txt = [
        "宿主 GBuffer 写入          已删除",
        "模式 2                       只读峰值补偿",
        "VL3DBridge.aux2            SDK 优先 / 白名单降级",
        "C++ 自测                     " + cpp_log.splitlines()[0],
        "PE 导出越界                  安全返回 0",
        "64KB 分块 RPM               TOCTOU 不崩溃",
        "GLB 负 stride / FFI 缓存     已加固",
        "句柄异常                     CloseHandle 必达",
        "帧缓冲备份                   copybuffer 优先",
    ]
    ax.text(0.02, 0.95, "\n".join(lines_txt), va="top", ha="left", color="#d7efe4", fontsize=11,
            transform=ax.transAxes)

    ax = axes[1, 0]
    ax.set_facecolor("#10141c")
    ax.imshow(b["framebuffer"])
    ax.set_title(f"分支 vs v2.86 彩窗  maxΔ={int(diff.max())}", color="#f4f1ea", fontsize=11)
    ax.axis("off")

    ax = axes[1, 1]
    ax.set_facecolor("#10141c")
    labels = [c["name"].replace("_", "\n") for c in report["checks"]]
    oks = [1 if c["ok"] else 0 for c in report["checks"]]
    ax.barh(range(len(oks)), oks, color=["#3ddc97" if v else "#e15a4a" for v in oks])
    ax.set_yticks(range(len(labels)))
    ax.set_yticklabels(labels, fontsize=6.2, color="#d5dbe3")
    ax.set_xlim(0, 1.15)
    ax.set_xticks([])
    ax.set_title(f"检查 {report['n_pass']}/{report['n_pass']+report['n_fail']} 通过", color="#f4f1ea")
    for sp in ax.spines.values():
        sp.set_color("#2c3644")
    fig.tight_layout(rect=(0, 0, 1, 0.95))
    fig_path = FIG / "fig12_branch_v290_verification.png"
    fig.savefig(fig_path, dpi=130, facecolor=fig.get_facecolor())
    print("figure", fig_path)
    print("ZIP", zip_path)
    if failed:
        print("FAILED", failed)
        sys.exit(1)
    print("ALL PASSED")


if __name__ == "__main__":
    main()
