#define _GNU_SOURCE
#include <stdint.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <pthread.h>
#include <sys/mman.h>
#include <sys/uio.h>

/*
 * Hardware Guard-Page + Win32 VirtualQuery / ReadProcessMemory / Handle Twin
 * Uses real Linux kernel MMU protections (mmap + mprotect PROT_NONE/PROT_READ/PROT_WRITE)
 * and kernel fault-safe process_vm_readv(getpid(), ...) to mirror Windows NtReadVirtualMemory.
 */

typedef struct {
    uintptr_t base;
    size_t    size;
    uint32_t  state;    /* 0x1000=MEM_COMMIT, 0x10000=MEM_FREE */
    uint32_t  protect;  /* 0x01=NOACCESS, 0x02=READONLY, 0x04=READWRITE, 0x20=EXECUTE_READ */
    uint32_t  type;     /* 0x20000=MEM_PRIVATE, 0x1000000=MEM_IMAGE */
} vreg_t;

#define MAX_VREGS 128
static vreg_t g_vregs[MAX_VREGS];
static int    g_nvregs = 0;
static uintptr_t g_exe_base = 0;
static pthread_mutex_t g_mu = PTHREAD_MUTEX_INITIALIZER;

/* Handle tracking for leak audit */
static int g_open_handles   = 0;
static int g_closed_handles = 0;
static int64_t g_mock_file_size = 0;

/* Optional TOCTOU race trigger when VirtualQuery queries a target region */
static uintptr_t g_toctou_target_base = 0;
static uintptr_t g_toctou_decommit_ptr = 0;
static size_t    g_toctou_decommit_len = 0;
static int       g_toctou_delay_us = 0;
static volatile int g_toctou_armed = 0;
static volatile int g_toctou_fired = 0;

void gw_reset_regions(void) {
    pthread_mutex_lock(&g_mu);
    g_nvregs = 0;
    g_exe_base = 0;
    g_toctou_armed = 0;
    g_toctou_fired = 0;
    pthread_mutex_unlock(&g_mu);
}

void gw_set_exe_base(uintptr_t base) {
    g_exe_base = base;
}

void gw_register_region(uintptr_t base, size_t size, uint32_t state, uint32_t protect, uint32_t type) {
    pthread_mutex_lock(&g_mu);
    if (g_nvregs < MAX_VREGS) {
        g_vregs[g_nvregs].base    = base;
        g_vregs[g_nvregs].size    = size;
        g_vregs[g_nvregs].state   = state;
        g_vregs[g_nvregs].protect = protect;
        g_vregs[g_nvregs].type    = type;
        g_nvregs++;
    }
    pthread_mutex_unlock(&g_mu);
}

/*
 * Allocate [leading_guard (4KB PROT_NONE)] [usable pages (RW)] [trailing_guard (4KB PROT_NONE)].
 * If align_end != 0, returns a pointer `usable_end - exact_len` so byte `exact_len` hits trailing PROT_NONE.
 * If align_end == 0, returns `usable_start` so byte `-1` hits leading PROT_NONE.
 */
typedef struct {
    uintptr_t raw_map;
    size_t    raw_len;
    uintptr_t usable_base;
    size_t    usable_len;
    uintptr_t ptr;
} guard_alloc_t;

int gw_guard_alloc(size_t exact_len, int align_end, guard_alloc_t* out) {
    size_t pg = 4096;
    size_t usable = ((exact_len + pg - 1) / pg) * pg;
    if (usable == 0) usable = pg;
    size_t total = pg + usable + pg;
    /* Hint an address in canonical low user space (< 2^47) */
    void* raw = mmap((void*)0x200000000ULL, total, PROT_READ | PROT_WRITE,
                     MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    if (raw == MAP_FAILED) return -1;
    uintptr_t b = (uintptr_t)raw;
    if (mprotect((void*)b, pg, PROT_NONE) != 0) { munmap(raw, total); return -2; }
    if (mprotect((void*)(b + pg + usable), pg, PROT_NONE) != 0) { munmap(raw, total); return -3; }

    uintptr_t ubase = b + pg;
    memset((void*)ubase, 0, usable);
    out->raw_map     = b;
    out->raw_len     = total;
    out->usable_base = ubase;
    out->usable_len  = usable;
    out->ptr         = align_end ? (ubase + usable - exact_len) : ubase;
    return 0;
}

int gw_protect(uintptr_t addr, size_t len, int prot_flags) {
    /* prot_flags: 0=NONE, 1=READ, 3=READ|WRITE */
    int p = PROT_NONE;
    if (prot_flags == 1) p = PROT_READ;
    else if (prot_flags == 3) p = PROT_READ | PROT_WRITE;
    return mprotect((void*)addr, len, p);
}

void gw_guard_free(const guard_alloc_t* a) {
    if (a && a->raw_map && a->raw_len) {
        munmap((void*)a->raw_map, a->raw_len);
    }
}

static void* toctou_worker(void* arg) {
    (void)arg;
    if (g_toctou_delay_us > 0) {
        usleep((useconds_t)g_toctou_delay_us);
    }
    if (g_toctou_decommit_ptr && g_toctou_decommit_len) {
        mprotect((void*)g_toctou_decommit_ptr, g_toctou_decommit_len, PROT_NONE);
        g_toctou_fired = 1;
    }
    return NULL;
}

void gw_arm_toctou(uintptr_t target_base, uintptr_t decommit_ptr, size_t decommit_len, int delay_us) {
    g_toctou_target_base  = target_base;
    g_toctou_decommit_ptr = decommit_ptr;
    g_toctou_decommit_len = decommit_len;
    g_toctou_delay_us     = delay_us;
    g_toctou_fired        = 0;
    g_toctou_armed        = 1;
}

int gw_did_toctou_fire(void) {
    return g_toctou_fired;
}

/* Win64 MEMORY_BASIC_INFORMATION (48 bytes):
 * +0  uint64 BaseAddress
 * +8  uint64 AllocationBase
 * +16 uint32 AllocationProtect
 * +20 uint32 __alignment1
 * +24 uint64 RegionSize
 * +32 uint32 State
 * +36 uint32 Protect
 * +40 uint32 Type
 * +44 uint32 __alignment2
 */
size_t mock_VirtualQuery(const void* lpAddress, void* lpBuffer, size_t dwLength) {
    if (!lpBuffer || dwLength < 48) return 0;
    uintptr_t a = (uintptr_t)lpAddress;
    uint8_t* mbi = (uint8_t*)lpBuffer;
    memset(mbi, 0, 48);

    pthread_mutex_lock(&g_mu);
    int best_next = -1;
    uintptr_t next_base = 0x7FFFFFFF0000ULL;

    for (int i = 0; i < g_nvregs; i++) {
        uintptr_t rb = g_vregs[i].base;
        size_t    rs = g_vregs[i].size;
        if (a >= rb && a < rb + rs) {
            uintptr_t page_a = a & ~((uintptr_t)4095);
            size_t rem = (rb + rs) - page_a;
            *(uint64_t*)(mbi + 0)  = (uint64_t)page_a;
            *(uint64_t*)(mbi + 8)  = (uint64_t)rb;
            *(uint32_t*)(mbi + 16) = g_vregs[i].protect;
            *(uint64_t*)(mbi + 24) = (uint64_t)rem;
            *(uint32_t*)(mbi + 32) = g_vregs[i].state;
            *(uint32_t*)(mbi + 36) = g_vregs[i].protect;
            *(uint32_t*)(mbi + 40) = g_vregs[i].type;

            if (g_toctou_armed && rb == g_toctou_target_base) {
                g_toctou_armed = 0;
                pthread_t th;
                if (pthread_create(&th, NULL, toctou_worker, NULL) == 0) {
                    pthread_detach(th);
                }
            }
            pthread_mutex_unlock(&g_mu);
            return 48;
        }
        if (rb > a && rb < next_base) {
            next_base = rb;
            best_next = i;
        }
    }
    pthread_mutex_unlock(&g_mu);

    if (a >= 0x7FFFFFFF0000ULL) return 0;
    uintptr_t page_a = a & ~((uintptr_t)4095);
    size_t free_sz = (best_next >= 0 ? next_base : 0x7FFFFFFF0000ULL) - page_a;
    *(uint64_t*)(mbi + 0)  = (uint64_t)page_a;
    *(uint64_t*)(mbi + 8)  = 0;
    *(uint64_t*)(mbi + 24) = (uint64_t)free_sz;
    *(uint32_t*)(mbi + 32) = 0x10000; /* MEM_FREE */
    *(uint32_t*)(mbi + 36) = 0x01;    /* PAGE_NOACCESS */
    return 48;
}

intptr_t mock_GetCurrentProcess(void) {
    return -1;
}

uintptr_t mock_GetModuleHandleW(const uint16_t* name) {
    if (name == NULL) return g_exe_base;
    return 0;
}

/* Kernel fault-safe ReadProcessMemory using Linux process_vm_readv(getpid(), ...) */
int32_t mock_ReadProcessMemory(intptr_t hProcess, const void* lpBaseAddress,
                               void* lpBuffer, size_t nSize, size_t* lpNumberOfBytesRead) {
    (void)hProcess;
    if (lpNumberOfBytesRead) *lpNumberOfBytesRead = 0;
    if (!lpBaseAddress || !lpBuffer || nSize == 0) return 0;
    if ((uintptr_t)lpBaseAddress < 0x10000ULL) return 0;

    struct iovec local_iov  = { .iov_base = lpBuffer,             .iov_len = nSize };
    struct iovec remote_iov = { .iov_base = (void*)lpBaseAddress, .iov_len = nSize };
    ssize_t n = process_vm_readv(getpid(), &local_iov, 1, &remote_iov, 1, 0);
    if (n <= 0) return 0;
    if (lpNumberOfBytesRead) *lpNumberOfBytesRead = (size_t)n;
    return ((size_t)n == nSize) ? 1 : 1; /* partial read up to page boundary mirrors RPM semantics */
}

/* Mock File Handle API for Handle-Leak Audit */
void gw_reset_handles(int64_t mock_file_sz) {
    g_open_handles   = 0;
    g_closed_handles = 0;
    g_mock_file_size = mock_file_sz;
}
int gw_get_open_handles(void)   { return g_open_handles; }
int gw_get_closed_handles(void) { return g_closed_handles; }

intptr_t mock_CreateFileW(const uint16_t* path, uint32_t acc, uint32_t share,
                          void* sa, uint32_t disp, uint32_t attr, void* tmpl) {
    (void)path; (void)acc; (void)share; (void)sa; (void)disp; (void)attr; (void)tmpl;
    g_open_handles++;
    return (intptr_t)(0x5000 + g_open_handles);
}

int32_t mock_GetFileSizeEx(intptr_t h, int64_t* sz_out) {
    if (h <= 0 || !sz_out) return 0;
    *sz_out = g_mock_file_size;
    return 1;
}

int32_t mock_ReadFile(intptr_t h, void* buf, uint32_t to_read, uint32_t* rd_out, void* ov) {
    (void)ov;
    if (h <= 0 || !buf || !rd_out) return 0;
    memset(buf, 0x41, to_read);
    *rd_out = to_read;
    return 1;
}

int32_t mock_CloseHandle(intptr_t h) {
    if (h > 0) g_closed_handles++;
    return 1;
}
