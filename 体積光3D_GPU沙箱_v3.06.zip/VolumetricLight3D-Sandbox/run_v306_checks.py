#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""体積光（3D）GPU 保真沙箱 — 便携自检套件（v3.06 配套）

在没有 AviUtl2 宿主的机器上（Windows / macOS / Linux）直接渲染 .obj2 脚本的
体积光效果并执行标准自检。用法：

    python run_v306_checks.py                    # 使用内置的 v3.06 脚本
    python run_v306_checks.py --script 别的.obj2  # 测试任意版本
    python run_v306_checks.py --width 1280 --height 720

自检项：
  [1] Verse1 子合成 · 手动指定图层4 · 仅真实3D遮光投影(m1)：frame_s=619 / frame=146 / scene_id=1
  [2] 遮蔽关闭参照渲染 + 阴影统计（bush 状填充率 ~0.6-0.8；>0.9 说明出现实心矩形）
  [3] v3.06 剪影审计回归：模拟真机「带效果加载返回不透明矩形」→ 应自动回退并标记 L4*
  [4] 受限宿主（_G.os=nil / _G.io=nil）初始化
"""
import argparse
import pathlib
import sys

import numpy as np
from PIL import Image

PKG = pathlib.Path(__file__).resolve().parent
sys.path.insert(0, str(PKG))

from sandbox_v2_fidelity import FidelityLayer, PersistentAviUtl2Session, VL3DBridgeMockHost  # noqa: E402
from generate_assets import make_plaster_bust_png, make_stained_glass_png  # noqa: E402

OUT = PKG / "outputs"
W, H = 640, 360
CAM = {"x": 0.0, "y": -40.0, "z": -1024.0, "tx": 0.0, "ty": 20.0, "tz": 0.0,
       "ux": 0.0, "uy": -1.0, "uz": 0.0, "rz": 0.0, "d": 1024.0}
PARAMS = {"src_layer": 2, "intensity": 150.0, "direction": 55.0, "pitch": 44.0,
          "occ_mode": 1, "occ_3d_mode": 0, "occ_target": 2, "occ_list": "4",
          "occ_strength": 100.0, "occ_soft": 8.0, "log_mode": True, "show_info": False}


def statue_layer(img, raw=None):
    return FidelityLayer(index=4, name="statue", x=0.0, y=-30.0, z=140.0, zoom=110.0,
                         alpha=1.0, image=img, raw_image=raw, kind_override="OTHER")


def render(script, tag, statue, occ_mode=1, restrict=False):
    br = VL3DBridgeMockHost(mode="v290_sdk_lock", scene_id=1)
    sess = PersistentAviUtl2Session(str(script), width=W, height=H,
                                    strict_getvalue=True, bridge=br)
    if restrict:
        sess.lua.execute("_G.os = nil; _G.io = nil")
    light = FidelityLayer(index=2, name="light", x=0.0, y=-100.0, z=333.0, zoom=435.0,
                          alpha=1.0, image=make_stained_glass_png(OUT / "stained_glass.png"),
                          kind_override="OTHER")
    res = sess.render_frame(params=dict(PARAMS, occ_mode=occ_mode), camera=CAM,
                            layers={2: light, 4: statue}, self_layer=10,
                            frame=146, totalframe=619, frame_s=619, scene_id=1)
    if res["error"] is not None:
        raise RuntimeError(f"{tag}: Lua error: {res['error']}")
    Image.fromarray(res["rgba8"]).save(OUT / f"{tag}.png")
    hud = next((l for l in res["logs"] if "遮蔽" in l or "遮挡" in l), "")
    stats = sess.lua.eval(
        "(function() local t=_G._VL3D_PERSIST_V280 and _G._VL3D_PERSIST_V280.occ_stats or {} "
        "local r={} for k,v in pairs(t) do r[k]=v end return r end)()")
    return res, hud, (dict(stats) if stats else {})


def main():
    global W, H
    ap = argparse.ArgumentParser(description="Volumetric Light (3D) sandbox self-check")
    ap.add_argument("--script", default=str(PKG / "Script" / "体積光（3D）.obj2"))
    ap.add_argument("--width", type=int, default=W)
    ap.add_argument("--height", type=int, default=H)
    args = ap.parse_args()
    W, H = args.width, args.height
    OUT.mkdir(parents=True, exist_ok=True)
    (PKG / "assets").mkdir(parents=True, exist_ok=True)
    script = pathlib.Path(args.script)
    print("=" * 62)
    print("体積光（3D）GPU 保真沙箱自检 / Volumetric Light (3D) sandbox check")
    print("=" * 62)
    print("script :", script)
    print("output :", OUT)

    bust = make_plaster_bust_png(PKG / "assets" / "plaster_bust.png")
    ok_all = True

    print("\n[1] Verse1 sub-scene, m1 manual L4 (frame_s=619, frame=146, scene_id=1)")
    r1, hud1, _ = render(script, "check1_verse1_m1", statue_layer(bust))
    print("    HUD :", hud1[:160])
    hit = "L4" in hud1 and "m1" in hud1
    print("    occlusion hit:", hit)
    ok_all &= hit

    print("\n[2] occlusion OFF reference + shadow statistics")
    r0, _, _ = render(script, "check2_noocc", statue_layer(bust), occ_mode=0)
    diff = np.clip(r0["rgba8"][..., :3].astype(np.int16) - r1["rgba8"][..., :3].astype(np.int16),
                   0, 255).sum(axis=2)
    ys, xs = np.nonzero(diff > 30)
    if len(xs):
        bw, bh = xs.max() - xs.min() + 1, ys.max() - ys.min() + 1
        fill = len(xs) / (bw * bh)
        print(f"    shadow bbox fill = {fill:.3f}  (bust-shaped ~0.6-0.8; solid rect > 0.9)")
        ok_all &= fill < 0.9
    else:
        print("    no visible shadow on screen")

    print("\n[3] v3.06 silhouette-audit regression (simulated broken fx-load)")
    opaque = np.full((512, 512, 4), 200, dtype=np.uint8)
    opaque[..., 3] = 255
    r3, hud3, s3 = render(script, "check3_fxfallback_sim", statue_layer(opaque, raw=bust))
    fell = s3.get("opaque_rect_fallback", 0) >= 1
    star = "L4*" in hud3
    d = int(np.abs(r3["rgba8"].astype(np.int16) - r1["rgba8"].astype(np.int16)).max())
    print("    HUD :", hud3[:160])
    print(f"    fallback fired: {fell} | L4* marker: {star} | vs healthy maxdiff: {d}")
    ok_all &= fell and star

    print("\n[4] restricted host (_G.os=nil, _G.io=nil)")
    r4, hud4, _ = render(script, "check4_restrict", statue_layer(bust), restrict=True)
    init_ok = any(("初期化完了" in l or "初始化完成" in l) for l in r4["logs"])
    print("    init-complete under os/io=nil:", init_ok)
    ok_all &= init_ok

    print("\n" + "=" * 62)
    print("RESULT:", "ALL CHECKS PASSED ^_^" if ok_all else "SOME CHECKS FAILED — see above")
    print("=" * 62)
    sys.exit(0 if ok_all else 1)


if __name__ == "__main__":
    main()
